<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2018-06-29 06:34:15 --> Severity: error --> Exception: Call to undefined method CI_Input::file() C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 538
ERROR - 2018-06-29 03:10:45 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 649
ERROR - 2018-06-29 03:10:48 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 649
ERROR - 2018-06-29 03:11:00 --> Severity: error --> Exception: syntax error, unexpected '$this' (T_VARIABLE), expecting function (T_FUNCTION) or const (T_CONST) C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 649
ERROR - 2018-06-29 03:12:52 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 541
ERROR - 2018-06-29 03:13:09 --> Severity: error --> Exception: syntax error, unexpected ')' C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 541
ERROR - 2018-06-29 03:13:16 --> 404 Page Not Found: Location/index
ERROR - 2018-06-29 03:13:27 --> 404 Page Not Found: Location/index
ERROR - 2018-06-29 03:18:38 --> 404 Page Not Found: Master_Home/image
ERROR - 2018-06-29 03:30:25 --> Severity: error --> Exception: syntax error, unexpected '$_FILES' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 4199
ERROR - 2018-06-29 03:30:27 --> Severity: error --> Exception: syntax error, unexpected '$_FILES' (T_VARIABLE), expecting ',' or ')' C:\xampp\htdocs\dmw\application\controllers\Master_Home.php 4199
ERROR - 2018-06-29 07:08:47 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:08:47 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:08:47 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:08:47 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:09:46 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:09:46 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:09:46 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:09:46 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:09:58 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:09:58 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:09:58 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:09:58 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:12:56 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:12:56 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:12:56 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:12:56 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:13:31 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:13:31 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:13:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:13:31 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:14:31 --> Severity: Warning --> strrpos() expects parameter 1 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1195
ERROR - 2018-06-29 07:14:31 --> Severity: Warning --> explode() expects parameter 2 to be string, array given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1028
ERROR - 2018-06-29 07:14:31 --> Severity: Warning --> count(): Parameter must be an array or an object that implements Countable C:\xampp\htdocs\dmw\system\libraries\Upload.php 1030
ERROR - 2018-06-29 07:14:31 --> Severity: Warning --> end() expects parameter 1 to be array, null given C:\xampp\htdocs\dmw\system\libraries\Upload.php 1035
ERROR - 2018-06-29 07:31:28 --> Query error: Unknown column 'img_name' in 'field list' - Invalid query: INSERT INTO `item_customer_details` (`item_id`, `name`, `hsn_code`, `img_name`, `part_no`, `status`, `df`, `created_at`) VALUES (3, '5', 'juiyytgg', 'Flaming_Rose.jpg', NULL, 0, 0, '2018-06-29 07:31:28')
ERROR - 2018-06-29 07:35:28 --> Query error: Unknown column 'img_name' in 'field list' - Invalid query: INSERT INTO `item_customer_details` (`item_id`, `name`, `hsn_code`, `img_name`, `part_no`, `status`, `df`, `created_at`) VALUES (4, '4', 'iiii', 'Flaming_Rose1.jpg', NULL, 0, 0, '2018-06-29 07:35:27')
ERROR - 2018-06-29 07:36:56 --> Query error: Column 'part_no' cannot be null - Invalid query: INSERT INTO `item_customer_details` (`item_id`, `name`, `hsn_code`, `img_name`, `part_no`, `status`, `df`, `created_at`) VALUES (5, '5', 'hhhhhhhh', 'Flaming_Rose2.jpg', NULL, 0, 0, '2018-06-29 07:36:56')
ERROR - 2018-06-29 10:04:46 --> Query error: Table 'dmw.location' doesn't exist - Invalid query: SELECT *
FROM `location`
WHERE `df` =0
ORDER BY `id` DESC
ERROR - 2018-06-29 10:14:29 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 119
ERROR - 2018-06-29 10:14:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 119
ERROR - 2018-06-29 10:17:51 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:18:30 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:18:38 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:18:45 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:19:10 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:20:27 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:20:32 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:20:54 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 10:21:42 --> Severity: Warning --> Invalid argument supplied for foreach() D:\xampp\htdocs\dmw\application\views\Master\Customer\View_Single_Customer.php 255
ERROR - 2018-06-29 08:15:56 --> 404 Page Not Found: Uploads/files
ERROR - 2018-06-29 08:15:56 --> 404 Page Not Found: Uploads/files
ERROR - 2018-06-29 08:15:56 --> 404 Page Not Found: Uploads/files
ERROR - 2018-06-29 11:51:31 --> Query error: Column 'description' cannot be null - Invalid query: INSERT INTO `item` (`name`, `code`, `uom`, `description`, `parent`, `cost_details`, `item_group`, `item_category`, `gst_applicable`, `item_type`, `levels`, `status`, `df`, `created_at`) VALUES ('sss', 'Perundurai Super Subsssss', 'Kg', NULL, '6', 'sss', '1', '2', '1', '2', 2, 0, 0, '2018-06-29 11:51:31')
