<?php

class common_model extends CI_Model {

    /**
     * Responsable for auto load the database
     * @return void
     */
    var $last_id = -1;

    public function __construct() {
        $this->load->database();
    }
    
    public function rawQuery($sql, $db = DB_COMMON) {
        if($db !=""){
            $db_sel=$this->load->database($db,true);
             $this->db=$db_sel;
            }
		$query = $this->db -> query($sql);
		return $query -> result();
	}

    function find_details($cond = "", $table, $select = "*", $order = "", $group = "", $limit = "",$db="") {
		if($db !=""){
        $db_query=$this->load->database($db,true);
       $this->db=$db_query;
        }
        $this->db->select($select);
        $this->db->from($table);
        if ($cond != "") {
            $this->db->where($cond);
        }
        if ($limit != "") {
            $this->db->limit($limit);
        }
        if ($group != "") {
            $this->db->group_by($group);
        }
        if ($order != "") {
            $this->db->order_by($order);
        }
        $query = $this->db->get()->result_array();
        
        
       
        return $query;
    }

    function insert_user($emp_name) {
        $insert_user_stored_proc = "CALL spInsEmp(?)";
        $data = array('emp_name' => $emp_name);
        $result = $this->db->query($insert_user_stored_proc, $data);
        if ($result !== NULL) {
            return TRUE;
        }
        return FALSE;
    }
    
    function availableUrl($host, $port=80, $timeout=10) { 
      $fp = fSockOpen($host, $port, $errno, $errstr, $timeout); 
      return $fp!=false;
    }

    function find_all_details($cond = "", $table = "", $select = "*", $order = "", $group = "", $limit = "",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->select($select);
        $this->db->from($table);
        if ($cond != "") {
            $this->db->where($cond);
        }
        if ($limit != "") {
            $this->db->limit($limit);
        }
        if ($group != "") {
            $this->db->group_by($group);
        }
        if ($order != "") {
            $this->db->order_by($order);
        } else {
            $this->db->order_by("id", "desc");
        }
        $query = $this->db->get();
        return $query->result_array();
    }

    function denomination($num) {
        $num1 = strlen($num);
        $amount = $num;
        if ($num1 > 5) {
            if ($num1 > 3) {
                $ss = substr($num, -3);
                $ss = "," . $ss;

                $num2 = substr($num, 0, $num1 - 3);
                $amount = $ss;
            }
            $num3 = strlen($num2);
            if ($num3 > 2) {
                $ss1 = substr($num2, -2);
                $ss1 = "," . $ss1;
                $num4 = substr($num, 0, $num3 - 2);
                $amount = $num4 . $ss1 . $amount;
            }
//echo $ss." v ".$num2." v ".$ss1." v ".$num4;
        } elseif ($num1 > 3) {
            $ss = substr($num, -3);
            $ss = "," . $ss;

            $num2 = substr($num, 0, $num1 - 3);
            $amount = $num2 . $ss;
        }
        return $amount;
    }

    function find_last_details($field, $value, $table,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->select('*');
        $this->db->from($table);
        if ($field != "") {
            if ($value != "") {
                $this->db->where($field, $value);
            }
        }
        $this->db->where("df", 0);
        $this->db->limit(1);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
        //print_r($this->db->last_query());
    }

    function find_details_with_limit($field, $value, $table, $limit_start, $limit_end,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->select('*');
        $this->db->from($table);
        if ($field != "") {
            if ($value != "") {
                $this->db->where($field, $value);
            }
        }
        $this->db->where("df", 0);
        $this->db->order_by("id", "desc");

        $this->db->limit($limit_start, $limit_end);
        $query = $this->db->get();

        //  print_r($this->db->last_query());


        return $query->result_array();
    }

    function find_user_details($field, $value, $table) {

        $this->db->select('*');
        $this->db->from($table);
        if ($field != "") {
            if ($value != "") {
                $this->db->where($field, $value);
            }
        }
        $this->db->where('verified', '1');
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
        // print_r($this->db->last_query());
    }

    function delete($field, $value, $table,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->where($field, $value);
        $this->db->delete($table);
    }

    function find_details_Asc($field, $value, $table) {

        $this->db->select('*');
        $this->db->from($table);
        if ($field != "") {
            if ($value != "") {
                $this->db->where($field, $value);
            }
        }
        $this->db->where("df", 0);
        $this->db->order_by("id", "asc");
        $query = $this->db->get();
        return $query->result_array();
        //print_r($this->db->last_query());
    }

    function find_details_two_field($field1, $field2, $value1, $value2, $table) {

        $this->db->select('*');
        $this->db->from($table);
        if ($field1 != "") {
            if ($value1 != "") {
                $this->db->where($field1, $value1);
            }
        }
        if ($field2 != "") {
            if ($value2 != "") {
                $this->db->where($field2, $value2);
            }
        }
        $this->db->where("df", 0);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        //   print_r($this->db->last_query());
        return $query->result_array();
    }

    function find_details_two_field_with_cond($field1, $field2, $value1, $value2, $table, $cond) {

        $this->db->select('*');
        $this->db->from($table);
        if ($field1 != "") {
            if ($value1 != "") {
                $this->db->where($field1, $value1);
            }
        }
        if ($field2 != "") {
            if ($value2 != "") {
                $this->db->where($field2, $value2);
            }
        }
        $this->db->where("df", 0);
        if ($cond != "") {
            $this->db->where($cond);
        }
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        //   print_r($this->db->last_query());
        return $query->result_array();
    }

    function find_users($field, $value, $table) {

        $this->db->select('activate,email,id,phone_no,profile_img,user_name,verified');
        $this->db->from($table);
        if ($field != "") {
            if ($value != "") {
                $this->db->where($field, $value);
            }
        }
        $this->db->where("df", 0);
        $this->db->order_by("id", "desc");
        $query = $this->db->get();
        return $query->result_array();
        //print_r($this->db->last_query());
    }

    function getDetailsByConditions($field, $table) {
        $this->db->select('*');
        $this->db->from($table);
        if ($field != "") {
            $this->db->where($field);
        }
        $this->db->where("df", 0);
        $query = $this->db->get();
        return $query->result_array();
    }
	
	public function getMenuSettings($id){
		$security_level_url = array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
		$returndata = array("LevelNo" => 0, "url" => "");
		$this->db->select('*');
		$this->db->from("tbl_menu_security_setting");
		$this->db->where("menu_id = '".$id."'");
			$this->db->limit(1);

			$query = $this->db->get();

			if ($query -> num_rows() == 1) {
				$result = $query -> row();
				
				$returndata["LevelNo"] = $result->security_level;
				$returndata["url"] = $security_level_url[$result->security_level];
				return $returndata;
			} else {
				return false;
			}
		
	}
	
	public function get($tablename,$id,$db = "default") {
		$db_sel = $this->load->database($db, TRUE);
		$condition = "id =" . "'" . $id . "'";
		$db_sel -> select('*');
		$db_sel -> from($tablename);
		$db_sel -> where($condition);
		$db_sel -> limit(1);
		$query = $db_sel -> get();

		if ($query -> num_rows() == 1) {
			return $query -> row();
		} else {
			return false;
		}
	}
	
	
	public function getbyCondition($tablename,$condition = "",$limit = false,$orderField = "id", $orderby = 'desc',$db = "default"){
		$db_sel = $this->load->database($db, TRUE);
		$db_sel -> select('*');
		$db_sel -> from($tablename);
		if($condition != ""){
			$db_sel -> where($condition);
		}
		if ($limit) {
			$db_sel -> limit(1);

			$query = $db_sel -> get();

			if ($query -> num_rows() == 1) {
				return $query -> row();
			} else {
				return false;
			}
		} else {
			$query = $db_sel -> get();
			return $query -> result();
		}
	}

    public function find_single_value($field, $value, $table, $fetch_data, $cond = "",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        if ($cond == "") {
            $cond = array(
                $field => $value
            );
        }
        $singleRec = $this->find_details($cond, $table);
        $cat = "";
        foreach ($singleRec as $users) {
            $cat = $users[$fetch_data];
        }
        return $cat;
    }

    public function find_last_insert_id($table,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->select('*');
        $this->db->order_by('id', "desc");
        $this->db->limit(1);
        $query = $this->db->get($table);
        return $query->result_array();
    }

    public function find_insert_id() {
        return $this->last_id;
    }

    function store_details($data, $table,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
             $this->db=$db_query;
            }
        $insert = $this->db->insert($table, $data);
        return $this->db->insert_id();
    }

    function update_details($field, $value, $data_to_store, $table,$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->where($field, $value);
        $update = $this->db->update($table, $data_to_store);
        return $update;
    }

    function update_cond_details($cond, $data_to_store, $table,$db="") {
            if($db !=""){
            $db_query=$this->load->database($db,true);
             $this->db=$db_query;
            }

        $this->db->where($cond);
        $update = $this->db->update($table, $data_to_store);
        return $update;
    }

    function update_notification_details($field, $value, $field1, $value1, $field2, $value2, $data_to_store, $table) {
        if ($field != "" && $value != "") {
            $this->db->where($field, $value);
        }
        if ($field1 != "" && $value1 != "") {
            $this->db->where($field1, $value1);
        }
        if ($field2 != "" && $value2 != "") {
            $this->db->where($field2, $value2);
        }

        $update = $this->db->update($table, $data_to_store);
        return $update;
    }

    function delete_details($field, $value, $table, $data_to_store = "") {
        if ($field != "" && $value != "") {
            $this->db->where($field, $value);
            $delete = $this->db->delete($table);
            return $delete;
        }
    }

    function delete_cond_details($cond, $table, $data = "",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
             $this->db=$db_query;
            }
        if ($cond != "") {
            $this->db->where($cond);
            $delete = $this->db->delete($table);
            return $delete;
        }
    }

    function convert_digit_to_words($no) {

        //creating array  of word for each digit
        $words = array('0' => 'Zero', '1' => 'one', '2' => 'two', '3' => 'three', '4' => 'four', '5' => 'five', '6' => 'six', '7' => 'seven', '8' => 'eight', '9' => 'nine', '10' => 'ten', '11' => 'eleven', '12' => 'twelve', '13' => 'thirteen', '14' => 'fourteen', '15' => 'fifteen', '16' => 'sixteen', '17' => 'seventeen', '18' => 'eighteen', '19' => 'nineteen', '20' => 'twenty', '30' => 'thirty', '40' => 'forty', '50' => 'fifty', '60' => 'sixty', '70' => 'seventy', '80' => 'eighty', '90' => 'ninty', '100' => 'hundred', '1000' => 'thousand', '100000' => 'lakh', '10000000' => 'crore');
        //$words = array('0'=> '0' ,'1'=> '1' ,'2'=> '2' ,'3' => '3','4' => '4','5' => '5','6' => '6','7' => '7','8' => '8','9' => '9','10' => '10','11' => '11','12' => '12','13' => '13','14' => '14','15' => '15','16' => '16','17' => '17','18' => '18','19' => '19','20' => '20','30' => '30','40' => '40','50' => '50','60' => '60','70' => '70','80' => '80','90' => '90','100' => '100','1000' => '1000','100000' => '100000','10000000' => '10000000');
        //for decimal number taking decimal part

        $cash = (int) $no;  //take number wihout decimal
        $decpart = $no - $cash; //get decimal part of number

        $decpart = sprintf("%01.2f", $decpart); //take only two digit after decimal

        $decpart1 = substr($decpart, 2, 1); //take first digit after decimal
        $decpart2 = substr($decpart, 3, 1);   //take second digit after decimal  

        $decimalstr = '';

        //if given no. is decimal than  preparing string for decimal digit's word

        if ($decpart > 0) {
            $decimalstr .= "point " . $numbers[$decpart1] . " " . $numbers[$decpart2];
        }

        if ($no == 0)
            return ' ';
        else {
            $novalue = '';
            $highno = $no;
            $remainno = 0;
            $value = 100;
            $value1 = 1000;
            while ($no >= 100) {
                if (($value <= $no) && ($no < $value1)) {
                    $novalue = $words["$value"];
                    $highno = (int) ($no / $value);
                    $remainno = $no % $value;
                    break;
                }
                $value = $value1;
                $value1 = $value * 100;
            }
            if (array_key_exists("$highno", $words))  //check if $high value is in $words array
                return $words["$highno"] . " " . $novalue . " " . $this->convert_digit_to_words($remainno) . $decimalstr;  //recursion
            else {
                $unit = $highno % 10;
                $ten = (int) ($highno / 10) * 10;
                return $words["$ten"] . " " . $words["$unit"] . " " . $novalue . " " . $this->convert_digit_to_words($remainno
                        ) . $decimalstr; //recursion
            }
        }
    }

    function find_station_details($where = "", $cond = "") {
        $this->db->select('tbldivisionmaster.DivisionID, tbldivisionmaster.RailwayID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->where("tblstationmaster.RecordStatus", 1);
        if($cond!="")
        {
            $this->db->where($cond);
        }
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblstationmaster.RailwayID' .' AND tbldivisionmaster.DivisionID=' . 'tblstationmaster.DivisionID');
        $query = $this->db->get('tblstationmaster');
        return $query->result_array();
    }

    function find_division_details($cond = "") {
        $this->db->select('tbldivisionmaster.DivisionID AS did, tbldivisionmaster.RailwayID AS rid, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
         $this->db->select('tblrailwaymaster.RailwayName, tblrailwaymaster.RailwayCode');
         $this->db->select("tblserveripdivisionwise.*");
        if($cond!="")
        {
            $this->db->where($cond);
        }
        $this->db->join('tbldivisionmaster', 'tblrailwaymaster.RailwayID=' . 'tbldivisionmaster.RailwayID');  

        $this->db->join('tblserveripdivisionwise', 'tblserveripdivisionwise.DivisionID=' . 'tbldivisionmaster.DivisionID' .' AND tblserveripdivisionwise.RailwayID=' . 'tbldivisionmaster.RailwayID', 'LEFT');

        $query = $this->db->get('tblrailwaymaster');
        return $query->result_array();
    }

    function find_level_details($where = "") {
        $this->db->select('tbllevelmaster.*');
        $this->db->join('tbluserrolemaster', 'tbluserrolemaster.LevelID=' . 'tbllevelmaster.LevelID');
        $this->db->group_by("tbllevelmaster.LevelID");
        $query = $this->db->get('tbllevelmaster');
        return $query->result_array();
    }

    function find_designation_details($where = "") {
        $this->db->select('tbldesignationmaster.*');
        $this->db->join('tbluserrolemaster', 'tbluserrolemaster.DesignationID=' . 'tbldesignationmaster.DesignationID');
        $this->db->group_by("tbldesignationmaster.DesignationID");
        $query = $this->db->get('tbldesignationmaster');
        return $query->result_array();
    }

    function find_user_rights_details($where = "") {
        $this->db->select('tbllevelmaster.LevelName, tbldesignationmaster.DesignationName');
        $this->db->select('tbluserrolemaster.*');
        $this->db->where("tbluserrolemaster.RecordStatus", 1);
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->join('tbldesignationmaster', 'tbldesignationmaster.DesignationID=' . 'tbluserrolemaster.DesignationID');
        $this->db->join('tbllevelmaster', 'tbllevelmaster.LevelID=' . 'tbluserrolemaster.LevelID');
        $query = $this->db->get('tbluserrolemaster');
        return $query->result_array();
    }
    
     function find_userloggedindetails($where = "") {
        $this->db->select('DATE_FORMAT(tbluserloggedindetails.InTime,"%d-%m-%Y %T") InTime, tbluserloggedindetails.UserID, tbllevelmaster.LevelName, tblusermaster.EmployeeName, tblusermaster.LoginName, tbldesignationmaster.DesignationName');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->join('tblusermaster', 'tblusermaster.UserID=' . 'tbluserloggedindetails.UserID');
        $this->db->join('tbldesignationmaster', 'tbldesignationmaster.DesignationID=' . 'tblusermaster.DesignationID');
        $this->db->join('tbllevelmaster', 'tbllevelmaster.LevelID=' . 'tblusermaster.LevelID');
        $query = $this->db->get('tbluserloggedindetails');
        return $query->result_array();
    }
    
    
    

    function find_version_logic_details($where = "",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
          $this->db=$db_query;
            }
        $this->db->select('tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select('tblversiondefine.*');
        $this->db->select('tblversiondefine.*');
        $this->db->where("tblversiondefine.RecordStatus", 1);
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
        $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->group_by('tblversiondefine.ID');
        $query = $this->db->get('tblversiondefine');
        return $query->result_array();
    }

	function find_version_details_latest_new($zone ="", $division = "", $station = "",$db=""){
        if($db !=""){
            $db_query=$this->load->database($db,true);
          $this->db=$db_query;
            }

		$this->db->select('tblversiondefine.VersionNO, tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select("tblversiondefine.*");
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
         $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
         
         if($zone != "" && $division != "" && $station != ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' and tblstationmaster.StationID = '".$station."' ";
}

else if($zone != "" && $division == "" && $station != ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tblstationmaster.StationID = '".$station."' ";
}

else if($zone == "" && $division == "" && $station != ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblstationmaster.StationID = '".$station."' ";
}


else if($zone != "" && $division != "" && $station == ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' ";
}


else if($zone != "" && $division == "" && $station == ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' ";
}

else if($zone == "" && $division == "" && $station == ""){ 
    $cond = "tblversiondefine.CreatedOn in (select max(CreatedOn) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1  ";
}

        $this->db->where($cond); 
        
        $query = $this->db->get('tblversiondefine');
        
        //print_r($this->db->last_query()); 
        return $query->result_array();
	}
	
		function find_version_details_latest($zone ="", $division = "", $station = "",$db=""){
        if($db !=""){
            $db_query=$this->load->database($db,true);
          $this->db=$db_query;
            }

		$this->db->select('tblversiondefine.VersionNO, tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select("tblversiondefine.*");
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
         $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
         
         if($zone != "" && $division != "" && $station != ""){ 
    
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' and tblstationmaster.StationID = '".$station."' ";
}

else if($zone != "" && $division == "" && $station != ""){ 
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tblstationmaster.StationID = '".$station."' ";
}

else if($zone == "" && $division == "" && $station != ""){ 
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblstationmaster.StationID = '".$station."' ";
}


else if($zone != "" && $division != "" && $station == ""){ 
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' ";
}


else if($zone != "" && $division == "" && $station == ""){ 
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' ";
}

else if($zone == "" && $division == "" && $station == ""){ 
    $cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1  ";
}

		 //if($zone == "" && $division == "" && $station == ""){
		 //$cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by StationID) and tblversiondefine.RecordStatus=1";
		 //} 
		/*if($zone != "" && $division == "" && $station == ""){
		 	$cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' ";
		 }
		 else if($zone != "" && $division != "" && $station == ""){
		 	$cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' ";
		 }else{
		 	$cond = "tblversiondefine.id in (select max(id) from tblversiondefine group by RailwayID, DivisionID, StationID, VendorID) and tblversiondefine.RecordStatus=1 and tblrailwaymaster.RailwayID = '".$zone."' and tbldivisionmaster.DivisionID = '".$division."' and tblstationmaster.StationID = '".$station."' ";
		 }*/
		 
        $this->db->where($cond);
        
        $query = $this->db->get('tblversiondefine');
        
        //print_r($this->db->last_query());
        return $query->result_array();
	}
	
	//Version History
	function find_version_history($zone ="", $division = "", $station = ""){
        if($db !=""){
            $db_query=$this->load->database($db,true);
          $this->db=$db_query;
            }
		$this->db->select('tblversiondefine.VersionNO, tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select("tblversiondefine.*");
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
         $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
		
		$cond = "tblversiondefine.RecordStatus=1 and tblversiondefine.DivisionID = '".$division."' and tblversiondefine.RailwayID = '".$zone."' and tblversiondefine.StationID = '".$station."' ";
		 
		 
        $this->db->where($cond);
        
        $query = $this->db->get('tblversiondefine');
        
        //print_r($this->db->last_query());
        return $query->result_array();
	}

    function find_version_details($where = "", $select = "tblversiondefine.*",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
          $this->db=$db_query;
            }
            if($select != ""){
                $select=$select;
            }else{
                $select = "tblversiondefine.*";
            }
        $this->db->select('tblversiondefine.VersionNO, tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select($select);
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
         $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
        if ($where != "") {
            $this->db->where($where);
        } else {
            $this->db->where('tblversiondefine.SignalPlanNumber !=', "");
        }
        $this->db->group_by('tblversiondefine.ID');
        $query = $this->db->get('tblversiondefine');
        
        //print_r($this->db->last_query());
        return $query->result_array();
    }

    function find_user_master_details($where = "") {
        $this->db->select('tblusermaster.LoginName,tblusermaster.LoginPassword, tblusermaster.EmployeeName,tblusermaster.CreatedOn, tblusermaster.ModifiedOn, tblusermaster.CreatedBy,  tblusermaster.ModifiedBy, tblusermaster.UserStatus, tblusermaster.UserRole, tblusermaster.IsAdmin, tblusermaster.DesignationID, tblusermaster.LevelID, tblusermaster.UserID');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tbldesignationmaster.DesignationName');
        $this->db->select('tbllevelmaster.LevelName');
        $this->db->join('tbldesignationmaster', 'tbldesignationmaster.DesignationID=' . 'tblusermaster.DesignationID');
        $this->db->join('tbllevelmaster', 'tbllevelmaster.LevelID=' . 'tblusermaster.LevelID');
       $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblusermaster.RailwayID AND tblstationmaster.DivisionID=' . 'tblusermaster.DivisionID AND tblstationmaster.StationID=' . 'tblusermaster.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblusermaster.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblusermaster.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblusermaster.RailwayID');
         if ($where != "") {
            $this->db->where($where);
        }
        $this->db->group_by('tblusermaster.UserID');
        $query = $this->db->get('tblusermaster');
        return $query->result_array();
    }

    function find_version_logic_details_with_main($where = "",$db="") {
        if($db !=""){
            $db_query=$this->load->database($db,true);
           $this->db=$db_query;
            }
        $this->db->select('*');
        $this->db->order_by('VersionID', 'Desc');
        $this->db->limit('1');
        if ($where != "") {
            $this->db->where($where);
        }
        $query = $this->db->get('tblversiondefine')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('*');
            $this->db->where("RailwayID", $val['RailwayID']);
            $this->db->where("DivisionID", $val['DivisionID']);
            $this->db->where("VendorID", $val['VendorID']);
            $this->db->where("StationID", $val['StationID']);
            $this->db->where("VersionID", $val['VersionID']);
            $query[$i]['cpu_det'] = $this->db->get('tbl_versionsubcpu')->result_array();
            $i++;
        }
        return $query;
    }

    function find_dashboard_det($query){
        $qout = $this->db->query($query);
        return $qout->result_array();
    }

    function find_dashboard_details($where = "", $query = "", $query_select="", $query_2 = "") {
        if($query!="")
        {
            $query_ot = $this->db->query($query);
        }
        $query_output = $this->db->query($query_select);
        if($query_2!="")
        {
            $query_output = $this->db->query($query_2);
        }
       // print_r($this->db->last_query());
        return $query_output->result_array();
    }
    function find_join_query($where = "") {
        $this->db->select('tbldivisionmaster.DivisionID, tbldivisionmaster.DivisionCode, tbldivisionmaster.DivisionName');
        $this->db->select('tblrailwaymaster.RailwayID, tblrailwaymaster.RailwayCode, tblrailwaymaster.RailwayName');
        $this->db->select('tblstationmaster.StationID,tblstationmaster.StationCode, tblstationmaster.StationName');
        $this->db->select('tblvendormaster.VendorID, tblvendormaster.VendorName');
        $this->db->select('tblversiondefine.VersionID');
        $this->db->where("tblversiondefine.RecordStatus", 1);
        $this->db->join('tblstationmaster', 'tblstationmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tblstationmaster.DivisionID=' . 'tblversiondefine.DivisionID AND tblstationmaster.StationID=' . 'tblversiondefine.StationID');
        $this->db->join('tbldivisionmaster', 'tbldivisionmaster.RailwayID=' . 'tblversiondefine.RailwayID AND tbldivisionmaster.DivisionID=' . 'tblversiondefine.DivisionID');
        $this->db->join('tblrailwaymaster', 'tblrailwaymaster.RailwayID=' . 'tblversiondefine.RailwayID');
         $this->db->join('tblvendormaster', 'tblvendormaster.VendorID=' . 'tblversiondefine.VendorID');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->group_by('tblversiondefine.RailwayID, tblversiondefine.DivisionID, tblversiondefine.StationID, tblversiondefine.VendorID');
        $query = $this->db->get('tblversiondefine');
        //print_r($this->db->last_query());
        return $query->result_array();
    }

    function find_customer_details($where = "") {
        $this->db->select('*,customer.id as customer_id,customer.name as customer_name,customer.code as customer_code');
        $this->db->select('location.name as location_name');
        $this->db->join('location', 'location.id=' . 'customer.location');

        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("customer_category.df", 0);
        $this->db->where("customer_reporting_group.df", 0);
        $this->db->where("customer.df", 0);
        $this->db->select('customer_reporting_group.name as customer_reporting_group_name');
        $this->db->join('customer_reporting_group', 'customer_reporting_group.id=' . 'customer.customer_reporting_group');
        $this->db->select('country.name as country_name');
        $this->db->join('country', 'country.id=' . 'customer.country');
        $this->db->select('state.name as state_name');
        $this->db->join('state', 'state.id=' . 'customer.state');
        $this->db->select('city.name as city_name');
        $this->db->join('city', 'city.id=' . 'customer.city');
        $this->db->select('customer_category.name as customer_category_name');
        $this->db->join('customer_category', 'customer_category.id=' . 'customer.customer_category');
        $this->db->select('user_type.user_type as user_type_name');
        $this->db->join('user_type', 'user_type.id=' . 'customer.user_type');
        $query = $this->db->get('customer');
        return $query->result_array();
    }

    function find_operation_name_details() {
        $this->db->select('operation_name.*,operation_name.id as operation_name_id');
        $this->db->where('operation_name.status', 0);
        $this->db->select('location.name as location_name');
        $this->db->join('location', 'location.id=' . 'operation_name.location');
        $this->db->select('asset.name as asset_name');
        $this->db->join('asset', 'asset.id=' . 'operation_name.asset');
        $this->db->select('time.time as time_name');
        $this->db->join('time', 'time.id=' . 'operation_name.time');
        $this->db->where("time.df", 0);
        $this->db->where("asset.df", 0);
        $this->db->where("location.df", 0);
        $this->db->where("operation_name.df", 0);
        $query = $this->db->get('operation_name');
        return $query->result_array();
    }

    function find_details_break($field, $value, $table) {


        if ($field != "") {
            if ($value != "") {
                $this->db->select('*');
                $this->db->select('shift.Name as shift_name');
                $this->db->select('shift.Code as shift_code');
                $this->db->order_by('shift_break.id', 'Desc');
                $this->db->join('shift', 'shift.id=' . 'shift_break.shift_primary_id');
                $this->db->where($field, $value);
            }
        }
        $this->db->where("shift_break.df", 0);
        $query = $this->db->get('shift_break');
        return $query->result_array();
        //print_r($this->db->last_query());
    }

    function find_item_details($where = "") {
        $this->db->select('item.*,item.id as item_id');
        $this->db->where('item.status', 0);
        $this->db->where('item.df', 0);
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->select('item_group.name as item_group_name');
        $this->db->join('item_group', 'item_group.id=' . 'item.item_group');
        $this->db->select('item_category.name as item_category_name');
        $this->db->join('item_category', 'item_category.id=' . 'item.item_category');
        $this->db->where("item_category.df", 0);
        $this->db->where("item_group.df", 0);
        $query = $this->db->get('item')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('item_customer_details.*,item_customer_details.id as item_customer_details_id');
            $this->db->where('item_customer_details.item_id', $val['item_id']);
            $this->db->select('customer.name as customer_name');
            $this->db->join('customer', 'customer.id=' . 'item_customer_details.name');
            $this->db->where("item_customer_details.df", 0);
            $this->db->where("customer.df", 0);
            $query[$i]['item_customer_details'] = $this->db->get('item_customer_details')->result_array();
            $i++;
        }
        return $query;
    }

    function find_employee_details($where = "") {
        $this->db->select('employee.*,employee.id as employee_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->select('employee_group.name as employee_group_name');
        $this->db->join('employee_group', 'employee_group.id=' . 'employee.group');
        $this->db->select('employee_category.name as employee_category_name');
        $this->db->join('employee_category', 'employee_category.id=' . 'employee.category');
        $this->db->select('department.name as department_name');
        $this->db->join('department', 'department.id=' . 'employee.department');
        $this->db->select('emp_user_type.name as emp_user_type_name');
        $this->db->join('emp_user_type', 'emp_user_type.id=' . 'employee.emp_user_type');
        $this->db->select('location.name as location_name');
        $this->db->join('location', 'location.id=' . 'employee.location');
        $this->db->select('asset.name as asset_name');
        $this->db->join('asset', 'asset.id=' . 'employee.cost_centre');
        $this->db->where("employee_group.df", 0);
        $this->db->where("employee_category.df", 0);
        $this->db->where("department.df", 0);
        $this->db->where("emp_user_type.df", 0);
        $this->db->where("asset.df", 0);
        $this->db->where("location.df", 0);
        $this->db->where("employee.df", 0);
        $query = $this->db->get('employee');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function checkArrayRecursively($arr, $table, $levels = "", $set_value = "") {
        $levels = $levels;
        $set_value = $set_value;
        if ($arr) {
            $arr_new = $this->common_model->find_details("parent", $arr['id'], $table);
            foreach ($arr_new as $value) {
                if (is_array($value)) {
                    $option_val = "";
                    for ($i = 1; $i < $value['levels']; $i++) {
                        $option_val .= "|-----";
                    }
                    echo "<option value='" . $value['id'] . "' " . set_select($set_value, $value['id'], False) . ">" . $option_val . $value['code'] . " / " . $value['name'] . $levels . "</option>";
                    $this->checkArrayRecursively($value, $table, $levels, $set_value);
                }
            }
        }
    }

    public function checkArrayRecursively1($arr, $table, $levels = "", $set_value = "") {
        $levels = $levels;
        $set_value = $set_value;
        if ($arr) {
            $arr_new = $this->common_model->find_details("parent", $arr['id'], $table);
            foreach ($arr_new as $value) {
                if (is_array($value)) {
                    $option_val = "";
                    for ($i = 1; $i < $value['levels']; $i++) {
                        $option_val .= "|-----";
                    }

                    if ($value['id'] == $set_value) {
                        $selected_text = "selected";
                    } else {
                        $selected_text = "";
                    }
                    echo "<option value='" . $value['id'] . "' " . $selected_text . ">" . $option_val . $value['code'] . " / " . $value['name'] . $levels . "</option>";
                    $this->checkArrayRecursively1($value, $table, $levels, $set_value);
                }
            }
        }
    }

    public function checkUpdateArrayRecursively($arr, $table, $id, $levels = "") {
        $levels = $levels;
        if ($arr) {
            $cond = array(
                "parent" => $arr['id'],
                "levels<" => $levels,
            );
            $arr_new = $this->common_model->find_all_details($cond, $table);
            foreach ($arr_new as $value) {
                if (is_array($value)) {
                    $option_val = "";
                    for ($i = 1; $i < $value['levels']; $i++) {
                        $option_val .= "|-----";
                    }
                    if ($id == $value['id']) {
                        $selected_text = "selected";
                    } else {
                        $selected_text = "";
                    }
                    echo "<option value='" . $value['id'] . "' " . $selected_text . ">" . $option_val . $value['name'] . " / " . $value['name'] . "</option>";
                    $this->checkUpdateArrayRecursively($value, $table, $id, $levels);
                }
            }
        }
    }

    public function updateLevelRecursively($arr, $table) {
        if ($arr) {
            $cond = array(
                "parent" => $arr['id'],
            );
            $arr_new = $this->find_all_details($cond, $table);
            foreach ($arr_new as $rows) {
                if (is_array($rows)) {
                    $U_Level_Id = $rows['levels'] + 1;
                    $value = $rows['id'];
                    $data_to_store = array(
                        "levels" => $U_Level_Id,
                        "parent" => $arr['id']
                    );
                    $this->update_details("id", $value, $data_to_store, "location");
                    $this->updateLevelRecursively($rows, $table);
                }
            }
        }
    }

    public function cycle_time_det($where = "") {
        $this->db->select('cycle_time.*,cycle_time.id as cycle_time_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->select('location.name as location_name,location.code as location_code');
        $this->db->join('location', 'location.id=' . 'cycle_time.location');
        $this->db->select('asset.name as asset_name,asset.code as asset_code');
        $this->db->join('asset', 'asset.id=' . 'cycle_time.machine_code');
        $this->db->select('item.name as item_name,item.code as item_code_val');
        $this->db->join('item', 'item.id=' . 'cycle_time.item_code');
        $this->db->where("cycle_time.df", 0);
        $this->db->where("location.df", 0);
        $this->db->where("asset.df", 0);
        $this->db->where("item.df", 0);
        $query = $this->db->get('cycle_time');
        //echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function defect_category_details($where = "") {
        $this->db->select('defect_category.*,defect_category.id as defect_category_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->select('defect_type.name as defect_type_name');
        $this->db->join('defect_type', 'defect_type.id=' . 'defect_category.defect_type');
        $this->db->where("defect_type.df", 0);
        $this->db->where("defect_category.df", 0);
        $query = $this->db->get('defect_category');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function item_details($where = "") {
        $this->db->select('item.*,item.id as item_id_val');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("item.df", 0);
        $query = $this->db->get('item')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('item_customer_details.*,item_customer_details.id as item_customer_details_id');
            $this->db->where('item_customer_details.item_id', $val['item_id_val']);
            $this->db->select('customer.name as customer_name');
            $this->db->join('customer', 'customer.id=' . 'item_customer_details.name');
            $this->db->where("item_customer_details.df", 0);
            $this->db->where("customer.df", 0);
            $query[$i]['item_customer_details'] = $this->db->get('item_customer_details')->result_array();
            $i++;
        }
        return $query;
    }

    public function shift_details($where = "") {
        $this->db->select('shift.*,shift.id as shift_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("shift.df", 0);
        $query = $this->db->get('shift')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('shift_break.*');
            $this->db->where('shift_break.shift_primary_id', $val['shift_id']);
            $this->db->where("shift_break.df", 0);
            $query[$i]['shift_break'] = $this->db->get('shift_break')->result_array();
            $i++;
        }
        return $query;
    }

    /* public function daily_production_details($value) {
      $this->db->select('daily_production_details.*,shift.name as shift_name,location.name as location_name,cycle_time.operation_code as operation_code_name,item.name as item_name');
      $this->db->where("daily_production_details.id", $value);
      $this->db->join('shift', 'shift.id=' . 'daily_production_details.shift');
      $this->db->join('location', 'location.id=' . 'daily_production_details.location');
      $this->db->join('cycle_time', 'cycle_time.id=' . 'daily_production_details.operation_code');
      $this->db->join('item', 'item.id=' . 'daily_production_details.item');
      $query = $this->db->get('daily_production_details')->result_array();
      return $query;
      }

      public function daily_production_downtime_details($value) {
      $this->db->select('daily_production_downtime_details.*');
      $this->db->where("daily_production_downtime_details.daily_production_id", $value);
      $this->db->select('down_time.*,down_time.name as down_time_name');
      $this->db->join('down_time', 'down_time.id=' . 'daily_production_downtime_details.title');
      $query = $this->db->get('daily_production_downtime_details')->result_array();
      return $query;
      }

      public function daily_production_defect_details($value) {
      $this->db->select('daily_production_defect_details.*,defect_type.name as defect_type_name,defect_category.name as defect_category_name');
      $this->db->where("daily_production_defect_details.daily_production_id", $value);
      $this->db->join('defect_type', 'defect_type.id=' . 'daily_production_defect_details.defect_type');
      $this->db->join('defect_category', 'defect_category.id=' . 'daily_production_defect_details.defect_category');
      $query = $this->db->get('daily_production_defect_details')->result_array();
      return $query;
      } */

    public function daily_production_details($value) {
        $this->db->select('daily_production_details.*,shift.name as shift_name');
        $this->db->where("daily_production_details.id", $value);
        $this->db->join('shift', 'shift.id=' . 'daily_production_details.shift');
        $query = $this->db->get('daily_production_details')->result_array();
        return $query;
    }

    public function daily_production_downtime_details($value) {
        $this->db->select('daily_production_downtime_details.*,sum(daily_production_downtime_details.value) as total_value,sum(daily_production_downtime_details.total_minitues) as total_minitues_value');
        $this->db->where("daily_production_downtime_details.daily_production_id", $value);
        $this->db->select('down_time.*,down_time.name as down_time_name');
        $this->db->join('down_time', 'down_time.id=' . 'daily_production_downtime_details.title');
        $this->db->group_by("daily_production_downtime_details.title");
        $query = $this->db->get('daily_production_downtime_details')->result_array();
        return $query;
    }

    public function daily_production_quantity_details($value) {
        $this->db->select('daily_production_quantity_details.*');
        $this->db->where("daily_production_quantity_details.daily_production_id", $value);
        $this->db->select('asset.name as asset_name');
        $this->db->join('asset', 'asset.id=' . 'daily_production_quantity_details.cost_center');
        $this->db->select('item.name as item_name');
        $this->db->join('item', 'item.id=' . 'daily_production_quantity_details.item');

        $this->db->select('cycle_time.operation_code as operation_code_val');
        $this->db->join('cycle_time', 'cycle_time.id=' . 'daily_production_quantity_details.operation_code');


        $query = $this->db->get('daily_production_quantity_details')->result_array();
        return $query;
    }

    public function daily_production_defect_details($value) {
        $this->db->select('daily_production_defect_details.*,defect_type.name as defect_type_name,defect_category.name as defect_category_name');
        $this->db->where("daily_production_defect_details.daily_production_id", $value);
        $this->db->join('defect_type', 'defect_type.id=' . 'daily_production_defect_details.defect_type');
        $this->db->join('defect_category', 'defect_category.id=' . 'daily_production_defect_details.defect_category');
        $query = $this->db->get('daily_production_defect_details')->result_array();
        return $query;
    }

    public function customer_category_details($where = "") {
        $this->db->select('customer_category.*');

        $query = $this->db->get('customer_category')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('customer_category.name as customer_category_name');
            $this->db->where('customer_category.parent', $val['id']);
            $this->db->where("customer_category.df", 0);
            $query[$i]['customer_category'] = $this->db->get('customer_category')->result_array();
            $i++;
        }

        return $query;
    }

    public function service_request_category_details($where = "") {
        $this->db->select('service_request_category.*,service_request_category.id as service_request_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("service_request_category.df", 0);
        $this->db->select('default_criticality.name as criticality_name');
        $this->db->join('default_criticality', 'default_criticality.id=' . 'service_request_category.default_criticality');
        $this->db->where("default_criticality.df", 0);
        $this->db->select('department.name as department_name');
        $this->db->join('department', 'department.id=' . 'service_request_category.department');
        $this->db->where("department.df", 0);
        $query = $this->db->get('service_request_category')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('notification_role.*,notification_role.id as notification_role_id');
            $this->db->where('notification_role.service_request_id', $val['id']);
            $this->db->where('notification_role.df', 0);
            $this->db->select('employee_role.name as role_name');
            $this->db->join('employee_role', 'employee_role.id=' . 'notification_role.multiple_role_notification');
            $this->db->where("employee_role.df", 0);
            $this->db->select('location.name as location_name');
            $this->db->join('location', 'location.id=' . 'notification_role.location');
            $this->db->where("location.df", 0);
            $this->db->select('default_criticality.name as criticality_name');
            $this->db->join('default_criticality', 'default_criticality.id=' . 'notification_role.criticality');
            $this->db->where("default_criticality.df", 0);
            $query[$i]['notification_role'] = $this->db->get('notification_role')->result_array();


            $this->db->select('assignment_role.*,assignment_role.id as assignment_role_id');
            $this->db->where('assignment_role.service_request_id', $val['id']);
            $this->db->where("assignment_role.df", 0);
            $this->db->select('employee_role.name as role_name');
            $this->db->join('employee_role', 'employee_role.id=' . 'assignment_role.assignment_rights');
            $this->db->where("employee_role.df", 0);
            $query[$i]['assignment_role'] = $this->db->get('assignment_role')->result_array();

            $this->db->select('service_request_attachment.*,service_request_attachment.id as service_request_attachment_id');
            $this->db->where('service_request_attachment.service_request_id', $val['id']);
            $this->db->where("service_request_attachment.df", 0);
            $query[$i]['service_request_attachment'] = $this->db->get('service_request_attachment')->result_array();
            $i++;
        }
        return $query;
    }

    public function cycle_time_details($where) {
        $this->db->select('cycle_time.*,cycle_time.id as cycle_time_id,item.name as item_name,item.code as item_code_value');
        $this->db->where("cycle_time.df", 0);
        $this->db->where($where);
        $this->db->group_by("cycle_time.item_code");
        $this->db->join('item', 'item.id=' . 'cycle_time.item_code');
        $query = $this->db->get('cycle_time')->result_array();
        return $query;
    }

    public function service_request_details($where = "") {

        $this->db->select('service_request.*,service_request.id as service_request_id,service_request_category.category_name as service_category_name');
        $this->db->where("service_request.df", 0);
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->select('service_request_category.category_name as service_category_name');
        $this->db->join('service_request_category', 'service_request_category.id=' . 'service_request.service_category');
        $this->db->select('department.name as department_name');
        $this->db->join('department', 'department.id=' . 'service_request.service_department');
        $this->db->select('default_criticality.name as default_criticality_name');
        $this->db->join('default_criticality', 'default_criticality.id=' . 'service_request.default_criticality');
        $this->db->select('asset.name as asset_name');
        $this->db->join('asset', 'asset.id=' . 'service_request.asset');
        $query = $this->db->get('service_request')->result_array();
        return $query;
    }

    public function service_request_notification_details($where = "") {
        $this->db->select('service_request.*,service_request.id as service_request_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("service_request.df", 0);
        $query = $this->db->get('service_request')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('notification.*');
            $this->db->where('notification.service_request_id', $val['id']);
            $this->db->where('notification.df', 0);
            $this->db->where('notification.notification_to', $this->session->userdata('role_value'));
            $this->db->where('notification.location', $this->session->userdata('location'));
            $query[$i]['notification'] = $this->db->get('notification')->result_array();
            $i++;
        }
        return $query;
    }

    public function service_request_notification_details_for_role_assign($where = "") {
        $this->db->select('service_request.*,service_request.id as service_request_id');
        if ($where != "") {
            $this->db->where($where);
        }
        $this->db->where("service_request.df", 0);
        $this->db->select('service_request_category.id as service_request_category_id');
        $this->db->join('service_request_category', 'service_request_category.id=' . 'service_request.service_category');
        $query = $this->db->get('service_request')->result_array();
        $i = 0;
        foreach ($query as $val) {
            $this->db->select('assignment_role.*');
            $this->db->where('assignment_role.service_request_id', $val['service_request_category_id']);
            $this->db->where('assignment_role.df', 0);
            $this->db->where('assignment_role.assignment_rights', $this->session->userdata('role_value'));
            $query[$i]['assignment_role'] = $this->db->get('assignment_role')->result_array();
            $i++;
        }
        return $query;
    }

    public function production_details() {
        $this->db->select('production.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'production.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('production');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function packing_details() {
        $this->db->select('packing.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'packing.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('packing');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function despatch_details() {
        $this->db->select('despatch.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'despatch.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('despatch');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function inward_details() {
        $this->db->select('inward.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'inward.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('inward');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function machine_rejection_despatch_details() {
        $this->db->select('machine_rejection_despatch.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'machine_rejection_despatch.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('machine_rejection_despatch');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function machine_rejection_details() {
        $this->db->select('machine_rejection.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'machine_rejection.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('machine_rejection');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function material_rejection_despatch_details() {
        $this->db->select('material_rejection_despatch.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'material_rejection_despatch.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('material_rejection_despatch');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function material_rejection_details() {
        $this->db->select('material_rejection.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'material_rejection.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('material_rejection');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function inspection_completed_details() {
        $this->db->select('inspection_completed.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'inspection_completed.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('inspection_completed');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function schedule_details() {
        $this->db->select('schedule.*');
        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'schedule.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('schedule');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function opening_stock_details() {
        $this->db->select('opening_stock.*');

        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'opening_stock.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('opening_stock');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function summary_details() {
        $this->db->select('summary.*');
        $this->db->select('customer.name as customer_name');
        $this->db->join('customer', 'customer.id=' . 'summary.customer');
        $this->db->where("customer.df", 0);
        $query = $this->db->get('summary');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function Search_Service_Request($service_department, $service_category) {
        $this->db->select('service_request.*');
        $this->db->where("service_request.df", 0);
        //$this->db->where("service_request.service_department", $service_department);
        $this->db->where("service_request.service_category", $service_category);
        $this->db->select('service_request_category.category_name as service_category_name');
        $this->db->join('service_request_category', 'service_request_category.id=' . 'service_request.service_category');
        $this->db->select('department.name as service_department_name');
        $this->db->join('department', 'department.id=' . 'service_request.service_department');
        $query = $this->db->get('service_request');
        // echo "<pre>"; print_r($query->result_array());exit;
        return $query->result_array();
    }

    public function search_employee_details($employee_name, $location, $department) {

        if ($employee_name != "" || $location != "" || $department != "") {
            $this->db->select('employee.*,employee.name as employee_name');
            $this->db->where("employee.df", 0);
            if ($location != "") {
                $this->db->where("employee.location", $location);
            }
            if ($department != "") {
                $this->db->where("employee.department", $department);
            }
            if ($employee_name != "") {
                $this->db->like('employee.name', $employee_name, 'both');
            }
            $this->db->select('location.name as location_name');
            $this->db->join('location', 'location.id=' . 'employee.location');
            $this->db->select('department.name as department_name');
            $this->db->join('department', 'department.id=' . 'employee.department');
            $query = $this->db->get('employee')->result_array();
            return $query;
        }
        return 1;
    }

    function time_elapsed_string($datetime, $full = false) {
        $now = new DateTime;
        $ago = new DateTime($datetime);
        $diff = $now->diff($ago);

        $diff->w = floor($diff->d / 7);
        $diff->d -= $diff->w * 7;

        $string = array(
            'y' => 'year',
            'm' => 'month',
            'w' => 'week',
            'd' => 'day',
            'h' => 'hour',
            'i' => 'minute',
            's' => 'second',
        );
        foreach ($string as $k => &$v) {
            if ($diff->$k) {
                $v = $diff->$k . ' ' . $v . ($diff->$k > 1 ? 's' : '');
            } else {
                unset($string[$k]);
            }
        }

        if (!$full)
            $string = array_slice($string, 0, 1);
        return $string ? implode(', ', $string) . ' ago' : 'just now';
    }
	
	

}

?>