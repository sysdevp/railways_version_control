<?php

class Excel_model extends CI_Model {

    /**
     * Responsable for auto load the database
     * @return void
     */
				var $last_id = -1;

				public function __construct() {
				$this->load->database();
				$this->load->library('Excel');


				}

				public function query_export($table1=null,$filename=null){
				

				ini_set('display_errors', TRUE);
				ini_set('display_startup_errors', TRUE);

				define('EOL',(PHP_SAPI == 'cli') ? PHP_EOL : '<br />');

				date_default_timezone_set('Asia/Kolkata');

				/** Include PHPExcel */


				$cacheMethod = PHPExcel_CachedObjectStorageFactory::cache_in_memory_gzip;
				if (!PHPExcel_Settings::setCacheStorageMethod($cacheMethod)) {
				die($cacheMethod . " caching method is not available" . EOL);
				}
				echo date('H:i:s') , " Enable Cell Caching using " , $cacheMethod , " method" , EOL;


				// Create new PHPExcel object
				echo date('H:i:s') , " Create new PHPExcel object" , EOL;
				$objPHPExcel = new PHPExcel();

				// Set document properties
				echo date('H:i:s') , " Set properties" , EOL;
				$objPHPExcel->getProperties()->setCreator("SUNIL")
				->setLastModifiedBy("SUNIL")
				->setTitle("TESTS")
				->setSubject("EXCEL CREATION")
				->setDescription("This is the test")
				->setKeywords("office 2007 openxml php")
				->setCategory("Test result file");


				// Create a first sheet
				echo date('H:i:s') , " Add data" , EOL;
				$objPHPExcel->setActiveSheetIndex(0);
				$alpha=range('A','Z');
				//print_r($alpha);

				$cnt=0;
				if($table1!=null){

				$query = $this->db->query($table1);
				$excel=$query ->result_array();
				foreach($excel as $rowkey=>$ex){
				if($rowkey==1){

				foreach($ex as $ckey=>$e){
				//echo $cnt."<br>";


				$cnt++;
				}
				}

				}
				}


				$tablecolumn=$query ->list_fields($table1);
				$tbcount=count($tablecolumn);
				foreach( $tablecolumn as $key => $t){
				$rowkey=1;

				$objPHPExcel->getActiveSheet()->setCellValue($alpha[$key].$rowkey,$t);

				}

				// Hide "Phone" and "fax" column
				echo date('H:i:s') , " Hide 'Phone' and 'fax' columns" , EOL;
				$objPHPExcel->getActiveSheet()->getColumnDimension('C')->setVisible(true);
				$objPHPExcel->getActiveSheet()->getColumnDimension('D')->setVisible(true);


				// Set outline levels
				echo date('H:i:s') , " Set outline levels" , EOL;
				$objPHPExcel->getActiveSheet()->getColumnDimension('E')->setOutlineLevel(1)
				->setVisible(true)
				->setCollapsed(false);

				// Freeze panes
				echo date('H:i:s') , " Freeze panes" , EOL;
				$objPHPExcel->getActiveSheet()->freezePane('A2');


				// Rows to repeat at top
				echo date('H:i:s') , " Rows to repeat at top" , EOL;
				$objPHPExcel->getActiveSheet()->getPageSetup()->setRowsToRepeatAtTopByStartAndEnd(1, 1);


				// Add data


				$alpha1=range('A','Z');
				//print_r($alpha1);

				$count=0;


				foreach ($excel as $key =>$el){
				//print_r($el);
				$key=$key+2;
				$chk=count($el);

				//echo "this is col countt".$chk."<br>";
				foreach($el as $e){
				if($count==$chk){
				//unset($count);
				$count=0;
				}
				//echo $count."<br>";
				$objPHPExcel->getActiveSheet()->setCellValue( $alpha1[$count]. $key, $e);
				$count++;
				}

				}

				// Set active sheet index to the first sheet, so Excel opens this as the first sheet
				$objPHPExcel->setActiveSheetIndex(0);


				// Save Excel 2007 file
				echo date('H:i:s') , " Write to Excel2007 format" , EOL;
				$callStartTime = microtime(true);
				$random=str_replace(':','',date('d:m:YH:i:s'));
				$objWriter = PHPExcel_IOFactory::createWriter($objPHPExcel, 'Excel2007');
				$objWriter->save(str_replace('.php', '.xlsx', './uploads/'.$filename.$random.'.xlsx'));
				$callEndTime = microtime(true);
				echo $callTime = $callEndTime - $callStartTime;

				$url123=base_url();

				echo "<a href='".$url123."uploads/".$filename.$random.".xlsx'>pls click for View excel</a>";


				//redirect(base_url().'upload/attendance'.$random.'.xlsx');

				}










				public function excelimport($table1=null,$filename=null){

				//$filename=$this->cadd();
				if($filename!=null){
				echo "suucsefully UPDATE DATBASE FROM".$filename;




				error_reporting(E_ALL);
				
				//$inputFileType = 'Excel15';
				//	$inputFileType = 'Excel2007';
				//	$inputFileType = 'Excel2003XML';
				//	$inputFileType = 'OOCalc';
				//	$inputFileType = 'Gnumeric';
				$inputFileName = './upload/'.$filename;

				$dta=array();

				$cnt=0;
				$alpha1=range('A','Z');
				$tablecolumn=$this->db->list_fields($table1);
				$tbcount=count($tablecolumn);
				foreach( $tablecolumn as $t){

				$dta[]=$t;

				}





				$inputFileType = PHPExcel_IOFactory::identify($inputFileName);
				echo 'File ',pathinfo($inputFileName,PATHINFO_BASENAME),' has been identified as an ',$inputFileType,' file<br />';

				echo 'Loading file ',pathinfo($inputFileName,PATHINFO_BASENAME),' using IOFactory with the identified reader type<br />';
				$objReader = PHPExcel_IOFactory::createReader($inputFileType);
				$objPHPExcel = $objReader->load($inputFileName);


				echo '<hr />';

				$sheetData = $objPHPExcel->getActiveSheet()->toArray(null,true,true,true);
				//print_r($sheetData);
				$data3=array();
				$ik=0;
				$tbcount=count($tablecolumn);
				foreach($sheetData as $key =>$sh){

				foreach( $tablecolumn as $colkey1 =>$t){


				if($colkey1!=0){
				$data3[$t]=$sh[$alpha1[$colkey1]];
				}

				}


				//$sh['F']=null;
				//$sh=$sh+1;
				//print_r($data3);
				if($key!=1){


				if($sh['B']!="")

				{
				$this->db->insert($table1,$data3);
				}
				}
				}	
				}
				}
	
	
	

}

?>