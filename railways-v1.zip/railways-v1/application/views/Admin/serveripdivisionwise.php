<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');
$menusetting = $this->common_model->getMenuSettings(3); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <form class="form-horizontal" method="post"   id="ip_form"  role="form">
                <div class="col-xs-12">
                    <!--user info table start-->

                    <section class="panel">
                        <div class="title">
                            <h3 class="pull-left">Server IP Details</h3>
                        </div>
                        <div class="panel-body">
                            
                            <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p>
                            <br>
                            <br>

                            <div class="row">
                                <form method="post">
                                    <div class="col-sm-12">
                                        <div class="form-group">
                                                    
                                                
                                            <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone</label>
                                            <div class="col-lg-4">
                                                <select class="form-control selectpicker m-bot15" name="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_serverip(this.value)"  id="RailwayID">
                                                    <option value="">Select Zone</option>
                                                    <?php
                                                    $RailwayID = $this->session->userdata("railway_session_list");
                                                    $rcond = false;
                                                    foreach ($zone as $rows) {
                                                        ?>
                                                        <option <?php if($zoneID == $rows['RailwayID']){ echo "selected"; } ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                        <?php
                                                    }
                                                    ?>
                                                </select>
                                            </div>
                                            <label class="col-sm-6 red"><?php echo form_error('RailwayID'); ?></label>
                                                
                                        </div>
                                    </div>
                                </form>
                            </div>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped view_version" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Zone</th>
                                        <th>Division</th>
                                        <th>Server IP</th>
                                        <th>Connection Status</th>
                                      <!--  <th>Last Connection Check</th>
                                             <td><?php if($rows['LastConnectionCheck'] != null ) { echo date("d-m-Y", strtotime($rows['LastConnectionCheck']));} ?></td>
                                        
                                                 <td> -->
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <?php
                                if(isset($submit))
                                    {?>
                                <tbody class="tbody">
                                    <?php
                                    $i = 1;
                                    foreach ($fields as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['RailwayName']; ?></td>
                                            <td><?php echo $rows['DivisionName']; ?></td>
                                            <td><?php echo $rows['ServerIP']; ?></td>
                                            <td>
                                                <p id="serveripvalue<?php echo $i;?>">
                                                <?php if($rows['ConnectionStatus']==1){ 
                                                 ?>
                                                 <i class="fa fa-check" style="color:green;font-size:20px; "></i>
                                                 <?php }else
                                                 {
                                                    ?>
                                                      <i class="fa fa-times" style="color:red;font-size:20px; "></i>
                                                    <?php
                                                }
                                                    ?>
                                                    </p>
                                                </td>
                                                  <td>                              
                                                <a href="<?php echo site_url(); ?>Admin/edit-settings-ip/<?php echo $rows['rid']."/". $rows['did']; ?>"><span  style="width: 50px;    padding: 12px;" class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> 
                                                </a>
                                                <button type="button" class="btn btn-success" onclick="loadingserver('<?php echo $rows['ServerIP'];?>', <?php echo $i;?>, <?php echo $rows['ID'];?>)">Check</button>
                                                
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                                <?php
                            }
                            ?>
                            </table>
                        </div>


                        </div>


                    </section>
                    <!--user info table end-->
                </div>

                
            </form>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<script>
    function zone_chg_serverip(id)
    {
        if(id !="")
        {
            $("form").submit();
        }
        else
        {
            $("tbody").html("");
        }
        /*
         $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Zone_Chg_ServerIP'); ?>",
                data: {
                    zoneid: id
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".server_div").html(res);
                        $(".selectpicker").selectpicker();
                    }
                }
            });
            */
    }

function loadingserver(ip, val, IDVal)
{
    var id = "#serveripvalue"+val;
    var serverip = $(id).val();
      $(id).html('<i class="fa fa-circle-o-notch fa-spin" style="font-size:20px; color:#0a82e8;"></i>');
    
    $.ajax ({
        type: "POST",
        url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>?ID="+IDVal,
        data:'serverip='+ip,           
        success: function(res){
            console.log(res);
            if(res == 1)
            { 
                $(id).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
            }
            else{
                $(id).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
            }
        }
    });
}
</script>

<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(15);
$slp = array(
    "setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<!--<script>

$(document).ready(function() {
                <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
                LevelSecurity.init(false);
 <?php
                                    }
                                    ?>
                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        ip_detail: 'required',
                    }, 
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
                                    <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                       LevelSecurity.showPassword();
                                        if(LevelSecurity.isPasswordOk == false){
                                                return false;
                                        }else
                                        {
                                              form.submit();
                                        }
                                    <?php
                                    }
                                    else{
                                    ?>
                                            form.submit();
                                    <?php
                                    }
                                    ?>
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
                
          });       
    </script>  --> 

</body>
</html>