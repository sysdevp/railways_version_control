<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');


 $module_security = $this->common_model->find_details(array("menu_id"=>2),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
 $security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
 $security_url = $security_level_url[$module_security];
 $security_level_Content = array("1"=>"Level1","2"=>"Level2","3"=>"Level3");
 $security_Level_Value = $security_level_Content[$module_security];


?>

<!--main content start-->

<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Auto Logout Time </h3>
                    </div>
                    <div class="panel-body">
                        <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: The Fields denoted in <span class="red">(*)</span> are mandatory. 
						<br>*The user will be automatically logged out, if the browser is kept idle until the time mentioned below.</p>  
                        
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" id="session_form" role="form" method="POST">
                            <?php
                            foreach ($sessiontimeout as $rows) {
                                ?>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="Minutes">Time in Minutes
                              <br>
                                        <span style="font-size: 12px;">(20 to 60 mins)</span> <span class="red">(*)</span></label>
                                    
                                    <div class="col-lg-4">
                                        <input type="number" data-validation="number"  data-validation-allowing="range[20;60],postive"

                                        data-validation-error-msg="Allowing minute is between 20 to 60"

                                           class="form-control" id="Minutes" name="Minutes" placeholder="Time in Minutes" value="<?php echo $rows['Minutes']; ?>">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('Minutes');?></label>
                                </div>
                                
                                <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<div class="modal fade alert_popup LevelPassword" id="<?php echo $security_Level_Value;?>PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="<?php echo $security_Level_Value;?>PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="<?php echo $security_Level_Value;?>PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="<?php echo $security_Level_Value;?>Password">Level <?=$module_security?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="<?php echo $security_Level_Value;?>Password" class="form-control" id="<?php echo $security_Level_Value;?>Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                         <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
            
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () {    
    $.validator.setDefaults({
            ignore: []
    });        
    $('.form-horizontal').validate({
            errorElement: 'span',
            errorClass: 'error',
            ignore: [], 
            lang: 'en',
            rules: {
                Minutes:
                {
                    required:true,
                    min:20,
                    max:60
                },
            }, 
            messages: {
                Minutes: {
                        min: "Allowing minute is between 20 to 60",
                        max: "Allowing minute is between 20 to 60"
                }
            },		
            submitHandler: function(form) {
                    if($(".form-horizontal").valid()==true)
                    {
                            <?php
                            if($this->session->userdata("UserRole")!="Admin")
                            {?> 
                                $("#<?php echo $security_Level_Value;?>PasswordModal").modal("show");
                                if(  $("#form-ok").val()!="ok"){
                                        return false;
                                } 
                                else{
                                        form.submit();
                                }
                            <?php
                            }
                            else{
                            ?>
                                    form.submit();
                            <?php
                            }
                            ?>
                    }
                    else{ 
                            return false;
                    }
            }
    });     
	}); 

        $(".message_info").hide();
        $('.password_verify').on('click', function (event) {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url($security_url); ?>",
                data: {
                    password: $("#<?php echo $security_Level_Value;?>Password").val(),
                },
                success: function (res) {      
                    if (res != 1)
                    {
                        $("#<?php echo $security_Level_Value;?>PasswordMessage").html(res);
                        $(".message_info").show();
                    }
                    else
                    {
                         $(".message_info").hide();
                        $("#<?php echo $security_Level_Value;?>PasswordMessage").html("");
                    }
                    if ($("#<?php echo $security_Level_Value;?>PasswordMessage").html() == "")
                    {
                      $("#form-ok").val("ok");
                      $("#session_form").submit();
                        //$("form").submit();
                    }
                }
            });
        });

</script>
</body>
</html>

