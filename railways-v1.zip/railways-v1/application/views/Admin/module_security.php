<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');

$module_security = $this->common_model->find_details(array("menu_id"=>7),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; 



?>
<style>
    #security-table_previous {
        color: #c7c7c7;
    }
    
    a.paginate_button.current {
        color: #797979;
        padding: 5px 10px;
        display: inline-block;
        border: 1px solid #ddd;
        margin: 0 1px;
        border-radius: 3px;
        -webkit-border-radius: 3px;
    }
    
    .paginate_button {
        color: #797979;
        padding: 5px 10px;
        display: inline-block;
        border: 1px solid #ddd;
        margin: 0 1px;
        border-radius: 3px;
        -webkit-border-radius: 3px;
    }
</style>

<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Level Settings</h3>
                        <ul class="pull-right">
                            
                        </ul>
                    </div>
                    
                    <div class="panel-body">
                        <div class="adv-table">
                          
<?php if( $this->session->userdata("success_done")) { ?>
                             <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php  echo $this->session->userdata("success_done" );?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                            <form method="post" action="<?=base_url();?>admin/update_module_security">
							<div class="adv-table">
                            
                            <table class="display dashboard-table table table-bordered table-striped" id="security-table">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Name</th>
                                        <th>Select Security Level</th>
                                        
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php 
                                        $i = 1;
                                       foreach ($modules as $key=> $rows) {
                                                ?>

                                                <tr>
                                                    <td><?=$rows["menu_id"];?></td>
                                                    <td><?=$rows["menu_name"]?></td>

                                                    <td>
                                                        <input type="hidden" name="menu_id[]" value="<?=$rows["menu_id"]?>">

                                                        <select name="security_level[]" onchange="update_security('<?= $rows["menu_id"]?>',this)"  class="form-control">
                                                        <!-- <option <?php if($rows["security_level"]=="0") echo "selected";?>  value="0">None</option> -->
                                                        <?php foreach($security as $val){?>
                                                        <option <?php if($rows["security_level"]==$val["SecurityID"]) echo "selected";?> value="<?=$val["SecurityID"]?>"><?=$val["LevelName"]?></option>

                                                    <?php } ?>
                                                    </select>


                                                   </td>
                                                  

                                            
                                                </tr>
                                                <?php
                                              
                                            }
                                  
                                    ?>
                                </tbody>
                            </table>
							</div>
                            <div class="form-group"><button class="btn btn-success preventbtn"  type="button" <?php if($edit_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Submit</button></div>
                           
                            </form>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script type="text/javascript">
      /*   $(function(){
        $('#security-table').dataTable( {
        "aaSorting": [[ 4, "asc" ]],
        "iDisplayLength": 20
        } );
        }); */

      <?php
        if($this->session->userdata("UserRole")!="Admin")
        {?>
                            $('.preventbtn').on('click', function (event) {
                          
                            LevelSecurity.showPassword();
                            if(LevelSecurity.isPasswordOk == false){
                            return false;
                            }
                            event.preventDefault();
                            return false
                        
                            });
<?php }
else
{
    ?>
        $('.preventbtn').on('click', function (event) {
            $("form").submit();
            });
        <?php
}
                        ?>
                                
/*        function update_security(menu_id,el){
            security=$(el).val();

            $.post("<?=base_url();?>admin/update_module_security",{menu_id:menu_id,security_level:security},function(){

                $("#success_screen").html("Successfully Updated");
                 $("#success_screen").fadeOut('slow', function() {
                     
                 });
              
            });
        }*/
     

</script>

<!--<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>-->
<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(19);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
				
				
				
			});

</script>
<script>
    $(document).ready(function () {
        var table = $('#security-table').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>
</body>
</html>

