<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Current Version Details <?php echo '- '.$zone_name ?></h3>
                        <ul class="pull-right">
                          <!--  <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                            <li><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download</button></li>-->
                        </ul>
                    </div>
                    <div class="panel-body">

                        <?php if($zoneid=="1") {?>
                        <div class="row m-bot20">
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/1";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;MAS</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/5";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;SA</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/4";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;PGT</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/6";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;TVC</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/2";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;TPJ</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/Division/1/3";?>" class="btn btn-success" style="width: 100%"><i class="fa fa-check" aria-hidden="true"></i>&nbsp;MDU</a>                                   
                            </div>
                        </div>
                    <?php } ?>

                        <table class="table dashboard-table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vendors</th>
                                    <th>Number of Stations</th>
                                    <th>View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $divisionid = "";
                                $spacecount=0;
                                foreach($dashboard as $rows)
                                {
                                    ?>
                                <tr>                                   
                                    <td>
										<?php echo $rows['VendorName'];?>
                                    </td>
                                    <td>
                                        <?php echo $rows['count'];?>
                                        
                                    </td>
                                    <td><?php if($rows['count'] != 0) { ?> <a href="<?php echo site_url()."Admin/Vendor/".$rows['VendorID']."/".$rows['RailwayID'];?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a> <?php } ?></td>
                                </tr>
                                
                                <?php
                                $divisionid = $rows['DivisionID'].$rows['RailwayID'];
                                }
                                ?>
                            </tbody>
                        </table>
						
						<div class="col-xs-12">	
							<div id="piechart" class="chart_div" style="margin-left:30%;"></div>
						</div>
						
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

 
<script type="text/javascript" src="<?php echo $asset_url; ?>js/charts_loader.js"></script>
<script>
					
					// Load google charts
					google.charts.load('current', {'packages':['corechart']});
					google.charts.setOnLoadCallback(drawChart);

					function drawChart()
					{
						var pausecontent = new Array();
						
						
						var data = google.visualization.arrayToDataTable([
							['Task', 'Hours per Day'],
							<?php for($i = 0; $i< count($dashboard); $i++){ ?>
							['<?php echo $dashboard[$i]['VendorName'] ?>', <?php echo $dashboard[$i]['count'] ?>],
							<?php } ?>
						]);
	
							var options = {'title':' ', 'width':550, 'height':400, pieSliceText: 'value'};
						
						
						// Display the chart inside the <div> element with id="piechart"
						var chart = new google.visualization.PieChart(document.getElementById('piechart'));
						chart.draw(data, options);
					}
			
</script>

</body>
</html>

