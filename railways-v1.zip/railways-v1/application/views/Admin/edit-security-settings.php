<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 

$module_security = $this->common_model->find_details(array("menu_id"=>11),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify Security Settings Details</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/security-settings" class="btn btn-info">View Security Settings</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach ($security_settings as $rows) {
                                ?>
                            <div class="form-group">
                                    <label class="col-sm-2 control-label" for="SecuritySettingsName">Level Name <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="text" readonly="" class="form-control" id="LevelName" required="" name="LevelName" value="<?php echo $rows['LevelName'];?>" >
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="SecuritySettingsName">Current Password <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="password"  minlength="8" class="form-control" id="current_password" required=""  name="current_password" placeholder="Current Password" maxlength="20">
                                    </div>
                                    <p>(Minimum 8 and Maximum 20 characters required.)</p>
                                    <label class="col-sm-6"><?php echo form_error('current_password');?></label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="SecuritySettingsName">New Password <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="password" minlength="8" class="form-control" id="password" required name="password" placeholder=" New Password" maxlength="20">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('password');?></label>
                                </div>
                            <div class="form-group">
                                    <label class="col-sm-2 control-label" for="SecuritySettingsName">Retype Password <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="password" minlength="8" class="form-control" id="re_password" required name="re_password" placeholder=" Retype Password" maxlength="20">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('re_password');?></label>
                                </div>
                                
                                <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Level <?=$module_security?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                         <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
                           
    $.validate({
                    lang: 'en',
                    onError : function($form) {

                    },
                    onSuccess : function($form) {
 <?php
        if($this->session->userdata("UserRole")!="Admin")
        {?>
                    $("#Level2PasswordModal").modal("show");
                    if(  $("#form-ok").val()!="ok"){
                    return false;
                     }
                <?php } ?>
                    // Will stop the submission of the form
                    }
                    });

$(".message_info").hide();
                                $('.preventbtn').on('click', function (event) {
                                   
                                });
                                $('.password_verify').on('click', function (event) {
                                    $.ajax({
                                        type: "POST",
                                        url: "<?php echo site_url($security_url); ?>",
                                        data: {
                                            password: $("#Level2Password").val(),
                                        },
                                        success: function (res) {      
                                            if (res != 1)
                                            {
                                                $("#Level2PasswordMessage").html(res);
                                                $(".message_info").show();
                                            }
                                            else
                                            {
                                                 $(".message_info").hide();
                                                $("#Level2PasswordMessage").html("");
                                            }
                                            if ($("#Level2PasswordMessage").html() == "")
                                            {
                                                 $("#form-ok").val('ok')
                                                $("form").submit();
                                            }
                                        }
                                    });
                                });

</script>
</body>
</html>

