<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<style>
.btn-success.redbtn
{
    background-color: #fd5a4e !important;
}
</style>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Dashboard</h3>
                        <ul class="pull-right">
                          <!--  <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                            <li><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download</button></li>-->
                        </ul>
                    </div>
                    <div class="panel-body">
						<form class="form-horizontal" role="form" method="POST">
							<div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="get_dashboard(this.value)">
                                        <option selected value="">Select Option</option>
                                        <?php
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php
                                            if($RailwaySelectID != 0)
                                            {
                                                if($RailwaySelectID == $rows['RailwayID'])
                                                {
                                                    echo "selected";
                                                }
                                            } echo set_select("RailwayID", $rows['RailwayID'], FALSE);
                                            ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('RailwayID'); ?></label>
                            </div>
                        </form>
						
						<div id="dashboard_id">
                        
						</div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>

<script src="<?php echo site_url('assets/boot/'); ?>js/main.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<script>
	$(document).ready(function () {
		var val = $('#RailwayID').val();
		get_dashboard(val);
	});
	function get_dashboard(id)
	{
		if(id != ''){
			$.ajax({
				type: "POST",
				url: "<?php echo site_url('Admin/Zone_Chg_Dashboard'); ?>",
				data: {
					id: id
				},
				success: function (res) {
					$("#dashboard_id").html("");
					if (res != 0)
					{
						$("#dashboard_id").html(res);
						$(".selectpicker").selectpicker();
					}
				}
			});
		}
	}
</script>
 
<script type="text/javascript" src="<?php echo $asset_url; ?>js/charts_loader.js"></script>

</body>
</html>

