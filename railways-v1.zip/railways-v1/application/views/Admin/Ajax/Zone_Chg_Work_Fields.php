
<div class="form-group" id="description_of_work">
	<label for="ReasonChanging" class="col-sm-2 control-label" id="description_of_work_label">Description of Work <span class="red">(*)</span></label>
	<div class="col-lg-4">
		<select class="form-control selectpicker" required data-tag="description_of_work" data-title="Description of Work" id="ReasonChanging" data-show-subtext="true" data-live-search="true" name="DescriptionOfWork">
				<option value="">Select Option</option>
				<?php
				foreach ($extrafields as $extra) {
					if($extra["for_field"] == 0){
					?>
					<option value="<?php echo $extra["field_value"]; ?>"><?php echo $extra["field_value"]; ?></option>
					<?php
				} }
				?>
				<option value="Others">Others</option>
			</select>
		<label class="col-sm-12 red" id="description_of_work_errmsg"><?php echo form_error('DescriptionOfWork'); ?></label>
	</div>
	<div class="col-lg-6">
		<p>( Select "Others" if the required option was not listed.)</p>
	</div>
</div> 
<div class="form-group" id="work_executed_up_by">
	<label form="WorkExcuited" class="col-sm-2 control-label" id="work_executed_up_by_label" for="inputSuccess">Work Executed by <span class="red">(*)</span></label>
	<div class="col-lg-4">
		<select class="form-control selectpicker" required data-tag="work_executed_up_by" data-title="Work Executed by" id="WorkExcuited" data-show-subtext="true" data-live-search="true" name="WorkExecutedBy">
				<option value="">Select Option</option>
				<?php
				foreach ($extrafields as $extra) {
					if($extra["for_field"] == 1){
					?>
					<option value="<?php echo $extra["field_value"]; ?>"><?php echo $extra["field_value"]; ?></option>
					<?php
				} }
				?>
				<option value="Others">Others</option>
			</select>
		<label class="col-sm-12 red" id="work_executed_up_by_errmsg"><?php echo form_error('WorkExecutedBy'); ?></label>
	</div>
	<div class="col-lg-6">
		<p>( Select "Others" if the required option was not listed.)</p>
	</div>
</div>