<?php echo $_POST["VendorID"]; ?>
