
<div class="form-group">

	<div id="approvedby">
		<label for="DateInstallation" id="approvedby_label" class="col-sm-2 control-label">Approved by</label>
		<div class="col-lg-4" id="tour6">
		<select class="form-control selectpicker" name="approvedby">
	
		   <option value="" >select approved by</option>
			  <?php foreach($approved_master as $data) {?>
				<option value="<?=$data["text"]?>"><?=$data["text"]?></option>
			<?php } ?>
			<option value="Others">Others</option>
		</select>


		</div>
		<div class="col-lg-6">
			<p>( Select "Others" if the required option was not listed.)</p>
		</div>
	</div>
</div>
<div class="form-group">


	<div id="verifiedby">
		<label for="DateInstallation" id="verifiedby_label" class="col-sm-2 control-label">Verified By</label>
		<div class="col-lg-4" id="tour7">

		<select  class="form-control selectpicker" name="verifiedby">
			<option value="" >select verified by</option>
			<?php foreach($verified_master as $data) {?>
				<option value="<?=$data["text"]?>"><?=$data["text"]?></option>
			<?php } ?>
			<option value="Others">Others</option>
		</select>


		</div>
		<div class="col-lg-6">
			<p>( Select "Others" if the required option was not listed.)</p>
		</div>
	</div>
</div>