<select class="form-control selectpicker required" id="DesignationID" data-show-subtext="true" data-live-search="true" name="DesignationID"  required="required">
    <option value="">Select Designation</option>
    <?php
    foreach ($designation as $rows) {
		
        ?>
        <option <?php echo set_select("DesignationID", $rows['DesignationID'], FALSE); ?> value="<?php echo $rows['DesignationID']; ?>"><?php echo $rows['DesignationName']; ?></option>
        <?php
    }
    ?>
</select>