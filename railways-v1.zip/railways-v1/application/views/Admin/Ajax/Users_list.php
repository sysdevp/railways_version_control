<select class="form-control selectpicker" data-validation="required" id="UserID" data-show-subtext="true" data-live-search="true" name="UserID">
                                            <option value="">Select Option</option>
											<?php if (isset($user)) { ?>
                                            <!-- <option value="All" selected> All</option> -->
                                            <?php $userloginid=$this->session->userdata("id_session_list");
                                            foreach ($user as $rows) {
                                                ?>
                                                <option <?php
                                                 echo set_select("UserID", $rows['UserID'],$rows['UserID']==$userloginid );
                                                ?> value="<?php echo $rows['UserID']; ?>"><?php echo $rows['EmployeeName'] . " (" . $rows['LoginName'] . ")"; ?></option>
                                                    <?php
                                                }
                                                }
                                                ?>
                                        </select>