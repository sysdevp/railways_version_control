					<?php if($zoneid=="1" && $LevelID != 1 ) {?>
					<?php if($zoneid=="1") {?>
						<div class="col-sm-12">
							<span><i class="fa fa-square green" aria-hidden="true"></i>  Connection successful</span>
							<span><i class="fa fa-square red" aria-hidden="true"></i>  Connection failure</span>
						</div>
                        <div class="row m-bot20">
							<?php
                            /* $serverips = $this->common_model->getbyCondition("tblserveripdetails", "", "", "ServerID", "asc");
							$i=1;
                            foreach ($serverips as $serverip) {
                                if ($serverip->ExtraIP == 0 && $serverip->ServerID <= 6) {
									if($serverip->ServerID == 1)
									{ $div_code = "MAS"; }
									else if($serverip->ServerID == 2)
									{ $div_code = "SA"; }
									else if($serverip->ServerID == 3)
									{ $div_code = "PGT"; }
									else if($serverip->ServerID == 4)
									{ $div_code = "TVC"; }
									else if($serverip->ServerID == 5)
									{ $div_code = "TPJ"; }
									else if($serverip->ServerID == 6)
									{ $div_code = "MDU"; }
									if($this->common_model->availableUrl($serverip->ServerIP)!=1){ 
									?>
										<div class="col-sm-2">
											<a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;<?php echo $div_code; ?></a>                                   
										</div>
									<?php
									}
									else{
									?>
										<div class="col-sm-2">
											<a href="<?php echo site_url()."Admin/connectivitynotexist/1";?>" class="btn btn-success" style="width: 100%; color: green;"><i class='fa fa-check' aria-hidden='true'></i>&nbsp;<?php echo $div_code; ?></a>                                   
										</div>
									<?php
									}
                                }
								$i++;
                            } */
                            ?>
                            <!--<div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;MAS</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;SA</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;PGT</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;TVC</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;TPJ</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <a href="<?php echo site_url()."Admin/connectivitynotexist";?>" class="btn btn-success redbtn" style="width: 100%"><i class="fa fa-times" aria-hidden="true"></i>&nbsp;MDU</a>                                   
                            </div>-->
                            <div class="col-sm-2">
                                <?php
                                    $btn1 = 'redbtn';
                                    $style1 = 'fa fa-times';
                                    $url1 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['MAS']) {
                                        $btn1 = 'greenbtn';
                                        $style1 = 'fa fa-check';
                                        $url1 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url1;?>" class="btn btn-success <?php echo $btn1; ?>" style="width: 100%"><i class=" <?php echo $style1 ?>" aria-hidden="true"></i>&nbsp;MAS</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <?php
                                    $btn2 = 'redbtn';
                                    $style2 = 'fa fa-times';
                                    $url2 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['SA']) {
                                        $btn2 = 'greenbtn';
                                        $style2 = 'fa fa-check';
                                        $url2 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url2;?>" class="btn btn-success <?php echo $btn2; ?>" style="width: 100%"><i class=" <?php echo $style2 ?>" aria-hidden="true"></i>&nbsp;SA</a>                                  
                            </div>
                            <div class="col-sm-2">
                                <?php
                                    $btn3 = 'redbtn';
                                    $style3 = 'fa fa-times';
                                    $url3 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['PGT']) {
                                        $btn3 = 'greenbtn';
                                        $style3 = 'fa fa-check';
                                        $url3 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url3;?>" class="btn btn-success <?php echo $btn3; ?>" style="width: 100%"><i class=" <?php echo $style3 ?>" aria-hidden="true"></i>&nbsp;PGT</a>                                   
                            </div>
                            <div class="col-sm-2">
                                <?php
                                    $btn4 = 'redbtn';
                                    $style4 = 'fa fa-times';
                                    $url4 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['TVC']) {
                                        $btn4 = 'greenbtn';
                                        $style4 = 'fa fa-check';
                                        $url4 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url4;?>" class="btn btn-success <?php echo $btn4; ?>" style="width: 100%"><i class=" <?php echo $style4 ?>" aria-hidden="true"></i>&nbsp;TVC</a>  
                                
                            </div>
                            <div class="col-sm-2">
                                <?php
                                    $btn5 = 'redbtn';
                                    $style5 = 'fa fa-times';
                                    $url5 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['TPJ']) {
                                        $btn5 = 'greenbtn';
                                        $style5 = 'fa fa-check';
                                        $url5 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url5;?>" class="btn btn-success <?php echo $btn5; ?>" style="width: 100%"><i class=" <?php echo $style5 ?>" aria-hidden="true"></i>&nbsp;TPJ</a>                                     
                            </div>
                            <div class="col-sm-2">
                                <?php
                                    $btn6 = 'redbtn';
                                    $style6 = 'fa fa-times';
                                    $url6 = site_url()."Admin/connectivitynotexist";
                                    if($connectivity['MDU']) {
                                        $btn6 = 'greenbtn';
                                        $style6 = 'fa fa-check';
                                        $url6 = site_url()."Admin/connectivitynotexist/1";
                                    }
                                ?>
                                <a href="<?php echo $url6;?>" class="btn btn-success <?php echo $btn6; ?>" style="width: 100%"><i class=" <?php echo $style6 ?>" aria-hidden="true"></i>&nbsp;MDU</a>                                   
                            </div>
                        </div>
                    <?php } ?>					
                        <div class="col-xs-12" id="index_tour2">	
                                <div id="piechart" class="chart_div" style="margin-left:30%;"></div>
                        </div>
						
                        <table class="table dashboard-table table-bordered">
                            <thead>
                                <tr>
                                    <th>Vendors</th>
                                    <th>Number of Stations</th>
                                    <th id="index_tour3">View</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $divisionid = "";
                                $spacecount=0;
                                foreach($dashboard as $rows)
                                {
                                    ?>
                                <tr>                                   
                                    <td>
										<?php echo $rows['VendorName'];?>
                                    </td>
                                    <td>
                                        <?php echo $rows['count'];?>
                                        
                                    </td>
                                    <td><?php if($rows['count'] != 0) { ?> <a href="<?php echo site_url()."Admin/Vendor/".$rows['VendorID']."/".$rows['RailwayID'];?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a> <?php } ?></td>
                                </tr>
                                
                                <?php
                                $divisionid = $rows['DivisionID'].$rows['RailwayID'];
                                }
                                ?>
                            </tbody>
                        </table>
						<script>
	
							// Load google charts
							google.charts.load('current', {'packages':['corechart']});
							google.charts.setOnLoadCallback(drawChart);

							function drawChart()
							{
								var pausecontent = new Array();
								
								
								var data = google.visualization.arrayToDataTable([
									['Task', 'Hours per Day'],
									<?php for($i = 0; $i< count($dashboard); $i++){ ?>
									['<?php echo $dashboard[$i]['VendorName'] ?>', <?php echo $dashboard[$i]['count'] ?>],
									<?php } ?>
								]);
			
									var options = {'title':' ', 'width':550, 'height':400, pieSliceText: 'value'};
								
								
								// Display the chart inside the <div> element with id="piechart"
								var chart = new google.visualization.PieChart(document.getElementById('piechart'));
								chart.draw(data, options);
							}
					
						</script>
						<?php
					}
					?>