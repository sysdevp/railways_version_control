<?php 
$module_security = $this->common_model->find_details(array("menu_id"=>5),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security];
if(isset($fieldid)) 
{
	if($fieldid == 0)
	{
		$fieldname = 'Work Description';
	}
	else if($fieldid == 1)
	{
		$fieldname = 'Executed By';
	}
	else if($fieldid == 2)
	{
		$fieldname = 'Verified By';
	}
	else if($fieldid == 3)
	{
		$fieldname = 'Approved By';
	}

?>
<table class="display table table-bordered table-striped example dataTable " id="example">

                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th><?php echo $fieldname; ?></th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($fields as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['field_value']; ?></td>
                                            <td>                                  
                                                <a href="<?php echo site_url(); ?>Admin/edit_version_desc/<?php echo $rows['id']; ?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                                
												
												<input type="hidden" class="version_field_id" id="version_field_id" value="<?php echo $rows['id']; ?>"/>
                                                <a href="javascript:void(0)" class="preventbtnnn"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                            </table>
							
<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Are you sure, you want to Delete?</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
				<h4>Note: This is an important data, Please ensure before proceeding.</h4>
				<?php if($this->session->userdata("UserRole") != "Admin") {?>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password"><b>Level <?=$module_security ;?> Security Code</b></label>
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
						<input type="hidden" class="version_field_idd" id="version_field_idd" value=""/>
                        <button type="submit" class="btn btn-danger password_verify2  pull-right" style="margin-top:5px;" >Yes</button>
                         <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
                    </div>
                </div>
				<?php } else {?>
					<div class="form-group">
						<div class="col-lg-12">
							<input type="hidden" class="version_field_idd" id="version_field_idd" value=""/>
							  <button type="button" class="btn btn-danger pull-right" style="margin-top:5px;" onclick="confirm_userole_admin();">Yes</button>
							 <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
							  
						</div>
					</div>
				<?php }?>
            </div>
            <div class="modal-footer">
               
            </div>
        </div>
    </div>
</div>
<script>
    $(".message_info").hide();
    $("#success-alert").hide();
    $('.preventbtnnn').on('click', function (event) {
		var $tr = $(this).closest("tr");
		 var permanent_id = $tr.find(".version_field_id").val();
		 $(".version_field_idd").val(permanent_id);
		console.log(permanent_id);
        $("#Level1PasswordModal").modal("show");
        event.preventDefault();
        return false
    });
    $('.password_verify2').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url($security_url); ?>",
            data: {
                password: $("#Level1Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level1PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $("#Level1PasswordMessage").html("");
                }
                if ($("#Level1PasswordMessage").html() == "")
                {
                    $("#Level1PasswordModal").modal("hide");
                    deleteversionfield($("#version_field_idd").val())
                }
            }
        });
    });
</script>
<script>
function confirm_userole_admin()
{
	$("#Level1PasswordModal").modal("hide");
	var id = $("#version_field_idd").val();
	$.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/delete-version-desc-fields'); ?>",
            data: {
                id: id,
            },
            success: function (res) {
                if (res == 1)
                {
                    window.location = "<?php echo site_url(); ?>Admin/version-desc-exec";
                }
                else
                {
                    $(".alert_status").html("Warning!");
                    $(".alert_msg").html("This record cannot be deleted because other records need this information.");
                    $("#myModal .modal-header").addClass("alert_warining");
                    $("#myModal").modal("show");
                }
            }
        });
}

    function deleteversionfield(id)
    {
		
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/delete-version-desc-fields'); ?>",
            data: {
                id: id,
            },
            success: function (res) {
                if (res == 1)
                {
                    window.location = "<?php echo site_url(); ?>Admin/version-desc-exec";
                }
                else
                {
                    $(".alert_status").html("Warning!");
                    $(".alert_msg").html("This record cannot be deleted because other records need this information.");
                    $("#myModal .modal-header").addClass("alert_warining");
                    $("#myModal").modal("show");
                }
            }
        });
    } 
</script>
							
<?php } ?>							