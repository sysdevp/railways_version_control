<select class="form-control selectpicker" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID" <?php if(isset($multiple)){?> onchange="station_chg(this.value)"<?php }?> <?php if(isset($userids)){?> onchange="select_user()"<?php }?>>
    <option value="">Select Option</option>
    <?php
    foreach ($station as $rows) {
    	$sel = $rows['StationID'];
		if($station_select != ""){
			$sel = $station_select;
		}

       


        ?>
        <option            <?php echo set_select("StationID", $sel, FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
        <?php
    }
    ?>
</select>