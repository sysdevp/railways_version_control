<select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID" <?php if(isset($multiple)){?> onchange="division_chg_station(this.value)"<?php }?>>
    
	<?php if(isset($page) && $page =="view-version"){ ?>
<option <?php if($DivisionID == "" || $DivisionID == "-1"){ echo "selected"; } ?> value="" >All Division</option>
	<?php }else{ ?>
	<option <?php if($DivisionID == "" || $DivisionID == "-1"){ echo "selected"; } ?> value="">Select Divisions</option>
	<?php } ?>
	
    <?php
    foreach($division as $rows)
    {
        ?>
        <option <?php if($DivisionID == "" || $DivisionID == "-1"){ set_select("DivisionID", $rows['DivisionID'], FALSE); }else{ if($DivisionID == $rows['DivisionID']){ echo "selected"; } }?> value="<?php echo $rows['DivisionID'];?>"> <?php echo $rows['DivisionName']. " (".$rows['DivisionCode'].")";?></option>
    <?php
    }
    ?>
</select>