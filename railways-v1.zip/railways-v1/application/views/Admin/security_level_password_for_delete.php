<div class="modal fade alert_popup LevelPassword" id="LevelPasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Are you sure, You want to delete? </h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="LevelPasswordMessage"></div>
				<h4>Note: This is an important data, Please ensure before proceeding.</h4>
				<?php if($this->session->userdata("UserRole") != "Admin") {?>
                <div class="form-group">
                    <label class="col-sm-4 control-label" id="levelsecurityLabel" for="Level1Password"><b>Level <?=$setting["LevelNo"]?> Security Code</b></label>
                    <div class="col-lg-8">
                        <input  type="password" name="Level1Password" class="form-control" id="LevelPassword" placeholder="Security Code" value="">
                    </div>
                </div>  
                <div class="form-group">
                    <div class="col-lg-12">
                          <button type="submit" class="btn btn-danger password_verify level_password_verify  pull-right" style="margin-top:5px;" >Yes</button>
                         <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
                          
                    </div>
                </div>
				<?php } else {?>
					<div class="form-group">
						<div class="col-lg-12">
							  <button type="button" class="btn btn-danger pull-right" style="margin-top:5px;" onclick="confirm_userole_admin();">Yes</button>
							 <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
							  
						</div>
					</div>
				<?php }?>
            </div>
            <div class="modal-footer">
               
            </div>
        </div>
    </div>
</div>
