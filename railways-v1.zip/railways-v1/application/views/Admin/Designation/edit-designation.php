<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify Designation Details</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-designation" class="btn btn-info">View Designation</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach ($designation as $rows) {
								$LevelID = $rows['LevelID'];
                                ?>
								<div class="form-group">
									<label class="col-sm-2 control-label" for="inputSuccess">Level <span class="red">(*)</span></label>
									<div class="col-lg-4">
										<select class="form-control selectpicker m-bot15" name="LevelID" data-show-subtext="true" data-live-search="true" required>
											<option value="">Select Option</option>
											<?php
											$rcond = false;
											foreach ($level as $levelrows) {
												?>
												<option <?php if ($LevelID == $levelrows['LevelID']) {
												$rcond = true;
												echo "selected";
											} echo set_select("LevelID", $levelrows['LevelID'], FALSE); ?> value="<?php echo $levelrows['LevelID']; ?>"><?php echo $levelrows['LevelName']; ?></option>
		<?php
	}
	?>
										</select>
									</div>
									<label class="col-sm-6"><?php echo form_error('LevelID'); ?></label>
								</div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="DesignationName">Designation Name <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" id="DesignationName" name="DesignationName" placeholder="Designation" value="<?php echo $rows['DesignationName']; ?>" maxlength="40" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&*+\=?;:<>]/gi, ''));" required>
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('DesignationName');?></label>
                                </div>
                                <div class="form-group">
                                    <label for="DesignationDescription" class="col-lg-2 col-sm-2 control-label">Designation Description</label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" name="DesignationDescription" id="DesignationDescription" placeholder="Designation Code" value="<?php echo $rows['DesignationDescription']; ?>">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('DesignationDescription');?></label>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                     <a href="<?php echo site_url(); ?>Admin/view-designation" class="btn btn-default">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(15);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

$(document).ready(function() {
				<?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
 <?php
                                    }
                                    ?>
                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        LevelID: 'required',
                        DesignationName: 'required',
                    }, 
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
                                    <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                       LevelSecurity.showPassword();
                                        if(LevelSecurity.isPasswordOk == false){
                                                return false;
                                        }else
                                        {
                                              form.submit();
                                        }
                                    <?php
                                    }
                                    else{
                                    ?>
                                            form.submit();
                                    <?php
                                    }
                                    ?>
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
				
		  }); 		
	</script>		

</body>
</html>

