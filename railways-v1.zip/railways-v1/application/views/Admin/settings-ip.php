<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');
$menusetting = $this->common_model->getMenuSettings(3); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <form class="form-horizontal" method="post"   id="ip_form"  role="form">
                <div class="col-xs-12">
                    <!--user info table start-->

                    <section class="panel">
                        <div class="title">
                            <h3 class="pull-left">Server IP Details</h3>
                        </div>
                        <div class="panel-body">
                            
                            <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p>
							<div class="col-sm-12">
								<span><i class="fa fa-circle-o-notch fa-spin" style="font-size:20px; color:#0a82e8;"></i>  Verifyng</span>
								<span><i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>  Connection Successful</span>
								<span><i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>  Connection Failure</span>
							</div>
							<br>
							<br>
                            <span id="error" style="color: red;font-size: 20px"></span>

                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
<?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <?php
							$condition = "ExtraIP = 0";
                            $serverips = $this->common_model->getbyCondition("tblserveripdetails", $condition, "", "ServerID", "asc");
							$i=1;
                            foreach ($serverips as $serverip) {
                                if ($serverip->ExtraIP == 0) {
                                    ?>
                                    <div class="form-group">
                                        <label for="Chennai" class="col-lg-4 col-sm-2 control-label"><?php echo $serverip->ServerName; ?> <span class="red">(*)</span> </label>
                                        <div class="col-lg-4">
                                            <input name="ServerID[]"  type="hidden" value="<?php echo $serverip->ServerID; ?>" required>
                                            <input name="ip_detail[]"  type="text" class="form-control ip_detail ip_detail1" placeholder="" value="<?php echo $serverip->ServerIP; ?>" onkeyup="$(this).val($(this).val().replace(/[a-z`~!@#$%^&*()_|+\=?;:,'<>\{\}\[\]\\\/]/gi, ''));" maxlength="15" required>
                                          
                                        </div>
                                        <div class="col-lg-4">
                                              <label id="serveripping<?php echo $i;?>"><i class="fa fa-circle-o-notch fa-spin" style="font-size:20px; color:#0a82e8;"></i></label>
											  <input type="hidden"  id="serveripvalue<?php echo $i;?>" value="<?php echo $serverip->ServerIP; ?>"/>
                                        </div>
                                    </div>
                                    <?php
                                }
								$i++;
                            }
                            ?>

                            <div class="form-group">
                                <div class="col-lg-offset-4 col-lg-4">
                                    <button type="submit" id="ip_detail1" class="btn btn-danger" <?php if ($edit_button_rights != 1) {
                                echo ' style="color:black;" disabled';
                            } ?>>Submit</button>
                                    <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>

                        </div>
                    </section>
                    <!--user info table end-->
                </div>

                <div class="col-xs-12">
                    <!--user info table start-->
                    <section class="panel">
                        <div class="title">
                            <h3 class="pull-left">Other Server IP Details</h3>
                        </div>
                        <div class="panel-body">
                             <span id="error2" style="color: red;font-size: 20px"></span>

                            <p><i>Notes: THe Connectivity status can be checked for the following servers</i></p>
                            <?php
							$condition = "ExtraIP = 1";
                            $serveripstwo = $this->common_model->getbyCondition("tblserveripdetails", $condition, "", "ServerID", "asc");
							$j=1;
                            foreach ($serveripstwo as $serverip) {
                                if ($serverip->ExtraIP == 1) {
                                    ?>
                                    <div class="form-group">
                                        <label for="Chennai" class="col-lg-4 col-sm-2 control-label"><?php echo $serverip->ServerName; ?></label>
                                        <div class="col-lg-4">
                                            <input name="ServerID[]"  type="hidden" value="<?php echo $serverip->ServerID; ?>">
                                            <input name="ip_detail[]"  type="text" class="form-control ip_detail ip_detail2" placeholder="" value="<?php echo $serverip->ServerIP; ?>" onkeyup="$(this).val($(this).val().replace(/[a-z`~!@#$%^&*()_|+\=?;:,'<>\{\}\[\]\\\/]/gi, ''));" maxlength="15">
                                        </div>
										<div class="col-lg-4">
                                              <label id="serverippings<?php echo $j;?>"><i class="fa fa-circle-o-notch fa-spin" style="font-size:20px; color:#0a82e8;"></i></label>
											  <input type="hidden"  id="serveripvalues<?php echo $j;?>" value="<?php echo $serverip->ServerIP; ?>"/>
                                        </div>
                                    </div>
                                    <?php
                                }
								$j++;
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-lg-4">
                                    <button type="submit" id="ip_detail2" class="btn btn-danger" <?php if ($edit_button_rights != 1) {
                                echo ' style="color:black;" disabled';
                            } ?>>Submit</button>
                                    <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </div>
                    </section>
                    <!--user info table end-->
                </div>
            </form>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script>
var i=1;
var k='<?php echo count($serverips);?>';
loadingserver();
function loadingserver()
{
	var id = "#serveripvalue1";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping1";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping1";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue2";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping2";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping2";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue3";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping3";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping3";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue4";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping4";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping4";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue5";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping5";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping5";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue6";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping6";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping6";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue7";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping7";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping7";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	var id = "#serveripvalue8";
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +k);
			if(res == 1)
			{
				var idval = "#serveripping8";
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serveripping8";
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			/* if(i<=k)
			{
				i++;
				loadingserver();
			} */
		}
	});
	
	
}

var j=1;
var n='<?php echo count($serveripstwo);?>';
loadingservers();
function loadingservers()
{
	
	var id = "#serveripvalues"+j;
	var serverip = $(id).val();
	$.ajax ({
		type: "POST",
		url: "<?php echo site_url('Admin/AjaxForm/checkserverip');?>",
		data:'serverip='+serverip,			 
		success: function(res){
			console.log(res+ " " +n);
			if(res == 1)
			{
				var idval = "#serverippings"+j;
				$(idval).html("<i class='fa fa-check' aria-hidden='true' style='font-size:20px; color:green;'></i>");
			}
			else{
				var idval = "#serverippings"+j;
				$(idval).html("<i class='fa fa-times' aria-hidden='true' style='font-size:20px; color:red;'></i>");
			}
			if(j<=n)
			{ 
				j++;
				loadingservers();
			}
		}
	});
}
</script>
<script type="text/javascript">

        $('#ip_form').find('input.ip_detail1').each(function () {
            $(document).on("change", this, function () {
                if (!isUnique()) {
                    $("#error").html("Same ip address repeated");
                } else {
                    $("#error").html("");
                }
            });
        });

        $(document).on("click", "#ip_detail1", function (event) {
            if (!isUnique()) {
                $("#error").html("enter unique Ip");
                alert("enter unique Ip");
                event.preventDefault();
            }
            else
            {
                $("form").submit(); 
            }
        });
        
        $('#ip_form').find('input.ip_detail2').each(function () {
            $(document).on("change", this, function () {
                if (!isUnique2()) {
                    $("#error2").html("Same ip address repeated");
                } else {
                    $("#error2").html("");
                }
            });
        });

        $(document).on("click", "#ip_detail2", function (event) {
            if (!isUnique2()) {
                $("#error2").html("enter unique Ip");
                alert("enter unique Ip");
                event.preventDefault();
            }
            else
            {
                $("form").submit(); 
            }
        });
        
        function isUnique(tableSelector) {
            // Collect all values in an array
            var values = [];
            $(".ip_detail1").each(function (idx, val) {
                values.push($(val).val().trim());
            });

            // Sort it
            values.sort();
            console.log(values);

            // Check whether there are two equal values next to each other
            for (var k = 1; k < values.length; ++k) {
                if (values[k] == values[k - 1])
                    return false;
            }
            return true;
        }

        function isUnique2(tableSelector) {
            // Collect all values in an array
            var values = [];
            $(".ip_detail2").each(function (idx, val) {
                values.push($(val).val().trim());
            });

            // Sort it
            values.sort();
            console.log(values);

            // Check whether there are two equal values next to each other
            for (var k = 1; k < values.length; ++k) {
                if (values[k] == values[k - 1])
                    return false;
            }
            return true;
        }
</script>

<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(15);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

$(document).ready(function() {
				<?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
 <?php
                                    }
                                    ?>
                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        ip_detail: 'required',
                    }, 
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
                                    <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                       LevelSecurity.showPassword();
                                        if(LevelSecurity.isPasswordOk == false){
                                                return false;
                                        }else
                                        {
                                              form.submit();
                                        }
                                    <?php
                                    }
                                    else{
                                    ?>
                                            form.submit();
                                    <?php
                                    }
                                    ?>
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
				
		  }); 		
	</script>	

</body>
</html>