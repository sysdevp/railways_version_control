<?php

class Admin_Login_Register extends CI_Controller {

    public function __construct() {
        parent::__construct();
        date_default_timezone_set('Asia/Kolkata');
        $nowtime = date('Y-m-d H:i:s', time());
        $interval = 5000;
        if ($this->session->userdata('last_activity') != false) {
            if ($this->session->userdata('last_activity') < time() - $interval) {
                
            } else {
                $datas['last_activity'] = time();
                $this->session->set_userdata($datas);
                redirect(site_url() . 'Admin');
            }
        }
    }

    public function login() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Login";
        $data['title'] = "Login";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('LoginPassword', 'Password', 'trim|required|min_length[4]');
            $this->form_validation->set_rules('LoginName', 'Login Name', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                $data['validation'] = validation_errors();
                $data['color_code'] = "#c50000";
                $data['message'] = $data['validation'];
                $data['display_value'] = "block";
            } else {
                $username = $this->input->post('LoginName');
                $password = $this->input->post('LoginPassword');
                $field = 'LoginName';
                $table = "tblusermaster";
                $is_valid = $this->common_model->find_details("LoginName = '".$username."'", $table);
                if ($is_valid) {
                    $role_array = array();
                    foreach ($is_valid as $rows) {
                        $decrypt = $this->encryption->decrypt($rows['LoginPassword']);
                    }
                    $name = $rows['EmployeeName'];
                    $id = $rows['UserID'];
                    $times = time();
                    if ($decrypt === $password) {
                        $datas = array(
                            'name_session_list' => $name,
                            'is_admin' => 0,
                            'id_session_list' => $id,
                            'last_activity' => $times,
                            'railway_session_list' => $rows['RailwayID'],
                            'division_session_list' => $rows['DivisionID'],
                            'station_session_list' => $rows['StationID'],
                            'is_logged_in_session' => true
                        );
                        $data['message'] = "Login Success";
                        $data['color_code'] = "#57b91b";
                        $data['display_value'] = "block";
                        $this->session->set_userdata($datas);
                        $datatostore = array(
                            'UserID' => $id,
                            'LoginDate' => date("Y-m-d"),
                            'Intime' => date("Y-m-d H:i:s"),
                        );
                        $this->common_model->store_details($datatostore, "tbluserloggedindetails");
                        redirect(site_url() . 'Admin');
                    } else {
                        $data['message'] = "Login Failed: Incorrect Password";
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['flash_message'] = FALSE;
                        $data['login_error'] = TRUE;
                    }
                } else { // incorrect username or password                    
                    $data['flash_message'] = FALSE;
                    $data['message'] = "Incorrect Username Or Password";
                    $data['display_value'] = "block";
                    $data['color_code'] = "#c50000";
                }
            }
        }
        $this->load->view('Admin/login', $data);
    }

    public function logout() {
        $this->session->unset_userdata('name_session_list');
        $this->session->unset_userdata('is_admin');
        $this->session->unset_userdata('id_session_list');
        $this->session->unset_userdata('last_activity');
        $this->session->unset_userdata('code_session_list');
        $this->session->unset_userdata('is_logged_in_session');
        redirect(site_url() . 'login');
    }

}
