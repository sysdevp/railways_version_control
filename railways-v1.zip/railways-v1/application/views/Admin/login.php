<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">


        <link rel="shortcut icon" href="img/favicon.html">

        <title>Login</title>

        <!-- Bootstrap core CSS -->
        <link href="<?php echo $asset_url; ?>css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo $asset_url; ?>css/bootstrap-reset.css" rel="stylesheet">
        <!--external css-->
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />
        <!-- Custom styles for this template -->
        <link href="<?php echo $asset_url; ?>css/style.css" rel="stylesheet">
        <link href="<?php echo $asset_url; ?>css/mystyle.css" rel="stylesheet">
        <link href="<?php echo $asset_url; ?>css/style-responsive.css" rel="stylesheet" />

        <!-- HTML5 shim and Respond.js IE8 support of HTML5 tooltipss and media queries -->
        <!--[if lt IE 9]>
        <script src="<?php echo $asset_url; ?>js/html5shiv.js"></script>
        <script src="<?php echo $asset_url; ?>js/respond.min.js"></script>
        <![endif]-->
    </head>

    <body class="login-body">

        <div class="container">
            <div class="col-md-8 col-xs-12">
          <!--<h2 class="login_page_content">Electronic Interlocking - Application Management Software<p>Powered by Mazenet</p></h2> -->
            </div>
            <form class="form-signin" action="" method="POST">
               
                <div style="text-align: center;padding: 15px; margin-top: 20px;"><img src="<?php echo $asset_url; ?>img/logo.png" style="max-width:120px;"></div>
                <h3 id="message_val" style="margin: 10px 0;text-align: center;width: 100%;padding:10px;color:#fff;display: <?php echo $display_value; ?>;min-height: 50px;margin-top: 0;background:<?php echo $color_code; ?>">
                    <?php echo $message; ?>
                    <i class="fa fa-close" style="float:right;margin-top: 0px;" onclick="close_header()"></i>
                </h3>
                <h2 class="form-signin-heading">sign in now</h2>
                <div class="login-wrap">
                    <input type="text" name="LoginName" class="form-control" placeholder="User ID" autofocus value="">
                    <input type="password" id="LoginPassword" name="LoginPassword" class="form-control valid" placeholder="Password">
                    <!-- <label class="checkbox">
                        <input style="float: left;margin-top: 2px;margin-right: 3px;" type="checkbox" value="remember-me"> Remember me
                        <span class="pull-right">
                           <a data-toggle="modal" href="#myModal"> Forgot Password?</a>
                        </span>
                    </label> -->
                    <button class="btn btn-lg btn-login btn-block" type="submit">Login</button>
                </div>
            </form>
            <!-- Modal -->
            <div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                            <h4 class="modal-title">Forgot Password ?</h4>
                        </div>
                        <div class="modal-body">
                            <p>Enter your e-mail address below to reset your password.</p>
                            <input type="text" name="email" placeholder="Email" autocomplete="off" class="form-control placeholder-no-fix">

                        </div>
                        <div class="modal-footer">
                            <button data-dismiss="modal" class="btn btn-default" type="button">Cancel</button>
                            <button class="btn btn-success" type="button">Submit</button>
                        </div>
                    </div>
                </div>
            </div>
            <!-- modal -->
        </div>
        <!-- js placed at the end of the document so the pages load faster -->
        <script src="<?php echo $asset_url; ?>js/jquery.js"></script>
        <script>
          //  document.getElementById("LoginPassword").defaultValue = "admin@01";

        </script>
        <script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
    </body>
</html>
