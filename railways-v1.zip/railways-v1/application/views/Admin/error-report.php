<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Error Report</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form">
                            <div class="form-group">
                                <label class="col-lg-2 col-sm-2 control-label">Select user</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-show-subtext="true" data-live-search="true">
                                        <option>1</option>
                                        <option>2</option>
                                        <option>3</option>
                                        <option>4</option>
                                        <option>5</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SelectDate" class="col-lg-2 col-sm-2 control-label">Select Date</label>
                                <div class="col-lg-4">
                                    <input type="date" class="form-control" id="SelectDate">
                                </div>
                            </div>
                        </form>
                        <ul class="pull-right col-sm-12 text-right">
                            <li class="pull-right" style="margin-left: 10px;"><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download PDF</button></li>
                            <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                        </ul>
                        <div class="adv-table">

                            <table class="display table table-bordered table-striped view_version" id="dynamic-table">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Date</th>
                                        <th>User Login</th>
                                        <th>IP Address</th>
                                        <th>Error On</th>
                                        <th>Error Details</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>22/05/2018</td>
                                        <td>Suguna</td>
                                        <td>191.15.18.2</td>
                                        <td>Version Update</td>
                                        <td>Application Checksum folder does not match with predefined value</td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>28/05/2018</td>
                                        <td>Vinoth</td>
                                        <td>191.15.17.2</td>
                                        <td>Login</td>
                                        <td>Invalid Login Attempt</td>
                                    </tr>
                                    <tr>
                                        <td>3</td>
                                        <td>30/05/2018</td>
                                        <td>Ravi</td>
                                        <td>191.15.81.2</td>
                                        <td>Vresion Update</td>
                                        <td>Session Expired</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

</body>
</html>