<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
						<p class="pull-left"><?php if($create_button_rights != 1) { ?>Note: Only Authorized users can create new Role<?php } ?></p>
                        
                        <ul class="pull-right">
							<li><button onclick="location.href='<?php echo site_url(); ?>Admin/create-role'" type="button" class="btn btn-info" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Create New Role</button></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<h3 class="pull-left">User Roles</h3>
						<?php if($this->session->flashdata("success_done")) { ?>
                         <h3 class="success_done" onclick="close_success()" id="message_val"  style="background:#3a5a9c;">
                            <?php echo $this->session->flashdata("success_done"); ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th colspan="4"></th>
                                        <th colspan="5" class="text-center">Permissions</th>
                                        <th></th>
                                    </tr>
                                    <tr>
                                        <th>S.No</th>
                                        <th>Level </th>
                                        <th>Designation </th>
                                        <th>Role Description</th>
                                        <th>View</th>
                                        <th>Create</th>
                                        <th>Edit</th>
                                        <th>Delete</th>
                                        <th>Approve/Reject</th>
                                        <th> Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($user_rights as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td ><?php echo $rows['LevelName']; ?></td>
                                            <td ><?php echo $rows['DesignationName']; ?></td>
                                            <td ><?php echo $rows['RoleDescription']; ?></td>
                                            <td ><?php echo ($rows['View']==1?"<i class='fa fa-check tickmark green' aria-hidden='true'></i>":"<i class='fa fa-times tickmark red' aria-hidden='true'></i>"); ?></td>
                                            <td ><?php echo ($rows['Save']==1?"<i class='fa fa-check tickmark green' aria-hidden='true'></i>":"<i class='fa fa-times tickmark red' aria-hidden='true'></i>"); ?></td>
                                            <td ><?php echo ($rows['Edit']==1?"<i class='fa fa-check tickmark green' aria-hidden='true'></i>":"<i class='fa fa-times tickmark red' aria-hidden='true'></i>"); ?></td>
                                            <td ><?php echo ($rows['Remove']==1?"<i class='fa fa-check tickmark green' aria-hidden='true'></i>":"<i class='fa fa-times tickmark red' aria-hidden='true'></i>"); ?></td>
                                            <td ><?php echo ($rows['Approve_Reject']==1?"<i class='fa fa-check tickmark green' aria-hidden='true'></i>":"<i class='fa fa-times tickmark red' aria-hidden='true'></i>"); ?></td>
                                            <td>     
                                            <?php if($rows['DesignationName'] !="Admin")
                                            {?>
                                                <a href="<?php echo site_url(); ?>Admin/edit-role/<?php echo $rows['LevelID']; ?>/<?php echo $rows['DesignationID']; ?>/<?php echo $rows['UserRoleID']; ?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                                <a href="javascript:void(0)" onclick="deleterole('<?php echo $rows['LevelID']; ?>', '<?php echo $rows['DesignationID']; ?>', '<?php echo $rows['UserRoleID']; ?>')"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                                <?php
                                            }
                                            ?>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>

                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<!-- Modal -->
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Heading</h4>
            </div>
            <div class="modal-body">
                <p>Popup Content</p>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- modal -->


<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>
	function close_success(){
		$(".success_done").remove();
	   }
</script>
<script>

var glid = 0, gdid = 0, grid = 0;
function confirm_userole_admin()
{
	$.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-role'); ?>",
                data: {
                    lid: glid,
                    did: gdid,
                    rid: grid,
                },
                success: function (res) {
                    console.log(res);
                    if(res==1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/user-rights";
                    }
                    else
                    {
                        alert("This record cannot be deleted");
                    }
                }
            });
}
    function deleterole(lid, did, rid)
    {
    	glid = lid;
    	gdid = did;
    	grid = rid;
    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}else{
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-role'); ?>",
                data: {
                    lid: lid,
                    did: did,
                    rid: rid,
                },
                success: function (res) {
                    console.log(res);
                    if(res==1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/user-rights";
                    }
                    else
                    {
                        alert("This record cannot be deleted");
                    }
                }
            });
        
        }
    }
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(13);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password_for_delete',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(true);
				LevelSecurity.triggerChange = function(){
					deleterole(glid, gdid, grid)
				}
			});

</script>
</body>
</html>

