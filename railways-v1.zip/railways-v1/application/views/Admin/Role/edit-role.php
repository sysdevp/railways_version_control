<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Edit Role</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/user-rights" class="btn btn-info">View Roles</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <form class="form-horizontal" role="form" method="POST">
                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <?php
                            foreach($user_rights as $mainrows)
                            {
                                $LevelID = $mainrows['LevelID'];
                                ?>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Level</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="LevelID" data-show-subtext="true" data-live-search="true" onchange="levelChg(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        $rcond = false;
                                        foreach ($level as $rows) {
                                            ?>
                                            <option <?php if ($LevelID == $rows['LevelID']) {
                                            $rcond = true;
                                            echo "selected";
                                        } echo set_select("LevelID", $rows['LevelID'], FALSE); ?> value="<?php echo $rows['LevelID']; ?>"><?php echo $rows['LevelName']; ?></option>
    <?php
}
?>
                                    </select>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('LevelID'); ?></label>
                            </div>
							<script>
								function levelChg(val)
								{
									var LevelID = val;
								 
									 $.ajax({
											type: "POST",
											url: "<?php echo site_url('Admin/Level_Chg_Designation'); ?>",
											data: {
												did: LevelID
											},
											success: function (res) {
												if (res != 0)
												{
													$(".designation_div").html(res);
													$(".selectpicker").selectpicker();
												}
											}
										});
								}
							</script>
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">Designation Name</label>
                                <div class="col-lg-4 designation_div">
                                    <select class="form-control selectpicker" id="DesignationID" data-show-subtext="true" data-live-search="true" name="DesignationID">
                                        <option value="">Select Option</option>
                                        <?php
                                        $DesignationID = $mainrows['DesignationID'];
                                        foreach ($designation as $rows) {
                                            ?>
                                            <option <?php if ($DesignationID == $rows['DesignationID']) {
                                            $rcond = true;
                                            echo "selected";
                                        } echo set_select("DesignationID", $rows['DesignationID'], FALSE); ?> value="<?php echo $rows['DesignationID']; ?>"><?php echo $rows['DesignationName']; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>

                                </div>
                                <label class="col-sm-6"><?php echo form_error('DesignationID'); ?></label>
                            </div>
                            
                            <div class="form-group">
                                <label for="inputPassword3" class="col-sm-2 control-label">Rights</label>
                                <div class="col-sm-6" style="padding-top:6px">
                                    <label>
                                        <input type="checkbox" class="minimal" name="View" value="Y" <?php if($mainrows['View']==1){echo "checked";}?>>
                                        View
                                    </label>
                                    &nbsp;
                                    <label>
                                        <input type="checkbox" class="minimal" name="Save" value="Y" <?php if($mainrows['Save']==1){echo "checked";}?>>
                                        Create
                                    </label>


                                    &nbsp;
                                    <label>
                                        <input type="checkbox" class="minimal" name="Edit" value="Y" <?php if($mainrows['Edit']==1){echo "checked";}?>>
                                        Edit
                                    </label>
                                    &nbsp;
                                    <label>
                                        <input type="checkbox" class="minimal" name="Remove" value="Y" <?php if($mainrows['Remove']==1){echo "checked";}?>>
                                        Delete
                                    </label>
                                    &nbsp;
                                    <label>
                                        <input type="checkbox" class="minimal" name="Approve_Reject" <?php if($mainrows['Approve_Reject']==1){echo "checked";}?> value="Y">
                                        Approve
                                    </label>
                                </div>

                            </div>
                            <div class="form-group">
                                <label for="Description" class="col-lg-2 col-sm-2 control-label">Description</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" name="RoleDescription" id="Description" placeholder="" value="<?php echo $mainrows["RoleDescription"];?>">
                                </div>
                                <label class="col-sm-6"><?php echo form_error('RoleDescription'); ?></label>
                            </div>
                            <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                     <a href="<?php echo site_url(); ?>Admin/user-rights" class="btn btn-default">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<!-- Modal -->
<div aria-hidden="true" aria-labelledby="myModalLabel" role="dialog" tabindex="-1" id="myModal" class="modal fade">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Heading</h4>
            </div>
            <div class="modal-body">
                <p>Popup Content</p>
            </div>
            <div class="modal-footer">
                <button data-dismiss="modal" class="btn btn-default" type="button">Close</button>
            </div>
        </div>
    </div>
</div>
<!-- modal -->


<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(14);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>

<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

$(document).ready(function() {
				<?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
 <?php
                                    }
                                    ?>
                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        LevelID: 'required',
                        DesignationID: 'required'
                    }, 
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
                                    <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                       LevelSecurity.showPassword();
                                        if(LevelSecurity.isPasswordOk == false){
                                                return false;
                                        }
                                        else
                                        {
                                              form.submit();
                                        }
                                    <?php
                                    }
                                    else{
                                    ?>
                                            form.submit();
                                    <?php
                                    }
                                    ?>
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
				
		  }); 		
				
				

</script>

</body>
</html>

