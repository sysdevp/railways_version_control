<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 
 $module_security = $this->common_model->find_details(array("menu_id"=>1),"tbl_menu_security_setting","security_level")[0]["security_level"];

?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View Log In Activity</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form" method="POST">
                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Date <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input type="text" required class="form-control mydatepicker_range" name="date" placeholder="date" value="<?php echo set_value("date");?>">
                                </div>
                                <label class="col-sm-6 red"><?php echo form_error('date'); ?></label>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">Select User <span class="red">(*)</span></label>
                                <div class="col-lg-4 user_div">   
									<?php if (isset($user)) { ?>
                                    <select class="form-control selectpicker" data-validation="required" id="UserID" data-show-subtext="true" data-live-search="true" name="UserID">
                                        <option value="">Select Option</option>
                                        <!-- <option value="All" selected> All</option> -->
                                        <?php
                                        foreach ($user as $rows) {
                                            ?>
                                            <option <?php echo set_select("UserID", $rows['UserID'], FALSE);?> value="<?php echo $rows['UserID']; ?>"><?php echo $rows['EmployeeName'] . " (" . $rows['LoginName'] . ")"; ?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
									
									<?php
                                    }
                                    ?>   
									
									
                                </div>
                                <label class="col-sm-6 red"><?php if(form_error('UserID') != '' ) { echo "This field is required"; } ?></label>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                   <button type="submit" class="btn btn-danger">Submit</button>
                                   <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                        <br><br><br>
                        <div class="col-sm-12 adv-table">
                            <table class="display table table-bordered table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Employee Name</th>
                                        <th>Level Name</th>
                                        <th>Designation Name</th>
                                        <th>Login Time</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($userloggedindetails as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['EmployeeName']." (".$rows['LoginName'].")"; ?></td>
                                            <td><?php echo $rows['LevelName']; ?></td>
                                            <td><?php echo $rows['DesignationName']; ?></td>
                                            <td><?php echo $rows['InTime']; ?></td>
                                            
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<!--<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>-->
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo $asset_url; ?>assets/datepicker/moment/min/moment.min.js"></script>
<script src="<?php echo $asset_url; ?>assets/datepicker/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- End of bootstrap-daterangepicker -->
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>

   







                function deletesecuritysettings(id)
                {
                var answer = confirm("Are you sure you want to delete from this Zone?");
                if (answer)
                {
                $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-securitysettings'); ?>",
                data: {
                id: id,
                },
                success: function (res) {
                if (res == 1)
                {
                window.location = "<?php echo site_url(); ?>Admin/view-securitysettings";
                }
                else
                {
                alert("Failed to delete");
                }
                }
                });
                }
                }
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>

<script>
    $(document).ready(function () {
        
        //var start = moment().subtract(29, 'days');
    //var end = moment();
     var start = moment();
    var end = moment();

    function cb(start, end) {
        $('.mydatepicker_range').val(start.format('DD-MM-YYYY') + ' - ' + end.format('DD-MM-YYYY'));
    }

    $('.mydatepicker_range').daterangepicker({
        startDate: start,
        endDate: end,
        calender_style: "picker_4",
          maxDate: new Date(),
          locale: {
            format: 'DD-MM-YYYY'
        },
        ranges: {
           'Today': [moment(), moment()],
           'Yesterday': [moment().subtract(1, 'days'), moment().subtract(1, 'days')],
           'Last 7 Days': [moment().subtract(6, 'days'), moment()],
           'Last 30 Days': [moment().subtract(29, 'days'), moment()],
           'This Month': [moment().startOf('month'), moment().endOf('month')],
           'Last Month': [moment().subtract(1, 'month').startOf('month'), moment().subtract(1, 'month').endOf('month')]
        }
    }, cb);

    cb(start, end);
        
        
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>


<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(1);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>

<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () { 
 <?php
					if($this->session->userdata("UserRole")!="Admin")
					{?>
		LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
		LevelSecurity.init(false); 
					<?php }
					?>
		$.validator.setDefaults({
			ignore: []
		});        
		$('.form-horizontal').validate({
			errorElement: 'span',
			errorClass: 'error',
			ignore: [], 
			lang: 'en',
			rules: {
				DivisionName:'required',
			},  
			submitHandler: function(form) {
				if($(".form-horizontal").valid()==true)
				{
					<?php
					if($this->session->userdata("UserRole")!="Admin")
					{?> 
						LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}
						else{
							form.submit();
						}
					<?php
					}
					else{
					?>
						form.submit();
					<?php
					}
					?>
				}
				else{ 
					return false;
				}
			}
		});    
		$('select').on('change', function() {
			$(this).valid();
		});    
	}); 
	</script>
<script>

/*$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
				
				$.validate({
                    lang: 'en',
                    modules: 'security',
                    onError : function($form) {
                    	console.log($form);
                    },
                    onSuccess : function($form) {
                    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}
                    }});
				
			});*/

</script>


</body>
</html>

