<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Edit Version</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version" class="btn btn-info">View Version</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal add_new_version_form" role="form" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code</label>
                                <div class="col-lg-10">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)" required="">
                                        <option value="">Select Option <?php echo $version[0]['RailwayID']; ?></option>
                                        <?php
                                        $RailwayID = $version[0]['RailwayID'];
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php
                                            if ($RailwayID == $rows['RailwayID']) {
                                                $rcond = true;
                                                echo "selected";
                                            }
                                            if (isset($RailwayIDPreview)) {
                                                if ($RailwayIDPreview == $rows['RailwayID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            echo set_select("RailwayID", $rows['RailwayID'], FALSE);
                                            ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code</label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    $dcond = false;
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($rcond == true) {
                                        $DivisionID = $version[0]['DivisionID'];
                                        ?>
                                        <select class="form-control selectpicker"  required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID"  onchange="division_chg_station(this.value)">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division_div as $rows) {
                                                ?>
                                                <option <?php
                                                if ($DivisionID != "" && $DivisionID != 0 && $DivisionID == $rows['DivisionID']) {
                                                    $dcond = true;
                                                    echo "selected";
                                                } echo set_select("DivisionID", $rows['DivisionID'], FALSE);
                                                ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                   
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                                <label for="StationName" class="col-sm-2 control-label">Station Name / Code</label>
                                <input type="hidden" name="VersionID" id="VersionID" value="<?php echo $version[0]["VersionID"]; ?>"    />
                                <div class="col-lg-4 station_div">
                                    <?php
                                    if (isset($station)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($dcond == true) {
                                        $StationID = $version[0]["StationID"];
                                        ?>  
                                        <select class="form-control selectpicker" required=""  id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station_div as $rows) {
                                                ?>
                                                <option <?php
                                                if ($StationID != "" && $StationID != 0 && $StationID == $rows['StationID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                } echo set_select("StationID", $rows['StationID'], FALSE);
                                                ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                  
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" required=""  data-show-subtext="true" data-live-search="true" name="VendorID" onchange="vendorChg(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        foreach ($vendor as $rows) {
                                            ?>
                                            <option <?php
                                            if (isset($VendorIDPreview)) {
                                                if ($VendorIDPreview != "" && $VendorIDPreview != 0 && $VendorIDPreview == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            $VendorID = $version[0]['VendorID'];
                                            if (isset($VendorID)) {
                                                if ($VendorID != "" && $VendorID != 0 && $VendorID == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            } echo set_select("VendorID", $rows['VendorID'], FALSE);
                                            ?> value="<?php echo $rows['VendorID']; ?>"><?php echo $rows['VendorName'] . $VendorID; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('VendorID'); ?></label>
                                </div>
                                <div id="distributed">
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="col-sm-3">
                                            <input id="DistributedYes" type="radio" name="isDistributedVersionType" value="1" <?php
                                            if ($version[0]['isDistributedVersionType'] == "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedYes">Yes</label>
                                        </div>
                                        <div class="col-sm-3">
                                            <input id="DistributedNo" type="radio" name="isDistributedVersionType" value="0"  <?php
                                            if ($version[0]['isDistributedVersionType'] != "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedNo">No</label>
                                        </div>
                                        <label class="col-sm-12"><?php echo form_error('isDistributedVersionType'); ?></label>
                                    </div>
                                </div>
                               </div>
                            </div>
                            <div class="form-group">
                            	<div id="signaling_plan_no">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number</label>
                                <div class="col-lg-4">
                                    <input type="text" name="SignalPlanNumber" required=""  class="form-control" id="SignalingPlanNumber" placeholder="Signaling Plan Number" value="<?php echo $version[0]['SignalPlanNumber']; ?>">
                                    <label class="col-sm-12"><?php echo form_error('SignalPlanNumber'); ?></label>
                                </div>
                                </div>
                                <div id="dateofinstallation">
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation</label>
                                <div class="col-lg-4">
                                    <input type="date" name="InstallationAlterationDate" required=""  class="form-control" id="DateInstallation" required="required" value="<?php echo $version[0]['InstallationAlterationDate']; ?>">
                                    <label class="col-sm-12"><?php echo form_error('InstallationAlterationDate'); ?></label>
                                </div>
                                </div>
                            </div>
                            <div class="form-group" id="description_of_work">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work</label>
                                <div class="col-lg-10">
                                    <input type="text" name="DescriptionOfWork" required=""  class="form-control" id="ReasonChanging" placeholder="Description of Work" value="<?php echo $version[0]['DescriptionOfWork']; ?>">
                                    <label class="col-sm-12"><?php echo form_error('DescriptionOfWork'); ?></label>
                                </div>
                            </div> 
                            <div class="form-group" id="work_executed_up_by">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed up by</label>
                                <div class="col-lg-4">
                                    <input type="text" name="WorkExecutedBy" required=""  class="form-control" id="WorkExcuited" placeholder="Work Executed up by" value="<?php echo $version[0]['WorkExecutedBy']; ?>">
                                    <label class="col-sm-12"><?php echo form_error('WorkExecutedBy'); ?></label>
                                </div>
                            </div>
                            <div class="form-group" id="executive_software">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Executive Software</th>
                                                <th>Vesion</th>
                                                <th>Checksum / CRC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Pervious Executive Software</td>
                                                <td>
                                                    <input type="text" name="PreviousESwVersion" id="PreviousESwVersion" readonly="" class="form-control"  value="<?php echo $version[0]['PreviousESwVersion']; ?>">
                                                    <label class="col-sm-12"><?php echo form_error('PreviousESwVersion'); ?></label>
                                                </td>
                                                <td>
                                                    <input type="text" name="PreviousESwChecksum" id="PreviousESwChecksum" readonly="" class="form-control"  value="<?php echo $version[0]['PreviousESwChecksum']; ?>">                                             
                                                    <label class="col-sm-12"><?php echo form_error('PreviousESwChecksum'); ?></label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>updated Executive Software</td>
                                                <td>
                                                    <input type="text" name="CurrentESwVersion" required=""  id="CurrentESwVersion" readonly="" class="form-control" value="<?php echo $version[0]['CurrentESwVersion']; ?>">
                                                    <label class="col-sm-12"><?php echo form_error('CurrentESwVersion'); ?></label>
                                                </td>
                                                <td>
                                                    <input type="text" name="CurrentESwChecksum" required=""  id="CurrentESwChecksum" class="form-control" value="<?php echo $version[0]['CurrentESwChecksum']; ?>">  
                                                    <label class="col-sm-12"><?php echo form_error('CurrentESwChecksum'); ?></label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group" id="noofcpu">
                                <label class="col-sm-2 control-label">No of CPU's</label>
                                <div class="col-lg-4">
                                    <input type="number" name="NoOfCPU" id="insert-rows-amnt" class="form-control NoOfCPU" min="0" max="15"  value="<?php echo $version[0]['NoOfCPU']; ?>"/>
                                    <label class="col-sm-12"><?php echo form_error('NoOfCPU'); ?></label>
                                    <!--<button id="add-row" type="button">Add Rows</button>-->
                                </div>
                                <div class="col-sm-12">
                                    <style>
                                        .NumberCpu {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .NumberCpu td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                    </style>
                                    <table style="<?php
                                    if (count($cpu_details) == 0) {
                                        ?>display: none;<?php } ?>" class="mtop20 NumberCpu table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="text-center" colspan="2">Vital</th>
                                                <th class="text-center" colspan="2">Non Vital</th>
                                                <th></th>
                                            <tr>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                            <tr>
                                        </thead>
                                        <tbody class="dynamic">
                                            <?php
                                            if (count($cpu_details) > 0) {
                                                foreach ($cpu_details as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td></td>
                                                        <td><input type="text" name="PreviousVital[]" class="form-control" value="<?php echo $subrows['PreviousVital']; ?>" readonly="" /></td>
                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="<?php echo $subrows['CurrentVital']; ?>" /></td>
                                                        <td><input type="text" name="PreviousNonVital[]" class="form-control" value="<?php echo $subrows['PreviousNonVital']; ?>" readonly="" /></td>
                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="<?php echo $subrows['CurentNonVital']; ?>" /></td>
                                                        <td>
                                                            <input type="hidden" class="cpuVendorID" value="<?php echo $subrows['VendorID']; ?>"/>
                                                            <input type="hidden" class="cpuRailwayID" value="<?php echo $subrows['RailwayID']; ?>"/>
                                                            <input type="hidden" class="cpuDivisionID" value="<?php echo $subrows['DivisionID']; ?>"/>
                                                            <input type="hidden" class="cpuStationID" value="<?php echo $subrows['StationID']; ?>"/>
                                                            <input type="hidden" class="cpuVersionID" value="<?php echo $subrows['VersionID']; ?>"/>
                                                            <input type="hidden" class="cpuID" value="<?php echo $subrows['CpuNo']; ?>"/>
                                                            <a class="label label-info label-mini remove_this_row_cpu btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tbody class="static">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
							
							<div class="form-group" id="software_file_upload">
                                	<label class="col-sm-2 control-label">Software File</label>
                                	<div class="col-lg-10">
                                		<div class="dropzone" id="SoftwareFile" name="mainFileUploader_SoftwareFile"></div>
                                		<input type="hidden" name="SoftwareFileDownloadPath" id="SoftwareFileDownloadPath" value="<?php echo $this->session->userdata('SoftwareFileDownloadPath'); ?>"/>
                                		<label class="cls red SoftwareLogic" style="margin-left: 15px;"></label>
                                	</div>
                                </div>

                            <div class="form-group" id="certificates">
                                    <label class="col-sm-2 control-label">Certificates</label>
                                    <div class="col-lg-10">
                                        <input type="hidden" id="CertificateFilePath" name="CertificateDownloadPath" value="<?php echo $this->session->userdata('CertificateDownloadPath'); ?>">
                                        <div class="dropzone" id="CertificateFile" name="mainFileUploader_VduFile">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group" id="other_uploads">
                                    <label class="col-sm-2 control-label">Others</label>
                                    <div class="col-lg-10">
                                        <input type="hidden" id="OthersDownloadPath" name="OthersDownloadPath" value="<?php echo $this->session->userdata('OthersDownloadPath'); ?>">
                                         <div class="dropzone" id="OthersDownloadFile" name="OthersDownloadFile">
                                        </div>
                                    </div>
                                </div>
                             <?php
                                foreach($fields as $field){ if($field["is_autofield"] == 1){
                                	$field_value = "";
                                	foreach($cust_field as $custom_field){
                                	if($field['field_name'] == $custom_field['field_name']){
                                		$field_value = $custom_field['field_value'];
                                	}
									}
                                	?>
                                	<div class="form-group" id="<?php echo $field["field_name"]; ?>">
                                <label class="col-sm-2 control-label" for="inputSuccess"><?php echo $field["field_display_name"]; ?></label>
                                <div class="col-lg-4">
                                    <input type="text" name="<?php echo $field["field_name"]; ?>" class="form-control" placeholder="<?php echo $field["field_display_name"]; ?>" value="<?php echo $field_value; ?>">
                                    <label class="col-sm-12"><?php echo form_error($field["field_name"]); ?></label>
                                </div>
                            </div><?php } } ?>
                            
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <style>
                                        .upload_add_row {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .upload_add_row td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                        .upload_add_row tr:first-child td:last-child a:last-child{
                                            pointer-events: none;
                                            opacity: 0.5;
                                        }
                                    </style>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Name</th>
                                                <th>Value</th>
                                                <th>Add</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if (count($parameter_details) > 0) {
                                                foreach ($parameter_details as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td></td>
                                                        <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value="<?php echo $subrows['ParameterName']; ?>"></td>
                                                        <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value="<?php echo $subrows['ParameterValue']; ?>"></td>
                                                        <td>
                                                            <input type="hidden" class="parameterVendorID" value="<?php echo $subrows['VendorID']; ?>"/>
                                                            <input type="hidden" class="parameterRailwayID" value="<?php echo $subrows['RailwayID']; ?>"/>
                                                            <input type="hidden" class="parameterDivisionID" value="<?php echo $subrows['DivisionID']; ?>"/>
                                                            <input type="hidden" class="parameterStationID" value="<?php echo $subrows['StationID']; ?>"/>
                                                            <input type="hidden" class="parameterVersionID" value="<?php echo $subrows['VersionID']; ?>"/>
                                                            <input type="hidden" class="parameterID" value="<?php echo $subrows['ParameterId']; ?>"/>
                                                            <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                            <a class="label label-info label-mini remove_this_row btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {
                                                ?>
                                                <tr>
                                                    <td></td>
                                                    <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value=""></td>
                                                    <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value=""></td>
                                                    <td>
                                                        <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                        <a data-action="remove_this_row"  class="label label-info label-mini btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-4  mtop20 checkbox_customize">                                  
                                    <input type="submit" class="btn btn-warning preventbtn" value="Preview"/>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>


<?php
if (count($version_logic) > 1) {
    ?>
                                            var cpu_det =<?php echo json_encode($version_logic[1]['cpu_det']); ?>;
    <?php
} else {
    ?>
                                            var cpu_det;
    <?php
}
?>
                                        var Applicationfileerr = false;
                                        var Interfacefileerr = false;
                                        var softwareFileerr = true; 
                                        var Vdufileerr = false;
                                        function zone_chg_division(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                                                data: {
                                                    id: id,
                                                    multiple: 1
                                                },
                                                success: function (res) {
                                                    $(".division_div").html("");
                                                    $(".station_div").html("");
                                                    if (res != 0)
                                                    {
                                                        $(".division_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }


                                        function division_chg_station(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                                                data: {
                                                    id: $("#RailwayID").val(),
                                                    did: id
                                                },
                                                success: function (res) {
                                                    if (res != 0)
                                                    {
                                                        $(".station_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }

                                        function vendorChg(id)
                                        {
                                            if ($("#RailwayID").val() == "" || $("#DivisionID").val() == "" || $("#StationID").val() == "")
                                            {
                                                alert("Please Choose Above Details");
                                            } else
                                            {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo site_url('Admin/Vendor_Chg_Version'); ?>",
                                                    data: {
                                                        id: $("#RailwayID").val(),
                                                        did: $("#DivisionID").val(),
                                                        sid: $("#StationID").val(),
                                                        vid: id
                                                    },
                                                    success: function (res) {
                                                        var data = JSON.parse(res);
                                                        console.log(data);
                                                        if (data == 2 || data == 0)
                                                        {
                                                            $("#PreviousESwChecksum").val("");
                                                            $("#PreviousESwVersion").val("");
                                                            $("#CurrentESwVersion").val("");
                                                            $("#VersionID").val("");

                                                            $("#SoftwareFileDownloadPath").val("");
                                                        }
                                                        else
                                                        {
                                                            if (data.length > 1)
                                                            {
                                                                cpu_det = data[1].cpu_det;
                                                                $("#PreviousESwChecksum").val(data[1].CurrentESwChecksum);
                                                                $("#PreviousESwVersion").val(data[1].VersionNo);
                                                            } else if (data.length > 0)
                                                            {
                                                                console.log(data);
                                                                $("#PreviousESwChecksum").val(data[0].PreviousESwChecksum);
                                                                $("#PreviousESwVersion").val(data[0].PreviousESwVersion);
                                                            }
                                                            $("#CurrentESwVersion").val(data[0].VersionNo);
                                                            $("#VersionID").val(data[0].VersionID);

                                                            $("#SoftwareFileDownloadPath").val(data[0].softwarefileDownloadPath);
                                                        }
                                                    }
                                                });
                                                
                                                getVendorFields(id);
                                            }
                                        }

                                        var maxField = 25; //Input fields increment limitation
                                        var addButton_more = $('.add_button_more'); //Add button selector
                                        var wrapper_more = $('.field_wrapper_more'); //Input field wrapper
                                        var fieldHTML_more = '<div class="row with-forms"><div class="col-md-5"><h5>Title</h5><input type="text" name="product_info_title[]" placeholder="Enter Title"></div><div class="col-md-5"><h5>Value</h5><input type="text" name="product_info_value[]" placeholder="Enter Value"></div><a href="javascript:void(0);" class="remove_button" title="Remove field"><img class="rem_field_img" src="http://localhost/Admin/assets/img/remove-icon.png"/></a></div>'; //New input field html 
                                        var x = 1; //Initial field counter is 1


                                        $('#insert-rows-amnt').blur(function () {
                                            var numNewRows = parseInt($('#insert-rows-amnt').val(), 10);

                                            console.log(numNewRows);
                                            if (isNaN(numNewRows) || numNewRows <= 0) {
                                                alert('Please enter number of rows to insert');
                                            } else if (numNewRows > 15)
                                            {
                                                alert('Maximum 15 Rows only can add');
                                            } else {
                                                $(".NumberCpu").show();
                                                // numNewRows = numNewRows - $('.dynamic tr').length;
                                                $tbody = $('.NumberCpu tbody.static');
                                                var trdetails = "";
                                                for (i = 0; i < numNewRows; i++)
                                                {
                                                    trdetails = trdetails + '<tr>\n\
                                                                        <td></td>\n\
                                                                        <td><input type="text" name="PreviousVital[]" class="form-control" value="" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="" /></td>\n\
                                                                        <td><input type="text" name="PreviousNonVital[]" class="form-control" value="" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="" /></td>\n\\n\
                                                                            <td></td>\n\
                                                    </tr>';

                                                }
                                                $tbody.html(trdetails);
                                            }
                                        });

                                        $('.remove_this_row').on('click', function () {
                                            var $tr = $(this).closest("tr");
                                            var ID = $tr.find(".parameterID").val();
                                            var parameterVendorID = $tr.find(".parameterVendorID").val();
                                            var parameterRailwayID = $tr.find(".parameterRailwayID").val();
                                            var parameterDivisionID = $tr.find(".parameterDivisionID").val();
                                            var parameterStationID = $tr.find(".parameterStationID").val();
                                            var parameterVersionID = $tr.find(".parameterVersionID").val();
                                            if (ID != "")
                                            {
                                                var answer = confirm("Are you sure you want to delete this Parameter?");
                                                if (answer)
                                                {

                                                    $.ajax({
                                                        type: "POST",
                                                        url: "<?php echo site_url('Admin/delete-parameter'); ?>",
                                                        data: {
                                                            id: ID,
                                                            VendorID: parameterVendorID,
                                                            RailwayID: parameterRailwayID,
                                                            DivisionID: parameterDivisionID,
                                                            StationID: parameterStationID,
                                                            VersionID: parameterVersionID
                                                        },
                                                        success: function (res) {
                                                            console.log(ID);
                                                            $tr.remove();
                                                        }
                                                    });
                                                }
                                            }
                                            else
                                            {
                                                $(this).closest('tr').remove();
                                            }
                                        });

                                        $('.remove_this_row_cpu').on('click', function () {
                                            var answer = confirm("Are you sure you want to delete this CPU?");
                                            if (answer)
                                            {
                                                var $tr = $(this).closest("tr");
                                                var ID = $tr.find(".parameterID").val();
                                                var ID = $tr.find(".cpuID").val();
                                                var cpuVendorID = $tr.find(".cpuVendorID").val();
                                                var cpuRailwayID = $tr.find(".cpuRailwayID").val();
                                                var cpuDivisionID = $tr.find(".cpuDivisionID").val();
                                                var cpuStationID = $tr.find(".cpuStationID").val();
                                                var cpuVersionID = $tr.find(".cpuVersionID").val();
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo site_url('Admin/delete-cpu'); ?>",
                                                    data: {
                                                        id: ID,
                                                        VendorID: cpuVendorID,
                                                        RailwayID: cpuRailwayID,
                                                        DivisionID: cpuDivisionID,
                                                        StationID: cpuStationID,
                                                        VersionID: cpuVersionID
                                                    },
                                                    success: function (res) {
                                                        console.log(ID);
                                                        $tr.remove();
                                                    }
                                                });
                                            }
                                        });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $('a[data-action="remove_this_row"]').on('click', function (event) {
            event.preventDefault();
            $(this).closest('tr').remove();
        });


        $('a[data-action="add_new_row"]').on('click', function (event) {
            event.preventDefault();
            var source = $(this).closest('tr');
            var clone = source.clone(true);
            source.after(clone);
            clone.find('.ParameterValue').val('');
            clone.find('.ParameterName').val('');
            clone.find('.parameterID').val('');
            clone.find('a.readonly').removeClass('readonly');

        });
    });


    function ApplicationFileChg(ApplicationFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('ApplicationLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                ApplicationFile: ApplicationFile,
                Important_Files_Application: $("#ApplicationImportantFilesRequired").val(),
            },
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                console.log(data);
                $("#ApplicationFolderCountAvailable").val(data.folderCount);
                if (data.folderCount != $("#ApplicationFolderCountRequiredText").val() || data.fileCount != $("#ApplicationFileCountRequiredText").val() || data.ImportantfileCount != $("#ApplicationImportantFilesCountText").val())
                {
                    $(".ApplicationLogic").html("Folder/File Count Invalid");
                    Applicationfileerr = true;
                }
                else
                {
                    $(".ApplicationLogic").html("");
                    Applicationfileerr = false;
                }
                $("#ApplicationFileCountAvailable").val(data.fileCount);
                $("#ApplicationImportantFilesAvailable").val(data.ImportantfileCount);
                $("#ApplicationFolderCountRequiredAvail").html(data.folderCount);
                $("#ApplicationFileCountRequiredAvail").html(data.fileCount);
                $("#ApplicationImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#ApplicationDownloadPath").val(data.FilePath);
            }
        });
    }

    function InterfaceFileChg(InterfaceFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('InterfaceLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                InterfaceFile: InterfaceFile,
                Important_Files_Interface: $("#InterfaceImportantFilesRequired").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#InterfaceFolderCountRequiredText").val() || data.fileCount != $("#InterfaceFileCountRequiredText").val() || data.ImportantfileCount != $("#InterfaceImportantFilesCountText").val())
                {
                    $(".InterfaceLogic").html("Folder/File Count Invalid");
                    Interfacefileerr = true;

                }
                else
                {
                    $(".InterfaceLogic").html("");
                    Interfacefileerr = false;
                }
                $("#InterfaceFolderCountAvailable").val(data.folderCount);
                $("#InterfaceFileCountAvailable").val(data.fileCount);
                $("#InterfaceImportantFilesAvailable").val(data.ImportantfileCount);
                $("#InterfaceFolderCountRequiredAvail").html(data.folderCount);
                $("#InterfaceFileCountRequiredAvail").html(data.fileCount);
                $("#InterfaceImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#InterfaceDownloadPath").val(data.FilePath);
            }
        });
    }


    function VduFileChg(VduFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('VduLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                VduFile: VduFile,
                Important_Files_Vdu: $("#VduImportantFilesRequired").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#VduFolderCountRequiredText").val() || data.fileCount != $("#VduFileCountRequiredText").val() || data.ImportantfileCount != $("#VduImportantFilesCountText").val())
                {
                    $(".VduLogic").html("Folder/File Count Invalid");
                    Vdufileerr = true;
                }
                else
                {
                    $(".VduLogic").html("");
                    Vdufileerr = false;
                }
                $("#VduFolderCountAvailable").val(data.folderCount);
                $("#VduFileCountAvailable").val(data.fileCount);
                $("#VduImportantFilesAvailable").val(data.ImportantfileCount);
                $("#VduFolderCountRequiredAvail").html(data.folderCount);
                $("#VduFileCountRequiredAvail").html(data.fileCount);
                $("#VduImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#VduDownloadPath").val(data.FilePath);
            }
        });
    }
</script>

<script src="<?php echo base_url(); ?>assets/js/dropzone.js"></script>
<script>
    Dropzone.autoDiscover = false;
    
    var myDropzone = new Dropzone("#SoftwareFile",{
    	url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var ApplicationFile = jQuery.trim(responseText);
                console.log(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.SoftwareLogic').html("Requrires Only Zip File");
                    this.removeFile(file);
                } else
                {
                    $('.SoftwareLogic').html("");
                    SoftwareFileChg(ApplicationFile);
                }
            });
        }
    });
    
    var myDropzone = new Dropzone("#CertificateFile", {
        url: "<?php echo site_url("Admin/uploadFile") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var CertificateFile = jQuery.trim(responseText);
                $('.CertificateLogic').html("");
                $("#CertificateFilePath").val(CertificateFile);
                /*var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.CertificateLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.CertificateLogic').html("");
                    $("#CertificateFilePath").val(CertificateFile);
                }*/
            });
        }
    });
    
    var myDropzone = new Dropzone("#OthersDownloadFile", {
        url: "<?php echo site_url("Admin/uploadFile") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var OthersDownloadFile = jQuery.trim(responseText);
                $('.OthersLogic').html("");
                $("#OthersDownloadPath").val(OthersDownloadFile);
                /*var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.OthersLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.OthersLogic').html("");
                    $("#OthersDownloadPath").val(OthersDownloadFile);
                }*/
            });
        }
    });

	function getVendorFields(id){
                                        	$.ajax({
                                        		type: "POST",
                                                    url: "<?php echo site_url('Admin/AjaxForm/getVendorFields'); ?>",
                                                    data: {
                                                        VendorID: id
                                                    },
                                                    success: function (res) {
                                                    	var data = JSON.parse(res);
                                                    	console.log(data);
                                                    	for(var i = 0; i< data.length; i++){
                                                    		$("#"+data[i].fname).each(function(){
                                                    			$(this).find(':input').not(':input[readonly]').removeAttr('required');
                                                    		});
                                                    		if(data[i].is_visible == 1){
                                                    			$("#"+data[i].fname).show();
                                                    		}
                                                    		if(data[i].is_mandatory == 1){
                                                    			$("#"+data[i].fname).each(function(){
                                                    				$(this).find(':input').not(':input[readonly]').prop('required',true);
                                                    			});
                                                    		}
                                                    	}
                                                    }
                                        	});
                                        }

    
    function SoftwareFileChg(SoftwareFile){
		$.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/AjaxForm/SoftwarefileUpload'); ?>",
            data: {
                VendorID: $("#VendorID").val(),
                ApplicationFile: SoftwareFile
            },
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                $(".SoftwareLogic").html('');
                softwareFileerr = true;
                $("#SoftwareFileDownloadPath").val("");
                if(data.valid === "false"){
                	$(".SoftwareLogic").html("File Doesn't Contain the Requirements");
                }else{
                	softwareFileerr = false;
                	$("#SoftwareFileDownloadPath").val(data.FilePath);
                }
            }
        });
	}

    
    $(document).ready(function () {
                                        <?php foreach($fields as $field){
                                        	?>$("#<?php echo $field['field_name']; ?>").hide(); <?php
                                        }
										?> 
										getVendorFields('<?php echo $VendorID; ?>');
										
										$('.preventbtn').on('click', function (event) {
											if (softwareFileerr == true || $(".SoftwareLogic").html() != "")
            {
            	alert('Require Software File to be uploaded');
                event.preventDefault();
                return false;
            }
            else
            {
                $("#Level2PasswordModal").modal("show");
                                    event.preventDefault();
                                    return false
            }
                                    
                                });
                                $('.password_verify').on('click', function (event) {
                                    $.ajax({
                                        type: "POST",
                                        url: "<?php echo site_url('Admin/level2-security-settings'); ?>",
                                        data: {
                                            password: $("#Level2Password").val(),
                                        },
                                        success: function (res) { 
                                        	console.log(res);     
                                            if (res != 1)
                                            {
                                                $("#Level2PasswordMessage").html(res);
                                                $(".message_info").show();
                                            }
                                            else
                                            {
                                                $(".message_info").hide();
                                                $("#Level2PasswordMessage").html("");
                                            }
                                            if ($("#Level2PasswordMessage").html() == "")
                                            {
                                                $("form").submit();
                                            }
                                        }
                                    });
                                });
    });
										
</script>

<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>

                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

</body>
</html>