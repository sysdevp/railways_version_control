<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<style>
.r_v_u {
    display: inline-block;
}
</style>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
						<p class="pull-left"><?php if($create_button_rights != 1) { ?>Note: Only Authorized users can create new User <?php } ?></p>
                        
                        <ul class="pull-right">
							<li><button onclick="location.href='<?php echo site_url(); ?>Admin/create-user'" type="button" class="btn btn-info" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Create User</button></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<h3 class="pull-left">Manage Users</h3>
					<?php if($this->session->flashdata("success_done")) { ?>
                         <h3 class="success_done" onclick="close_success()" id="message_val"  style="background:#3a5a9c;">
                            <?php echo $this->session->flashdata("success_done"); ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>User Name</th>
                                        <th>User Level </th>
                                        <th>User Designation </th>
                                        <th>Employee Name</th>
                                        <th>Railway Zone</th>
                                        <th>Division Name</th>
                                        <th>Station Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i=1;
                                    foreach($user as $rows)
                                    {
                                        if($rows['LoginName']!="admin")
                                        {
										$cond_user_header = array(
											"UserID" => $rows['UserID'],
										);
										$user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID,RailwayID,DivisionID,StationID");
										$level_id = $user_details_header[0]['LevelID'];
										?>
                                    <tr>
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $rows['LoginName'];?></td>
                                        <td><?php echo $rows['LevelName'];?></td>
                                        <td><?php echo $rows['DesignationName'];?></td>
                                        <td><?php echo $rows['EmployeeName'];?></td>
                                        <td><?php if($level_id == 2 || $level_id == 3 || $level_id == 4) { echo $rows['RailwayName']; }?></td>
                                        <td><?php if($level_id == 3 || $level_id == 4) { echo $rows['DivisionName']; }?></td>
                                        <td><?php if($level_id == 4) { echo $rows['StationName']; }?></td>
                                        <td>                                            
                                            <a href="<?php echo site_url(); ?>Admin/view-user-detail/<?php echo $rows['UserID'];?>"><span class="label label-info label-mini btn-success r_v_u" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                            <a href="<?php echo site_url(); ?>Admin/edit-user/<?php echo $rows['UserID'];?>"><span class="label label-info label-mini btn-edit r_v_u" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                            <a href="javascript:void(0)" onclick="deleteuser('<?php echo $rows['UserID'];?>')"><span class="label label-info label-mini btn-danger r_v_u" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                        }
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<script>
	function close_success(){
		$(".success_done").remove();
	   }
</script>

<script>
var userid = 0;
function confirm_userole_admin()
{
	$.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-user'); ?>",
                data: {
                    id: userid,
                },
                success: function (res) {
                    if(res==1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/view-user";
                    }
                    else
                    {
                        alert("This record cannot be deleted");
                    }
                },
                error: function(res){
                	console.log(res);
                	//alert(res.responseText);
                }
            });
}
    function deleteuser(id)
    {
    	userid = id;
    	console.log(userid);
    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}else{
        
        	
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-user'); ?>",
                data: {
                    id: id,
                },
                success: function (res) {
					console.log(res);
                    if(res==1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/view-user";
                    }
                    else
                    {
                        alert("This record cannot be deleted");
                    }
                },
                error: function(res){
                	console.log(res);
                	//alert(res.responseText);
                }
            });
            
        
        }
    }
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(13);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password_for_delete',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(true);
				LevelSecurity.triggerChange = function(){
					deleteuser(userid);
				}
			});

</script>

</body>
</html>

