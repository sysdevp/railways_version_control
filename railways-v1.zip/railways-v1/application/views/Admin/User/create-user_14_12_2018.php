<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Create New User</h3>
                         <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-user" class="btn btn-info">Manage Users</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" id="validform" role="form" method="POST" novalidate>
                            <div class="form-group">
                                <label for="UserName" class="col-lg-2 col-sm-2 control-label">Mobile Number <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input data-validation="required"   type="text" class="form-control" name="mobile" id="mobile" placeholder="Mobile Number" required="required" value="<?php echo set_value("mobile");?>" onchange="get_username(this.value)"  onkeyup="$(this).val($(this).val().replace(/[a-z`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="11">
                                </div>
                                <label class="col-sm-12" id="mobile_msg"><?php echo form_error('mobile'); ?></label>
                            </div>
							<script>
							 function get_username(val)
							 {
								 var mobile = val;
								 
								  $.ajax({
										type: "POST",
										url: "<?php echo site_url('Admin/Check_Username'); ?>",
										data: {
											mobile: mobile,
										},
										success: function (res) {
											if (res == 1)
											{
												$("#mobile_msg").html("Mobile Number already Exist");
												
												$('#UserName').val('');
											}
											else
											{
												$("#mobile_msg").html("");
												$('#UserName').val(mobile);
											}
										}
									});
								 
							 }
							</script>
							<div class="form-group">
                                <label for="UserName" class="col-lg-2 col-sm-2 control-label">User Name <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input data-validation="required"   type="text" class="form-control" name="LoginName" id="UserName" placeholder="User Name" required="required" value="<?php echo set_value("LoginName");?>" readonly>
                                </div>
                                <label class="col-sm-12"><?php echo form_error('LoginName'); ?></label>
                            </div>
                          
                            <div class="form-group">
                                <label for="ConfirmPassword" class="col-lg-2 col-sm-2 control-label"> Password <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input  data-validation="confirmation"   type="password" class="form-control" name="LoginPassword" id="ConfirmPassword" placeholder="Confirm Password" required="required">
                                </div>
                                <label class="col-sm-12"><?php echo form_error('LoginPassword'); ?></label>
                            </div>

                              <div class="form-group">
                                <label for="Password" class="col-lg-2 col-sm-2 control-label">Confirm Password <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input data-validation="required"   type="password" class="form-control" name="LoginPassword_confirmation" id="Password" placeholder="Password" required="required">
                                </div>
                                <label class="col-sm-12"><?php echo form_error('LoginPassword_confirmation'); ?></label>
                            </div>
                            <div class="form-group">
                                <label class="col-lg-2 col-sm-2 control-label">Level1 <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-validation="required" name="LevelID" id="LevelID" data-show-subtext="true" data-live-search="true" onchange="level_access(this.value)" required="required">
                                        <option value="">Select Level</option>
                                        <?php
                                        foreach($level as $rows)
                                        {?>
                                        <option <?php echo set_select("LevelID", $rows['LevelID'], FALSE);?> value="<?php echo $rows['LevelID'];?>"><?php echo $rows['LevelName'];?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-12" id="LevelID_msg"><?php echo form_error('LevelID'); ?></label>
                            </div>
							
							<script>
							 function level_access(val)
							 {
								 var LevelID = val;
								 
								 $.ajax({
										type: "POST",
										url: "<?php echo site_url('Admin/Level_Chg_Designation'); ?>",
										data: {
											did: LevelID
										},
										success: function (res) {
											if (res != 0)
											{
												$(".designation_div").html(res);
												$(".selectpicker").selectpicker();
											}
										}
									});
								 
								 if(LevelID == 1)
								 {
									$('#RailwayID').prop('required',false);
									$('#DivisionID').prop('required',false);
									$('#StationID').prop('required',false);
									
									 $('#railway_div').hide(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
									 
									 //$('select[name=RailwayID] option:eq(1)').attr('selected', 'selected');
									 //$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
									//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 2)
								 {
									$('#RailwayID').prop('required',true);
									$('#DivisionID').prop('required',false);
									$('#StationID').prop('required',false);
									
									 $('#railway_div').show(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
									 
									//$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
									//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 3)
								 {
									 $('#RailwayID').prop('required',true);
									 $('#DivisionID').prop('required',true);
									 $('#StationID').prop('required',false);
									
									 $('#railway_div').show(); 	
									 $('#division_div').show(); 	
									 $('#station_div').hide(); 	
									 
									 //$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 4)
								 {
									 $('#RailwayID').prop('required',true);
									 $('#DivisionID').prop('required',true);
									 $('#StationID').prop('required',true);
									 
									 $('#railway_div').show(); 	
									 $('#division_div').show(); 	
									 $('#station_div').show(); 	
								 }
								 else
								 {
									 $('#RailwayID').prop('required',false);
									 $('#DivisionID').prop('required',false);
									 $('#StationID').prop('required',false);
									 
									 $('#railway_div').hide(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
								 }
							 }
							</script>
                             <div class="form-group">
                                <label class="col-lg-2 col-sm-2 control-label">Designation <span class="red">(*)</span></label>
                                <div class="col-lg-4 designation_div">
                                    <select class="form-control selectpicker required" id="DesignationID" name="DesignationID" data-show-subtext="true" data-live-search="true" required="required">
                                        <option value="">Select Designation</option>
                                        
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-12" id="DesignationID_msg"><?php echo form_error('DesignationID'); ?></label>
                            </div>
                            <div class="form-group">
                                <label for="EmployeeName" class="col-lg-2 col-sm-2 control-label">Employee Name <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input type="text" name="EmployeeName" class="form-control" value="<?php echo set_value("EmployeeName");?>" id="EmployeeName" placeholder="Employee Name" required="required">
                                </div>
                                <label class="col-sm-12"><?php echo form_error('EmployeeName'); ?></label>
                            </div>
                            <div class="form-group" id="railway_div">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php echo set_select("RailwayID", $rows['RailwayID'], FALSE); ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group" id="division_div">
                                <label class="col-lg-2 col-sm-2 control-label">Division Name <span class="red">(*)</span></label>
                                <div class="col-lg-4 division_div">
                                   <?php
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID" onchange="division_chg_station(this.value)">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                    
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group" id="station_div">
                                <label class="col-lg-2 col-sm-2 control-label">Station Name <span class="red">(*)</span></label>
                                <div class="col-lg-4 station_div">
                                     <?php
                                    if (isset($station)) {
                                        ?>
                                        <select class="form-control selectpicker" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                    
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script>
	$(document).ready(function(){
		 $('#railway_div').hide(); 	
		 $('#division_div').hide(); 	
		 $('#station_div').hide(); 	
	});
</script>

<script>

        function zone_chg_division(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                data: {
                    id: id,
                    multiple: 1
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".division_div").html(res);
                        $(".selectpicker").selectpicker();
                    }
                }
            });
        }
        
        
        function division_chg_station(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                data: {
                    id: $("#RailwayID").val(),
                    did: id
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".station_div").html(res);
                        $(".selectpicker").selectpicker();
                    }
                }
            });
        }
        
        
</script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(13);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
				
				$.validate({
                    lang: 'en',
                    modules: 'security',
                    onError : function($form) {
                    	console.log($form);
                    },
                    onSuccess : function($form) {
                    	var valid = true;
                    	if($("#DesignationID").val() == ""){
                    		valid = false;
                    		$("#DesignationID_msg").html("Designation is Required");
                    	}
						
						if($("#LevelID").val() == ""){
                    		valid = false;
                    		$("#LevelID_msg").html("Level is Required");
                    	}
                    	
                    	if(valid){
                    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}
                    	}else{
                    		return false;
                    	}
                    }});
				
			});

</script>
</body>
</html>

