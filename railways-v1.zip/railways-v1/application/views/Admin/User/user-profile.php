<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">User Profile</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-user" class="btn btn-info">Manage Users</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3> 
						
						<form class="form-horizontal" role="form" method="POST">
                        <?php
                        foreach ($user as $rows) {
                            ?>
                            <p class="col-sm-12"">User Name: <?php echo $rows['LoginName']; ?></p>
                            <p class="col-sm-12"">Level: <?php echo $rows['LevelName']; ?></p>
                            <p class="col-sm-12"">Designation: <?php echo $rows['DesignationName']; ?></p>
                            <p class="col-sm-12"">Employee Name: <?php echo $rows['EmployeeName']; ?></p>
							<?php if($rows['LevelID'] != '1'){ ?>
                            <p class="col-sm-12"">Zone Name: <?php echo $rows['RailwayName']; ?></p> 
							<?php } if($rows['LevelID'] != 1 && $rows['LevelID'] != 2){ ?>
							<p class="col-sm-12"">Division Name: <?php echo $rows['DivisionName']; ?></p>
							<?php } if($rows['LevelID'] != 1 && $rows['LevelID'] != 2 && $rows['LevelID'] != 3){ ?>
                            <p class="col-sm-12"">Station Name: <?php echo $rows['StationName']; ?></p>
							<?php } ?>
                               <p class="col-sm-12">Created by <?php echo $this->common_model->find_single_value("UserID", $rows['CreatedBy'], "tblusermaster", "EmployeeName"); ?> on : <?php echo date("d-m-Y H:i:s", strtotime($rows['CreatedOn'])); ?></p>
                                    <p class="col-sm-12">Record Last Modified by <?php echo $this->common_model->find_single_value("UserID", $rows['ModifiedBy'], "tblusermaster", "EmployeeName"); ?> on :  <?php echo date("d-m-Y H:i:s", strtotime($rows['ModifiedOn'])); ?></p>
							<br>		
							<br>		
							<br>
							 <h4 class="pull-left">Change Password</h4>
							<br>		
							<br>		
							<br>
							<div class="col-sm-12">					
								<div class="form-group">
									<label for="OldPassword" class="col-lg-2 col-sm-2 control-label">Current Password</label>
									<div class="col-lg-4">
										<input type="password" class="form-control" name="OldPassword" id="OldPassword" placeholder="Current Password" required maxlength="20">
									</div>
								   
								</div>	
								<div class="form-group">
									<label for="Password" class="col-lg-2 col-sm-2 control-label">New Password</label>
									<div class="col-lg-4">
										<input type="password" class="form-control" name="LoginPassword" id="Password" placeholder="New Password" required maxlength="20">
									</div>
									<div class="col-lg-6">
    									<p>[ Minimum 8 and Maximum 20 characters required ]</p>
    								</div>
									
								</div>
								<div class="form-group">
									<label for="ConfirmPassword" class="col-lg-2 col-sm-2 control-label">Confirm Password </label>
									<div class="col-lg-4">
										<input type="password" class="form-control" name="LoginRePassword" id="ConfirmPassword" placeholder="Confirm Password" required maxlength="20">
									</div>
									
								</div>
								
									 <?php
							}
							?>
								<div class="form-group">
									<div class="col-lg-offset-2 col-lg-10">
										<button type="submit" class="btn btn-danger">Submit</button>

										 <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
									</div>
									<div class="col-lg-offset-2 col-lg-10">
										<p><b>You will be redirected to login page after changing password.</b></p>
									</div>
								</div>
                            </div>
                        </form>
						
						
                        </div>
                    </section>
                    <!--user info table end-->
                </div>
            </div>
        </section>
    </section>
    <!--main content end-->

    <?php $this->load->view('Admin/footer'); ?>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo $asset_url; ?>js/jquery.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
    <script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
	<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
	<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
	<?php 
	$menusetting = $this->common_model->getMenuSettings(13);
	$slp = array(
		"setting" => $menusetting
	);
	$this->load->view('Admin/security_level_password',$slp); ?>
	
	<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);

                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        LoginPassword: {
                            minlength:8
                        },
                        LoginRePassword: {
                            equalTo: '#Password',
                            minlength:8
                        },
                    }, 
                    messages: {
                       LoginPassword: {
                            minlength: "The Password field must be at least 8 characters in length.",
                       }
                    },
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
									form.submit();
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
				
				
			});

</script>
	
</body>
</html>

