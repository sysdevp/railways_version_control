<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View User</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-user" class="btn btn-info">Manage Users</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <?php
                        foreach ($user as $rows) {
                            ?>
                            <p class="col-sm-12"">User Name: <?php echo $rows['LoginName']; ?></p>
                            <p class="col-sm-12"">Level: <?php echo $rows['LevelName']; ?></p>
                            <p class="col-sm-12"">Designation: <?php echo $rows['DesignationName']; ?></p>
                            <p class="col-sm-12"">Employee Name: <?php echo $rows['EmployeeName']; ?></p>
                            <?php if($rows['LevelID'] != '1'){ ?>
                            <p class="col-sm-12"">Zone Name: <?php echo $rows['RailwayName']; ?></p> 
							<?php } if($rows['LevelID'] != 1 && $rows['LevelID'] != 2){ ?>
							<p class="col-sm-12"">Division Name: <?php echo $rows['DivisionName']; ?></p>
							<?php } if($rows['LevelID'] != 1 && $rows['LevelID'] != 2 && $rows['LevelID'] != 3){ ?>
                            <p class="col-sm-12"">Station Name: <?php echo $rows['StationName']; ?></p>
							<?php } ?>
                               <p class="col-sm-12">Created by <?php echo $this->common_model->find_single_value("UserID", $rows['CreatedBy'], "tblusermaster", "EmployeeName"); ?> on : <?php echo date("d-m-Y H:i:s", strtotime($rows['CreatedOn'])); ?></p>
                                    <p class="col-sm-12">Record Last Modified by <?php echo $this->common_model->find_single_value("UserID", $rows['ModifiedBy'], "tblusermaster", "EmployeeName"); ?> on :  <?php echo date("d-m-Y H:i:s", strtotime($rows['ModifiedOn'])); ?></p>
                                 <?php
                        }
                        ?>
                            <!--
                            <h4 class="col-sm-12">Modification History:</strong></h4>
                            <div class="col-sm-12">
                                <table class="table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sno</th>
                                            <th>Date</th>
                                            <th>Action</th>
                                            <th>User Name</th>                                        
                                            <th>User Role</th>
                                            <th>Employee Name</th>
                                            <th>Division Name</th>
                                            <th>Station Name</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>25/07/2018 13:25:55</td>
                                            <td>Created</td>
                                            <td>Ravii</td>
                                            <td>Admin</td>
                                            <td>Krishna</td>
                                            <td>Chennai (MAS)</td>
                                            <td>Ambur (AB)</td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>27/07/2018 13:25:55</td>
                                            <td>Modified</td>
                                            <td>Ravi</td>
                                            <td>Admin</td>
                                            <td>Krishna</td>
                                            <td>Chennai (MAS)</td>
                                            <td>Ambur (AB)</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            <p class="col-sm-12"><strong>Synchronized on 27/07/2018</strong></p>
                            <h4 class="col-sm-12">Synchronization History:</h4>
                            <div class="col-sm-12">
                                <table class=" table table-bordered table-striped">
                                    <thead>
                                        <tr>
                                            <th>Sno</th>
                                            <th>Attempted On</th>
                                            <th>Message</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <tr>
                                            <td>1</td>
                                            <td>25/07/2018 22:25:55</td>
                                            <td>Connetivity Error</td>
                                        </tr>
                                        <tr>
                                            <td>2</td>
                                            <td>27/07/2018 22:35:15</td>
                                            <td>Success</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                            -->
                        </div>
                    </section>
                    <!--user info table end-->
                </div>
            </div>
        </section>
    </section>
    <!--main content end-->

    <?php $this->load->view('Admin/footer'); ?>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="<?php echo $asset_url; ?>js/jquery.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
    <script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
    <script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
    <script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
    <script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
    <script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
    <!--right slidebar-->
    <script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
    <!--dynamic table initialization -->
    <script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
    <!--common script for all pages-->
    <script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
    <script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

</body>
</html>

