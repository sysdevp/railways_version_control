<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify User</h3>
                         <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-user" class="btn btn-info">Manage Users</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach($user as $userrows)
                            {?>
                            <div class="form-group">
								<input hidden type="text" name="LoginName_origin" id="LoginName_origin" value="<?php echo $userrows['LoginName'];?>"/>
									<label for="UserName" class="col-lg-2 col-sm-2 control-label">Mobile Number <span class="red">(*)</span></label>
									<div class="col-lg-4">
										<input type="text" class="form-control" name="mobile" id="mobile" placeholder="Mobile Number" value="<?php echo $userrows['LoginName'];?>" onchange="get_username(this.value)" required="required"  onkeyup="$(this).val($(this).val().replace(/[a-z`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="10">
									</div>
									<div class="col-lg-6">
										<p>[ Enter only 10 digits ]</p>
									</div>
								<div class="col-sm-12">
									<div class="col-lg-2"></div>
									<label class="col-lg-4 red" id="mobile_msg"><?php echo form_error('mobile'); ?></label>
                                </div>
                            </div>
							<script>
							 function get_username(val)
							 {
								 var mobile = val;
								 var LoginName_origin = $('#LoginName_origin').val();
								 
								 if(mobile != LoginName_origin)
								 {
								  $.ajax({
										type: "POST",
										url: "<?php echo site_url('Admin/Check_Username'); ?>",
										data: {
											mobile: mobile,
										},
										success: function (res) {
											if (res == 1)
											{
												$("#mobile_msg").html("Mobile Number already Exist");
												
												$('#UserName').val('');
											}
											else
											{
												$("#mobile_msg").html("");
												$('#UserName').val(mobile);
											}
										}
									});
								 }
								 else
								{
									$("#mobile_msg").html("");
									$('#UserName').val(mobile);
								}
								 
							 }
							</script>
							<div class="form-group">
									<label for="UserName" class="col-lg-2 col-sm-2 control-label">User Name <span class="red">(*)</span></label>
									<div class="col-lg-4">
										<input type="text" class="form-control" name="LoginName" id="UserName" placeholder="User Name" required="required" value="<?php echo $userrows['LoginName'];?>" readonly>
									</div>
								<div class="col-sm-12">
									<div class="col-lg-2"></div>
									<label class="col-lg-4 red"><?php echo form_error('LoginName'); ?></label>
                                </div>
                                
                            </div>
                            <div class="form-group">
                                <label for="Password" class="col-lg-2 col-sm-2 control-label">Password</label>
                                <div class="col-lg-4">
                                    <input type="password" class="form-control" name="LoginPassword" id="Password" placeholder="Password" maxlength="20">
                                </div>
                                <div class="col-lg-6">
                                    <p>[ Minimum 8 and Maximum 20 characters required. Leave this field blank, if you don't want to change the password]</p>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ConfirmPassword" class="col-lg-2 col-sm-2 control-label">Confirm Password </label>
                                <div class="col-lg-4">
                                    <input type="password" class="form-control" name="LoginRePassword" id="ConfirmPassword" placeholder="Confirm Password" maxlength="20">
                                </div>
                                
                            </div>
                            <div class="form-group">
                                <label class="col-lg-2 col-sm-2 control-label">Level <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" name="LevelID" id="LevelID" data-show-subtext="true" data-live-search="true" onchange="level_access(this.value)">
                                        <option value="">Select Level</option>
                                        <?php
                                        foreach($level as $rows)
                                        {?>
                                        <option <?php if($rows['LevelID']==$userrows['LevelID']){ echo "selected";}?> value="<?php echo $rows['LevelID'];?>"><?php echo $rows['LevelName'];?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-12" id="LevelID_msg"><?php echo form_error('LevelID'); ?></label>
                            </div>
							
							<script>
							 function level_access(val)
							 {
								 var LevelID = val; 
								 $.ajax({
										type: "POST",
										url: "<?php echo site_url('Admin/Level_Chg_Designation'); ?>",
										data: {
											did: LevelID
										},
										success: function (res) {
											if (res != 0)
											{
												$(".designation_div").html(res);
												$(".selectpicker").selectpicker();
											}
										}
									});
									
								 if(LevelID == 1)
								 {
									$('#RailwayID').prop('required',false);
									$('#DivisionID').prop('required',false);
									$('#StationID').prop('required',false);
									
									 $('#railway_div').hide(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
									 
									 //$('select[name=RailwayID] option:eq(1)').attr('selected', 'selected');
									 //$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
									//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 2)
								 {
									$('#RailwayID').prop('required',true);
									$('#DivisionID').prop('required',false);
									$('#StationID').prop('required',false);
									
									 $('#railway_div').show(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
									 
									//$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
									//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 3)
								 {
									 $('#RailwayID').prop('required',true);
									 $('#DivisionID').prop('required',true);
									 $('#StationID').prop('required',false);
									
									 $('#railway_div').show(); 	
									 $('#division_div').show(); 	
									 $('#station_div').hide(); 	
									 
									 //$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
								 }
								 else if(LevelID == 4)
								 {
									 $('#RailwayID').prop('required',true);
									 $('#DivisionID').prop('required',true);
									 $('#StationID').prop('required',true);
									 
									 $('#railway_div').show(); 	
									 $('#division_div').show(); 	
									 $('#station_div').show(); 	
								 }
								 else
								 {
									 $('#RailwayID').prop('required',false);
									 $('#DivisionID').prop('required',false);
									 $('#StationID').prop('required',false);
									 
									 $('#railway_div').hide(); 	
									 $('#division_div').hide(); 	
									 $('#station_div').hide(); 	
								 }
							 }
							</script>
							
                             <div class="form-group">
                                <label class="col-lg-2 col-sm-2 control-label">Designation <span class="red">(*)</span></label>
                                <div class="col-lg-4 designation_div">
                                    <select class="form-control selectpicker" name="DesignationID" id="DesignationID" data-show-subtext="true" data-live-search="true">
                                        <option value="">Select Designation</option>
                                        <?php
                                        foreach($designation as $rows)
                                        {?>
                                            <option <?php if($rows['DesignationID']==$userrows['DesignationID']){ echo "selected";}?>  value="<?php echo $rows['DesignationID'];?>"><?php echo $rows['DesignationName'];?></option>
                                        <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-12" id="DesignationID_msg"><?php echo form_error('DesignationID'); ?></label>
                            </div>
                            <div class="form-group">
                                <label for="EmployeeName" class="col-lg-2 col-sm-2 control-label">Employee Name <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" name="EmployeeName" id="EmployeeName" placeholder="User Name" value="<?php echo $userrows['EmployeeName'];?>" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 32 || event.charCode == 46" maxlength="40">
                                </div>
                                <label class="col-sm-12"><?php echo form_error('EmployeeName'); ?></label>
                            </div>
                            <div class="form-group" id="railway_div">
                                <label class="col-lg-2 col-sm-2 control-label">Railway Zone / Code <span class="red">(*)</span></label>
                                <div class="col-lg-4">
									
									<select class="form-control selectpicker" id="RailwayID" data-show-subtext="true" data-live-search="true" name="RailwayID"  onchange="zone_chg_division(this.value)">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($zone as $rows) {
                                                ?>
                                                <option <?php if($rows['RailwayID']==$userrows['RailwayID']){ echo "selected";}?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>  
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                            </div>
							<div class="form-group" id="division_div">
                                <label class="col-lg-2 col-sm-2 control-label">Division Name <span class="red">(*)</span></label>
                                <div class="col-lg-4 division_div">
									
									<select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID"  onchange="division_chg_station(this.value)">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php if($rows['DivisionID']==$userrows['DivisionID']){ echo "selected";}?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>  
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group" id="station_div">
                                <label class="col-lg-2 col-sm-2 control-label">Station Name <span class="red">(*)</span></label>
                                <div class="col-lg-4 station_div">
                                        <select class="form-control selectpicker" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php if($rows['StationID']==$userrows['StationID']){ echo "selected";}?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>                              
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
                            </div>
                            <?php if($this->session->userdata("UserRole") == "Admin")
                            {?>
                            <div class="form-group">
                                <label for="EmployeeName" class="col-lg-2 col-sm-2 control-label">Enable Admin Rights</label>
                                <div class="col-lg-8">
                                    <input style="width: 30px;height:22px;" type="checkbox" name="IsAdmin" class="form-control" <?php if($userrows['IsAdmin'] == 1){ echo "checked";}?> id="IsAdmin">
									<p>[ User with Admin Privileges will gain all access ]</p>
                                </div>
                                <label class="col-sm-12"><?php echo form_error('IsAdmin'); ?></label>
                            </div>
                            <?php
                            }
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                     <a href="<?php echo site_url(); ?>Admin/view-user" class="btn btn-default">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(13);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>

<script>

        function zone_chg_division(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                data: {
                    id: id,
                    multiple: 1
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".division_div").html(res);
                        $(".selectpicker").selectpicker();
						
						var LevelID = $('#LevelID').val();
						if(LevelID == 1)
						{
							$('#DivisionID').prop('required',false);
						}
						else if(LevelID == 2)
						{
							$('#DivisionID').prop('required',false);
						}
						else if(LevelID == 3)
						{
							$('#DivisionID').prop('required',true);
						}
						else if(LevelID == 4)
						{
							$('#DivisionID').prop('required',true);
						}
						
						var div_val = $("#DivisionID").val();
						division_chg_station(div_val);
                    }
                }
            });
        }
        
        
        function division_chg_station(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                data: {
                    id: $("#RailwayID").val(),
                    did: id
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".station_div").html(res);
                        $(".selectpicker").selectpicker();
						
						var LevelID = $('#LevelID').val();
						if(LevelID == 1)
						{
							$('#StationID').prop('required',false);
						}
						else if(LevelID == 2)
						{
							$('#StationID').prop('required',false);
						}
						else if(LevelID == 3)
						{
							$('#StationID').prop('required',false);
						}
						else if(LevelID == 4)
						{
							$('#StationID').prop('required',true);
						}
                    }
                }
            });
        }
        
        
</script>

<script>
$(document).ready(function() {
	
	var LevelID = $('#LevelID').val();
	 var def_val = 1;
	 if(LevelID == 1)
	 {
		$('#RailwayID').prop('required',false);
		$('#DivisionID').prop('required',false);
		$('#StationID').prop('required',false);
		
		 $('#railway_div').hide(); 	
		 $('#division_div').hide(); 	
		 $('#station_div').hide(); 	
		 
		 //$('select[name=RailwayID] option:eq(1)').attr('selected', 'selected');
		 //$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
		//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
	 }
	 else if(LevelID == 2)
	 {
		$('#RailwayID').prop('required',true);
		$('#DivisionID').prop('required',false);
		$('#StationID').prop('required',false);
		
		 $('#railway_div').show(); 	
		 $('#division_div').hide(); 	
		 $('#station_div').hide(); 	
		 
		//$('select[name=DivisionID] option:eq(1)').attr('selected', 'selected');
		//$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
	 }
	 else if(LevelID == 3)
	 {
		 $('#RailwayID').prop('required',true);
		 $('#DivisionID').prop('required',true);
		 $('#StationID').prop('required',false);
		
		 $('#railway_div').show(); 	
		 $('#division_div').show(); 	
		 $('#station_div').hide(); 	
		 
		 //$('select[name=StationID] option:eq(1)').attr('selected', 'selected');
	 }
	 else if(LevelID == 4)
	 {
		 $('#RailwayID').prop('required',true);
		 $('#DivisionID').prop('required',true);
		 $('#StationID').prop('required',true);
		 
		 $('#railway_div').show(); 	
		 $('#division_div').show(); 	
		 $('#station_div').show(); 	
	 }
	 
	 });
</script>
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);

                $('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        mobile:{
                            required: true,
                            minlength:10,
                            maxlength:10
                        },
                        LoginName: 'required',
                        LoginPassword: {
                            minlength:8
                        },
                        LoginRePassword: {
                            equalTo: '#Password',
                            minlength:8
                        },
                        LevelID: 'required',
                        DesignationID: 'required',
                        EmployeeName: 'required'
                    }, 
                    messages: {
						mobile: {
                            minlength: "Enter only 10 digits.",
                            maxlength: "Enter only 10 digits.",
                        },
                       LoginPassword: {
                            minlength: "The Password field must be at least 8 characters in length.",
                       }
                    },
                    submitHandler: function(form) {
                            if($(".form-horizontal").valid()==true)
                            {
                                    <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                       LevelSecurity.showPassword();
                                        if(LevelSecurity.isPasswordOk == false){
                                            return false;
                                        }
                                        else{
                                            form.submit();
                                        }
                                    <?php
                                    }
                                    else{
                                    ?>
                                            form.submit();
                                    <?php
                                    }
                                    ?>
                            }
                            else{ 
                                    return false;
                            }
                    }
            }); 
				
				/*$.validate({
                    lang: 'en',
                    modules: 'security',
                    onError : function($form) {
                    	console.log($form);
                    },
                    onSuccess : function($form) {
						
						var valid = true;
                    	if($("#DesignationID").val() == ""){
                    		valid = false;
                    		$("#DesignationID_msg").html("Designation is Required");
                    	}
						
						if($("#LevelID").val() == ""){
                    		valid = false;
                    		$("#LevelID_msg").html("Level is Required");
                    	}
                    	
                    	if(valid){
                    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}
                    	}else{
                    		return false;
                    	}
						
                    }});*/
				
			});

</script>
</body>
</html>

