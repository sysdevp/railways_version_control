<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">ADD New Version Logic</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version-logic" class="btn btn-info">View Version Logic</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal create_version_logic" role="form" method="POST" enctype='multipart/form-data'>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)">
                                        <option value="">Select Option</option>
                                         <?php
                                        $RailwayID = $this->session->userdata("railway_session_list");
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php if($RailwayID!="" && $RailwayID!=0 && $RailwayID ==$rows['RailwayID'] ){ $rcond=true; echo "selected";} echo set_select("RailwayID", $rows['RailwayID'], FALSE); ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                                <label class="col-sm-2 control-label col-lg-2">Division Name</label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    $dcond=false;
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    elseif($rcond==true)
                                    {
                                        $DivisionID = $this->session->userdata("division_session_list");
                                        $dcond=false;
                                        $division = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                                        ?>
                                    
                                    <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID"  onchange="division_chg_station(this.value)">>
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php if($DivisionID!="" && $DivisionID!=0 && $DivisionID ==$rows['DivisionID'] ){ $dcond=true; echo "selected";} echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    <?php
                                    }
                                        
                                    ?>                                  
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>

                            </div>
                            
                             
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">Station Name</label>
                                <div class="col-lg-4 station_div">
                                    <?php
                                    if (isset($station)) {
                                        ?>
                                        <select class="form-control selectpicker" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    elseif($dcond==true)
                                    {
                                        $StationID = $this->session->userdata("station_session_list");
                                        $dcond=false;
                                        $station = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID), "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
                                        ?>  
                                     <select class="form-control selectpicker" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php if($StationID!="" && $StationID!=0 && $StationID ==$rows['StationID'] ){ $rcond=true; echo "selected";} echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    <?php
                                    }
                                    ?>
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
                                <label class="col-sm-2 control-label col-lg-2">OEM's Name</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-show-subtext="true" data-live-search="true" name="VendorID">
                                        <option value="">Select Option</option>
                                       <?php
                                            foreach ($vendor as $rows) {
                                                ?>
                                                <option <?php echo set_select("VendorID", $rows['VendorID'], FALSE); ?> value="<?php echo $rows['VendorID']; ?>"><?php echo $rows['VendorName']; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('VendorID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="VendorNumber" class="col-sm-2 control-label col-lg-2">Version Number</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" name="VersionNo" id="VendorNumber" placeholder="Version Number" required="required">
                                </div>
                                <label class="col-sm-12"><?php echo form_error('VersionNo'); ?></label>
                            </div>
                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>Application Logic</h3></label>
                                    <label for="ApplicationFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="number" class="form-control" name="ApplicationFileCountRequired" id="ApplicationFile" required="required">
                                        <label class="col-sm-12"><?php echo form_error('ApplicationFileCountRequired'); ?></label>
                                    </div>
                                    <label for="ApplicationFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4 m-bot20">
                                        <input type="number" class="form-control" name="ApplicationFolderCountRequired" id="ApplicationFolder" required="required">
                                        <label class="col-sm-12"><?php echo form_error('ApplicationFolderCountRequired'); ?></label>
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="ApplicationImportantFilesRequired[]" class="tagsinput" value="" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>Interface Logic</h3></label>
                                    <label for="CircuitFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="number" class="form-control" name="InterfaceFileCountRequired" id="CircuitFile" required="required">
                                        <label class="col-sm-12"><?php echo form_error('InterfaceFileCountRequired'); ?></label>
                                    </div>
                                    <label for="CircuitFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4 m-bot20">
                                        <input type="number" class="form-control" name="InterfaceFolderCountRequired" id="CircuitFolder" required="required">
                                        <label class="col-sm-12"><?php echo form_error('InterfaceFolderCountRequired'); ?></label>
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="InterfaceImportantFilesRequired[]" class="tagsinput" value="" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>VDU Logic</h3></label>
                                    <label for="VideoFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="number" class="form-control" name="VduFileCountRequired" placeholder="" id="VideoFile" required="required">
                                        <label class="col-sm-12"><?php echo form_error('VduFileCountRequired'); ?></label>
                                    </div>
                                    <label for="VideoFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4 m-bot20">
                                        <input type="number" class="form-control" name="VduFolderCountRequired" id="VideoFolder" required="required">
                                        <label class="col-sm-12"><?php echo form_error('VduFolderCountRequired'); ?></label>
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="VduImportantFilesRequired[]" class="tagsinput" value="" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-lg-12 text-center mtop20 checkbox_customize">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>


<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>

<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.tagsinput.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/form-component.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>
        function zone_chg_division(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                data: {
                    id: id,
                    multiple: 1
                },
                success: function (res) {
                    $(".division_div").html("");
                    $(".station_div").html("");
                    if (res != 0)
                    {
                        $(".division_div").html(res);
                        $(".selectpicker").selectpicker();
                    }
                }
            });
        }
        
        
        function division_chg_station(id)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                data: {
                    id: $("#RailwayID").val(),
                    did: id
                },
                success: function (res) {
                    if (res != 0)
                    {
                        $(".station_div").html(res);
                        $(".selectpicker").selectpicker();
                    }
                }
            });
        }
        
        
</script>
</body>


</html>