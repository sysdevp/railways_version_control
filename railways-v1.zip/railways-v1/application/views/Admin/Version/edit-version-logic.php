<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify Version Logic</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version-logic" class="btn btn-info">View Version Logic</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal create_version_logic" role="form" method="POST">
                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <?php
                            foreach($version_logic as $rows)
                            {
                                ?>
                            <div class="form-group">
                                <label for="VendorNumber" class="col-sm-2 control-label col-lg-2">Version Number</label>
                                <div class="col-lg-4">
                                    <input type="text" name="VersionNo" class="form-control" id="VendorNumber" placeholder="OEM's Number" value="<?php echo $rows['VersionNo'];?>">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>Application Logic</h3></label>
                                    <label for="ApplicationFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="ApplicationFileCountRequired" class="form-control" id="ApplicationFile" value="<?php echo $rows['ApplicationFileCountRequired'];?>">
                                    </div>
                                    <label for="ApplicationFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="ApplicationFolderCountRequired" class="form-control" id="ApplicationFolder" value="<?php echo $rows['ApplicationFolderCountRequired'];?>">
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="ApplicationImportantFilesRequired[]" class="tagsinput" value="<?php echo $rows['ApplicationImportantFilesRequired'];?>" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>Interface Logic</h3></label>
                                    <label for="CircuitFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="InterfaceFileCountRequired" class="form-control" id="CircuitFile" value="<?php echo $rows['InterfaceFileCountRequired'];?>">
                                    </div>
                                    <label for="CircuitFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="InterfaceFolderCountRequired" class="form-control" id="CircuitFolder" value="<?php echo $rows['InterfaceFolderCountRequired'];?>">
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="InterfaceImportantFilesRequired[]" class="tagsinput" value="<?php echo $rows['InterfaceImportantFilesRequired'];?>" />
                                    </div>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="border_wrapper">
                                    <label class="col-lg-12"><h3>VDU Logic</h3></label>
                                    <label for="VideoFile" class="col-lg-2 col-sm-2 control-label">Total No.of Files</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="VduFileCountRequired" class="form-control" placeholder="" id="VideoFile" value="<?php echo $rows['VduFileCountRequired'];?>">
                                    </div>
                                    <label for="VideoFolder" class="col-lg-2 col-sm-2 control-label">Total No.of Folder</label>
                                    <div class="col-lg-4">
                                        <input type="text" name="VduFolderCountRequired" class="form-control" id="VideoFolder" value="<?php echo $rows['VduFolderCountRequired'];?>">
                                    </div>
                                    <label class="col-sm-2 control-label col-lg-2">Important Files</label>
                                    <div class="col-lg-10">
                                        <input id="tagsinput" name="VduImportantFilesRequired[]" class="tagsinput" value="<?php echo $rows['VduImportantFilesRequired'];?>" />
                                    </div>
                                </div>
                            </div>
                            
                            <?php
                                }
                            ?>

                            <div class="form-group">
                                <div class="col-lg-12 text-center mtop20 checkbox_customize">
                                    <button type="submit" class="btn btn-info">Update</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>

<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.tagsinput.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/form-component.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>


</body>
</html>