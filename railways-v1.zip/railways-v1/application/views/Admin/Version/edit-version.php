<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');
$menusetting_station_in_red = $this->common_model->getMenuSettings(17);
$menusetting_station_in_normal = $this->common_model->getMenuSettings(17);
 ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify EI - Logic Files</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version" class="btn btn-info">View EI - Logic Files</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. *API details can be edited only within the limited days, (Refer ADMIN -> EI Files). *Previously uploaded Software files / Certificates / others will remain same if you didnt upload any new files in Edit mode.</p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal add_new_version_form" role="form" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)" required="">
                                        <option value="">Select Option <?php echo $version[0]['RailwayID']; ?></option>
                                        <?php
                                        $RailwayID = $version[0]['RailwayID'];
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php
                                            if ($RailwayID == $rows['RailwayID']) {
                                                $rcond = true;
                                                echo "selected";
                                            }
                                            if (isset($RailwayIDPreview)) {
                                                if ($RailwayIDPreview == $rows['RailwayID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            echo set_select("RailwayID", $rows['RailwayID'], FALSE);
                                            ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code <span class="red">(*)</span></label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    $dcond = false;
									$DivisionID = "";
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($rcond == true) {
                                        $DivisionID = $version[0]['DivisionID'];
                                        $dcond = false;
                                        $division = $this->common_model->find_details("RecordStatus = 1 and RailwayID = '".$RailwayID."'", "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                                        ?>
                                        <select class="form-control selectpicker"  required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID"  onchange="division_chg_station(this.value)">>
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php
                                                if ($DivisionID != "" && $DivisionID != 0 && $DivisionID == $rows['DivisionID']) {
                                                    $dcond = true;
                                                    echo "selected";
                                                } echo set_select("DivisionID", $rows['DivisionID'], FALSE);
                                                ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                   
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                               
                            </div>
                            <div class="form-group">
								 <label for="StationName" class="col-sm-2 control-label">Station Name / Code <span class="red">(*)</span></label>
                                <input type="hidden" name="VersionID" id="VersionID" value="<?php echo $version[0]["VersionID"]; ?>"    />
                                <div class="col-lg-4 station_div">
                                    <?php
                                    if (isset($station)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option included='<?php if(isset($row['is_include'])){if($rows["is_include"] != ""){ echo "red"; }else{ echo "normal"; }}else{ echo 'normal'; } ?>' <?php echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($dcond == true) {
                                        $StationID = $version[0]["StationID"];
                                        $dcond = false;

                                        $station = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID, "DivisionID" => $DivisionID), "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
                                        ?>  
                                        <select class="form-control selectpicker" required=""  id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option included='<?php if(isset($row['is_include'])){if($rows["is_include"] != ""){ echo "red"; }else{ echo "normal"; }}else{ echo 'normal'; } ?>' <?php
                                                if ($StationID != "" && $StationID != 0 && $StationID == $rows['StationID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                } echo set_select("StationID", $rows['StationID'], FALSE);
                                                ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                  
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
							</div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" required data-tag="make_of_ei" data-title="Make of EI" id="VendorID"  data-show-subtext="true" data-live-search="true" name="VendorID" onchange="vendorChg(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        foreach ($vendor as $rows) {
                                            ?>
                                            <option <?php
                                            if (isset($VendorIDPreview)) {
                                                if ($VendorIDPreview != "" && $VendorIDPreview != 0 && $VendorIDPreview == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            $VendorID = $version[0]['VendorID'];
                                            if (isset($VendorID)) {
                                                if ($VendorID != "" && $VendorID != 0 && $VendorID == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            } echo set_select("VendorID", $rows['VendorID'], FALSE);
                                            ?> value="<?php echo $rows['VendorID']; ?>"><?php echo $rows['VendorName']; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12 red" id="make_of_ei_errmsg"><?php echo form_error('VendorID'); ?></label>
                                </div>
                              
                            </div>
                            <div class="form-group">
                            	<div id="signaling_plan_no">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number</label>
                                <div class="col-lg-4">
                                    <input type="text" name="SignalPlanNumber" required="" data-tag="signaling_plan_no" data-title="Signaling Plan Number" class="form-control" id="SignalingPlanNumber" placeholder="Signaling Plan Number" value="<?php echo $version[0]['SignalPlanNumber']; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40">
                                    <label class="col-sm-12 red" id="signaling_plan_no_errmsg"><?php echo form_error('SignalPlanNumber'); ?></label>
                                </div>
                                </div>
                                
                            </div>
                       
                       <div class="form-group">
                            <div id="dateofinstallation">
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input type="text" name="InstallationAlterationDate" required data-tag="dateofinstallation" data-title="Date of Installation" class="form-control mydatepicker" id="DateInstallation" required="required" value="<?php echo $version[0]['InstallationAlterationDate']; ?>">
                                    <label class="col-sm-12 red" id="dateofinstallation_errmsg"><?php echo form_error('InstallationAlterationDate'); ?></label>
                                </div>
                                </div>
                             </div>

                              <div class="form-group">

                               <div id="distributed">
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="col-sm-3">
                                            <input id="DistributedYes" type="radio" name="isDistributedVersionType" value="1" <?php
                                            if ($version[0]['isDistributedVersionType'] == "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedYes">Yes</label>
                                        </div>
                                        <div class="col-sm-3">
                                            <input id="DistributedNo" type="radio" name="isDistributedVersionType" value="0"  <?php
                                            if ($version[0]['isDistributedVersionType'] != "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedNo">No</label>
                                        </div>
                                        <label class="col-sm-12"><?php echo form_error('isDistributedVersionType'); ?></label>
                                    </div>
                                </div>
                               </div>
</div>

                            <div id="field_idz1">
                            <div class="form-group" id="description_of_work">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                	<select class="form-control selectpicker" required data-tag="description_of_work" data-title="Description of Work" id="ReasonChanging" data-show-subtext="true" data-live-search="true" name="DescriptionOfWork">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($extrafields as $extra) {
                                            	if($extra["for_field"] == 0){
                                                ?>
                                                <option <?php if($extra["field_value"] == $version[0]['DescriptionOfWork']){
                                                	echo "selected";
                                                } ?> value="<?php echo $extra["field_value"]; ?>"><?php echo $extra["field_value"]; ?></option>
                                                <?php
                                            } }
                                            ?>
											 <option value="Others" <?=set_select('DescriptionOfWork','Others',$version[0]['DescriptionOfWork']=='Others')?>>Others</option>
                                        </select>
                                    <label class="col-sm-12 red" id="description_of_work_errmsg"><?php echo form_error('DescriptionOfWork'); ?></label>
                                </div>
								<div class="col-lg-6">
        							<p>( Select "Others" if the required option was not listed.)</p>
        						</div>
                            </div> 
                            <div class="form-group" id="work_executed_up_by">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed by <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" required data-tag="work_executed_up_by" data-title="Work Executed by" id="WorkExcuited" data-show-subtext="true" data-live-search="true" name="WorkExecutedBy">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($extrafields as $extra) {
                                            	if($extra["for_field"] == 1){
                                                ?>
                                                <option value="<?php echo $extra["field_value"]; ?>" <?php if($extra["field_value"] == $version[0]['WorkExecutedBy']){
                                                	echo "selected";
                                                } ?> ><?php echo $extra["field_value"]; ?></option>
                                                <?php
                                            } }
                                            ?>
											<option value="Others" <?=set_select('WorkExecutedBy','Others',$version[0]['WorkExecutedBy']=='Others')?>>Others</option>
                                        </select>
                                    <label class="col-sm-12 red" id="work_executed_up_by_errmsg"><?php echo form_error('WorkExecutedBy'); ?></label>
                                </div>
								<div class="col-lg-6">
        							<p>( Select "Others" if the required option was not listed.)</p>
        						</div>
                            </div>
                            </div>



                          <div id="field_idz2"> 
                               <div class="form-group">

                        <div id="approvedby">
                        <label for="DateInstallation" class="col-sm-2 control-label">Approved by</label>
                        <div class="col-lg-4">
                        <select class="form-control selectpicker" name="approvedby">
                    
                           <option>select approved by</option>
                              <?php foreach($approved_master as $data) {?>
                                <option <?php if($data["text"]==@$approved_by_the[0]["field_value"]) echo "selected"?>  value="<?=$data["text"]?>"><?=$data["text"]?></option>
                            <?php } ?>
							<option value="Others">Others</option>
                            
                        </select>


                        </div>
						<div class="col-lg-6">
							<p>( Select "Others" if the required option was not listed.)</p>
						</div>
                        </div>
                        </div>

                 

                      
                        <div class="form-group">


                        <div id="verifiedby">
                        <label for="DateInstallation" class="col-sm-2 control-label">Verified By</label>
                        <div class="col-lg-4">

                        <select  class="form-control selectpicker" name="verifiedby">
                            <option>select verified by</option>
                            <?php foreach($verified_master as $data) {?>
                                <option  <?php if($data["text"]==@$verifiedby_the[0]["field_value"]) echo "selected"?>   value="<?=$data["text"]?>"><?=$data["text"]?></option>
                            <?php } ?>
							<option value="Others">Others</option>
                        </select>


                        </div>
						<div class="col-lg-6">
							<p>( Select "Others" if the required option was not listed.)</p>
						</div>
                        </div>
                        </div>
                        </div>
                        




                            <div class="form-group" id="executive_software">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Executive Software</th>
                                                <th>Vesion</th>
                                                <th>Checksum / CRC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr hidden>
                                                <td>Pervious Executive Software</td>
                                                <td>
                                                    <input type="text" name="PreviousESwVersion" id="PreviousESwVersion" readonly="" class="form-control"  value="<?php echo $version[0]['PreviousESwVersion']; ?>">
                                                    <label class="col-sm-12"><?php echo form_error('PreviousESwVersion'); ?></label>
                                                </td>
                                                <td>
                                                    <input type="text" name="PreviousESwChecksum" id="PreviousESwChecksum" readonly="" class="form-control"  value="<?php echo $version[0]['PreviousESwChecksum']; ?>">                                             
                                                    <label class="col-sm-12"><?php echo form_error('PreviousESwChecksum'); ?></label>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td>updated Executive Software</td>
                                                <td>
                                                    <input type="text" name="CurrentESwVersion" id="CurrentESwVersion" class="form-control" value="<?php echo $version[0]['CurrentESwVersion']; ?>">
                                                    <label class="col-sm-12"><?php echo form_error('CurrentESwVersion'); ?></label>
                                                </td>
                                                <td>
                                                    <input type="text" name="CurrentESwChecksum" id="CurrentESwChecksum" class="form-control" value="<?php echo $version[0]['CurrentESwChecksum']; ?>">  
                                                    <label class="col-sm-12"><?php echo form_error('CurrentESwChecksum'); ?></label>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group" id="noofcpu">
                                <label class="col-sm-2 control-label">No of CPU's</label>
                                <div class="col-lg-4">
                                    <input type="number" name="NoOfCPU" data-tag="noofcpu" data-title="No of CPU" id="insert-rows-amnt" class="form-control NoOfCPU" min="0" max="15"  value="<?php echo $version[0]['NoOfCPU']; ?>"/>
                                    <label class="col-sm-12 red" id="noofcpu_errmsg"><?php echo form_error('NoOfCPU'); ?></label>
                                    <!--<button id="add-row" type="button">Add Rows</button>-->
                                </div>
                                <div class="col-sm-12">
                                    <style>
                                        .NumberCpu {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .NumberCpu td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                    </style>
                                    <table style="<?php
                                    if (count($cpu_details) == 0) {
                                        ?>display: none;<?php } ?>" class="mtop20 NumberCpu table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="text-center">Vital</th>
                                                <th class="text-center">Non Vital</th>
                                                <th></th>
                                            <tr>
                                            <!-- <tr>
                                                <th>Sno</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Action</th>
                                            <tr> -->
                                        </thead>
                                        <tbody class="dynamic">
                                            <?php
                                            if (count($cpu_details) > 0) {
                                                foreach ($cpu_details as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td></td>
                                                      
                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="<?php echo $subrows['CurrentVital']; ?>" /></td>
                                                        <!-- <td><input type="text" name="PreviousNonVital[]" class="form-control" value="<?php //echo $subrows['PreviousNonVital']; ?>" readonly="" /></td>-->
                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="<?php echo $subrows['CurentNonVital']; ?>" /></td>
                                                        <td>
                                                            <input type="hidden" class="cpuVendorID" value="<?php echo $subrows['VendorID']; ?>"/>
                                                            <input type="hidden" class="cpuRailwayID" value="<?php echo $subrows['RailwayID']; ?>"/>
                                                            <input type="hidden" class="cpuDivisionID" value="<?php echo $subrows['DivisionID']; ?>"/>
                                                            <input type="hidden" class="cpuStationID" value="<?php echo $subrows['StationID']; ?>"/>
                                                            <input type="hidden" class="cpuVersionID" value="<?php echo $subrows['VersionID']; ?>"/>
                                                            <input type="hidden" class="cpuID" value="<?php echo $subrows['CpuNo']; ?>"/>
                                                            <a class="label label-info label-mini remove_this_row_cpu btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            }
                                            ?>
                                        </tbody>
                                        <tbody class="static">

                                        </tbody>
                                    </table>
                                </div>
                            </div>
							
							<div class="form-group" id="software_file_upload">
                                	<label class="col-sm-2 control-label">Software File</label>
                                	<div class="col-lg-4">
                                		<div class="dropzone" id="SoftwareFile" name="mainFileUploader_SoftwareFile">
                                      
<div class="dz-message" data-dz-message><span>Upload FAT/SAT certificate File Here </span></div>

                                        </div>
                                		<input type="hidden" name="SoftwareFileDownloadPath" id="SoftwareFileDownloadPath" value="<?php echo $version[0]['softwarefileDownloadPath']; ?>"/>
                                		<label class="cls red SoftwareLogic" style="margin-left: 15px;"><?php if($version[0]['softwarefileDownloadPath'] != ""){ echo "Had Software File"; } ?></label>
                                	</div>
                                	<div class="col-lg-2" id="file_loader">
                                		<p>Processing File</p>
                                		<img src="<?php echo $asset_url; ?>img/loading_file.gif" width="48px" />
                                	</div>
                                </div>

                            <div class="form-group" id="certificates">
                                    <label class="col-sm-2 control-label">Certificates</label>
                                    <div class="col-lg-4">
                                        <input type="hidden" id="CertificateFilePath" name="CertificateDownloadPath" value="<?php echo $version[0]['CertificateDownloadPath']; ?>">
                                        <div class="dropzone" id="CertificateFile" name="mainFileUploader_VduFile">
                                            <div class="dz-message" data-dz-message><span>Upload Certificates File Here </span></div>
                                        </div>
                                        <label class="cls red" style="margin-left: 15px;"><?php if($version[0]['CertificateDownloadPath'] != ""){ echo "Had Certificate File"; } ?></label>
                                    </div>
                                </div>
                                <div class="form-group" id="other_uploads">
                                    <label class="col-sm-2 control-label">Others</label>
                                    <div class="col-lg-4">
                                        <input type="hidden" id="OthersDownloadPath" name="OthersDownloadPath" value="<?php echo $version[0]['OthersDownloadPath']; ?>">
                                         <div class="dropzone" id="OthersDownloadFile" name="OthersDownloadFile">
                                            <div class="dz-message" data-dz-message><span>Upload Others File Here </span></div>
                                        </div>
                                        <label class="cls red" style="margin-left: 15px;"><?php if($version[0]['OthersDownloadPath'] != ""){ echo "Had Other File"; } ?></label>
                                    </div>
                                </div>
                             <?php
                                foreach($fields as $field){ if($field["is_autofield"] == 1){
                                	$field_value = "";
                                	foreach($cust_field as $custom_field){
                                	if($field['field_name'] == $custom_field['field_name']){
                                		$field_value = $custom_field['field_value'];
                                	}
									}

                                    if($field["VersionFieldsMasterID"]!="23" && $field["VersionFieldsMasterID"]!="24"){
                                	?>
                                	<div class="form-group" id="<?php echo $field["field_name"]; ?>">
                                <label class="col-sm-2 control-label" for="inputSuccess"><?php echo $field["field_display_name"]; ?></label>
                                <div class="col-lg-4">
                                    <input type="text" data-tag="<?php echo $field["field_name"]; ?>" data-title="<?php echo $field["field_display_name"]; ?>" name="<?php echo $field["field_name"]; ?>" id="<?php echo $field["field_name"]; ?>_ids" class="form-control" placeholder="<?php echo $field["field_display_name"]; ?>" value="<?php echo $field_value; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40">
                                    <label class="col-sm-12 red" id="<?php echo $field["field_name"]; ?>_errmsg"><?php echo form_error($field["field_name"]); ?></label>
                                </div>
                            </div><?php } } }
                            ?>
                            
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <style>
                                        .upload_add_row {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .upload_add_row td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                        .upload_add_row tr:first-child td:last-child a:last-child{
                                            pointer-events: none;
                                            opacity: 0.5;
                                        }
                                    </style>
                                    <strong>Additional info (if any):</strong>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Name (For eg: Application type)</th>
                                                <th>Value (For eg: Centralized)</th>
                                                <th>Add</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            if (count($parameter_details) > 0) {
                                                foreach ($parameter_details as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td></td>
                                                        <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value="<?php echo $subrows['ParameterName']; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40"></td>
                                                        <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value="<?php echo $subrows['ParameterValue']; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40"></td>
                                                        <td>
                                                            <input type="hidden" class="parameterVendorID" value="<?php echo $subrows['VendorID']; ?>"/>
                                                            <input type="hidden" class="parameterRailwayID" value="<?php echo $subrows['RailwayID']; ?>"/>
                                                            <input type="hidden" class="parameterDivisionID" value="<?php echo $subrows['DivisionID']; ?>"/>
                                                            <input type="hidden" class="parameterStationID" value="<?php echo $subrows['StationID']; ?>"/>
                                                            <input type="hidden" class="parameterVersionID" value="<?php echo $subrows['VersionID']; ?>"/>
                                                            <input type="hidden" class="parameterID" value="<?php echo $subrows['ParameterId']; ?>"/>
                                                            <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                            <a class="label label-info label-mini remove_this_row btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                    <?php
                                                }
                                            } else {
                                                ?>
                                                <tr>
                                                    <td></td>
                                                    <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value="" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40"></td>
                                                    <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value="" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&+=?;:']/gi, ''));" maxlength="40"></td>
                                                    <td>
                                                        <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                        <a data-action="remove_this_row"  class="label label-info label-mini btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                    </td>
                                                </tr>
                                            <?php }
                                            ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-4  mtop20 checkbox_customize">                                  
                                    <input type="submit" id="sub_btn" class="btn btn-warning preventbtn" value="Submit"/>
                                    <a href="<?php echo site_url(); ?>Admin/view-version" class="btn btn-default">Back</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<!-- bootstrap-daterangepicker -->
<script src="<?php echo $asset_url; ?>assets/datepicker/moment/min/moment.min.js"></script>
<script src="<?php echo $asset_url; ?>assets/datepicker/bootstrap-daterangepicker/daterangepicker.js"></script>
<!-- End of bootstrap-daterangepicker -->

<script>

$(function(){

	$('#checksum_ids').keyup(function()
	{
		var yourInput = $(this).val();
		re = /[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi;
		var isSplChar = re.test(yourInput);
		if(isSplChar)
		{
			var no_spl_char = yourInput.replace(/[`~!@#$%^&*()_|+\-=?;:'",.<>\{\}\[\]\\\/]/gi, '');
			$(this).val(no_spl_char);
		}
	});

});


</script>
<script>


<?php
if (count($version_logic) > 1) {
    ?>
                                            var cpu_det =<?php echo json_encode($version_logic[1]['cpu_det']); ?>;
    <?php
} else {
    ?>
                                            var cpu_det = [];
    <?php
}
?>
                                        var Applicationfileerr = false;
                                        var Interfacefileerr = false;
                                        var softwareFileerr = true; 
                                        var Vdufileerr = false;
                                        function zone_chg_division(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                                                data: {
                                                    id: id,
                                                    multiple: 1,
                                                    db:'another_db'
                                                },
                                                success: function (res) {
                                                    $(".division_div").html("");
                                                    $(".station_div").html("");
                                                    if (res != 0)
                                                    {
                                                        $(".division_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
											
											$.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Work_Fields'); ?>",
                                                data: {
                                                    id: id,
                                                    db:'another_db'
                                                },
                                                success: function (res) {
                                                    $("#field_idz1").html("");
                                                    if (res != 0)
                                                    {
                                                        $("#field_idz1").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
											$.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Fields'); ?>",
                                                data: {
                                                    id: id,
                                                    db:'another_db'
                                                },
                                                success: function (res) {
                                                    $("#field_idz2").html("");
                                                    if (res != 0)
                                                    {
                                                        $("#field_idz2").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }


                                        function division_chg_station(Divid)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                                                data: {
                                                    id: $("#RailwayID").val(),
                                                    did: Divid,
                                                    db:'another_db'
                                                },
                                                success: function (res) {
                                                    if (res != 0)
                                                    {
                                                        $(".station_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }

                                        function vendorChg(id)
                                        {
                                            if ($("#RailwayID").val() == "" || $("#DivisionID").val() == "" || $("#StationID").val() == "")
                                            {
                                                alert("Please Choose Above Details");
                                            } else
                                            {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo site_url('Admin/Vendor_Chg_Version'); ?>",
                                                    data: {
                                                        id: $("#RailwayID").val(),
                                                        did: $("#DivisionID").val(),
                                                        sid: $("#StationID").val(),
                                                        vid: id,
                                                        db:'another_db'
                                                    },
                                                    success: function (res) {
                                                        var data = JSON.parse(res);
                                                        console.log(data);
                                                        if (data == 2 || data == 0)
                                                        {
                                                           // $("#PreviousESwChecksum").val("");
                                                            //$("#PreviousESwVersion").val("");
                                                           // $("#CurrentESwVersion").val("");
                                                            $("#VersionID").val("");

                                                            $("#SoftwareFileDownloadPath").val("");
                                                        }
                                                        else
                                                        {
                                                            if (data.length >= 0)
                                                            {
                                                                cpu_det = data[0].cpu_det;
                                                               // $("#PreviousESwChecksum").val(data[0].CurrentESwChecksum);
                                                               // $("#PreviousESwVersion").val(data[0].VersionNo);
                                                            } else if (data.length > 0)
                                                            {
                                                                console.log(data);
                                                               // $("#PreviousESwChecksum").val(data[0].PreviousESwChecksum);
                                                               // $("#PreviousESwVersion").val(data[0].PreviousESwVersion);
                                                            }
                                                            //$("#CurrentESwVersion").val(data[0].VersionNo);
                                                            $("#VersionID").val(data[0].VersionID);

                                                            $("#SoftwareFileDownloadPath").val(data[0].softwarefileDownloadPath);
                                                        }
                                                    }
                                                });
                                                
                                                getVendorFields(id);
                                            }
                                        }

                                        var maxField = 25; //Input fields increment limitation
                                        var addButton_more = $('.add_button_more'); //Add button selector
                                        var wrapper_more = $('.field_wrapper_more'); //Input field wrapper
                                        var fieldHTML_more = '<div class="row with-forms"><div class="col-md-5"><h5>Title</h5><input type="text" name="product_info_title[]" placeholder="Enter Title"></div><div class="col-md-5"><h5>Value</h5><input type="text" name="product_info_value[]" placeholder="Enter Value"></div><a href="javascript:void(0);" class="remove_button" title="Remove field"><img class="rem_field_img" src="http://localhost/Admin/assets/img/remove-icon.png"/></a></div>'; //New input field html 
                                        var x = 1; //Initial field counter is 1


                                        $('#insert-rows-amnt').blur(function () {
                                            addNoofCPU($('#insert-rows-amnt').val());
                                        });
                                        
                                        function addNoofCPU(nrows){
                                        	var numNewRows = parseInt(nrows, 10);
                                            
                                            console.log(numNewRows);
                                            if (isNaN(numNewRows) || numNewRows <= 0) {
                                                alert('Please enter number of rows to insert');
                                            } else if (numNewRows > 15)
                                            {
                                                alert('Maximum 15 Rows only can add');
                                            } else {
                                                $(".NumberCpu").show();
                                                // numNewRows = numNewRows - $('.dynamic tr').length;
                                                $tbody = $('.NumberCpu tbody.static');
                                                var trdetails = "";
                                                for (i = 0; i < numNewRows; i++)
                                                {
                                                    trdetails = trdetails + '<tr>\n\
                                                                        <td></td>\n\
                                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="" /></td>\n\
                                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="" /></td>\n\\n\
                                                                            <td></td>\n\
                                                    </tr>';

                                                }
                                                $tbody.html(trdetails);
                                            }
                                        }

                                        $('.remove_this_row').on('click', function () {
                                            var $tr = $(this).closest("tr");
                                            var ID = $tr.find(".parameterID").val();
                                            var parameterVendorID = $tr.find(".parameterVendorID").val();
                                            var parameterRailwayID = $tr.find(".parameterRailwayID").val();
                                            var parameterDivisionID = $tr.find(".parameterDivisionID").val();
                                            var parameterStationID = $tr.find(".parameterStationID").val();
                                            var parameterVersionID = $tr.find(".parameterVersionID").val();
                                            if (ID != "")
                                            {
                                                var answer = confirm("Are you sure you want to delete this Parameter?");
                                                if (answer)
                                                {

                                                    $.ajax({
                                                        type: "POST",
                                                        url: "<?php echo site_url('Admin/delete-parameter'); ?>",
                                                        data: {
                                                            id: ID,
                                                            VendorID: parameterVendorID,
                                                            RailwayID: parameterRailwayID,
                                                            DivisionID: parameterDivisionID,
                                                            StationID: parameterStationID,
                                                            VersionID: parameterVersionID,
                                                            db:'another_db'
                                                        },
                                                        success: function (res) {
                                                            console.log(ID);
                                                            $tr.remove();
                                                        }
                                                    });
                                                }
                                            }
                                            else
                                            {
                                                $(this).closest('tr').remove();
                                            }
                                        });

                                        $('.remove_this_row_cpu').on('click', function () {
                                            var answer = confirm("Are you sure you want to delete this CPU?");
                                            if (answer)
                                            {
                                                var $tr = $(this).closest("tr");
                                                var ID = $tr.find(".parameterID").val();
                                                var ID = $tr.find(".cpuID").val();
                                                var cpuVendorID = $tr.find(".cpuVendorID").val();
                                                var cpuRailwayID = $tr.find(".cpuRailwayID").val();
                                                var cpuDivisionID = $tr.find(".cpuDivisionID").val();
                                                var cpuStationID = $tr.find(".cpuStationID").val();
                                                var cpuVersionID = $tr.find(".cpuVersionID").val();
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo site_url('Admin/delete-cpu'); ?>",
                                                    data: {
                                                        id: ID,
                                                        VendorID: cpuVendorID,
                                                        RailwayID: cpuRailwayID,
                                                        DivisionID: cpuDivisionID,
                                                        StationID: cpuStationID,
                                                        VersionID: cpuVersionID,
                                                        db:'another_db'
                                                    },
                                                    success: function (res) {
                                                        console.log(ID);
                                                        $tr.remove();
                                                    }
                                                });
                                            }
                                        });
</script>

<script type="text/javascript">
    $(document).ready(function () {
    	
    	$('.mydatepicker').daterangepicker({
          singleDatePicker: true,
          calender_style: "picker_4",
          maxDate: new Date(),
          locale: {
            format: 'DD-MM-YYYY'
        }
        }, function(start, end, label) {
          console.log(start.toISOString(), end.toISOString(), label);
        });
    	
        $('a[data-action="remove_this_row"]').on('click', function (event) {
            event.preventDefault();
            $(this).closest('tr').remove();
        });


        $('a[data-action="add_new_row"]').on('click', function (event) {
            event.preventDefault();
            var source = $(this).closest('tr');
            var clone = source.clone(true);
            source.after(clone);
            clone.find('.ParameterValue').val('');
            clone.find('.ParameterName').val('');
            clone.find('.parameterID').val('');
            clone.find('a.readonly').removeClass('readonly');

        });
    });


    function ApplicationFileChg(ApplicationFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('ApplicationLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                db:'another_db',
                ApplicationFile: ApplicationFile,
                Important_Files_Application: $("#ApplicationImportantFilesRequired").val(),
            },
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                console.log(data);
                $("#ApplicationFolderCountAvailable").val(data.folderCount);
                if (data.folderCount != $("#ApplicationFolderCountRequiredText").val() || data.fileCount != $("#ApplicationFileCountRequiredText").val() || data.ImportantfileCount != $("#ApplicationImportantFilesCountText").val())
                {
                    $(".ApplicationLogic").html("Folder/File Count Invalid");
                    Applicationfileerr = true;
                }
                else
                {
                    $(".ApplicationLogic").html("");
                    Applicationfileerr = false;
                }
                $("#ApplicationFileCountAvailable").val(data.fileCount);
                $("#ApplicationImportantFilesAvailable").val(data.ImportantfileCount);
                $("#ApplicationFolderCountRequiredAvail").html(data.folderCount);
                $("#ApplicationFileCountRequiredAvail").html(data.fileCount);
                $("#ApplicationImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#ApplicationDownloadPath").val(data.FilePath);
            }
        });
    }

    function InterfaceFileChg(InterfaceFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('InterfaceLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                db:'another_db',
                InterfaceFile: InterfaceFile,
                Important_Files_Interface: $("#InterfaceImportantFilesRequired").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#InterfaceFolderCountRequiredText").val() || data.fileCount != $("#InterfaceFileCountRequiredText").val() || data.ImportantfileCount != $("#InterfaceImportantFilesCountText").val())
                {
                    $(".InterfaceLogic").html("Folder/File Count Invalid");
                    Interfacefileerr = true;

                }
                else
                {
                    $(".InterfaceLogic").html("");
                    Interfacefileerr = false;
                }
                $("#InterfaceFolderCountAvailable").val(data.folderCount);
                $("#InterfaceFileCountAvailable").val(data.fileCount);
                $("#InterfaceImportantFilesAvailable").val(data.ImportantfileCount);
                $("#InterfaceFolderCountRequiredAvail").html(data.folderCount);
                $("#InterfaceFileCountRequiredAvail").html(data.fileCount);
                $("#InterfaceImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#InterfaceDownloadPath").val(data.FilePath);
            }
        });
    }


    function VduFileChg(VduFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('VduLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                VduFile: VduFile,
                db:'another_db',
                Important_Files_Vdu: $("#VduImportantFilesRequired").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#VduFolderCountRequiredText").val() || data.fileCount != $("#VduFileCountRequiredText").val() || data.ImportantfileCount != $("#VduImportantFilesCountText").val())
                {
                    $(".VduLogic").html("Folder/File Count Invalid");
                    Vdufileerr = true;
                }
                else
                {
                    $(".VduLogic").html("");
                    Vdufileerr = false;
                }
                $("#VduFolderCountAvailable").val(data.folderCount);
                $("#VduFileCountAvailable").val(data.fileCount);
                $("#VduImportantFilesAvailable").val(data.ImportantfileCount);
                $("#VduFolderCountRequiredAvail").html(data.folderCount);
                $("#VduFileCountRequiredAvail").html(data.fileCount);
                $("#VduImportantFilesCountAvail").html(data.ImportantfileCount);
                $("#VduDownloadPath").val(data.FilePath);
            }
        });
    }
</script>

<script src="<?php echo base_url(); ?>assets/js/dropzone.js"></script>
<script>
    Dropzone.autoDiscover = false;
    
    var myDropzone = new Dropzone("#SoftwareFile",{
    	url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var ApplicationFile = jQuery.trim(responseText);
                console.log(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.SoftwareLogic').html("Requrires Only Zip File");
                    this.removeFile(file);
                } else
                {
                    $('.SoftwareLogic').html("");
                    SoftwareFileChg(ApplicationFile);
                }
            });
        }
    });
    
    var myDropzone = new Dropzone("#CertificateFile", {
        url: "<?php echo site_url("Admin/uploadFile") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var CertificateFile = jQuery.trim(responseText);
                $('.CertificateLogic').html("");
                $("#CertificateFilePath").val(CertificateFile);
                /*var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.CertificateLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.CertificateLogic').html("");
                    $("#CertificateFilePath").val(CertificateFile);
                }*/
            });
        }
    });
    
    var myDropzone = new Dropzone("#OthersDownloadFile", {
        url: "<?php echo site_url("Admin/uploadFile") ?>",
        addRemoveLinks: true,
        maxFiles:1,
        init: function () {
            this.on("success", function (file, responseText) {
                var OthersDownloadFile = jQuery.trim(responseText);
                $('.OthersLogic').html("");
                $("#OthersDownloadPath").val(OthersDownloadFile);
                /*var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.OthersLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.OthersLogic').html("");
                    $("#OthersDownloadPath").val(OthersDownloadFile);
                }*/
            });
        }
    });

	function getVendorFields(id){
		<?php foreach($fields as $field){
                                        	?>$("#<?php echo $field['field_name']; ?>").hide(); <?php
                                        }
										?> 
                                        	$.ajax({
                                        		type: "POST",
                                                    url: "<?php echo site_url('Admin/AjaxForm/getVendorFields'); ?>",
                                                    data: {
                                                        VendorID: id,
                                                        db:'another_db'
                                                    },
                                                    success: function (res) {
                                                    	var data = JSON.parse(res);
                                                    	for(var i = 0; i< data.length; i++){
                                                    		$("#"+data[i].fname).each(function(){
                                                    			$(this).find(':input').not(':input[readonly]').removeAttr('required');
                                                    		});
                                                    		if(data[i].is_visible == 1){
                                                    			$("#"+data[i].fname).show();
                                                    		}
                                                    		if(data[i].is_mandatory == 1){
                                                    			$("#"+data[i].fname).each(function(){
                                                    				$(this).find(':input').not(':input[readonly]').prop('required',true);
                                                    			});
                                                    		}
                                                    	}
                                                    }
                                        	});
                                        	//addNoofCPU($('#insert-rows-amnt').val());
                                        }

    
    function SoftwareFileChg(SoftwareFile){
    	$("#file_loader").show();
    	console.log("VendorID "+$("#VendorID").val());
		$.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/AjaxForm/SoftwarefileUpload'); ?>",
            data: {
                VendorID: $("#VendorID").val(),
                ApplicationFile: SoftwareFile,
                db:'another_db'
            },
            success: function (res) {
                console.log(res);
                var data = JSON.parse(res);
                $(".SoftwareLogic").html('');
                softwareFileerr = true;
                $("#SoftwareFileDownloadPath").val("");
                if(data.valid === "false"){
                	$("#file_loader").hide();
                	$(".SoftwareLogic").html("File Doesn't Contain the Requirements");
                }else{
                	softwareFileerr = false;
                	$("#file_loader").hide();
                	$("#SoftwareFileDownloadPath").val(data.FilePath);
                }
            }
        });
	}

    
    $(document).ready(function () {
    	$("#file_loader").hide();
                                        <?php foreach($fields as $field){
                                        	?>$("#<?php echo $field['field_name']; ?>").hide(); <?php
                                        }
										?> 
										getVendorFields('<?php echo $VendorID; ?>');
										vendorChg('<?php echo $VendorID; ?>');
										
										function validateBefore(){
											var passed = true;
											$('form').find('select, textarea, input').each(function(){
												$("#"+$(this).attr("data-tag")+"_errmsg").html("");
												if($(this).prop('required')){
													if($(this).val() === ""){
													passed = false;
													$("#"+$(this).attr("data-tag")+"_errmsg").html($(this).attr("data-title")+" is Required to Continue");
													}
												}
											});
											return passed;
										}
										
										$('.preventbtn').on('click', function (event) {
											event.preventDefault();
											var passed = validateBefore();
											if(passed == true){
											if ($(".SoftwareLogic").html() != "" && $(".SoftwareLogic").html() != "Had Software File")
            {
            	alert('Require Software File to be uploaded');
                event.preventDefault();
                return false;
            }
            else
            {
                var option = $('#StationID option:selected').attr('included');
                <?php
                                    if($this->session->userdata("UserRole")!="Admin")
                                    {?> 
                                                 if(option === "red"){
                                                 	LevelSecurity.securityUrl = '<?=site_url($menusetting_station_in_red["url"])?>';
                                                 	LevelSecurity.changeLable('Level <?php echo $menusetting_station_in_red["LevelNo"]; ?> Password');
                                                 	LevelSecurity.showPassword();
                                                 }else{
                                                 	LevelSecurity.securityUrl = '<?=site_url($menusetting_station_in_normal["url"])?>';
                                                 	LevelSecurity.changeLable('Level <?php echo $menusetting_station_in_normal["LevelNo"]; ?> Password');
                                                 	LevelSecurity.showPassword();
                                                 }
                                                 if(LevelSecurity.isPasswordOk == false){
                                                 		return false;
                                                 }
                                    event.preventDefault();
                                    return false
                                    <?php
                                    }
                                    ?>
                $("form").submit(); 
            }
           }else{
           	alert('Fill all the Required Fields');
           	return false;
           }
                                    
                                });
                                
    });
										
</script>

<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Level <?=$menusetting_station_in_red["security_level"]?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 

$slp = array(
	"setting" => $menusetting_station_in_normal
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.init(false);
				
				
			});

</script>

</body>
</html>