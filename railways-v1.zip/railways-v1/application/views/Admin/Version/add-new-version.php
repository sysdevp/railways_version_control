<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Add New Version</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version" class="btn btn-info">View Version</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal add_new_version_form" role="form" method="POST" enctype="multipart/form-data">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code</label>
                                <div class="col-lg-10">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)" required="">
                                        <option value="">Select Option</option>
                                        <?php
                                        $RailwayID = $this->session->userdata("railway_session_list");
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php
                                            if ($RailwayID != "" && $RailwayID != 0 && $RailwayID == $rows['RailwayID']) {
                                                $rcond = true;
                                                echo "selected";
                                            }
                                            if (isset($RailwayIDPreview)) {
                                                if ($RailwayIDPreview != "" && $RailwayIDPreview != 0 && $RailwayIDPreview == $rows['RailwayID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            echo set_select("RailwayID", $rows['RailwayID'], FALSE);
                                            ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code</label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    $dcond = false;
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($rcond == true) {
                                        $DivisionID = $this->session->userdata("division_session_list");
                                        $dcond = false;
                                        $division = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                                        ?>

                                        <select class="form-control selectpicker"  required="" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID"  onchange="division_chg_station(this.value)">>
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php
                                                if ($DivisionID != "" && $DivisionID != 0 && $DivisionID == $rows['DivisionID']) {
                                                    $dcond = true;
                                                    echo "selected";
                                                } echo set_select("DivisionID", $rows['DivisionID'], FALSE);
                                                ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                   
                                    <label class="col-sm-12"><?php echo form_error('DivisionID'); ?></label>
                                </div>
                                <label for="StationName" class="col-sm-2 control-label">Station Name / Code</label>
                                <input type="hidden" name="VersionID" id="VersionID" value="<?php echo $this->session->userdata("VersionID"); ?>"    />
                                <div class="col-lg-4 station_div">
                                    <?php
                                    if (isset($station)) {
                                        ?>
                                        <select class="form-control selectpicker" required="" id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php echo set_select("StationID", $rows['StationID'], FALSE); ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    } elseif ($dcond == true) {
                                        $StationID = $this->session->userdata("station_session_list");
                                        $dcond = false;
                                        $station = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID), "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
                                        ?>  
                                        <select class="form-control selectpicker" required=""  id="StationID" data-show-subtext="true" data-live-search="true" name="StationID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($station as $rows) {
                                                ?>
                                                <option <?php
                                                if ($StationID != "" && $StationID != 0 && $StationID == $rows['StationID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                } echo set_select("StationID", $rows['StationID'], FALSE);
                                                ?> value="<?php echo $rows['StationID']; ?>"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></option>
                                                    <?php
                                                }
                                                ?>
                                        </select>
                                        <?php
                                    }
                                    ?>                                  
                                    <label class="col-sm-12"><?php echo form_error('StationID'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-validation="required"data-show-subtext="true" data-live-search="true" id="VendorID" name="VendorID" onchange="vendorChg(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        foreach ($vendor as $rows) {
                                            ?>
                                            <option <?php
                                            if (isset($VendorIDPreview)) {
                                                if ($VendorIDPreview != "" && $VendorIDPreview != 0 && $VendorIDPreview == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            }
                                            $VendorID = $this->session->userdata('VendorID');
                                            if (isset($VendorID)) {
                                                if ($VendorID != "" && $VendorID != 0 && $VendorID == $rows['VendorID']) {
                                                    $rcond = true;
                                                    echo "selected";
                                                }
                                            } echo set_select("VendorID", $rows['VendorID'], FALSE);
                                            ?> value="<?php echo $rows['VendorID']; ?>"><?php echo $rows['VendorName'] . $VendorID; ?></option>
                                                <?php
                                            }
                                            ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('VendorID'); ?></label>
                                </div>
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="col-sm-3">
                                            <input id="DistributedYes" type="radio" name="isDistributedVersionType" value="1" <?php
                                            if ($this->session->userdata('isDistributedVersionType') == "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedYes">Yes</label>
                                        </div>
                                        <div class="col-sm-3">
                                            <input id="DistributedNo" type="radio" name="isDistributedVersionType" value="0"  <?php
                                            if ($this->session->userdata('isDistributedVersionType') != "1") {
                                                echo "checked";
                                            }
                                            ?>>
                                            <label style="font-weight:normal" for="DistributedNo">No</label>
                                        </div>
                                        <label class="col-sm-12"><?php echo form_error('isDistributedVersionType'); ?></label>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number</label>
                                <div class="col-lg-4">
                                    <input type="text" name="SignalPlanNumber" required=""  class="form-control" id="SignalingPlanNumber" placeholder="Signaling Plan Number" value="<?php echo $this->session->userdata('SignalPlanNumber'); ?>">
                                    <label class="col-sm-12"><?php echo form_error('SignalPlanNumber'); ?></label>
                                </div>
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation</label>
                                <div class="col-lg-4">
                                    <input type="date" name="InstallationAlterationDate" required=""  class="form-control" id="DateInstallation" required="required" value="<?php echo $this->session->userdata('InstallationAlterationDate'); ?>">
                                    <label class="col-sm-12"><?php echo form_error('InstallationAlterationDate'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work</label>
                                <div class="col-lg-10">
                                    <input type="text" name="DescriptionOfWork" required=""  class="form-control" id="ReasonChanging" placeholder="Description of Work" value="<?php echo $this->session->userdata('DescriptionOfWork'); ?>">
                                    <label class="col-sm-12"><?php echo form_error('DescriptionOfWork'); ?></label>
                                </div>
                            </div> 
                            <div class="form-group">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed up by</label>
                                <div class="col-lg-4">
                                    <input type="text" name="WorkExecutedBy" required=""  class="form-control" id="WorkExcuited" placeholder="Work Executed up by" value="<?php echo $this->session->userdata('WorkExecutedBy'); ?>">
                                    <label class="col-sm-12"><?php echo form_error('WorkExecutedBy'); ?></label>
                                </div>
                            </div>
                            <div class="hiddenarea">
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <table class="table dashboard-table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Executive Software</th>
                                                    <th>Vesion</th>
                                                    <th>Checksum / CRC</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>Pervious Executive Software</td>
                                                    <td>
                                                        <input type="text" name="PreviousESwVersion" id="PreviousESwVersion" readonly="" class="form-control"  value="<?php echo $this->session->userdata('PreviousESwVersion'); ?>">
                                                        <label class="col-sm-12"><?php echo form_error('PreviousESwVersion'); ?></label>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="PreviousESwChecksum" id="PreviousESwChecksum" readonly="" class="form-control"  value="<?php echo $this->session->userdata('PreviousESwChecksum'); ?>">                                             
                                                        <label class="col-sm-12"><?php echo form_error('PreviousESwChecksum'); ?></label>
                                                    </td>
                                                </tr>
                                                <tr>
                                                    <td>updated Executive Software</td>
                                                    <td>
                                                        <input type="text" name="CurrentESwVersion" required=""  id="CurrentESwVersion" readonly="" class="form-control" value="<?php echo $this->session->userdata('CurrentESwVersion'); ?>">
                                                        <label class="col-sm-12"><?php echo form_error('CurrentESwVersion'); ?></label>
                                                    </td>
                                                    <td>
                                                        <input type="text" name="CurrentESwChecksum" required=""  id="CurrentESwChecksum" class="form-control" value="<?php echo $this->session->userdata('CurrentESwChecksum'); ?>">  
                                                        <label class="col-sm-12"><?php echo form_error('CurrentESwChecksum'); ?></label>
                                                    </td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">No of CPU's</label>
                                    <div class="col-lg-4">
                                        <input type="number" name="NoOfCPU" id="insert-rows-amnt" class="form-control" min="0" max="15"  value="<?php echo $this->session->userdata('NoOfCPU'); ?>"/>
                                        <label class="col-sm-12"><?php echo form_error('NoOfCPU'); ?></label>
                                        <!--<button id="add-row" type="button">Add Rows</button>-->
                                    </div>
                                    <div class="col-sm-12">
                                        <style>
                                            .NumberCpu {
                                                counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                            }
                                            .NumberCpu td:first-child:before {
                                                counter-increment: serial-number;  /* Increment the serial number counter */
                                                content: counter(serial-number);  /* Display the counter */
                                            }
                                        </style>
                                        <table style="<?php
                                        if (count($this->session->userdata('temp_cpu_details')) == 0) {
                                            ?>display: none;<?php } ?>" class="mtop20 NumberCpu table dashboard-table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th class="text-center" colspan="2">Vital</th>
                                                    <th class="text-center" colspan="2">Non Vital</th>
                                                <tr>
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Previous</th>
                                                    <th>Updated</th>
                                                    <th>Previous</th>
                                                    <th>Updated</th>
                                                <tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (count($this->session->userdata('temp_cpu_details')) > 0) {
                                                    foreach ($this->session->userdata('temp_cpu_details') as $subrows) {
                                                        ?>
                                                        <tr>
                                                            <td></td>
                                                            <td><input type="text" name="PreviousVital[]" class="form-control" value="<?php echo $subrows['PreviousVital']; ?>" readonly="" /></td>
                                                            <td><input type="text" name="CurrentVital[]" class="form-control" value="<?php echo $subrows['CurrentVital']; ?>" /></td>
                                                            <td><input type="text" name="PreviousNonVital[]" class="form-control" value="<?php echo $subrows['PreviousNonVital']; ?>" readonly="" /></td>
                                                            <td><input type="text" name="CurentNonVital[]" class="form-control" value="<?php echo $subrows['CurentNonVital']; ?>" /></td>
                                                        </tr>
                                                        <?php
                                                    }
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Application Logic</label>
                                    <div class="col-lg-10 ApplicationLogicBG">
                                        <input type="hidden" id="VersionFileApplicationLogic" name="VersionFileApplicationLogic" />                                    
                                        <input type="hidden" id="ApplicationFileImportant" name="ApplicationFileImportant" value="<?php echo $this->session->userdata('ApplicationFileImportant'); ?>"/>                                    
                                        <input type="hidden" name="ApplicationDownloadPath" id="ApplicationDownloadPath" value="<?php echo $this->session->userdata('ApplicationDownloadPath'); ?>"/>
                                        <div class="dropzone" id="ApplicationFile" name="mainFileUploader_ApplicationFile">
                                        </div>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Folder: 
                                            <input type="hidden" name="ApplicationFolderCountAvailable" id="ApplicationFolderCountAvailable" value="<?php echo $this->session->userdata('ApplicationFolderCountAvailable'); ?>"/>
                                            <span id="ApplicationFolderValAvail"><?php echo $this->session->userdata('ApplicationFolderCountAvailable'); ?> </span> /
                                            <input type="hidden" name="ApplicationFolderVal" id="ApplicationFolderValText" value="<?php echo $this->session->userdata('ApplicationFolderVal'); ?>"/>
                                            <span id="ApplicationFolderVal"><?php echo $this->session->userdata('ApplicationFolderVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                            Files:
                                            <input type="hidden" name="ApplicationFileCountAvailable" id="ApplicationFileCountAvailable" value="<?php echo $this->session->userdata('ApplicationFileCountAvailable'); ?>"/>
                                            <span id="ApplicationFileValAvail"><?php echo $this->session->userdata('ApplicationFileCountAvailable'); ?> </span> / 
                                            <input type="hidden" name="ApplicationFileVal" id="ApplicationFileValText" value="<?php echo $this->session->userdata('ApplicationFileVal'); ?>"/>
                                            <span id="ApplicationFileVal"><?php echo $this->session->userdata('ApplicationFileVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Important Files: 
                                            <input type="hidden" name="ApplicationImportantFilesAvailable" id="ApplicationImportantFilesAvailable" value="<?php echo $this->session->userdata('ApplicationImportantFilesAvailable'); ?>"/>
                                            <span id="ApplicationImportantFilesValAvail"><?php echo $this->session->userdata('ApplicationImportantFilesAvailable'); ?> </span> /
                                            <input type="hidden" name="ApplicationImportantFilesVal" id="ApplicationImportantFilesValText" value="<?php echo $this->session->userdata('ApplicationImportantFilesVal'); ?>"/>
                                            <span id="ApplicationImportantFilesVal"><?php echo $this->session->userdata('ApplicationImportantFilesVal'); ?></span>
                                        </label>
                                        <label class="cls red ApplicationLogic" style="margin-left: 15px;"></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Interface Logic</label>
                                    <div class="col-lg-10 InterfaceLogicBG">
                                        <input type="hidden" id="InterfaceFileImportant"  name="InterfaceFileImportant" value="<?php echo $this->session->userdata('InterfaceFileImportant'); ?>"/>                                    
                                        <input type="hidden" name="InterfaceDownloadPath" id="InterfaceDownloadPath" value="<?php echo $this->session->userdata('InterfaceDownloadPath'); ?>"/>
                                        <div class="dropzone" id="InterfaceFile" name="mainFileUploader_InterfaceFile">
                                        </div>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Folder: 
                                            <input type="hidden" name="InterfaceFolderCountAvailable" id="InterfaceFolderCountAvailable" value="<?php echo $this->session->userdata('InterfaceFolderCountAvailable'); ?>"/>
                                            <span id="InterfaceFolderValAvail"><?php echo $this->session->userdata('InterfaceFolderCountAvailable'); ?> </span> /
                                            <input type="hidden" name="InterfaceFolderVal" id="InterfaceFolderValText" value="<?php echo $this->session->userdata('InterfaceFolderVal'); ?>"/>
                                            <span id="InterfaceFolderVal"><?php echo $this->session->userdata('InterfaceFolderVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                            Files:
                                            <input type="hidden" name="InterfaceFileCountAvailable" id="InterfaceFileCountAvailable" value="<?php echo $this->session->userdata('InterfaceFileCountAvailable'); ?>"/>
                                            <span id="InterfaceFileValAvail"><?php echo $this->session->userdata('InterfaceFileCountAvailable'); ?> </span> / 
                                            <input type="hidden" name="InterfaceFileVal" id="InterfaceFileValText" value="<?php echo $this->session->userdata('InterfaceFileVal'); ?>"/>
                                            <span id="InterfaceFileVal"><?php echo $this->session->userdata('InterfaceFileVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Important Files: 
                                            <input type="hidden" name="InterfaceImportantFilesAvailable" id="InterfaceImportantFilesAvailable" value="<?php echo $this->session->userdata('InterfaceImportantFilesAvailable'); ?>"/>
                                            <span id="InterfaceImportantFilesValAvail"><?php echo $this->session->userdata('InterfaceImportantFilesAvailable'); ?> </span> /
                                            <input type="hidden" name="InterfaceImportantFilesVal" id="InterfaceImportantFilesValText" value="<?php echo $this->session->userdata('InterfaceImportantFilesVal'); ?>"/>
                                            <span id="InterfaceImportantFilesVal"><?php echo $this->session->userdata('InterfaceImportantFilesVal'); ?></span>
                                        </label>
                                        <label class="cls red InterfaceLogic" style="margin-left: 15px;"></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Vdu Logic</label>
                                    <div class="col-lg-10 VduLogicBG">
                                        <input type="hidden" id="VduFileImportant" name="VduFileImportant" value="<?php echo $this->session->userdata('VduFileImportant'); ?>" />                                    
                                        <input type="hidden" name="VduDownloadPath" id="VduDownloadPath" value="<?php echo $this->session->userdata('VduDownloadPath'); ?>"/>
                                        <div class="dropzone" id="VduFile" name="mainFileUploader_VduFile">
                                        </div>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Folder: 
                                            <input type="hidden" name="VduFolderCountAvailable" id="VduFolderCountAvailable" value="<?php echo $this->session->userdata('VduFolderCountAvailable'); ?>"/>
                                            <span id="VduFolderValAvail"><?php echo $this->session->userdata('VduFolderCountAvailable'); ?> </span> /
                                            <input type="hidden" name="VduFolderVal" id="VduFolderValText" value="<?php echo $this->session->userdata('VduFolderVal'); ?>"/>
                                            <span id="VduFolderVal"><?php echo $this->session->userdata('VduFolderVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i>
                                            Files:
                                            <input type="hidden" name="VduFileCountAvailable" id="VduFileCountAvailable" value="<?php echo $this->session->userdata('VduFileCountAvailable'); ?>"/>
                                            <span id="VduFileValAvail"><?php echo $this->session->userdata('VduFileCountAvailable'); ?> </span> / 
                                            <input type="hidden" name="VduFileVal" id="VduFileValText" value="<?php echo $this->session->userdata('VduFileVal'); ?>"/>
                                            <span id="VduFileVal"><?php echo $this->session->userdata('VduFileVal'); ?></span>
                                        </label>
                                        <label class="cls green" style="margin-left: 15px;">
                                            <i class="fa fa-check" aria-hidden="true"></i> 
                                            Important Files: 
                                            <input type="hidden" name="VduImportantFilesAvailable" id="VduImportantFilesAvailable" value="<?php echo $this->session->userdata('VduImportantFilesAvailable'); ?>"/>
                                            <span id="VduImportantFilesValAvail"><?php echo $this->session->userdata('VduImportantFilesAvailable'); ?> </span> /
                                            <input type="hidden" name="VduImportantFilesVal" id="VduImportantFilesValText" value="<?php echo $this->session->userdata('VduImportantFilesVal'); ?>"/>
                                            <span id="VduImportantFilesVal"><?php echo $this->session->userdata('VduImportantFilesVal'); ?></span>
                                        </label>
                                        <label class="cls red VduLogic" style="margin-left: 15px;"></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Certificates</label>
                                    <div class="col-lg-10">
                                        <input type="hidden" id="CertificateFilePath" name="CertificateDownloadPath" value="<?php echo $this->session->userdata('CertificateDownloadPath'); ?>">
                                        <div class="dropzone" id="CertificateFile" name="mainFileUploader_VduFile">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label">Others</label>
                                    <div class="col-lg-10">
                                        <input type="hidden" id="OthersDownloadPath" name="OthersDownloadPath" value="<?php echo $this->session->userdata('OthersDownloadPath'); ?>">
                                         <div class="dropzone" id="OthersDownloadFile" name="mainFileUploader_VduFile">
                                        </div>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <style>
                                            .upload_add_row {
                                                counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                            }
                                            .upload_add_row td:first-child:before {
                                                counter-increment: serial-number;  /* Increment the serial number counter */
                                                content: counter(serial-number);  /* Display the counter */
                                            }
                                            .upload_add_row tr:first-child td:last-child a:last-child{
                                                pointer-events: none;
                                                opacity: 0.5;
                                            }
                                        </style>
                                        <table class="mtop20 upload_add_row table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Name</th>
                                                    <th>Value</th>
                                                    <th>Add</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                if (count($this->session->userdata('temp_parameter_details')) > 0) {
                                                    foreach ($this->session->userdata('temp_parameter_details') as $subrows) {
                                                        ?>
                                                        <tr>
                                                            <td></td>
                                                            <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value="<?php echo $subrows['ParameterName']; ?>"></td>
                                                            <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value="<?php echo $subrows['ParameterValue']; ?>"></td>
                                                            <td>
                                                                <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                                <a data-action="remove_this_row"  class="label label-info label-mini btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                            </td>
                                                        </tr>
                                                        <?php
                                                    }
                                                } else {
                                                    ?>
                                                    <tr>
                                                        <td></td>
                                                        <td><input class="form-control ParameterName" name="ParameterName[]" type="text" value=""></td>
                                                        <td><input class="form-control ParameterValue" name="ParameterValue[]" type="text" value=""></td>
                                                        <td>
                                                            <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                            <a data-action="remove_this_row"  class="label label-info label-mini btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                        </td>
                                                    </tr>
                                                <?php }
                                                ?>
                                            </tbody>

                                        </table>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-4  mtop20 checkbox_customize">                                  
                                    <input type="submit" class="btn btn-warning preview_btn" value="Preview"/>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>
<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>
                                        var cpu_det;
                                        $(".hiddenarea").hide();
                                        var Applicationfileerr = true;
                                        var Interfacefileerr = true;
                                        var Vdufileerr = true;
                                        function zone_chg_division(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                                                data: {
                                                    id: id,
                                                    multiple: 1
                                                },
                                                success: function (res) {
                                                    $(".division_div").html("");
                                                    $(".station_div").html("");
                                                    if (res != 0)
                                                    {
                                                        $(".division_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }


                                        function division_chg_station(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Division_Chg_Station'); ?>",
                                                data: {
                                                    id: $("#RailwayID").val(),
                                                    did: id
                                                },
                                                success: function (res) {
                                                    if (res != 0)
                                                    {
                                                        $(".station_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }

                                        function vendorChg(id)
                                        {
                                            if ($("#RailwayID").val() == "" || $("#DivisionID").val() == "" || $("#StationID").val() == "")
                                            {
                                                alert("Please Choose Above Details");
                                                $(".hiddenarea").hide();
                                            } else
                                            {
                                                $.ajax({
                                                    type: "POST",
                                                    url: "<?php echo site_url('Admin/Vendor_Chg_Version'); ?>",
                                                    data: {
                                                        id: $("#RailwayID").val(),
                                                        did: $("#DivisionID").val(),
                                                        sid: $("#StationID").val(),
                                                        vid: id
                                                    },
                                                    success: function (res) {
                                                        var data = JSON.parse(res);
                                                        console.log(data);
                                                        if (data == 2 || data == 0)
                                                        {
                                                            $("#PreviousESwChecksum").val("");
                                                            $("#PreviousESwVersion").val("");
                                                            $("#CurrentESwVersion").val("");
                                                            $("#VersionID").val("");

                                                            $("#ApplicationFolderVal").html("");
                                                            $("#ApplicationFileVal").html("");
                                                            $("#ApplicationImportantFilesVal").html("");
                                                            $("#ApplicationFolderValText").val("");
                                                            $("#ApplicationFileValText").val("");
                                                            $("#ApplicationImportantFilesValText").val("");
                                                            $("#ApplicationFileImportant").val("");

                                                            $("#InterfaceFolderVal").html("");
                                                            $("#InterfaceFileVal").html("");
                                                            $("#InterfaceImportantFilesVal").html("");
                                                            $("#InterfaceFolderValText").val("");
                                                            $("#InterfaceFileValText").val("");
                                                            $("#InterfaceImportantFilesValText").val("");
                                                            $("#InterfaceFileImportant").val("");

                                                            $("#VduFolderVal").html("");
                                                            $("#VduFileVal").html("");
                                                            $("#VduImportantFilesVal").html("");
                                                            $("#VduFolderValText").val("");
                                                            $("#VduFileValText").val("");
                                                            $("#VduImportantFilesValText").val("");
                                                            $("#VduFileImportant").val("");

                                                            $(".hiddenarea").hide();
                                                        }
                                                        else
                                                        {
                                                            if (data.length > 1)
                                                            {
                                                                cpu_det = data[1].cpu_det;
                                                                $("#PreviousESwChecksum").val(data[1].CurrentESwChecksum);
                                                                $("#PreviousESwVersion").val(data[1].VersionNo);
                                                            } else if (data.length > 0)
                                                            {
                                                                cpu_det ="";
                                                                console.log(data);
                                                                $("#PreviousESwChecksum").val(data[0].PreviousESwChecksum);
                                                                $("#PreviousESwVersion").val(data[0].PreviousESwVersion);
                                                            }
                                                            $("#CurrentESwVersion").val(data[0].VersionNo);
                                                            $("#VersionID").val(data[0].VersionID);

                                                            $("#ApplicationFolderVal").html(data[0].ApplicationFolderCountRequired);
                                                            $("#ApplicationFileVal").html(data[0].ApplicationFileCountRequired);
                                                            $("#ApplicationImportantFilesVal").html(data[0].ApplicationImportantFilesCount);
                                                            $("#ApplicationFolderValText").val(data[0].ApplicationFolderCountRequired);
                                                            $("#ApplicationFileValText").val(data[0].ApplicationFileCountRequired);
                                                            $("#ApplicationImportantFilesValText").val(data[0].ApplicationImportantFilesCount);
                                                            $("#ApplicationFileImportant").val(data[0].ApplicationImportantFilesRequired);

                                                            $("#InterfaceFolderVal").html(data[0].InterfaceFolderCountRequired);
                                                            $("#InterfaceFileVal").html(data[0].InterfaceFileCountRequired);
                                                            $("#InterfaceImportantFilesVal").html(data[0].InterfaceImportantFilesCount);
                                                            $("#InterfaceFolderValText").val(data[0].InterfaceFolderCountRequired);
                                                            $("#InterfaceFileValText").val(data[0].InterfaceFileCountRequired);
                                                            $("#InterfaceImportantFilesValText").val(data[0].InterfaceImportantFilesCount);
                                                            $("#InterfaceFileImportant").val(data[0].InterfaceImportantFilesRequired);

                                                            $("#VduFolderVal").html(data[0].VduFolderCountRequired);
                                                            $("#VduFileVal").html(data[0].VduFileCountRequired);
                                                            $("#VduImportantFilesVal").html(data[0].VduImportantFilesCount);
                                                            $("#VduFolderValText").val(data[0].VduFolderCountRequired);
                                                            $("#VduFileValText").val(data[0].VduFileCountRequired);
                                                            $("#VduImportantFilesValText").val(data[0].VduImportantFilesCount);
                                                            $("#VduFileImportant").val(data[0].VduImportantFilesRequired);
                                                            $(".hiddenarea").show();
                                                        }
                                                    }
                                                });
                                            }
                                        }

                                        var maxField = 25; //Input fields increment limitation
                                        var addButton_more = $('.add_button_more'); //Add button selector
                                        var wrapper_more = $('.field_wrapper_more'); //Input field wrapper
                                        var fieldHTML_more = '<div class="row with-forms"><div class="col-md-5"><h5>Title</h5><input type="text" name="product_info_title[]" placeholder="Enter Title"></div><div class="col-md-5"><h5>Value</h5><input type="text" name="product_info_value[]" placeholder="Enter Value"></div><a href="javascript:void(0);" class="remove_button" title="Remove field"><img class="rem_field_img" src="http://localhost/Admin/assets/img/remove-icon.png"/></a></div>'; //New input field html 
                                        var x = 1; //Initial field counter is 1


                                        $('#insert-rows-amnt').blur(function () {
                                            var numNewRows = parseInt($('#insert-rows-amnt').val(), 10);
                                            if (isNaN(numNewRows) || numNewRows <= 0) {
                                                alert('Please enter number of rows to insert');
                                            } else if (numNewRows > 15)
                                            {
                                                alert('Maximum 15 Rows only can add');
                                            } else {
                                                $(".NumberCpu").show();
                                                $tbody = $('.NumberCpu tbody');
                                                var trdetails = "";
                                                for (i = 0; i < numNewRows; i++)
                                                {
                                                    console.log(cpu_det);
                                                    if (cpu_det.length > i)
                                                    {
                                                        trdetails = trdetails + '<tr>\n\
                                                                        <td></td>\n\
                                                                        <td><input type="text" name="PreviousVital[]" class="form-control" value="' + cpu_det[i].CurrentVital + '" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="" /></td>\n\
                                                                        <td><input type="text" name="PreviousNonVital[]" class="form-control" value="' + cpu_det[i].CurentNonVital + '" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="" /></td>\n\
                                                                    </tr>';
                                                    }
                                                    else
                                                    {
                                                        trdetails = trdetails + '<tr>\n\
                                                                        <td></td>\n\
                                                                        <td><input type="text" name="PreviousVital[]" class="form-control" value="" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurrentVital[]" class="form-control" value="" /></td>\n\
                                                                        <td><input type="text" name="PreviousNonVital[]" class="form-control" value="" readonly="" /></td>\n\
                                                                        <td><input type="text" name="CurentNonVital[]" class="form-control" value="" /></td>\n\
                                                                    </tr>';
                                                    }
                                                }
                                                $tbody.html(trdetails);
                                            }
                                        });
</script>

<script type="text/javascript">
    $(document).ready(function () {
        $('a[data-action="remove_this_row"]').on('click', function (event) {
            event.preventDefault();
            $(this).closest('tr').remove();
        });

        $('.preview_btn').on('click', function (event) {
            if (Applicationfileerr == true || Interfacefileerr == true || Vdufileerr == true || $(".ApplicationLogic").html() != "" || $(".InterfaceLogic").html() != "" || $(".VduLogic").html() != "")
            {
                event.preventDefault();
                return false;
            }
            else
            {
                return true;
            }
        });

        $(".ApplicationLogic")

        $('a[data-action="add_new_row"]').on('click', function (event) {
            event.preventDefault();
            var source = $(this).closest('tr');
            var clone = source.clone(true);
            source.after(clone);
            clone.find('.ParameterValue').val('');
            clone.find('.ParameterName').val('');
            clone.find('a.readonly').removeClass('readonly');

        });
    });


    function ApplicationFileChg(ApplicationFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('ApplicationLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                VendorID: $("#VendorID").val(),
                ApplicationFile: ApplicationFile,
                Important_Files_Application: $("#ApplicationFileImportant").val(),
            },
            success: function (res) {
                if (res != 0)
                {
                    var data = JSON.parse(res);
                    console.log(data);
                    $("#ApplicationFolderCountAvailable").val(data.folderCount);
                   
                    if (data.folderCount != $("#ApplicationFolderValText").val() || data.fileCount != $("#ApplicationFileValText").val() || data.ImportantfileCount != $("#ApplicationImportantFilesValText").val())
                    {
                        $(".ApplicationLogic").html("Folder/File Count Invalid");
                    }
                    else
                    {
                        $(".ApplicationLogic").html("");
                        Applicationfileerr = false;
                    }                    
                    if(data.startletter == "false")
                    {
                        $(".ApplicationLogic").html("Invalid File Name");
                    }
                    $("#ApplicationFileCountAvailable").val(data.fileCount);
                    $("#ApplicationImportantFilesAvailable").val(data.ImportantfileCount);
                    $("#ApplicationFolderValAvail").html(data.folderCount);
                    $("#ApplicationFileValAvail").html(data.fileCount);
                    $("#ApplicationImportantFilesValAvail").html(data.ImportantfileCount);
                    $("#ApplicationDownloadPath").val(data.FilePath);
                }
                else
                {
                    $(".ApplicationLogic").html("Folder/File Count Invalid");
                }
            }
        });
    }

    function InterfaceFileChg(InterfaceFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('InterfaceLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                VendorID: $("#VendorID").val(),
                InterfaceFile: InterfaceFile,
                Important_Files_Interface: $("#InterfaceFileImportant").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#InterfaceFolderValText").val() || data.fileCount != $("#InterfaceFileValText").val() || data.ImportantfileCount != $("#InterfaceImportantFilesValText").val())
                {
                    $(".InterfaceLogic").html("Folder/File Count Invalid");

                }
                else
                {
                    $(".InterfaceLogic").html("");
                    Interfacefileerr = false;
                }                    
                if(data.startletter == "false")
                {
                    $(".ApplicationLogic").html("Invalid File Name");
                }
                $("#InterfaceFolderCountAvailable").val(data.folderCount);
                $("#InterfaceFileCountAvailable").val(data.fileCount);
                $("#InterfaceImportantFilesAvailable").val(data.ImportantfileCount);
                $("#InterfaceFolderValAvail").html(data.folderCount);
                $("#InterfaceFileValAvail").html(data.fileCount);
                $("#InterfaceImportantFilesValAvail").html(data.ImportantfileCount);
                $("#InterfaceDownloadPath").val(data.FilePath);
            }
        });
    }


    function VduFileChg(VduFile)
    {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('VduLogic.php'); ?>",
            data: {
                id: $("#VersionID").val(),
                VendorID: $("#VendorID").val(),
                VduFile: VduFile,
                Important_Files_Vdu: $("#VduFileImportant").val(),
            },
            success: function (res) {
                var data = JSON.parse(res);
                console.log(data);
                if (data.folderCount != $("#VduFolderValText").val() || data.fileCount != $("#VduFileValText").val() || data.ImportantfileCount != $("#VduImportantFilesValText").val())
                {
                    $(".VduLogic").html("Folder/File Count Invalid");

                }
                else
                {
                    $(".VduLogic").html("");
                    Vdufileerr = false;
                }
                $("#VduFolderCountAvailable").val(data.folderCount);
                $("#VduFileCountAvailable").val(data.fileCount);
                $("#VduImportantFilesAvailable").val(data.ImportantfileCount);
                $("#VduFolderValAvail").html(data.folderCount);
                $("#VduFileValAvail").html(data.fileCount);
                $("#VduImportantFilesValAvail").html(data.ImportantfileCount);
                $("#VduDownloadPath").val(data.FilePath);
            }
        });
    }
</script>

<script src="<?php echo base_url(); ?>assets/js/dropzone.js"></script>
<script>
    Dropzone.autoDiscover = false;

    var myDropzone = new Dropzone("#ApplicationFile", {
        url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        init: function () {
            this.on("success", function (file, responseText) {
                var ApplicationFile = jQuery.trim(responseText);
                console.log(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.ApplicationLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.ApplicationLogic').html("");
                    ApplicationFileChg(ApplicationFile);
                }
            });
        }
    });

    var myDropzone = new Dropzone("#InterfaceFile", {
        url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        init: function () {
            this.on("success", function (file, responseText) {
                var InterfaceFile = jQuery.trim(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.InterfaceLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.InterfaceLogic').html("");
                    InterfaceFileChg(InterfaceFile);
                }
            });
        }
    });



    var myDropzone = new Dropzone("#VduFile", {
        url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        init: function () {
            this.on("success", function (file, responseText) {
                var VduFile = jQuery.trim(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.VduLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.VduLogic').html("");
                    VduFileChg(VduFile);
                }
            });
        }
    });


    var myDropzone = new Dropzone("#CertificateFile", {
        url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        init: function () {
            this.on("success", function (file, responseText) {
                var CertificateFile = jQuery.trim(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.CertificateLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.CertificateLogic').html("");
                    $("#CertificateFilePath").val(CertificateFile);
                }
            });
        }
    });
    
    var myDropzone = new Dropzone("#OthersDownloadFile", {
        url: "<?php echo site_url("Admin/uploadimage") ?>",
        addRemoveLinks: true,
        init: function () {
            this.on("success", function (file, responseText) {
                var OthersDownloadFile = jQuery.trim(responseText);
                var n = responseText.search(".zip");
                if (n < 0)
                {
                    $('.OthersLogic').html(responseText);
                    this.removeFile(file);
                } else
                {
                    $('.OthersLogic').html("");
                    $("#OthersDownloadPath").val(OthersDownloadFile);
                }
            });
        }
    });
    

    $(".dz-default.dz-message").html("Upload");
    $(".dz-default.dz-message").css("display", "block");
</script>

</body>
</html>