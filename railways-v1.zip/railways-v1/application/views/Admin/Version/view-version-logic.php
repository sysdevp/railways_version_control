<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View Version Logic</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/create-version-logic" class="btn btn-info">Create New Version Logic</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped view_version" id="example">
                                <thead>
                                    <tr>
                                        <th colspan="5"></th>
                                        <th colspan="2">Application Logic</th>
                                        <th colspan="2">Interface Logic</th>
                                        <th colspan="2">VDU Logic</th>
                                        <th colspan="2"></th>
                                    </tr>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Division</th>
                                        <th>Station</th>
                                        <th>vendor</th>
                                        <th>Version</th>
                                        <th>Files</th>
                                        <th>Folders</th>
                                        <th>Files</th>
                                        <th>Folders</th>
                                        <th>Files</th>
                                        <th>Folders</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($version_logic as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></td>
                                            <td><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></td>
                                            <td><?php echo $rows['VendorName']; ?></td>
                                            <td><?php echo $rows['VersionNo']; ?></td>
                                            <td class="green"><?php echo ($rows['ApplicationFileCountAvailable'] != '') ? $rows['ApplicationFileCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['ApplicationFileCountRequired']; ?></td>
                                            <td class="green"><?php echo ($rows['ApplicationFolderCountAvailable'] != '') ? $rows['ApplicationFolderCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['ApplicationFolderCountRequired']; ?></td>
                                            <td class="green"><?php echo ($rows['InterfaceFileCountAvailable'] != '') ? $rows['InterfaceFileCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['InterfaceFileCountRequired']; ?></td>
                                            <td class="green"><?php echo ($rows['InterfaceFolderCountAvailable'] != '') ? $rows['InterfaceFolderCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['InterfaceFolderCountRequired']; ?></td>
                                            <td class="green"><?php echo ($rows['VduFileCountAvailable'] != '') ? $rows['VduFileCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['VduFileCountRequired']; ?></td>
                                            <td class="green"><?php echo ($rows['VduFolderCountAvailable'] != '') ? $rows['VduFolderCountAvailable'] : 0;?>&nbsp;/&nbsp;<?php echo $rows['VduFolderCountRequired']; ?></td>
                                            <td>                                            
                                                <a href="<?php echo site_url(); ?>Admin/view-version-logic-detail/<?php echo $rows['RailwayID']."/".$rows['DivisionID']."/".$rows['StationID']."/".$rows['VersionID'];?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                                <a href="<?php echo site_url(); ?>Admin/edit-version-logic/<?php echo $rows['RailwayID']."/".$rows['DivisionID']."/".$rows['StationID']."/".$rows['VersionID'];?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                                <a href="javascript:void(0)" onclick="deleteversionlogic('<?php echo $rows['RailwayID']; ?>', '<?php echo $rows['DivisionID']; ?>', '<?php echo $rows['StationID']; ?>', '<?php echo $rows['VersionID']; ?>')"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                            </td>
                                        </tr>
                                        <?php
                                    $i++;}
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script>
    function deleteversionlogic(id, did, sid, vid)
    {
        var answer = confirm("Are you sure you want to delete from this Division?");
        if (answer)
        {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-version-logic'); ?>",
                data: {
                    id: id,
                    did: did,
                    sid: sid,
                    vid: vid
                },
                success: function (res) {
                    if (res == 1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/view-version-logic";
                    }
                    else
                    {
                        alert("Failed to delete");
                    }
                }
            });
        }
    }
    
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>

</body>
</html>