<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View Version Logic</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-version-logic" class="btn btn-info">View Version Logic</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal create_version_logic" role="form">
                            <?php
                            foreach ($version_logic as $rows) {
                                ?>
                                <div class="form-group">
                                    <p class="col-sm-12">Railway Zone : <?php echo $this->common_model->find_single_value("RailwayID", $rows['RailwayID'], "tblrailwaymaster", "RailwayName") . " (" . $this->common_model->find_single_value("RailwayID", $rows['RailwayID'], "tblrailwaymaster", "RailwayCode") . ")"; ?></p>
                                    <p class="col-sm-12">Division : <?php echo $this->common_model->find_single_value("DivisionID", $rows['DivisionID'], "tbldivisionmaster", "DivisionName") . " (" . $this->common_model->find_single_value("DivisionID", $rows['DivisionID'], "tbldivisionmaster", "DivisionCode") . ")"; ?></p>
                                    <p class="col-sm-12">Station : <?php echo $this->common_model->find_single_value("StationID", $rows['StationID'], "tblstationmaster", "StationName") . " (" . $this->common_model->find_single_value("StationID", $rows['StationID'], "tblstationmaster", "StationCode") . ")"; ?></p>
                                    <p class="col-sm-12">OEM Name: <?php echo $this->common_model->find_single_value("VendorID", $rows['VendorID'], "tblvendormaster", "VendorName"); ?></p>
                                    <p class="col-sm-12"><strong>Version No: <?php echo $rows['VersionNo']; ?></strong></p>
                                </div>
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <table class="table table-bordered table-striped">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th>Files Defined</th>                                        
                                                    <th>Files uploaded</th>
                                                    <th>Folders Defined</th>
                                                    <th>Folders uploaded</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td><strong>Application Logic</strong></td>
                                                    <td><?php echo $rows['ApplicationFileCountRequired'];?></td>
                                                    <td><?php echo ($rows['ApplicationFileCountAvailable'] != '') ? $rows['ApplicationFileCountAvailable'] : 0;?></td>
                                                    <td><?php echo $rows['ApplicationFolderCountRequired'];?></td>
                                                    <td><?php echo ($rows['ApplicationFolderCountAvailable'] != '') ? $rows['ApplicationFolderCountAvailable'] : 0;?></td>
                                                </tr>
                                                <tr>
                                                    <td><strong>Interface Logic</strong></td>
                                                    <td><?php echo $rows['InterfaceFileCountRequired'];?></td>
                                                    <td><?php echo ($rows['InterfaceFileCountAvailable'] != '') ? $rows['InterfaceFileCountAvailable'] : 0;?></td>
                                                    <td><?php echo $rows['InterfaceFolderCountRequired'];?></td>
                                                    <td><?php echo ($rows['InterfaceFolderCountAvailable'] != '') ? $rows['InterfaceFolderCountAvailable'] : 0;?></td>
                                                </tr>
                                                <tr>
                                                    <td><strong>VDU Logic</strong></td>
                                                    <td><?php echo $rows['VduFileCountRequired'];?></td>
                                                    <td><?php echo ($rows['VduFileCountAvailable'] != '') ? $rows['VduFileCountAvailable'] : 0;?></td>
                                                    <td><?php echo $rows['VduFolderCountRequired'];?></td>
                                                    <td><?php echo ($rows['VduFolderCountAvailable'] != '') ? $rows['VduFolderCountAvailable'] : 0;?></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <p class="col-sm-12">Created by <?php echo $this->common_model->find_single_value("UserID", $rows['CreatedBy'], "tblusermaster", "EmployeeName"); ?> on : <?php echo date("d-m-Y H:i:s", strtotime($rows['CreatedOn'])); ?></p>
                                    <p class="col-sm-12">Record Last Modified by <?php echo $this->common_model->find_single_value("UserID", $rows['ModifiedBy'], "tblusermaster", "EmployeeName"); ?> on :  <?php echo date("d-m-Y H:i:s", strtotime($rows['ModifiedOn'])); ?></p>
                                    
                                </div>
                                <?php
                            }
                            ?>

                            <!--
                            <div class="form-group">
                                <h4 class="col-sm-12">Modification History:</h4>
                                <div class="col-sm-12">
                                    <div class="table-responsive">
                                        <table class="table table-striped table-hover table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Date</th>                                        
                                                    <th>Action</th>
                                                    <th>Name</th>
                                                    <th>Division</th>
                                                    <th>Station</th>
                                                    <th>OEM</th>
                                                    <th>Version</th>
                                                    <th>Application Files</th>
                                                    <th>Application Folder</th>
                                                    <th>Interface Files</th>
                                                    <th>Interface Folder</th>
                                                    <th>Video Files</th>
                                                    <th>Video Folder</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr>
                                                    <td>1</td>
                                                    <td>25/07/2018</td>                                        
                                                    <td>Created</td>
                                                    <td>Shanmugam</td>
                                                    <td>Chennai (MAS)</td>
                                                    <td>Chennai Central (MAS)</td>
                                                    <td>Ansaldo</td>
                                                    <td>9</td>
                                                    <td>25</td>
                                                    <td>22</td>
                                                    <td>100</td>
                                                    <td>22</td>
                                                    <td>39</td>
                                                    <td>15</td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                            -->
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>


</body>
</html>