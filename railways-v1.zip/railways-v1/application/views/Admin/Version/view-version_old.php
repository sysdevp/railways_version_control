<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
						<p class="pull-left"><?php if($create_button_rights != 1) { ?>Note: Only Authorized users can create new Version<?php } ?></p>
                        
                        <ul class="pull-right" id="tour1">
							<li><button onclick="location.href='<?php echo site_url(); ?>Admin/addnew-version'" type="button" class="btn btn-info" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Click here to Upload New EI - Logic Files</button></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<div class="col-sm-12">
							<h3 class="pull-left">View EI - Logic Files</h3>
						</div>
						<br>
						<br>
						<br>
                        <!--<ul class="pull-right col-sm-12 text-right">
                            <li class="pull-right" style="margin-left: 10px;"><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download PDF</button></li>
                            <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                        </ul>-->
						
						 <?php if($this->session->flashdata("success_done")) { ?>
                         <h3 class="success_done" onclick="close_success()" id="message_val"  style="background:#3a5a9c;">
                            <?php echo $this->session->flashdata("success_done"); ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
						
						<div class="col-sm-12">
						<br>
						<br>
						<br>
						
						</div>
                        <div class="row">
                        	<form method="get">
                        	<div class="col-sm-12">
                        <div class="form-group">
                        	<div class="row">
                        		<div class="col-sm-12">
                        			
                        		
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)"  id="RailwayID">
                                        <option <?php if($zoneID == ""){ echo "selected"; } ?> value="">All Zones</option>
                                        <?php
                                        $RailwayID = $this->session->userdata("railway_session_list");
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php if($zoneID == $rows['RailwayID']){ echo "selected"; } ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-6 red"><?php echo form_error('RailwayID'); ?></label>
                                </div>
                        	</div>
                            </div>
                            <div class="form-group">
                            	<div class="row">
                        		<div class="col-sm-12">
                                <label class="col-sm-2 control-label col-lg-2">Division Name</label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID" >
                                            <option <?php if($DivisionID == ""){ echo "selected"; } ?> value="">All Divisions</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php if($DivisionID == $rows['DivisionID']){ echo "selected"; } ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    elseif($rcond==true)
                                    {
                                        $DivisionID = $this->session->userdata("division_session_list");
                                        $dcond=false;
                                        $division = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $RailwayID), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                                        ?>
                                    
                                    <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID" >
                                            <option value="">Select Division</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php if($DivisionID!="" && $DivisionID!=0 && $DivisionID ==$rows['DivisionID'] ){ $rcond=true; echo "selected";} echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    <?php
                                    }
                                        
                                    ?>
                                </div>
                                <label class="col-sm-6 red"><?php echo form_error('DivisionID'); ?></label>
                            </div>
                            </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">View</button>
                                </div>
                            </div>
                            </div>
                            </form>
                        </div>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped view_version" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Zone</th>
                                        <th>Division</th>
                                        <th>Station</th>
                                        <th>Make of EI</th>
                                        <th>Installation / Alteration  Date</th>
                                        <th>Work Executed by</th>
                                        <th id="tour5">Sync</th>
                                        <th id="tour4">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($version as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['RailwayName']; ?></td>
                                            <td><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></td>
                                            <td><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></td>
                                            <td><?php echo $rows['VendorName']; ?></td>
                                            <td><?php if($rows['InstallationAlterationDate']!="") echo $rows['InstallationAlterationDate'] ; ?></td>
                                            <td><?php echo $rows['WorkExecutedBy']; ?></td>
                                            <td class="green"><i class="fa fa-check" aria-hidden="true"></i> Yes</td>
                                            <td>                                            
                                                <a href="<?php echo site_url(); ?>Admin/detail-version-view/<?php echo $rows['RailwayID'] . "/" . $rows['DivisionID'] . "/" . $rows['StationID'] . "/" . $rows['VendorID'] . "/" . $rows['VersionID']. "/1"; ?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                                <a href="<?php echo site_url(); ?>Admin/edit-version/<?php echo $rows['RailwayID'] . "/" . $rows['DivisionID'] . "/" . $rows['StationID'] . "/" . $rows['VendorID'] . "/" . $rows['VersionID']; ?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                                <a href="javascript:void(0)" onclick="deleteversion('<?php echo $rows['RailwayID']; ?>', '<?php echo $rows['DivisionID']; ?>', '<?php echo $rows['StationID']; ?>', '<?php echo $rows['VendorID']; ?>', '<?php echo $rows['VersionID']; ?>')"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                               <!-- <tfoot>
                                    <tr>
                                        <th colspan="7"></th>
                                        <th id="tour6"><a href="#" class="btn btn-success">Sync All</a></th>
                                        <th></th>
                                    </tr>
                                </tfoot> -->
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>

<script src="<?php echo site_url('assets/boot/'); ?>js/version.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script>
var gid = 0, gdid = 0, gsid = 0, gvid = 0, gverid = 0;
function zone_chg_division(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                                                data: {
                                                    id: id, db:'another_db',div: <?php if($DivisionID == ""){ echo "-1"; }else{ echo $DivisionID; } ?> },
                                                success: function (res) {
                                                    if (res != 0)
                                                    {
                                                        $(".division_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }else{
                                                    	$(".division_div").html("<select class='form-control selectpicker' id='DivisionID' data-show-subtext='true' data-live-search='true' name='DivisionID'><option value=''>All Divisions</option></select>");
                                                    	$(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }

										function confirm_userole_admin()
										{
											$.ajax({
													type: "POST",
													url: "<?php echo site_url('Admin/delete-version'); ?>",
													data: {
														id: gid,
														did: gdid,
														sid: gsid,
														vid: gvid,
														verid: gverid,
                                                        db:'another_db'
													},
													success: function (res) {
														if (res == 1)
														{
															window.location = "<?php echo site_url(); ?>Admin/view-version";
														} else
														{
															alert("Failed to delete");
														}
													}
												});
										}
										
                                                function deleteversion(id, did, sid, vid, verid)
                                                {
                                                	
                                                	gid = id;
                                                	gdid = did;
                                                	gsid = sid;
                                                	gvid = vid;
                                                	gverid = verid;
                                                	
                                                	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}else{
                                                  
                                                   
                                                        $.ajax({
                                                            type: "POST",
                                                            url: "<?php echo site_url('Admin/delete-version'); ?>",
                                                            data: {
                                                                id: id,
                                                                did: did,
                                                                sid: sid,
                                                                vid: vid,
                                                                verid: verid,
                                                                db:'another_db'
                                                            },
                                                            success: function (res) {
                                                                if (res == 1)
                                                                {
                                                                    window.location = "<?php echo site_url(); ?>Admin/view-version";
                                                                } else
                                                                {
                                                                    alert("Failed to delete");
                                                                }
                                                            }
                                                        });
                                                    
                                                    }
                                                }

</script>
<script>
    $(document).ready(function () {
    	
    	zone_chg_division(<?php echo $zoneID; ?>);
    	
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>

<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>

<script>
	function close_success(){
		$(".success_done").remove();
	   }
</script>

<?php 
$menusetting = $this->common_model->getMenuSettings(16);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password_for_delete',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(true);
				LevelSecurity.triggerChange = function(){
					deleteversion(gid, gdid, gsid, gvid, gverid)
				}
			});

</script>

</body>
</html>