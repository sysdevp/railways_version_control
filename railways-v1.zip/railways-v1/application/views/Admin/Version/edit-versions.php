<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify Version</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>view-version" class="btn btn-info">View Version</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal add_new_version_form" role="form">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" data-show-subtext="true" data-live-search="true" disabled="">
                                        <option value="">Select Option</option>
                                        <option value="Thiruvananthapuram">Thiruvananthapuram</option>
                                        <option value="Palakkad">Palakkad</option>
                                        <option value="Madurai">Madurai</option>
                                        <option value="Chennai" selected="selected">Chennai (MAS)</option>
                                        <option value="Tiruchirappalli">Tiruchirappalli</option>
                                        <option value="Salem">Salem</option>
                                    </select>
                                </div>
                                <label for="StationName" class="col-sm-2 control-label">Station Name / Code</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" data-show-subtext="true" data-live-search="true">
                                        <option value="">Select Option</option>
                                        <option value="Acharapakkam">Attitattu (AIP)</option>
                                        <option value="Akkampeta" selected="selected">Basin Bridge Jn (BBQ)</option>
                                        <option value="Ambattur">Elavur (ELR)</option>
                                        <option value="Ambur">Ennor (ENR)</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI</label>
                                <div class="col-lg-4">
                                    <select id="make_ei" class="form-control selectpicker m-bot15" data-show-subtext="true" data-live-search="true">
                                        <option value="">select Options</option>
                                        <option value="0" selected="selected">Ansaldo</option>
                                        <option value="1">Ge</option>
                                        <option value="2">Kyosan</option>
                                        <option value="3">Westrace</option>
                                    </select>
                                </div>
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                <div class="col-lg-4">
                                    <div class="form-group">
                                        <div class="col-sm-3">
                                            <input id="DistributedYes" type="radio" name="Distributed" checked="">
                                            <label style="font-weight:normal" for="DistributedYes">Yes</label>
                                        </div>
                                        <div class="col-sm-3">
                                            <input id="DistributedNo" type="radio" name="Distributed" checked="">
                                            <label style="font-weight:normal" for="DistributedNo">No</label>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" id="SignalingPlanNumber" placeholder="Signaling Plan Number" value="9">
                                </div>
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation</label>
                                <div class="col-lg-4">
                                    <input type="date" class="form-control" id="DateInstallation" required="required" value="25/08/2018">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work</label>
                                <div class="col-lg-10">
                                    <input type="text" class="form-control" id="ReasonChanging" placeholder="Description of Work" value="Track Changed">
                                </div>
                            </div> 
                            <div class="form-group">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed up by</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" id="WorkExcuited" placeholder="Work Executed up by" value="kumar">
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Executive Software</th>
                                                <th>Vesion</th>
                                                <th>Checksum / CRC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Pervious Executive Software</td>
                                                <td><input type="text" value="11" class="form-control" disabled=""></td>
                                                <td><input type="text" value="212121" class="form-control" disabled=""></td>
                                            </tr>
                                            <tr>
                                                <td>updated Executive Software</td>
                                                <td><input type="text" value="12"  class="form-control"></td>
                                                <td><input type="text" value="54688" class="form-control"></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">No of CPU's</label>
                                <div class="col-lg-4">
                                    <input type="number" id="insert-rows-amnt" value="3" class="form-control" min="0" max="15" />
                                    <!--<button id="add-row" type="button">Add Rows</button>-->
                                </div>
                                <div class="col-sm-12">
                                    <table class="mtop20 table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="text-center" colspan="2">Vital</th>
                                                <th class="text-center" colspan="2">Non Vital</th>
                                            <tr>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                            <tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td><input type="text" class="form-control" value="111" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                                <td><input type="text" class="form-control" value="51" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td><input type="text" class="form-control" value="111" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                                <td><input type="text" class="form-control" value="51" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td><input type="text" class="form-control" value="111" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                                <td><input type="text" class="form-control" value="51" disabled="" /></td>
                                                <td><input type="text" class="form-control" value="" /></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Application Logic</label>
                                <div class="col-lg-10">
                                    <input type="file" id="LogicFolder">
                                    <label for="LogicFolder" class="btn">Upload</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Folder: 25/25</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Files: 25/25</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Important Files: 5/5</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Interface Circuit</label>
                                <div class="col-lg-10">
                                    <input type="file" id="LogicFolder">
                                    <label for="CircuitFolder" class="btn">Upload</label>
                                    <label class="red" style="margin-left: 15px;"><i class="fa fa-times" aria-hidden="true"></i> Folder: 20/25</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Files: 25/25</label>
                                    <label class="red" style="margin-left: 15px;"><i class="fa fa-times" aria-hidden="true"></i> Important Files: 2/5</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">VDU Logic</label>
                                <div class="col-lg-10">
                                    <input type="file" id="VideoLogic">
                                    <label for="VideoLogic" class="btn">Upload</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Folder: 25/25</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Files: 25/25</label>
                                    <label class="green" style="margin-left: 15px;"><i class="fa fa-check" aria-hidden="true"></i> Important Files: 5/5</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Certificates</label>
                                <div class="col-lg-10">
                                    <input type="file" id="Certificates">
                                    <label for="Certificates" class="btn">Upload</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">Others</label>
                                <div class="col-lg-10">
                                    <input type="file" id="Others">
                                    <label for="Others" class="btn">Upload</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <style>
                                        .upload_add_row {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .upload_add_row td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                        .upload_add_row tr:first-child td:last-child a:last-child{
                                            pointer-events: none;
                                            opacity: 0.5;
                                        }
                                    </style>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Name</th>
                                                <th>Value</th>
                                                <th>Add</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td><input class="form-control" type="text" value=""></td>
                                                <td><input class="form-control" type="text" value=""></td>
                                                <td>
                                                    <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                    <a data-action="remove_this_row"  class="label label-info label-mini btn-danger disabled"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="ReasonEdit">Reason for Edit</label>
                                <div class="col-lg-10">
                                    <textarea id="ReasonEdit" class="form-control" rows="3" placeholder="Reason for Edit"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="text-center col-lg-12  mtop20">
                                    <a href="<?php echo site_url(); ?>add-new-version-preview" class="btn btn-info">Preview</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>


</body>
</html>