<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');

$module_security = $this->common_model->find_details(array("menu_id"=>7),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify EI - description and executed by</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/version-desc-exec" class="btn btn-info">EI - description and executed by</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach ($fields as $rows) {
								if($rows['for_field'] == 0)
								{
									$fieldname = 'Work Description';
								}
								else if($rows['for_field'] == 1)
								{
									$fieldname = 'Executed By';
								}
								else if($rows['for_field'] == 2)
								{
									$fieldname = 'Verified By';
								}
								else if($rows['for_field'] == 3)
								{
									$fieldname = 'Approved By';
								}
                                ?>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="t_type">Railway Zone / Code </label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" id="RailwayID" name="RailwayID" placeholder="Railway Zone" value="<?php echo $zoneid['RailwayName'] . " (" . $zoneid['RailwayCode'] . ")"; ?>" readonly>
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('RailwayID');?></label>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="t_type">For Field </label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" id="t_type" name="t_type" placeholder="Railway Zone" value="<?php echo $fieldname; ?>" readonly>
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('t_type');?></label>
                                </div>
                                <div class="form-group">
                                    <label for="desc_value" class="col-lg-2 col-sm-2 control-label">Description Value <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" name="desc_value" id="desc_value" placeholder="Railway Zone Code" value="<?php echo $rows['field_value']; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="40">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('desc_value');?></label>
                                </div>
                                <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password">Level <?=$module_security?>  Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>   
        
        $(".message_info").hide();
        
        <?php
        if($this->session->userdata("UserRole")!="Admin")
        { ?>
        $('.preventbtn').on('click', function (event) {
            $("#Level1PasswordModal").modal("show");
            event.preventDefault();
            return false
        });
        <?php } ?>
        $('.password_verify').on('click', function (event) {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url($security_url); ?>",
                data: {
                    password: $("#Level1Password").val(),
                },
                success: function (res) {
                    if (res != 1)
                    {
                        $("#Level1PasswordMessage").html(res);
                        $(".message_info").show();
                    }
                    else
                    {
                        $(".message_info").hide();
                        $("#Level1PasswordMessage").html("");
                    }
                    if ($("#Level1PasswordMessage").html() == "")
                    {
                        $("form").submit();
                    }
                }
            });
        });
</script>
</body>
</html>

