<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Detailed Version View Preview</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/add-new-version" class="btn btn-info">Previous</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                         <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal add_new_version_form" role="form" method="POST">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">
                                        <?php
                                        echo $version[0]['DivisionName'] . " (" . $version[0]['DivisionCode'] . ")";
                                        ?>
                                    </label>
                                </div>
                                <label class="col-sm-2 control-label" for="inputSuccess">Station Name / Code:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">
                                        <?php
                                        echo $version[0]['StationName'] . " (" . $version[0]['StationCode'] . ")";
                                        ?>
                                    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">
                                        <?php
                                        echo $version[0]['VendorName'];
                                        ?>
                                    </label>
                                </div>
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                <div class="col-lg-4">
                                    <label class="control-label"><?php echo ($this->session->userdata('isDistributedVersionType') == '1') ? "Yes" : "No"; ?>    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number:</label>
                                <div class="col-lg-4">
                                    <label class="control-label"><?php echo $this->session->userdata('SignalPlanNumber'); ?></label>
                                </div>
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation:</label>
                                <div class="col-lg-4">
                                    <label class="control-label"><?php echo $this->session->userdata('InstallationAlterationDate'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work:</label>
                                <div class="col-lg-10">
                                    <label class="control-label"><?php echo $this->session->userdata('DescriptionOfWork'); ?></label>
                                </div>
                            </div> 
                            <div class="form-group">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed up by:</label>
                                <div class="col-lg-4">
                                    <label class="control-label"><?php echo $this->session->userdata('WorkExecutedBy'); ?></label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Executive Software</th>
                                                <th>Vesion</th>
                                                <th>Checksum / CRC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Pervious Executive Software</td>
                                                <td><label class="control-label"><?php echo $this->session->userdata('PreviousESwVersion'); ?></label></td>
                                                <td><label class="control-label"><?php echo $this->session->userdata('PreviousESwChecksum'); ?></label></td>
                                            </tr>
                                            <tr>
                                                <td>updated Executive Software</td>
                                                <td><label class="control-label"><?php echo $this->session->userdata('CurrentESwVersion'); ?></label></td>
                                                <td><label class="control-label"><?php echo $this->session->userdata('CurrentESwChecksum'); ?></label></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">No of CPU's:</label>
                                <div class="col-lg-4">
                                    <label class="control-label"><?php echo $this->session->userdata('NoOfCPU'); ?></label>
                                </div>
                                <div class="col-sm-12">
                                    <table class="mtop20 table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="text-center" colspan="2">Vital</th>
                                                <th class="text-center" colspan="2">Non Vital</th>
                                            <tr>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                            <tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i = 1;
                                            foreach ($this->session->userdata('temp_cpu_details') as $subrows) {
                                                ?>
                                                <tr>
                                                    <td><?php echo $i; ?></td>
                                                    <td><?php echo $subrows['PreviousVital']; ?></td>
                                                    <td><?php echo $subrows['CurrentVital']; ?></td>
                                                    <td><?php echo $subrows['PreviousNonVital']; ?></td>
                                                    <td><?php echo $subrows['CurentNonVital']; ?></td>
                                                </tr>
                                                <?php
                                                $i++;
                                            }
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table text-center table-bordered detail_view_table">
                                        <tbody>
                                            <tr>
                                                <td colspan="4"><strong>Application Logic Folder: <a target="_blank" class="preventbtn" href="<?php echo site_url("uploads/files/".$this->session->userdata('ApplicationDownloadPath')); ?>">[Download]</a></strong></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td><?php echo $version[0]['ApplicationFolderCountRequired']; ?></td>
                                                <td>Folder Count Avaliable</td>
                                                <td><?php echo $this->session->userdata('ApplicationFolderCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td><?php echo $version[0]['ApplicationFileCountRequired']; ?></td>
                                                <td>Files count Avaliable</td>
                                                <td><?php echo $this->session->userdata('ApplicationFileCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2"> Important Files (<?php echo $this->session->userdata('ApplicationImportantFilesCountAvail'); ?>)</td>
                                                <td colspan="2">
                                                    <?php echo $this->session->userdata('ApplicationImportantFilesRequired'); ?>
                                                </td>
                                            </tr>

                                            <tr>
                                                <td colspan="4"><strong>Interface Logic Folder: <a  target="_blank" class="preventbtn" href="<?php echo site_url("uploads/files/".$this->session->userdata('InterfaceDownloadPath')); ?>">[Download]</a></strong></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td><?php echo $version[0]['InterfaceFolderCountRequired']; ?></td>
                                                <td>Folder Count Avaliable</td>
                                                <td><?php echo $this->session->userdata('InterfaceFolderCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td><?php echo $version[0]['InterfaceFileCountRequired']; ?></td>
                                                <td>Files count Avaliable</td>
                                                <td><?php echo $this->session->userdata('InterfaceFileCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Important Files (<?php echo $this->session->userdata('InterfaceImportantFilesCountAvail'); ?>)</td>
                                                <td colspan="2">
                                                    <?php echo $this->session->userdata('InterfaceImportantFilesRequired'); ?>
                                                </td>
                                            </tr>



                                            <tr>
                                                <td colspan="4"><strong>Vdu Logic Folder: <a   target="_blank" class="preventbtn" href="<?php echo site_url("uploads/files/".$this->session->userdata('VduDownloadPath')); ?>">[Download]</a></strong></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td><?php echo $version[0]['VduFolderCountRequired']; ?></td>
                                                <td>Folder Count Avaliable</td>
                                                <td><?php echo $this->session->userdata('VduFolderCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td><?php echo $version[0]['VduFileCountRequired']; ?></td>
                                                <td>Files count Avaliable</td>
                                                <td><?php echo $this->session->userdata('VduFileCountAvailable'); ?></td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Important Files (<?php echo $this->session->userdata('VduImportantFilesCountAvail'); ?>)</td>
                                                <td colspan="2">
                                                    <?php echo $this->session->userdata('VduImportantFilesRequired'); ?>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-md-12">
                                    <h4>Other Info</h4>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Name</th>
                                                <th>Value</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php
                                            $i=1;
                                            if (count($this->session->userdata('temp_parameter_details')) > 0) {
                                                foreach ($this->session->userdata('temp_parameter_details') as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $i;?></td>
                                                        <td><?php echo $subrows['ParameterName']; ?></td>
                                                        <td><?php echo $subrows['ParameterValue']; ?></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                            }
                                            ?>
                                        </tbody>

                                    </table>
                                </div>
                            </div>

                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-4  mtop20 checkbox_customize">
                                    <a href="<?php echo site_url(); ?>Admin/add-new-version" class="btn btn-info">Previous</a>
                                    <button type="submit" class="btn btn-success">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>

                        </form>

                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script>
document.getElementById('make_ei').addEventListener('change', function () {
    var style = this.value == 1 ? 'block' : 'none';
    document.getElementById('hidden_div').style.display = style;
});

document.getElementById('version_type').addEventListener('change', function () {
    var style = this.value == 1 ? 'block' : 'none';
    document.getElementById('hidden_div1').style.display = style;
});
</script>
<div class="modal fade alert_popup LevelPassword" id="Level3PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level3PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level3PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level3Password">Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level3Password" class="form-control" id="Level3Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="urllink"/>
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    var popup = false;
    $(".message_info").hide();
    $('.preventbtn').on('click', function (event) {
        $("#urllink").val($(this).attr('href'));
            $("#Level3PasswordModal").modal("show");
            event.preventDefault();
            return false
    });
    $('.password_verify').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/level3-security-settings'); ?>",
            data: {
                password: $("#Level3Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level3PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $(".message_info").hide();
                    $("#Level3PasswordMessage").html("");
                }
                if ($("#Level3PasswordMessage").html() == "")
                {
                    window.open($("#urllink").val());
                    $("#Level3PasswordModal").modal("hide");
                }
            }
        });
    });

</script>
</body>
</html>