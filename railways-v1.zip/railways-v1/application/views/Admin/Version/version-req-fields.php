<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 
$module_security = $this->common_model->find_details(array("menu_id"=>6),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Version Fields Required</h3>
                    </div>
                    <div class="panel-body">
                        <?php if( $this->session->userdata("success_done")) { ?>
                             <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php  echo $this->session->userdata("success_done" );?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                         <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: This page is used to define the field names and the mandatory fields for OEMs</p>
                        <form class="form-horizontal" role="form" method="POST">
                          
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">OEM's Name</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-show-subtext="true" data-live-search="true" name="VendorID" onchange="vendor_chg(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        foreach ($vendor as $rows) {
                                            ?>
                                            <option <?php echo set_select("VendorID", $rows['VendorID'], FALSE); ?> value="<?php echo $rows['VendorID']; ?>"><?php echo $rows['VendorName']; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('VendorID'); ?></label>
                                </div>
                            </div>
                            <h3 class="station_chg_div">Version Fields </h3>                            
                            <div class="form-group station_chg_div ">
                                <div class="col-sm-12">
                                    <style>
                                        .upload_add_row {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .upload_add_row td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                        .upload_add_row tr:first-child td:last-child a:last-child{
                                            pointer-events: none;
                                            opacity: 0.5;
                                        }
                                    </style>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Field Name</th>
                                                <th>Visible</th>
                                                <th>Mandatory</th>
                                                <th>Options</th>
                                            </tr>
                                        </thead>
                                        <tbody class="field_div">
                                        	
                                        </tbody>
                                        
                                        <tbody>
                                            <tr>
                                                <td></td>
                                                <td>
                                                    <input class="form-control ParameterName" name="FieldName[]" type="text" value="" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="40"></td>
                                                <td><div class="checkbox"><input class="form-control minimal" name="FVisible[]" type="checkbox" value="0"></div></td>
                                                <td><div class="checkbox"><input class="form-control minimal" name="FMandatory[]" type="checkbox" value="0"></div></td>
                                                <td>
                                                    <a data-action="add_new_row" data-field-id="{{ $field->id }}" class="label label-info label-mini btn-success"><i class="fa fa-plus" aria-hidden="true"></i></a>
                                                    <a data-action="remove_this_row"  class="label label-info label-mini btn-danger readonly"><i class="fa fa-minus" aria-hidden="true"></i></a>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group station_chg_div">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>

                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Level <?=$module_security?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>	
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>

<script>
    
 $(document).ready(function () { 
		$.validator.setDefaults({
			ignore: []
		});        
		$('.form-horizontal').validate({
                    errorElement: 'span',
                    errorClass: 'error',
                    ignore: [], 
                    lang: 'en',
                    rules: {
                        VendorID:'required',
                    }
		});    
		$('select').on('change', function() {
			$(this).valid();
		});    
	}); 
    $(document).ready(function () {
        $('a[data-action="remove_this_row"]').on('click', function (event) {
            event.preventDefault();
            $(this).closest('tr').remove();
        });

        $('a[data-action="add_new_row"]').on('click', function (event) {
            event.preventDefault();
            var source = $(this).closest('tr');
            var clone = source.clone(true);
            source.after(clone);
            clone.find('.ParameterValue').val('');
            clone.find('.ParameterName').val('');
            clone.find('a.readonly').removeClass('readonly');

        });
        $("#field_div").html("");
        

         <?php
        if($this->session->userdata("UserRole")!="Admin")
        {?>

    $('.preventbtn').on('click', function (event) {
        $("#Level2PasswordModal").modal("show");
        event.preventDefault();
        return false
    });<?php }
					?>
        $('.password_verify').on('click', function (event) {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url($security_url); ?>",
                data: {
                    password: $("#Level2Password").val(),
                },
                success: function (res) { 
                        console.log(res);     
                    if (res != 1)
                    {
                        $("#Level2PasswordMessage").html(res);
                        $(".message_info").show();
                    }
                    else
                    {
                        $(".message_info").hide();
                        $("#Level2PasswordMessage").html("");
                    }
                    if ($("#Level2PasswordMessage").html() == "")
                    {
                        $("form").submit();
                    }
                }
            });
        });

        
    });

</script>

</script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.tagsinput.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>
<?php
if (!isset($_POST['FileType'])) {
    ?>
    $(".station_chg_div").hide();
    <?php
}
?>
    function vendor_chg(id)
    {
        if(id!="")
        {
            $(".field_div").html("");
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/AjaxForm/VendorChgFIELDS'); ?>",
                data: {
                    VendorID: id
                },
                success: function (res) {
                    console.log(res);
                     $(".station_chg_div").show();
                    $(".station_div").html("");
                    $(".field_div").html(res);
                }
            });
        }
        else
        {
            $(".station_chg_div").hide();
            $(".station_div").html("");
            $(".field_div").html("");
        }
    }
    
    function mandatoryCheck(id){
    	
    	var vischk = $("#field_visible_"+id);
    	var manchk = $("#field_mandatory_"+id);
    	if(manchk.is(':checked')){
    		vischk.attr('checked', true);
    	}else{
    		
    	}
    }
    
    function visibleCheck(id){
    	var vischk = $("#field_visible_"+id);
    	var manchk = $("#field_mandatory_"+id);
    	if(vischk.is(':checked')){
    		
    	}else{
    		manchk.attr('checked', false);    		
    	}
    }
    
    <?php
    if(isset($_POST['VendorID'])){
    	?>
    	vendor_chg(<?php echo $_POST['VendorID']; ?>);
    	<?php
    }
    ?>

</script>
<style>
	.checkbox{
    width: 20px;
    margin: 0 auto;
	}
</style>
</body>
</html>

