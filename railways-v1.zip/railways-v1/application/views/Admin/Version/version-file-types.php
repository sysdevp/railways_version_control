<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Version File Types</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/version-file-names" class="btn btn-info">Create File Name</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <form class="form-horizontal" role="form" method="POST">
                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">File Type <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input class="form-control" name="file_type" />
                                    <label class="col-sm-12"><?php echo form_error('file_type'); ?></label>
                                </div>
                            </div>
                            <div class="form-group station_chg_div">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                            <h3 class="station_chg_div">File Types </h3>                            
                            <div class="form-group station_chg_div ">
                                <div class="col-sm-12">
                                    <style>
                                        .upload_add_row {
                                            counter-reset: serial-number;  /* Set the serial number counter to 0 */
                                        }
                                        .upload_add_row td:first-child:before {
                                            counter-increment: serial-number;  /* Increment the serial number counter */
                                            content: counter(serial-number);  /* Display the counter */
                                        }
                                        .upload_add_row tr:first-child td:last-child a:last-child{
                                            pointer-events: none;
                                            opacity: 0.5;
                                        }
                                    </style>
                                    <table class="mtop20 upload_add_row table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Type</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        	
                                        	<?php
                                        	foreach($file_types as $ft){
                                        		?>
                                        		<tr>
                                        			<td></td>
                                        			<td><?php echo $ft["file_type"]; ?></td>
                                        		</tr>
                                        		<?php
                                        	}
                                        	?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            

                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>

</script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.tagsinput.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () { 
    $.validator.setDefaults({
        ignore: []
    });        
    $('.form-horizontal').validate({
        errorElement: 'span',
        errorClass: 'error',
        ignore: [], 
        lang: 'en',
        rules: {
                file_type:'required',
        }
    });    
}); 
	</script>
</body>
</html>

