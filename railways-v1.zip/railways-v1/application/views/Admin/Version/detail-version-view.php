<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 

$module_security = $this->common_model->find_details(array("menu_id"=>20),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security];
?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">EI - Logic Files</h3>
                        <ul class="pull-right">
                            <!--<li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                            <li><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download</button></li>-->
                            <li><a href="<?php echo site_url(); ?>Admin/view-version" class="btn btn-info">View EI - Logic Files</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">

                        <form class="form-horizontal add_new_version_form" role="form">
                            <?php
                            foreach ($version as $rows) {
                                ?>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></label>
                                    </div>
                                    <label for="StationName" class="col-sm-2 control-label">Station Name / Code:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="inputSuccess">Make of EI:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['VendorName']; ?></label>
                                    </div>
                                    <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo ($rows['isDistributedVersionType'] == '1') ? "Yes" : "No"; ?>    </label>
                                    </div>
                                </div>
                                <div class="form-group" id="signaling_plan_no">
                                    <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['SignalPlanNumber']; ?></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="DateInstallation" class="col-sm-2 control-label">Date of installation:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['InstallationAlterationDate']; ?></label>
                                    </div>
                                </div>
                                <div class="form-group">
                                    <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work:</label>
                                    <div class="col-lg-10">
                                        <label class="control-label"><?php echo $rows['DescriptionOfWork']; ?></label>
                                    </div>
                                </div> 
                                <div class="form-group">
                                    <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed by:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['WorkExecutedBy']; ?></label>
                                    </div>
                                </div>
                                <div class="form-group" id="executive_software">
                                    <div class="col-sm-12">
                                        <table class="table dashboard-table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th>Executive Software</th>
                                                    <th>Version</th>
                                                    <th>Checksum / CRC</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <tr hidden>
                                                    <td>Pervious Executive Software</td>
                                                    <td><label class="control-label"><?php echo $rows['PreviousESwVersion']; ?></label></td>
                                                    <td><label class="control-label"><?php echo $rows['PreviousESwChecksum']; ?></label></td>
                                                </tr>
                                                <tr>
                                                    <td>updated Executive Software</td>
                                                    <td><label class="control-label"><?php echo $rows['CurrentESwVersion']; ?></label></td>
                                                    <td><label class="control-label"><?php echo $rows['CurrentESwChecksum']; ?></label></td>
                                                </tr>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <div class="form-group" id="noofcpu">
                                    <label class="col-sm-2 control-label">No of CPU's:</label>
                                    <div class="col-lg-4">
                                        <label class="control-label"><?php echo $rows['NoOfCPU']; ?></label>
                                    </div>
                                    <div class="col-sm-12">
                                        <table class="mtop20 table dashboard-table table-bordered">
                                            <thead>
                                                <tr>
                                                    <th></th>
                                                    <th class="text-center">Vital</th>
                                                    <th class="text-center">Non Vital</th>
                                                <tr>
                                                <!--<tr>
                                                    <th>Sno</th>
                                                    <th>Previous</th>
                                                    <th>Updated</th>
                                                    <th>Previous</th>
                                                    <th>Updated</th>
                                                <tr>-->
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 1;
                                                foreach ($versionsubcpu as $subrows) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $i; ?></td>
                                                        <!-- <td><?php // echo $subrows['PreviousVital']; ?>
                                                        </td>-->
                                                        <td><?php echo $subrows['CurrentVital']; ?></td>
                                                        <!-- <td><?php //echo $subrows['PreviousNonVital']; ?></td>-->
                                                        <td><?php echo $subrows['CurentNonVital']; ?></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php if(count($custom_fields) > 0){
                                     if(count($custom_fields) == 1 && $custom_fields[0]['field_dis']=="" && $custom_fields[0]['field_value'] == ""){
                                     }
                                     else
                                     {
?>
                                <div class="form-group">
                                    
                                    <div class="col-sm-12">
                                        <table class="mtop20 table dashboard-table table-bordered">
                                            <thead>
                                                
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Field Name</th>
                                                    <th>Value</th>
                                                <tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 1;
                                                foreach ($custom_fields as $cusfield) {
                                                    ?>
                                                    <tr id="<?php echo $cusfield['field_id']; ?>">
                                                        <td><?php echo $i; ?></td>
                                                        <td><?php echo $cusfield['field_dis']; ?></td>
                                                        <td><?php echo $cusfield['field_value']; ?></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php }} ?>
                                
                                <?php if(count($versionsubuserdefinedparameters) > 0){ 
                                    if(count($versionsubuserdefinedparameters) == 1 && $versionsubuserdefinedparameters[0]['ParameterName']=="" && $versionsubuserdefinedparameters[0]['ParameterValue'] == ""){
                                     }
                                     else
                                     {
                                	?>
                                	<div class="form-group">
                                    
                                    <div class="col-sm-12">
                                        <table class="mtop20 table dashboard-table table-bordered">
                                            <thead>
                                                
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Field Name</th>
                                                    <th>Value</th>
                                                <tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 1;
                                                foreach ($versionsubuserdefinedparameters as $parms) {
                                                    ?>
                                                    <tr id="<?php echo $parms['ParameterId']; ?>">
                                                        <td><?php echo $i; ?></td>
                                                        <td><?php echo $parms['ParameterName']; ?></td>
                                                        <td><?php echo $parms['ParameterValue']; ?></td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
									
                            <?php } }
								?>
                                
                                <div class="form-group">
                                    <div class="col-sm-12">
                                        <table class="table dashboard-table text-center table-bordered detail_view_table">
                                            <tbody>
                                            	<?php if($rows['softwarefileDownloadPath'] != ""){ ?>
                                                <tr>
                                                    <td colspan="4"><strong><a target="_blank" class="<?php if($this->session->userdata("UserRole")!="Admin") { echo "preventbtn";} ?>" href="<?php echo base_url()."uploads/files/".$rows['softwarefileDownloadPath']; ?>">Download Software File [<?=$rows['softwarefileDownloadPath'];?>](<?php
                                                       echo round(@filesize("./uploads/files/".$rows['softwarefileDownloadPath'])/1024,2);
                                                        ?>KB)</a></strong></td>
                                                </tr>
                                                 <?php }else{ ?>
                                                 <tr>
                                                    <td colspan="4"><strong style="color: red">Software File not Uploaded</strong></td>
                                                </tr>

                                                <?php } ?>
                                                <?php if($rows['CertificateDownloadPath'] != ""){ ?>
                                                <tr>
                                                    <td colspan="4"><strong><a target="_blank" href="<?php echo base_url()."uploads/others/".$rows['CertificateDownloadPath']; ?>">Download Certificate File [<?=$rows['CertificateDownloadPath']?>](<?=round(@filesize("./uploads/files/".$rows['CertificateDownloadPath'])/1024,2);?>KB)</a></strong></td>
                                                </tr>
                                                <?php }else{ ?>

                                                         <tr>
                                                    <td colspan="4"><strong style="color: red">Certificate File not Uploaded</strong></td>
                                                </tr>

                                                <?php } ?>
                                                <?php if($rows['OthersDownloadPath'] != ""){ ?>
                                                <tr>
                                                    <td colspan="4"><strong> <a target="_blank" href="<?php echo base_url()."uploads/others/".$rows['OthersDownloadPath']; ?>">Download Other File[<?=$rows['OthersDownloadPath']?>](<?php
                                                       echo round(@filesize("./uploads/files/".$rows['OthersDownloadPath'])/1024,2);
                                                        ?>KB)</a></strong></td>
                                                </tr>
                                                <?php }else{ ?>
                                                        <tr>
                                                    <td colspan="4"><strong style="color: red">Additional File not Uploaded (Optional)</strong></td>
                                                </tr>

                                                <?php } ?>
                                                
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
								
								
								<?php 
								//Version History
								if(count($version_history) > 0){ ?>
								<div class="form-group">
									<div class="col-lg-12">
										<h4>Version History</h4>
									</div>
								</div>
                                <div class="form-group">
                                    
                                    <div class="col-sm-12">
                                        <table class="mtop20 table dashboard-table table-bordered">
                                            <thead>
                                                
                                                <tr>
                                                    <th>Sno</th>
                                                    <th>Station Name</th>
                                                    <th>Make of EI</th>
													<th>Installation / Alteration  Date</th>
													<th>Work Executed by</th>
													<th>Action</th>
                                                <tr>
                                            </thead>
                                            <tbody>
                                                <?php
                                                $i = 1;
                                                foreach ($version_history as $cusfield) {
                                                    ?>
                                                    <tr>
                                                        <td><?php echo $i; ?></td>
														<td><?php echo $rows['StationName'] . " (" . $rows['StationCode'] . ")"; ?></td>
                                                        <td><?php echo $cusfield['VendorName']; ?></td>
														<td>
															<?php if($cusfield['InstallationAlterationDate']!="") echo $cusfield['InstallationAlterationDate'] ; ?>
														</td>
														<td><?php echo $cusfield['WorkExecutedBy']; ?></td>
														<td>                                            
															<a href="<?php echo site_url(); ?>Admin/detail-version-view/<?php echo $cusfield['RailwayID'] . "/" . $cusfield['DivisionID'] . "/" . $cusfield['StationID'] . "/" . $cusfield['VendorID'] . "/" . $cusfield['VersionID'] . "/0"; ?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
														</td>
                                                    </tr>
                                                    <?php
                                                    $i++;
                                                }
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                                <?php } ?>
								
                                <div class="form-group">
                                    <div class="col-lg-12">
                                        <label class="control-label">Created by <?php echo $this->common_model->find_single_value("UserID", $rows['CreatedBy'], "tblusermaster", "EmployeeName"); ?> on : <?php echo date("d-m-Y H:i:s", strtotime($rows['CreatedOn'])); ?></label>

                                    </div>
                                </div>
                                <div class="form-group">
                                    <div class="col-lg-12">
                                        <label class="control-label">Record Last Modified by <?php echo $this->common_model->find_single_value("UserID", $rows['ModifiedBy'], "tblusermaster", "EmployeeName"); ?> on :  <?php echo date("d-m-Y H:i:s", strtotime($rows['ModifiedOn'])); ?></label>
                                    </div>
                                </div>
                            </form>
                            <?php
                        }
                        ?>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<div class="modal fade alert_popup LevelPassword" id="Level3PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level3PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level3PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level3Password">Level <?=$module_security?>  Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level3Password" class="form-control" id="Level3Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <input type="hidden" id="urllink"/>
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
    var popup = false;
    $(".message_info").hide();
    $('.preventbtn').on('click', function (event) {
        $("#urllink").val($(this).attr('href'));
            $("#Level3PasswordModal").modal("show");
            event.preventDefault();
            return false
    });
    $('.password_verify').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url($security_url); ?>",
            data: {
                password: $("#Level3Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level3PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $(".message_info").hide();
                    $("#Level3PasswordMessage").html("");
                }
                if ($("#Level3PasswordMessage").html() == "")
                {
                    window.open($("#urllink").val());
                    $("#Level3PasswordModal").modal("hide");
                }
            }
        });
    });
    
    function getVendorFields(id){
                                        	$.ajax({
                                        		type: "POST",
                                                    url: "<?php echo site_url('Admin/AjaxForm/getVendorFields'); ?>",
                                                    data: {
                                                        VendorID: id
                                                    },
                                                    success: function (res) {
                                                    	var data = JSON.parse(res);
                                                    	console.log(data);
                                                    	for(var i = 0; i< data.length; i++){
                                                    		if(data[i].is_visible == 1){
                                                    			$("#"+data[i].fname).show();
                                                    		}
                                                    	}
                                                    }
                                        	});
                                        }
    
    $(document).ready(function () {
                                        <?php foreach($fields as $field){
                                        	?>$("#<?php echo $field['field_name']; ?>").hide(); <?php
                                        }
										?>
										getVendorFields('<?php echo $VendorID; ?>');
										 });

</script>

</body>
</html>