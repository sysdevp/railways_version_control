<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 
$module_security = $this->common_model->find_details(array("menu_id"=>5),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">EI - description and executed by</h3>
                    </div>
                    <div class="panel-body">
						 <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
						<?php if($this->session->flashdata("success_done")) { ?>
                         <h3 class="success_done" onclick="close_success()" id="message_val"  style="background:#3a5a9c;">
                            <?php echo $this->session->flashdata("success_done"); ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                        <form class="form-horizontal" name="form_name" role="form" method="POST">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" id="RailwayID" data-show-subtext="true" data-live-search="true"  onchange="get_field();" required="required" >
                                        <option value="">Select Option</option>
                                        <?php
                                        $RailwayID = $this->session->userdata("railway_session_list");
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php if($RailwayID!="" && $RailwayID!=0 && $RailwayID ==$rows['RailwayID'] ){ $rcond=true; echo "selected";} echo set_select("RailwayID", $rows['RailwayID'], FALSE); ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('RailwayID'); ?></label>
                            </div>
							
                            <div class="form-group" id="field_id">
                                <label class="col-sm-2 control-label" for="inputSuccess">Select Field <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="t_type" id="t_type" data-show-subtext="true" data-live-search="true" required="" onchange="get_table();">
                                        <option value="">Select Option</option>
                                        <option <?php if($forField != '' && $forField == 0) {echo "selected";} ?> value="0">Work Description</option>
                                        <option <?php if($forField != '' && $forField == 1) {echo "selected";} ?> value="1">Executed By</option>

                                        <option <?php if($forField != '' && $forField == 2) {echo "selected";} ?> value="2">Verified By</option>
                                        <option <?php if($forField != '' && $forField == 3) {echo "selected";} ?> value="3">Approved By</option>
                                    </select>
                                    <label class="col-sm-12"><?php echo form_error('t_type'); ?></label>
                                </div>
                            </div>
                            
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="desc_value" id="label_text">Description <span class="red">(*)</span></label>
                                    <div class="col-lg-4">
                                        <input data-validation="required"  type="text" class="form-control" id="desc_value" name="desc_value" value="" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="40">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('desc_value');?></label>
                                </div>
                                
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
						<br><br><br>
						<div class="adv-table" id="tab_id">
							<?php 
									if(isset($fieldid)) 
									{
										if($fieldid == 0)
										{
											$fieldname = 'Work Description';
										}
										else if($fieldid == 1)
										{
											$fieldname = 'Executed By';
										}
										else if($fieldid == 2)
										{
											$fieldname = 'Verified By';
										}
										else if($fieldid == 3)
										{
											$fieldname = 'Approved By';
										}

									?>
									<table class="display table table-bordered table-striped example dataTable " id="example">

																	<thead>
																		<tr>
																			<th>Sno</th>
																			<th><?php echo $fieldname; ?></th>
																			<th>Action</th>
																		</tr>
																	</thead>
																	<tbody>
																		<?php
																		$i = 1;
																		foreach ($desc_fields as $rows) {
																			?>
																			<tr>
																				<td><?php echo $i; ?></td>
																				<td><?php echo $rows['field_value']; ?></td>
																				<td>                                  
																					<a href="<?php echo site_url(); ?>Admin/edit_version_desc/<?php echo $rows['id']; ?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
																					
																					
																					<input type="hidden" class="version_field_id" id="version_field_id" value="<?php echo $rows['id']; ?>"/>
																					<a href="javascript:void(0)" class="preventbtnnn"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
																				</td>
																			</tr>
																			<?php
																			$i++;
																		}
																		?>
																	</tbody>
																</table>
<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Are you sure, you want to Delete?</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
				<h4>Note: This is an important data, Please ensure before proceeding.</h4>
				<?php if($this->session->userdata("UserRole") != "Admin") {?>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password"><b>Level <?=$module_security ;?> Security Code</b></label>
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
						<input type="hidden" class="version_field_idd" id="version_field_idd" value=""/>
                        <button type="submit" class="btn btn-danger password_verify2  pull-right" style="margin-top:5px;" >Yes</button>
                         <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
                    </div>
                </div>
				<?php } else {?>
					<div class="form-group">
						<div class="col-lg-12">
							<input type="hidden" class="version_field_idd" id="version_field_idd" value=""/>
							  <button type="button" class="btn btn-danger pull-right" style="margin-top:5px;" onclick="confirm_userole_admin();">Yes</button>
							 <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
							  
						</div>
					</div>
				<?php }?>
            </div>
            <div class="modal-footer">
               
            </div>
        </div>
    </div>
</div>
<script>
    $(".message_info").hide();
    $("#success-alert").hide();
    $('.preventbtnnn').on('click', function (event) {
		var $tr = $(this).closest("tr");
		 var permanent_id = $tr.find(".version_field_id").val();
		 $(".version_field_idd").val(permanent_id);
		console.log(permanent_id);
        $("#Level1PasswordModal").modal("show");
        event.preventDefault();
        return false
    });
    $('.password_verify2').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url($security_url); ?>",
            data: {
                password: $("#Level1Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level1PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $("#Level1PasswordMessage").html("");
                }
                if ($("#Level1PasswordMessage").html() == "")
                {
                    $("#Level1PasswordModal").modal("hide");
                    deleteversionfield($("#version_field_idd").val())
                }
            }
        });
    });
</script>
<script>
function confirm_userole_admin()
{
	$("#Level1PasswordModal").modal("hide");
	var id = $("#version_field_idd").val();
	$.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/delete-version-desc-fields'); ?>",
            data: {
                id: id,
            },
            success: function (res) {
                if (res == 1)
                {
                    window.location = "<?php echo site_url(); ?>Admin/version-desc-exec";
                }
                else
                {
                    $(".alert_status").html("Warning!");
                    $(".alert_msg").html("This record cannot be deleted because other records need this information.");
                    $("#myModal .modal-header").addClass("alert_warining");
                    $("#myModal").modal("show");
                }
            }
        });
}

    function deleteversionfield(id)
    {
		
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/delete-version-desc-fields'); ?>",
            data: {
                id: id,
            },
            success: function (res) {
                if (res == 1)
                {
                    window.location = "<?php echo site_url(); ?>Admin/version-desc-exec";
                }
                else
                {
                    $(".alert_status").html("Warning!");
                    $(".alert_msg").html("This record cannot be deleted because other records need this information.");
                    $("#myModal .modal-header").addClass("alert_warining");
                    $("#myModal").modal("show");
                }
            }
        });
    } 
</script>
							<?php	}
							?>
						</div>
						
						<script>
							
							 function get_field()
							 {
								 var zoneid = $('#RailwayID').val();
								 if(zoneid != '')
								 {
									$("#field_id").show();
									get_table();
								 }
								 else
								 {
									 $("#field_id").hide();
								 }
							 }
							 function get_table()
							 {
								 var fieldid = $('#t_type').val();
								 var zoneid = $('#RailwayID').val();
								if(fieldid=="") {
								     $("#label_text").html();
    								    $("#label_text").html("Description <span class='red'>(*)</span>");
								 }
								 else {
								    var label_text = $('#t_type :selected').text();
    								$("#label_text").html();
    								$("#label_text").html(label_text + " <span class='red'>(*)</span>");
								 }
								 $.ajax({
										type: "POST",
										url: "<?php echo site_url('Admin/EI_description_view'); ?>",
										data: {
											fieldid: fieldid,
											zoneid: zoneid,
										},
										success: function (res) {
											if (res != 0)
											{
												$("#tab_id").html(res);
											}
										}
									});
							 }
						</script>
                    </div>
                </section>
                <!--user info table end-->
            </div>
            
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>
<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script>
    function close_success(){
        $(".success_done").remove();
    }
</script>



<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () {

	$('#NoOfDays').on('keydown keyup', function(e){
    if ($(this).val() > 99 
        && e.keyCode !== 46 // keycode for delete
        && e.keyCode !== 8 // keycode for backspace
       ) {
       e.preventDefault();
       $(this).val(99);
    }else if($(this).val() < 0 
        && e.keyCode !== 46 // keycode for delete
        && e.keyCode !== 8 // keycode for backspace
        ){
    	e.preventDefault();
       	$(this).val(0);
    }
});

		$.validator.setDefaults({
			ignore: []
		});        
		$('.form-horizontal').validate({
			errorElement: 'span',
			errorClass: 'error',
			ignore: [], 
			lang: 'en',
			rules: {
                            desc_value:'required',
                            t_type:'required'
			},  
			submitHandler: function(form) {
				if($(".form-horizontal").valid()==true)
				{
					<?php
					if($this->session->userdata("UserRole")!="Admin")
					{?> 
						$("#Level2PasswordModal").modal("show");
						if(  $("#form-ok").val()!="ok"){
							return false;
						} 
						else{
							form.submit();
						}
					<?php
					}
					else{
					?>
						form.submit();
					<?php
					}
					?>
				}
				else{ 
					return false;
				}
			}
		});    
		$('select').on('change', function() {
			$(this).valid();
		});    
	}); 
	
	
	
    $(document).ready(function () {
    	    	
    	/*$('#NoOfDays').on('keydown keyup', function(e){
    if ($(this).val() > 99 
        && e.keyCode !== 46 // keycode for delete
        && e.keyCode !== 8 // keycode for backspace
       ) {
       e.preventDefault();
       $(this).val(99);
    }else if($(this).val() < 0 
        && e.keyCode !== 46 // keycode for delete
        && e.keyCode !== 8 // keycode for backspace
        ){
    	e.preventDefault();
       	$(this).val(0);
    }
});

        $.validate({
                    lang: 'en',
                    onError : function($form) {

                    },
                    onSuccess : function($form) {

                    $("#Level2PasswordModal").modal("show");
                    if(  $("#form-ok").val()!="ok"){
                    return false;
                    } // Will stop the submission of the form
                    }
                    });*/


$('.preventbtn').on('click', function (event) {
               // $("#Level2PasswordModal").modal("show");
                                   // event.preventDefault();
                                 //   return false
            
                                    
                                });
                                
                                $('.password_verify').on('click', function (event) {
                                    $.ajax({
                                        type: "POST",
                                        url: "<?php echo site_url($security_url); ?>",
                                        data: {
                                            password: $("#Level2Password").val(),
                                        },
                                        success: function (res) { 
                                        	//console.log(res);     
                                            if (res != 1)
                                            {
                                                $("#Level2PasswordMessage").html(res);
                                                $(".message_info").show();
                                            }
                                            else
                                            {
                                                $(".message_info").hide();
                                                $("#Level2PasswordMessage").html("");
                                            }
                                            if ($("#Level2PasswordMessage").html() == "")
                                            {
                                                 $("#form-ok").val("ok");
                                                $("form[name='form_name']").submit();
                                            }
                                        }
                                    });
                                });
    	


    });

</script>

<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.tagsinput.js"></script>

<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/form-component.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>




<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>

<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Level <?=$module_security?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
</body>
</html>

