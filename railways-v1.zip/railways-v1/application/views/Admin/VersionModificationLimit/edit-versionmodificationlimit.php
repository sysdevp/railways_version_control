<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify VersionModificationLimit Details</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-versionmodificationlimit" class="btn btn-info">View VersionModificationLimit</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach ($versionmodificationlimit as $rows) {
                                ?>
                                <div class="form-group">
                                    <label class="col-sm-2 control-label" for="NoOfDays">VersionModificationLimit</label>
                                    <div class="col-lg-4">
                                        <input type="text" class="form-control" id="NoOfDays" name="NoOfDays" placeholder="VersionModificationLimit" value="<?php echo $rows['NoOfDays']; ?>">
                                    </div>
                                    <label class="col-sm-6"><?php echo form_error('NoOfDays');?></label>
                                </div>
                                
                                <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<div class="modal fade alert_popup LevelPassword" id="Level2PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level2PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level2PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level2Password">Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level2Password" class="form-control" id="Level2Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script>
                                $(".message_info").hide();
                                $('.preventbtn').on('click', function (event) {
                                    $("#Level2PasswordModal").modal("show");
                                    event.preventDefault();
                                    return false
                                });
                                $('.password_verify').on('click', function (event) {
                                    $.ajax({
                                        type: "POST",
                                        url: "<?php echo site_url('Admin/level2-security-settings'); ?>",
                                        data: {
                                            password: $("#Level2Password").val(),
                                        },
                                        success: function (res) {      
                                            if (res != 1)
                                            {
                                                $("#Level2PasswordMessage").html(res);
                                                $(".message_info").show();
                                            }
                                            else
                                            {
                                                 $(".message_info").hide();
                                                $("#Level2PasswordMessage").html("");
                                            }
                                            if ($("#Level2PasswordMessage").html() == "")
                                            {
                                                $("form").submit();
                                            }
                                        }
                                    });
                                });

</script>
</body>
</html>

