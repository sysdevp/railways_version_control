<div class="modal fade alert_popup LevelPassword" id="LevelPasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="LevelPasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" id="levelsecurityLabel" for="Level1Password">Level <?=$setting["LevelNo"]?> Security Code</label>
                    <div class="col-lg-8">
                        <input  type="password" name="Level1Password" class="form-control" id="LevelPassword" placeholder="Security Code" value="">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger level_password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                          <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
