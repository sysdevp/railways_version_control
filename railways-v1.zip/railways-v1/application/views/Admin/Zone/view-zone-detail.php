<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Railway Zone Details</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-zone" class="btn btn-info">View Railway Zone</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <?php
                        foreach($zone as $rows)
                        {?>
                        <p class="col-sm-12">Railway Zone : <?php echo $rows['RailwayName'];?> (<?php echo $rows['RailwayCode'];?>)</p>
                        <p class="col-sm-12">Created by <?php echo $this->common_model->find_single_value("UserID", $rows['CreatedBy'], "tblusermaster", "EmployeeName");?> on : <?php echo date("d-m-Y H:i:s", strtotime($rows['CreatedOn']));?></p>
                        <p class="col-sm-12">Record Last Modified by <?php echo $this->common_model->find_single_value("UserID", $rows['ModifiedBy'], "tblusermaster", "EmployeeName");?> on :  <?php echo date("d-m-Y H:i:s", strtotime($rows['ModifiedOn']));?></p>
                        <?php
                        }
                        ?>
                    <!--    <h4 class="col-sm-12">Modification History:</strong></h4>
                        <div class="col-sm-12">
                            <table class="table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Date</th>                                        
                                        <th>Action</th>
                                        <th>Name</th>
                                        <th>Railway Zone</th>
                                        <th>Railway Zone Code</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>25/07/2018 13:22:35</td>
                                        <td>Created</td>
                                        <td>Shanmugam</td>
                                        <td>Southernn Railway</td>
                                        <td>(SR)</td>
                                    </tr>
                                    <tr>
                                        <td>1</td>
                                        <td>25/07/2018 13:22:35</td>
                                        <td>Modified</td>
                                        <td>Shanmugam</td>
                                        <td>Southern Railway</td>
                                        <td>(SR)</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <p class="col-sm-12"><strong>Synchronized on 27/07/2018</strong></p>
                        <h4 class="col-sm-12">Synchronization History:</h4>
                        <div class="col-sm-12">
                            <table class=" table table-bordered table-striped">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Attempted On</th>
                                        <th>Message</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>25/07/2018 13:22:35</td>
                                        <td>Connetivity Error</td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>27/07/2018 22:12:35</td>
                                        <td>Success</td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    -->
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>


<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>



</body>
</html>

