<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 
$module_security = $this->common_model->find_details(array("menu_id"=>12),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Modify Help Settings</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-help" class="btn btn-info">Manage Help Settings</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                            <?php echo $message; ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                        <form class="form-horizontal" role="form" method="POST">
                            <?php
                            foreach($help as $rows)
                            {?>
                            <div class="form-group">
                                <label for="HelpName" class="col-lg-2 col-sm-2 control-label">Help Name <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input type="text" name="HelpName" class="form-control" id="HelpName" placeholder="Help Name" required="required" value="<?php echo $rows["HelpName"]; ?>" onkeyup="$(this).val($(this).val().replace(/[`~!@#$%^&*()_|+\=?;:,.'<>\{\}\[\]\\\/]/gi, ''));" maxlength="40">
                                </div>
                                <label class="col-sm-6"><?php echo form_error('HelpName'); ?></label>
                            </div>
                            <div class="form-group">
                                <label for="PrimaryContactNumber" class="col-lg-2 col-sm-2 control-label">Help Description&nbsp; <span class="red">(*)</span></label>
                                <div class="col-lg-10">
                                    <textarea name="HelpDescription"  class="form-control" id="HelpDescription" placeholder="Help Description"><?php echo $rows["HelpDescription"]; ?></textarea>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('HelpDescription'); ?></label>
                            </div>
                           
                            <?php
                            }
                            ?>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<div class="modal fade alert_popup LevelPassword" id="Level3PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level3PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level3PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level3Password"> Level <?=$module_security?> Security Code</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level3Password" class="form-control" id="Level3Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                         <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script src="<?php echo site_url(); ?>assets/src/jquery.richtext.js"></script>

<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () { 
		$.validator.setDefaults({
			ignore: []
		});        
		$('.form-horizontal').validate({
			errorElement: 'span',
			errorClass: 'error',
			ignore: [], 
			lang: 'en',
			rules: {
				HelpName:'required',
				HelpDescription:'required',
			},  
			submitHandler: function(form) {
				if($(".form-horizontal").valid()==true)
				{
					<?php
					if($this->session->userdata("UserRole")!="Admin")
					{?> 
						$("#Level3PasswordModal").modal("show");
						if(  $("#form-ok").val()!="ok"){
							return false;
						} 
						else{
							form.submit();
						}
					<?php
					}
					else{
					?>
						form.submit();
					<?php
					}
					?>
				}
				else{ 
					return false;
				}
			}
		});    
		$('select').on('change', function() {
			$(this).valid();
		});    
	}); 
        $(".message_info").hide();
        $(document).ready(function() {
            $('#HelpDescription').richText();
        });
        $('.preventbtn').on('click', function (event) {
         
        });
        
        $('.password_verify').on('click', function (event) {
            $.ajax({
                type: "POST",
               url: "<?php echo site_url($security_url); ?>",
                data: {
                    password: $("#Level3Password").val(),
                },
                success: function (res) {      
                    if (res != 1)
                    {
                        $("#Level3PasswordMessage").html(res);
                        $(".message_info").show();
                    }
                    else
                    {
                         $(".message_info").hide();
                        $("#Level3PasswordMessage").html("");
                    }
                    if ($("#Level3PasswordMessage").html() == "")
                    {
                        $("#form-ok").val("ok");
                        $("form").submit();
                    }
                }
            });
        });

</script>
</body>
</html>

