<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); 

$module_security = $this->common_model->find_details(array("menu_id"=>12),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security]; ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
						<p class="pull-left"><?php if($create_button_rights != 1) { ?>Note: Only Authorized users can create new Help Settings<?php } ?></p>
                        
                        <ul class="pull-right">
							<li><button onclick="location.href='<?php echo site_url(); ?>Admin/create-help'" type="button" class="btn btn-info" <?php if($create_button_rights != 1) { echo ' style="color:black;" disabled';} ?>>Create New Help Settings</button></li>
                        </ul>
                    </div>
                    <div class="panel-body">
						<h3 class="pull-left">Help Settings</h3>
						<?php if($this->session->flashdata("success_done")) { ?>
                         <h3 class="success_done" onclick="close_success()" id="message_val"  style="background:#3a5a9c;">
                            <?php echo $this->session->flashdata("success_done"); ?>
                            <i class="fa fa-close" style="" onclick="close_header()"></i>
                        </h3>
                    <?php } ?>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Help Name</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i=1;
                                    foreach($help as $rows)
                                    {?>
                                    <tr>
                                        <td><?php echo $i;?></td>
                                        <td><?php echo $rows['HelpName'];?></td>
                                        <td>                                            
                                            <a href="<?php echo site_url(); ?>Admin/edit-help/<?php echo $rows['HelpID'];?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                            <input type="hidden" class="HelpID" value="<?php echo $rows['HelpID']; ?>"/>
                                            <a href="javascript:void(0)" class="preventbtn"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                        </td>
                                    </tr>
                                    <?php
                                    $i++;
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Are you sure, you want to Delete?</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
				<h4>Note: This is an important data, Please ensure before proceeding.</h4>
				<?php if($this->session->userdata("UserRole") != "Admin") { ?>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password"><b>Level <?php echo $module_security;?> Security Code</b></label>
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>  
				<div class="form-group">
                    <div class="col-lg-12">
						<input type="hidden" class="helpid" id="helpid" value=""/>
                         <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Yes</button>
                         <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
                    </div>
                </div>
				<?php } else { ?>
					<div class="form-group">
						<div class="col-lg-12">
							<input type="hidden" class="helpid" id="helpid" value=""/>
							  <button type="button" class="btn btn-danger pull-right" style="margin-top:5px;" onclick="confirm_userole_admin();">Yes</button>
							 <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
							  
						</div>
					</div>
				<?php } ?>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>

<script>
	function close_success(){
		$(".success_done").remove();
	   }
</script>
<script>
    $(".message_info").hide();
    $("#success-alert").hide();
    $('.preventbtn').on('click', function (event) {
		id = $(this).closest("td").find(".HelpID").val();
		$(".helpid").val(id);
        $("#Level1PasswordModal").modal("show");
        event.preventDefault();
        return false
    });
    $('.password_verify').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url($security_url); ?>",
            data: {
                password: $("#Level1Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level1PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $("#Level1PasswordMessage").html("");
                }
                if ($("#Level1PasswordMessage").html() == "")
                {
                    $("#Level1PasswordModal").modal("hide");
                    deletehelp($("#helpid").val())
                }
            }
        });
    });
</script>
<script>
function confirm_userole_admin()
{
	$("#Level1PasswordModal").modal("hide");
	var helpid = $("#helpid").val();
	
	$.ajax({
		type: "POST",
		url: "<?php echo site_url('Admin/delete-help'); ?>",
		data: {
			id: helpid,
		},
		success: function (res) {
			if(res==1)
			{
				window.location = "<?php echo site_url(); ?>Admin/view-help";
			}
			else
			{
				$(".alert_status").html("Warning!");
				$(".alert_msg").html("Failed to delete. No permission Or Invalid Request");
				$("#myModal .modal-header").addClass("alert_warining");
				$("#myModal").modal("show");
			}
		}
	});
}
    function deletehelp(id)
    {
       
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-help'); ?>",
                data: {
                    id: id,
                },
                success: function (res) {
                    if(res==1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/view-help";
                    }
                    else
                    {
                        $(".alert_status").html("Warning!");
                        $(".alert_msg").html("Failed to delete. No permission Or Invalid Request");
                        $("#myModal .modal-header").addClass("alert_warining");
                        $("#myModal").modal("show");
                    }
                }
            });
        
    }
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>

</body>
</html>

