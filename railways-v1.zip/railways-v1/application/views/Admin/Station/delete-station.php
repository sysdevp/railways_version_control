<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Delete Station</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>view-station" class="btn btn-info">View Station</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form">
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">Division Name</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker" data-show-subtext="true" data-live-search="true" disabled="">
                                        <option value="">Select Option</option>
                                        <option value="Thiruvananthapuram">Thiruvananthapuram</option>
                                        <option value="Palakkad">Palakkad</option>
                                        <option value="Madurai">Madurai</option>
                                        <option value="Chennai" selected="selected">Chennai (MAS)</option>
                                        <option value="Tiruchirappalli">Tiruchirappalli</option>
                                        <option value="Salem">Salem</option>
                                    </select>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="StationName" class="col-lg-2 col-sm-2 control-label">Station Name *</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" id="StationName" placeholder="Eg: Villivakkam" value="Chennai Central" disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="StationCode" class="col-lg-2 col-sm-2 control-label">Station Code *</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control" id="StationCode" placeholder="Eg: VLK" value="MAS" disabled>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ReasobDelete" class="col-lg-2 col-sm-2 control-label">Reason for Delete *</label>
                                <div class="col-lg-4">
                                    <textarea rows="4" id="ReasobDelete" class="form-control" placeholder="Reason for Delete"></textarea>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>

</body>
</html>

