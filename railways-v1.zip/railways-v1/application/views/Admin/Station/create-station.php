<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar');
$module_security = $this->common_model->find_details(array("menu_id"=>9),"tbl_menu_security_setting","security_level")[0]["security_level"]; 
$security_level_url=array("1"=>"Admin/level1-security-settings","2"=>"Admin/level2-security-settings","3"=>"Admin/level3-security-settings");
$security_url = $security_level_url[$module_security];?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Create New Station</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/view-station" class="btn btn-info">View Station</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: <br>The Fields denoted in <span class="red">(*)</span> are mandatory. </p> 
                        <form class="form-horizontal" role="form" method="POST">
                            <h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Railway Zone / Code</label>
                                <div class="col-lg-4">
                                    <select class="form-control selectpicker m-bot15" name="RailwayID" data-show-subtext="true" data-live-search="true" onchange="zone_chg_division(this.value)">
                                        <option value="">Select Option</option>
                                        <?php
                                        $RailwayID = $this->session->userdata("railway_session_list");
                                        $rcond = false;
                                        foreach ($zone as $rows) {
                                            ?>
                                            <option <?php if($RailwayID!="" && $RailwayID!=0 && $RailwayID ==$rows['RailwayID'] ){ $rcond=true; echo "selected";} echo set_select("RailwayID", $rows['RailwayID'], FALSE); ?> value="<?php echo $rows['RailwayID']; ?>"><?php echo $rows['RailwayName'] . " (" . $rows['RailwayCode'] . ")"; ?></option>
                                            <?php
                                        }
                                        ?>
                                    </select>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('RailwayID'); ?></label>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label col-lg-2">Division Name</label>
                                <div class="col-lg-4 division_div">
                                    <?php
                                    if (isset($division)) {
                                        ?>
                                        <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division as $rows) {
                                                ?>
                                                <option <?php echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                        <?php
                                    }
                                    elseif($rcond==true)
                                    {
                                        $DivisionID = $this->session->userdata("division_session_list");
                                        $dcond=false;
                                        ?>
                                    
                                    <select class="form-control selectpicker" id="DivisionID" data-show-subtext="true" data-live-search="true" name="DivisionID">
                                            <option value="">Select Option</option>
                                            <?php
                                            foreach ($division_div as $rows) {
                                                ?>
                                                <option <?php if($DivisionID!="" && $DivisionID!=0 && $DivisionID ==$rows['DivisionID'] ){ $rcond=true; echo "selected";} echo set_select("DivisionID", $rows['DivisionID'], FALSE); ?> value="<?php echo $rows['DivisionID']; ?>"><?php echo $rows['DivisionName'] . " (" . $rows['DivisionCode'] . ")"; ?></option>
                                                <?php
                                            }
                                            ?>
                                        </select>
                                    <?php
                                    }
                                        
                                    ?>
                                </div>
                                <label class="col-sm-6"><?php echo form_error('DivisionID'); ?></label>
                            </div>
                            <div class="form-group">
                                <label for="StationName" class="col-lg-2 col-sm-2 control-label">Station Name <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <div data-tip="Station Name">
                                        <input data-validation="required" type="text" class="form-control" id="StationName" name="StationName" placeholder="Eg: Villivakkam" value="<?php echo set_value('StationName');?>" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 32 || event.charCode == 46" maxlength="40">
                                     </div>
                                </div>
                                 </div>
                                
                                  <div class="form-group">
                                <label for="StationCode" class="col-lg-2 col-sm-2 control-label">Station Code <span class="red">(*)</span></label>
                                <div class="col-lg-4">
                                    <input  data-validation="required"   type="text" class="form-control" id="StationCode" name="StationCode"  placeholder="Eg: VLK" value="<?php echo set_value('StationCode');?>" onkeypress="return (event.charCode > 64 && event.charCode < 91) || (event.charCode > 96 && event.charCode < 123) || event.charCode == 32 || event.charCode == 46" maxlength="5">
                                </div>
                                <label class="col-sm-6"><?php echo form_error('StationCode');?></label>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-offset-2 col-lg-10">
                                    <button type="submit" class="btn btn-danger preventbtn">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                            </div>
                          
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<!--<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>-->
<script src="<?php echo $asset_url; ?>js/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>
<script>
                                        function zone_chg_division(id)
                                        {
                                            $.ajax({
                                                type: "POST",
                                                url: "<?php echo site_url('Admin/Zone_Chg_Division'); ?>",
                                                data: {
                                                    id: id,
                                                },
                                                success: function (res) {
                                                    if (res != 0)
                                                    {
                                                        $(".division_div").html(res);
                                                        $(".selectpicker").selectpicker();
                                                    }
                                                }
                                            });
                                        }
</script>
<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Warning!</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password">Level <?=$module_security?> Security Code</label>
                    
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                        <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Submit</button>
                        
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
            </div>
        </div>
    </div>
</div>
<script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.validate_new.min.js"></script>
<script>

 $(document).ready(function () { 
		$.validator.setDefaults({
			ignore: []
		});        
		$('.form-horizontal').validate({
			errorElement: 'span',
			errorClass: 'error',
			ignore: [], 
			lang: 'en',
			rules: {
				RailwayID:'required',
                                DivisionID:'required',
                                StationName:'required',
                                StationCode:'required',
			},  
			submitHandler: function(form) {
				if($(".form-horizontal").valid()==true)
				{
					<?php
					if($this->session->userdata("UserRole")!="Admin")
					{?> 
                                        $("#Level1PasswordModal").modal("show");
                                            if(  $("#form-ok").val()!="ok"){
                                            return false;
                                            } 
						else{
							form.submit();
						}
					<?php
					}
					else{
					?>
						form.submit();
					<?php
					}
					?>
				}
				else{ 
					return false;
				}
			}
		});    
		$('select').on('change', function() {
			$(this).valid();
		});    
	}); 

                                $(".message_info").hide();
                                $('.preventbtn').on('click', function (event) {
                                  //  $("#Level1PasswordModal").modal("show");
                                   /// event.preventDefault();
                                    //eturn false
                                });
                                $('.password_verify').on('click', function (event) {
                                    $.ajax({
                                        type: "POST",
                                         url: "<?php echo site_url($security_url); ?>",
                                        data: {
                                            password: $("#Level1Password").val(),
                                        },
                                        success: function (res) {      
                                            if (res != 1)
                                            {
                                                $("#Level1PasswordMessage").html(res);
                                                $(".message_info").show();
                                            }
                                            else
                                            {
                                                 $(".message_info").hide();
                                                $("#Level1PasswordMessage").html("");
                                            }
                                            if ($("#Level1PasswordMessage").html() == "")
                                            {    $("#form-ok").val("ok")
                                                $("form").submit();
                                            }
                                        }
                                    });
                                });

</script>

</body>
</html>

