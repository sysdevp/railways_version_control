<!--sidebar start-->
<aside>
    <div id="sidebar"  class="nav-collapse ">
        <!-- sidebar menu start-->
        <div class="main_logo"><span><img src="<?php echo site_url();?>assets/themes/img/logo.png"></span></div>
        <ul class="sidebar-menu" id="nav-accordion">
            <!--<li class="text-center"><span style="display: inline-block; margin-bottom: 23px;border: 3px solid #636363;border-radius: 50%;"><img src="<?php echo $asset_url;?>img/logo.png" style="max-width:90px;"></span></li>-->
            <li id="index_tour1">
                <a class="<?php if (isset($this_page)) { if($this_page=='Dashboard'){echo 'active';} }?>" href="<?php echo site_url(); ?>Admin/">
                    <i class="fa fa-dashboard"></i>
                    <span>Dashboard</span>
                </a>
            </li>
            
            
            <li class="sub-menu">
                <a class="<?php if (isset($this_page)) {
                            if ($this_page == 'Master' || $this_page == 'Admin') {
                                echo 'active';
                            }
                        } ?>" href="javascript:;" >
                    <i class="fa fa-sitemap"></i>
                    <span>Admin</span>
                </a>
                <ul class="sub" <?php if (isset($this_page)) {
                            if ($this_page == 'Master') {
                                echo "style='display:block;'";
                            }
                        } ?>>


                          

                    <li><a class="<?php  if (isset($this_page_sub)) {
                            if ($this_page_sub == 'User Login History') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/user-loggedin-details"><i class="fa fa-chevron-right" aria-hidden="true"></i> User Login History</a></li>
                    <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'Logout Time') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/edit-sessiontimeout/1"><i class="fa fa-chevron-right" aria-hidden="true"></i> Logout Time</a></li>
                   
                    <!--<li><a class="<?php //if (isset($this_page_sub)) {
                           // if ($this_page_sub == 'Restrict Version Modification') {
                           //     echo 'active';
                           // }
                    // } ?>" href="<?php// echo site_url(); ?>Admin/edit-versionmodificationlimit/1"><i class="fa fa-chevron-right" aria-hidden="true"></i> EI - Modification</a></li>-->
                    <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'EI - S/W Files') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/version-file-names"><i class="fa fa-chevron-right" aria-hidden="true"></i> EI - S/W Files </a></li>
                    <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'EI - Desc and Exec') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/version-desc-exec"><i class="fa fa-chevron-right" aria-hidden="true"></i> EI - DESC and EXEC</a></li>
                    <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'EI - Required Fields') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/version-req-fields"><i class="fa fa-chevron-right" aria-hidden="true"></i> EI - Required Fields</a></li>
                    
                    <!--<li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'View Version Logic') {
                                echo 'active';
                            }
                     } ?>" href="<?php echo site_url(); ?>Admin/view-version-logic"><i class="fa fa-chevron-right" aria-hidden="true"></i> Version Logic (remove)</a></li>-->
                    
                    <li class="sub-menu">
                        <a href="javascript:;" class="<?php if(isset($this_page_middle)) {
                        if ($this_page_middle == 'Advanced Settings') {
                            echo 'active';
                        } }
                        ?>">
                            <span>Advanced Settings</span>
                        </a>
                                <?php { ?>
                            <ul class="sub">
                                <li><a class="<?php
                                    if (isset($this_page_sub)) {
                                        if ($this_page_sub == 'View Zone') {
                                            echo 'active';
                                        }
                                    }
                                    ?>" href="<?php echo site_url(); ?>Admin/view-zone">Zones</a></li>
                                <li><a class="<?php
                                if (isset($this_page_sub)) {
                                    if ($this_page_sub == 'View Division') {
                                        echo 'active';
                                    }
                                }
                                    ?>" href="<?php echo site_url(); ?>Admin/view-division">Division</a></li>
                                <li><a class="<?php
                                    if (isset($this_page_sub)) {
                                        if ($this_page_sub == 'View Station') {
                                            echo 'active';
                                        }
                                    }
                                    ?>" href="<?php echo site_url(); ?>Admin/view-station">Stations</a></li>
                                <li><a class="<?php
                                      if (isset($this_page_sub)) {
											if ($this_page_sub == 'View Vendor') {
												echo 'active';
											}
										}
                                    ?>" href="<?php echo site_url(); ?>Admin/view-vendor">OEM's</a></li>                                
                                <li class="sub-menu"><a class="<?php
                                            if (isset($this_page_sub)) {
                                                if ($this_page_sub == 'View Security Settings') {
                                                    echo 'active';
                                                }
                                            }
                                            ?>" href="<?php echo site_url(); ?>Admin/security-settings">Level Password</a></li>

                                             <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'menu_security_level') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/module_security_level"></i>Level Settings</a></li>

                         <li><a class="<?php if (isset($this_page_sub)) {
                            if ($this_page_sub == 'Server IP Details') {
                                echo 'active';
                            }
                        } ?>" href="<?php echo site_url(); ?>Admin/settings-ips"> Server IP Details</a></li>
                                <li class="sub-menu"><a class="<?php
                                            if (isset($this_page_sub)) {
                                                if ($this_page_sub == 'Help Settings') {
                                                    echo 'active';
                                                }
                                            }
                                            ?>" href="<?php echo site_url(); ?>Admin/security-settings">Help Settings</a>
                                    <ul class="sub">
                                        <li><a class="<?php
                                            if (isset($this_page_super_sub)) {
                                                if ($this_page_super_sub == 'Add New help') {
                                                    echo 'active';
                                                }
                                            }
                                            ?>" href="<?php echo site_url('Admin/create-help/');?>">Add New</a></li>
                                        <?php
                                        $help =  $this->common_model->find_details("RecordStatus = 1", "tblhelpmaster", "HelpName, HelpID");
                                        foreach($help as $rows)
                                        {?>
                                            <li><a class="<?php
                                            if (isset($this_page_super_sub)) {
                                                if ($this_page_super_sub == 'Help Sub'.$rows['HelpID']) {
                                                    echo 'active';
                                                }
                                            }
                                            ?>" href="<?php echo site_url('Admin/edit-help/').$rows['HelpID'];?>"><?php echo $rows['HelpName'];?></a></li>
                                        <?php
                                        }?>
                                    </ul>

                                </li>                                
                            </ul>
    <?php
}
?>
                    </li>
                    <li class="sub-menu">
                        <a href="javascript:;" class="<?php if(isset($this_page_middle)) { if($this_page_middle=='User'){echo 'active';} }?>">
                            <span>User Management</span>
                        </a>
                        <?php

                        {?>
                        <ul class="sub">
                            <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='View User'){echo 'active';} }?>" href="<?php echo site_url(); ?>Admin/view-user">Users</a></li>
                            <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='User Rights'){echo 'active';} }?>" href="<?php echo site_url(); ?>Admin/user-rights">User Rights</a></li>
                            <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='View Designation'){echo 'active';} }?>" href="<?php echo site_url(); ?>Admin/view-designation">Designation</a></li>
                        </ul>
                        <?php
                        }
                        ?>
                    </li>
                </ul>
            </li>

            
            <li class="sub-menu">
                <a href="<?php echo site_url(); ?>Admin/view-version" class="<?php if($this_page=='View Version'){echo 'active';} ?>">
                    <i class="fa fa-th"></i>
                    <span>View EI - Logic Files</span>
                </a>
            </li>
          <?php
            $userdtet = $this->common_model->find_details(array("UserID" => $this->session->userdata('id_session_list')), "tblusermaster", "RailwayID,LevelID,isAdmin")[0];
            $zoneid = $userdtet["RailwayID"];
            $LevelID = $userdtet["LevelID"];
            $isAdmin = $userdtet["isAdmin"];
            
            if($isAdmin="1" || $zoneid="1") {
                
          ?>
            <li class="sub-menu">
                <a href="javascript:;" class="<?php if($this_page=='Other Links'){echo 'active';} ?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Other Links</span>
                </a>
                 <?php
                
                {?>
                <ul class="sub">
                    <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='GIS'){echo 'active';} }?>" target="_blank" href="http://10.185.130.10/gis">GIS</a></li>
                    <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='Signal Telecom'){echo 'active';} }?>" target="_blank" href="http://10.185.130.11/railway_signal_telecom/">Signal & Telecom</a></li>
                </ul>                
                <?php
                }
                ?>
            </li>
            <?php } ?>
            <li class="sub-menu">
                <a href="javascript:;" class="<?php if($this_page=='Help'){echo 'active';} ?>">
                    <i class="fa fa-dashboard"></i>
                    <span>Help</span>
                </a>
                 <?php
                
                {?>
                <ul class="sub">
                    <?php
                                        $help =  $this->common_model->find_details("RecordStatus = 1", "tblhelpmaster", "HelpName, HelpID");
                                        foreach($help as $rows)
                                        {?>
                                            <li><a class="<?php if(isset($this_page_sub)) { if($this_page_sub=='View Help'.$rows['HelpID']){echo 'active';} } ?>" href="<?php echo site_url('Admin/view-help-detail/').$rows['HelpID'];?>"><?php echo $rows['HelpName'];?></a></li>
                                        <?php
                                        }?>
                </ul>
                <?php
                }
                ?>
            </li>
            
        </ul>
        <!-- sidebar menu end-->
    </div>
</aside>
<!--sidebar end-->