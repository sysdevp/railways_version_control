 <!--footer start-->
 <input type="hidden" id="form-ok">
      <footer class="site-footer">
          <div class="text-center">
              <div class="col-sm-12">
              <div class="col-sm-9">
              Copyright © <?php echo date("Y"); ?> <a href="http://www.mazenetsolution.com/" target="_blank">MAZENET SOLUTION</a>. All rights reserved.
              </div>
              <div class="col-sm-2" style="text-align:right;">V 1.0</div>
              <a href="#" class="go-top">
                  
                  <i class="fa fa-angle-up"></i>
              </a>
              </div>
          </div>
      </footer>
      <!--footer end-->
       </section>
       
         
        <script type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.min.js"></script>
        <script src="<?php echo site_url('assets/boot/'); ?>js/hopscotch-0.2.6.min.js"></script>
      
      <script>
        
        $("form :input").attr("autocomplete", "off");
      </script>
      
       <script>
           function close_header()
           {
              document.getElementById("message_val").style.display = "none";
           }
        </script>
        
        
        
        
        
    