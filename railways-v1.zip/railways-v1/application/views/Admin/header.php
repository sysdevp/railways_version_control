<!DOCTYPE html>
<html lang="en">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta name="description" content="">
        <link rel="shortcut icon" href="<?php echo $asset_url; ?>img/favicon.html">
        <title><?php echo $title; ?></title>
        <!-- Bootstrap core CSS -->
		<link href="<?php echo site_url('assets/boot/'); ?>css/hopscotch-0.2.6.min.css" rel="stylesheet">
       
		
        <link rel="stylesheet" href="<?php echo $asset_url; ?>css/bootstrap-select.min.css" />
        <link href="<?php echo $asset_url; ?>css/bootstrap.min.css" rel="stylesheet">
        <link href="<?php echo $asset_url; ?>css/bootstrap-reset.css" rel="stylesheet">
        <!--external css-->
        <link href="<?php echo $asset_url; ?>assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

        <link href="<?php echo $asset_url; ?>assets/jquery-easy-pie-chart/jquery.easy-pie-chart.css" rel="stylesheet" type="text/css" media="screen"/>
        <link rel="stylesheet" href="<?php echo $asset_url; ?>css/owl.carousel.css" type="text/css">
        <!--right slidebar-->
        <link href="<?php echo $asset_url; ?>css/slidebars.css" rel="stylesheet">
        <!--dynamic table-->
        <link href="<?php echo $asset_url; ?>assets/advanced-datatable/media/css/demo_page.css" rel="stylesheet" />
        <link href="<?php echo $asset_url; ?>assets/advanced-datatable/media/css/demo_table.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.css" />
        <!-- Custom styles for this template -->
        <link href="<?php echo $asset_url; ?>css/style.css" rel="stylesheet">
        <link href="<?php echo $asset_url; ?>css/style-responsive.css" rel="stylesheet" />
        <link rel="stylesheet" href="<?php echo site_url(); ?>assets/css/dropzone.css">
        <link rel="stylesheet" href="<?php echo site_url(); ?>assets/src/richtext.min.css">
        <link href="<?php echo $asset_url; ?>css/mystyle.css" rel="stylesheet">
        <!-- bootstrap-daterangepicker -->
    <link href="<?php echo $asset_url; ?>assets/datepicker/bootstrap-daterangepicker/daterangepicker.css" rel="stylesheet">
        
        <style>
            #message_val{
                margin: 10px 0 50px;
                text-align: center;
                width: 100%;
                padding: 9px;
                color: #fff;
                font-size: 18px;
                font-weight: bold;
                min-height: 29px;
                line-height: 28px;
            }
            #message_val i
            {
                margin-top: 5px;
                float:right;
            }
			#message_vals{
                margin: 10px 0 50px;
                text-align: center;
                width: 100%;
                padding: 9px;
                color: #fff;
                font-size: 18px;
                font-weight: bold;
                min-height: 29px;
                line-height: 28px;
            }
            #message_vals i
            {
                margin-top: 5px;
                float:right;
            }
            .tickmark
            {
                    margin: 0 auto;
    text-align: center;
    display: block;
            }
            #startTourBtn {
                position: relative;
                background: #fd5a4e;
                border: 0;
                font-weight: bold;
                transition: all .3s ease;
            }
            #startTourBtn:hover {
    background: green;
    transition: all .3s ease;
	}
        @media only screen and (min-width: 992px) and (max-width: 1179px){ 

                a.logo {font-size:16px;}
        }
        @media only screen and (min-width: 1180px){
            a.logo {font-size:16px;}
        }
        @media only screen and (max-width: 991px) {
                #startTourBtn { display:none;}

        }
		.myList {
			cursor:pointer;
			cursor:hand;
		}

        </style>
    </head>
    <?php
    


    $cond_user_header = array(
        "UserID" => $this->session->userdata("id_session_list"),
    );
    $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID,DesignationID,RailwayID,DivisionID,StationID");
    $message_header = "";

                $cond3 = array(
                "RailwayID" => $user_details_header[0]["RailwayID"]
                
                );

                 $zone_name = $this->common_model->find_details($cond3, "tblrailwaymaster", "RailwayName")[0]["RailwayName"];


                
    
                $cond1 = array(
                "RailwayID" => $user_details_header[0]["RailwayID"],
                "DivisionID" => $user_details_header[0]['DivisionID'],
                );
                $division_name = $this->common_model->find_details($cond1, "tbldivisionmaster", "DivisionName, DivisionCode")[0]["DivisionName"];
                $cond2 = array(
                "RailwayID" => $user_details_header[0]['RailwayID'],
                "DivisionID" =>$user_details_header[0]['DivisionID'],
                'StationID' =>$user_details_header[0]['StationID'],
                );
                $station_name = $this->common_model->find_details($cond2, "tblstationmaster", "StationName, StationCode")[0]["StationName"];


    $notifications_header = array();
    $notifications_header_from = array();
    if (count($user_details_header) > 0) {
        $cond_header = array(
            "DesignationID" => $user_details_header[0]['DesignationID'],
            "LevelID" => $user_details_header[0]['LevelID'],
        );
        $user_role_details_header = $this->common_model->find_details($cond_header, "tbluserrolemaster", "Approve_Reject");
        if (count($user_role_details_header) > 0) {
            if ($user_role_details_header[0]['Approve_Reject'] == 1) {
                $cond_header = array(
                    "NotificationTo" => $user_details_header[0]['LevelID'],
                    "Status" => "Pending",
                );
                $notifications_header = $this->common_model->find_details($cond_header, "tblnotifications");

                $cond_header = array(
                    "NotificationFrom" => $user_details_header[0]['LevelID'],
                    "CreatedBy" => $this->session->userdata("id_session_list"),
                    "Status !=" => "Pending",
                    "ReadStatusFrom" => 0
                );
                $notifications_header_from = $this->common_model->find_details($cond_header, "tblnotifications");
            }
        }
    }
    ?>
    <body>
            <div class="modal fade alert_popup" id="myModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h3 class="modal-title alert_status" id="exampleModalLabel"></h3>
                            <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <p class="alert_msg"></p>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary close_model"   data-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        <section id="container">
            <!--header start-->
            <header class="header white-bg">
                <div class="sidebar-toggle-box">
                    <i class="fa fa-bars"></i>
                </div>
                <!--logo start-->
                <a href="<?php echo site_url(); ?>" class="logo">Electronic Interlocking - Application Management Software</a>

                  

                <!--logo end-->

                <div class="top-nav ">
                    <!--search & user info start-->
                    <ul class="nav pull-right top-menu">
                        <!-- user login dropdown start-->
                        <li class="dropdown">
                            <a href="<?php echo site_url(); ?>Admin/user-profile">
                                <img alt="" src="<?php echo $asset_url; ?>img/avatar1_small.jpg">
                                <span class="username"><?php echo $this->session->userdata("name_session_list"); ?></span>
                            </a>
                        </li>
                        <li>
                            <a href="<?php echo site_url(); ?>Admin/logout">
                                <img alt="" src="<?php echo $asset_url; ?>img/shutdown.png" style="max-width: 29px;opacity: 0.7;"> <span class="username">Logout</span>
                            </a>
                        </li>
                        <!-- user login dropdown end -->
                    </ul>
                    <!--search & user info end-->
                </div>

                <script>
                    
                    function go_back_history(){
                        //alert(window.location.href);
                       // alert(document.referrer);
                         if(window.location.href==document.referrer){
                            window.history.go(-2);
                            //window.history.back();
                         }else{

                           window.history.go(-1);
                           //window.location.href=document.referrer;
                           
                         }
                    }
                </script>
                <div class="nav notify-row" id="top_menu">
                    <!--  notification start -->
                    <ul class="nav top-menu">
                        <!-- settings start -->
                        <!-- settings end -->
                        <!-- inbox dropdown start -->
                        <?php if(isset($tour_visible)) { if($tour_visible == "active") { ?>
                        <li class="dropdown">
                            <b class="text-center">
                                <button id="startTourBtn" class="btn btn-primary">Try it out!</button>
                            </b>
                        </li>
                        <?php 
                        }
                        }
                        ?>
                          <li id="header_inbox_bar" class="dropdown">
                        <!--  <a href="<?php echo @$_SERVER['HTTP_REFERER']; ?>" class="btn btn-warning">Back</a> -->
						<?php 
							if($this_page != 'Dashboard')
							{
								$session_data = array(
									"back_button_disable" => false
								);
								$this->session->set_userdata($session_data);
							}
							if($this->session->userdata('back_button_disable') == false)
							{
						?>
                        <a onclick="go_back_history()" data-toggle="tooltip" data-placement="top" title="Back"><i class="fa fa-arrow-circle-left fa-lg myList" style="color:#3371FF;"></i></a>
							<?php } ?>
                        </li>
                        <li id="header_inbox_bar" class="dropdown">
                            <a href="<?php echo site_url(); ?>Admin/" data-toggle="tooltip" data-placement="top" title="Home">
                                <i class="fa fa-home fa-lg" style="color:#3371FF;"></i>
                            </a>
                        </li>
                        
                        <!-- inbox dropdown end -->
                        <!-- notification dropdown start-->
                        <!--<li id="header_notification_bar" class="dropdown">
                            <a data-toggle="dropdown" class="dropdown-toggle" href="#">
                                <i class="fa fa-bell-o"></i>
                                <span class="badge bg-warning"><?php echo count($notifications_header) + count($notifications_header_from); ?></span>
                            </a>
                            <ul class="dropdown-menu extended notification">
                                <div class="notify-arrow notify-arrow-yellow"></div>
                                <li>
                                    <p class="yellow">You have <?php echo count($notifications_header) + count($notifications_header_from); ?> new notifications</p>
                                </li>
                                <?php
                                foreach ($notifications_header as $rows) {
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                        'StationID' => $rows['StationID'],
                                        'VendorID' => $rows['VendorID'],
                                        'VersionID' => $rows['VersionID'],
                                    );
                                    $version_info = $this->common_model->find_details($cond, "tblversiondefine", "VersionNo");
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                    );
                                    $division_info = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionName, DivisionCode");
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                        'StationID' => $rows['StationID'],
                                    );
                                    $station_info = $this->common_model->find_details($cond, "tblstationmaster", "StationName, StationCode");
                                    ?>
                                    <li>
                                        <a href="<?php echo site_url(); ?>Admin/detail-version-approve/<?php echo $rows['RailwayID']; ?>/<?php echo $rows['DivisionID']; ?>/<?php echo $rows['StationID']; ?>/<?php echo $rows['VendorID']; ?>/<?php echo $rows['VersionID']; ?>/<?php echo $rows['NID']; ?>/<?php echo $rows['CreatedBy']; ?>">
                                            <span class="label label-danger"><i class="fa fa-bolt"></i></span>
                                            Approval Request for Version  <?php echo $rows['NotificationType']; ?> -
                                            <?php
                                            if (count($version_info) > 0) {
                                                echo $version_info[0]['VersionNo'];
                                            }
                                            ?> <br/> <?php
                                            if (count($division_info) > 0) {
                                                echo $division_info[0]['DivisionName'] . " (" . $division_info[0]['DivisionCode'] . ") - ";
                                            }
                                            ?> <?php
                                            if (count($station_info) > 0) {
                                                echo $station_info[0]['StationName'] . " (" . $station_info[0]['StationCode'] . ")";
                                            }
                                            ?><br/>
                                            <span class="small italic"><?php echo $this->common_model->time_elapsed_string($rows['CreatedOn']); ?></span>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                                <?php
                                foreach ($notifications_header_from as $rows) {
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                        'StationID' => $rows['StationID'],
                                        'VendorID' => $rows['VendorID'],
                                        'VersionID' => $rows['VersionID'],
                                    );
                                    $version_info = $this->common_model->find_details($cond, "tblversiondefine", "VersionNo");
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                    );
                                    $division_info = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionName, DivisionCode");
                                    $cond = array(
                                        "RailwayID" => $rows['RailwayID'],
                                        "DivisionID" => $rows['DivisionID'],
                                        'StationID' => $rows['StationID'],
                                    );
                                    $station_info = $this->common_model->find_details($cond, "tblstationmaster", "StationName, StationCode");
                                    ?>
                                    <li>
                                        <a href="<?php echo site_url(); ?>Admin/detail-version-approve/<?php echo $rows['RailwayID']; ?>/<?php echo $rows['DivisionID']; ?>/<?php echo $rows['StationID']; ?>/<?php echo $rows['VendorID']; ?>/<?php echo $rows['VersionID']; ?>/<?php echo $rows['NID']; ?>/<?php echo $rows['CreatedBy']; ?>">
                                            <span class="label label-danger"><i class="fa fa-<?php
                                                if ($rows['Status'] == "Approved") {
                                                    echo "check";
                                                } elseif ($rows['Status'] == "Declined") {
                                                    echo "remove";
                                                } else {
                                                    echo "exclamation-triangle";
                                                };
                                                ?>"></i></span>
                                            <?php echo $rows['Status']; ?> for Version  <?php echo $rows['NotificationType']; ?> -
                                            <?php
                                            if (count($version_info) > 0) {
                                                echo $version_info[0]['VersionNo'];
                                            }
                                            ?> <br/> <?php
                                            if (count($division_info) > 0) {
                                                echo $division_info[0]['DivisionName'] . " (" . $division_info[0]['DivisionCode'] . ") - ";
                                            }
                                            ?> <?php
                                            if (count($station_info) > 0) {
                                                echo $station_info[0]['StationName'] . " (" . $station_info[0]['StationCode'] . ")";
                                            }
                                            ?><br/>
                                            <span class="small italic"><?php echo $this->common_model->time_elapsed_string($rows['ModifiedOn']); ?></span>
                                        </a>
                                    </li>
                                    <?php
                                }
                                ?>
                            </ul>
                        </li>-->
                        <!-- notification dropdown end -->
                    </ul>
                </div>
				
			<?php 
				$level_id = $user_details_header[0]['LevelID'];
				$cond_desig = array(
                "DesignationID" => $user_details_header[0]['DesignationID']
                );
				$detail_format = "";
                 $DesignationArray = $this->common_model->find_details($cond_desig, "tbldesignationmaster", "DesignationName");
                 $DesignationName = "";
					 if(count($DesignationArray)>0)
					 {
						 $DesignationName = $DesignationArray[0]['DesignationName'];
					 }
					if($level_id == 1)
					{
						$detail_format = '('.$DesignationName.')';		
					}
					else if($level_id == 2)
					{
						$detail_format = '('.$zone_name.' - '.$DesignationName.')';	
					}
					else if($level_id == 3)
					{
						$detail_format = '('.$zone_name.' - '.$division_name.' - '.$DesignationName.')';	
					}
					else if($level_id == 4)
					{
						$detail_format = '('.$zone_name.' - '.$division_name.' - '.$station_name.' - '.$DesignationName.')';	
					}
					if($detail_format=="()")
					{
						$detail_format = "";
					}
					
				?>
               <div    style=" clear: both;text-align: right;";> <?php echo $detail_format; ?></div>


  



            </header>
            <!--header end-->
