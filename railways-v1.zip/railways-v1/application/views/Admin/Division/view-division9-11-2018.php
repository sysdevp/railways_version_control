<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<!--main content start-->
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View Divison</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>Admin/create-division" class="btn btn-info">Create New Division</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped" id="example">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Division Name</th>
                                        <th>Division Code</th>
                                        <th>Sync</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    $i = 1;
                                    foreach ($division as $rows) {
                                        ?>
                                        <tr>
                                            <td><?php echo $i; ?></td>
                                            <td><?php echo $rows['DivisionName']; ?></td>
                                            <td><?php echo $rows['DivisionCode']; ?></td>
                                            <td class="green"><i class="fa fa-check" aria-hidden="true"></i> Yes</td>
                                            <td>                                            
                                                <a href="<?php echo site_url(); ?>Admin/view-division-detail/<?php echo $rows['RailwayID']; ?>/<?php echo $rows['DivisionID']; ?>"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                                <a href="<?php echo site_url(); ?>Admin/edit-division/<?php echo $rows['RailwayID']; ?>/<?php echo $rows['DivisionID']; ?>"><span class="label label-info label-mini btn-edit" title="Edit"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></span> </a>
                                                <input type="hidden" id="RailwayID" value="<?php echo $rows['RailwayID']; ?>"/>
                                                <input type="hidden" id="DivisionID" value="<?php echo $rows['DivisionID']; ?>"/>
                                                <a href="javascript:void(0)" class="preventbtn"><span class="label label-info label-mini btn-danger" title="Delete"><i class="fa fa-trash-o" aria-hidden="true"></i></span> </a>
                                            </td>
                                        </tr>
                                        <?php
                                        $i++;
                                    }
                                    ?>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="3"></th>
                                        <th><a href="#" class="btn btn-success">Sync All</a></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>
<!--main content end-->

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<div class="modal fade alert_popup LevelPassword" id="Level1PasswordModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title" id="Level1PasswordTitle">Are you sure, you want to Delete?</h3>
                <button  type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="message_info" id="Level1PasswordMessage"></div>
                <div class="form-group">
                    <label class="col-sm-4 control-label" for="Level1Password">Enter the Security Code to delete</label>
                    <div class="col-lg-8">
                        <input type="password" name="Level1Password" class="form-control" id="Level1Password" placeholder="Security Code" value="<?php echo set_value("RailwayName"); ?>">
                    </div>
                </div>                           
                <div class="form-group">
                    <div class="col-lg-12">
                      <button type="submit" class="btn btn-danger password_verify  pull-right" style="margin-top:5px;" >Yes</button>
                         <button type="button pull-right" style="margin-top:5px;margin-left: 80%;"class="btn btn-secondary close_model"   data-dismiss="modal">No</button>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
              
            </div>
        </div>
    </div>
</div>
<script>
    $(".message_info").hide();
    $("#success-alert").hide();
    $('.preventbtn').on('click', function (event) {
        $("#Level1PasswordModal").modal("show");
        event.preventDefault();
        return false
    });
    $('.password_verify').on('click', function (event) {
        $.ajax({
            type: "POST",
            url: "<?php echo site_url('Admin/level1-security-settings'); ?>",
            data: {
                password: $("#Level1Password").val(),
            },
            success: function (res) {
                if (res != 1)
                {
                    $("#Level1PasswordMessage").html(res);
                    $(".message_info").show();
                }
                else
                {
                    $("#Level1PasswordMessage").html("");
                }
                if ($("#Level1PasswordMessage").html() == "")
                {
                    $("#Level1PasswordModal").modal("hide");
                    deletedivision($("#RailwayID").val(),$("#DivisionID").val() )
                }
            }
        });
    });
</script>
<script>
    function deletedivision(id, did)
    {
            $.ajax({
                type: "POST",
                url: "<?php echo site_url('Admin/delete-division'); ?>",
                data: {
                    id: id,
                    did: did
                },
                success: function (res) {
                    if (res == 1)
                    {
                        window.location = "<?php echo site_url(); ?>Admin/view-division";
                    }
                    else
                    {
                       $(".alert_status").html("Warning!");
                        $(".alert_msg").html("This record cannot be deleted because other records need this information.");
                        $("#myModal .modal-header").addClass("alert_warining");
                        $("#myModal").modal("show");
                    }
                }
            });
    }
    
</script>

<script>
    $(document).ready(function () {
        var table = $('#example').DataTable({
            "paging": true,
            "pageLength": 10,
            "dom": 'lBfrtip',
            buttons: [
                'pdf', 'print'
            ]
        });
        $(".buttons-pdf").html("<i class='fa fa-file-pdf-o' aria-hidden='true'></i> Download PDF");
        $(".buttons-pdf").addClass("btn btn-info");
        $(".buttons-print").html("<i class='fa fa-print' aria-hidden='true'></i> Print");
        $(".buttons-print").addClass("btn btn-default");
        $(".dataTables_filter input").addClass("form-control");
        $('a.toggle-vis').on('click', function (e) {
            e.preventDefault();

            // Get the column API object
            var column = table.column($(this).attr('data-column'));

            // Toggle the visibility
            column.visible(!column.visible());
        });
    });
</script>
<script src="<?php echo $asset_url; ?>js/jquery.dataTables.min.js"></script>
<script src="<?php echo $asset_url; ?>js/dataTables.buttons.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.flash.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jszip.min.js"></script>
<script src="<?php echo $asset_url; ?>js/pdfmake.min.js"></script>
<script src="<?php echo $asset_url; ?>js/vfs_fonts.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.html5.min.js"></script>
<script src="<?php echo $asset_url; ?>js/buttons.print.min.js"></script>


</body>
</html>

