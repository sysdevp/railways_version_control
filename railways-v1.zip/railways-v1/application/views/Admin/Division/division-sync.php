<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">View Version</h3>
                        <ul class="pull-right">
                            <li><a href="<?php echo site_url(); ?>add-new-version" class="btn btn-info">Create New Version</a></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <ul class="pull-right col-sm-12 text-right">
                            <li class="pull-right" style="margin-left: 10px;"><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download PDF</button></li>
                            <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                        </ul>
                        <div class="adv-table">
                            <table class="display table table-bordered table-striped view_version" id="dynamic-table">
                                <thead>
                                    <tr>
                                        <th>Sno</th>
                                        <th>Division</th>
                                        <th>Station</th>
                                        <th>Make of EI</th>
                                        <th>Installation / Alteration  Date</th>
                                        <th>Distributed</th>
                                        <th>Version</th>
                                        <th>Checksum / CRC</th>
                                        <th>Work Executed by</th>
                                        <th>Sync</th>
                                        <th>Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td>1</td>
                                        <td>Chennai (MAS)</td>
                                        <td>Chennai Central (MAS)</td>
                                        <td>Ansaldo</td>
                                        <td>25/07/2018</td>
                                        <td>Yes</td>
                                        <td>9</td>
                                        <td>98765</td>
                                        <td>Kumar</td>
                                        <td class="red"><i class="fa fa-times" aria-hidden="true"></i> No</td>
                                        <td>                                            
                                            <a href="<?php echo site_url(); ?>division-sync-detail"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td>2</td>
                                        <td>Chennai (MAS)</td>
                                        <td>Basin Bridge Jn. (BBQ)</td>
                                        <td>GE</td>
                                        <td>28/07/2018</td>
                                        <td>No</td>
                                        <td>11</td>
                                        <td>69584</td>
                                        <td>Kumar</td>
                                        <td class="red"><i class="fa fa-times" aria-hidden="true"></i> No</td>
                                        <td>                                            
                                            <a href="<?php echo site_url(); ?>division-sync-detail"><span class="label label-info label-mini btn-success" title="View"><i class="fa fa-eye" aria-hidden="true"></i></span> </a>
                                        </td>
                                    </tr>
                                </tbody>
                                <tfoot>
                                    <tr>
                                        <th colspan="9"></th>
                                        <th><a href="#" class="btn btn-success">Sync All</a></th>
                                        <th></th>
                                    </tr>
                                </tfoot>
                            </table>
                        </div>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<script>
    $(document).ready(function() {
    var table = $('#example').DataTable( {
        "scrollY": "200px",
        "paging": false
    } );
 
    $('a.toggle-vis').on( 'click', function (e) {
        e.preventDefault();
 
        // Get the column API object
        var column = table.column( $(this).attr('data-column') );
 
        // Toggle the visibility
        column.visible( ! column.visible() );
    } );
} );
</script>
    

</body>
</html>