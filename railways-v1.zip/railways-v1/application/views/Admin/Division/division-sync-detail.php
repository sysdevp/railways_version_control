<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Detailed Version View</h3>
                        <ul class="pull-right">
                            <li><button type="button" class="btn btn-default"><i class="fa fa-print" aria-hidden="true"></i> Print</button></li>
                            <li><button type="button" class="btn btn-info"><i class="fa fa-file-pdf-o" aria-hidden="true"></i> Download</button></li>
                        </ul>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal add_new_version_form" role="form">
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Division Name / Code:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">Chennai (MAS)</label>
                                </div>
                                <label for="StationName" class="col-sm-2 control-label">Station Name / Code:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">Basin Bridge Jn (BBQ)</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label" for="inputSuccess">Make of EI:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">Ansaldo</label>
                                </div>
                                <label class="col-sm-2 control-label" for="inputSuccess">Distributed</label>
                                <div class="col-lg-4">
                                    <label class="control-label">Yes    </label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="SignalingPlanNumber" class="col-sm-2 control-label">Signaling Plan Number:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">9</label>
                                </div>
                                <label for="DateInstallation" class="col-sm-2 control-label">Date of installation:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">25/08/2018</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="ReasonChanging" class="col-sm-2 control-label">Description of Work:</label>
                                <div class="col-lg-10">
                                    <label class="control-label">Track Changed</label>
                                </div>
                            </div> 
                            <div class="form-group">
                                <label form="WorkExcuited" class="col-sm-2 control-label" for="inputSuccess">Work Executed up by:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">Kumar</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th>Executive Software</th>
                                                <th>Vesion</th>
                                                <th>Checksum / CRC</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>Pervious Executive Software</td>
                                                <td><label class="control-label">11</label></td>
                                                <td><label class="control-label">212121</label></td>
                                            </tr>
                                            <tr>
                                                <td>updated Executive Software</td>
                                                <td><label class="control-label">12</label></td>
                                                <td><label class="control-label">45754</label></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <label class="col-sm-2 control-label">No of CPU's:</label>
                                <div class="col-lg-4">
                                    <label class="control-label">3</label>
                                </div>
                                <div class="col-sm-12">
                                    <table class="mtop20 table dashboard-table table-bordered">
                                        <thead>
                                            <tr>
                                                <th></th>
                                                <th class="text-center" colspan="2">Vital</th>
                                                <th class="text-center" colspan="2">Non Vital</th>
                                            <tr>
                                            <tr>
                                                <th>Sno</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                                <th>Previous</th>
                                                <th>Updated</th>
                                            <tr>
                                        </thead>
                                        <tbody>
                                            <tr>
                                                <td>1</td>
                                                <td>9</td>
                                                <td>10</td>
                                                <td>11</td>
                                                <td>12</td>
                                            </tr>
                                            <tr>
                                                <td>2</td>
                                                <td>8</td>
                                                <td>9</td>
                                                <td>10</td>
                                                <td>11</td>
                                            </tr>
                                            <tr>
                                                <td>3</td>
                                                <td>7</td>
                                                <td>8</td>
                                                <td>9</td>
                                                <td>10</td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-sm-12">
                                    <table class="table dashboard-table text-center table-bordered detail_view_table">
                                        <tbody>
                                            <tr>
                                                <td colspan="4"><strong>Application Logic Folder: <a href="#">[Download]</strong></a></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td>7</td>
                                                <td>Folder Count Avaliable</td>
                                                <td>7</td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td>12</td>
                                                <td>Files count Avaliable</td>
                                                <td>12</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Important Files (3)</td>
                                                <td colspan="2">
                                                    version.doc<br>
                                                    version.pdf<br>
                                                    client.doc<br>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4"><strong>Interface Circuit Folder: <a href="#">[Download]</strong></a></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td>7</td>
                                                <td>Folder Count Avaliable</td>
                                                <td>7</td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td>12</td>
                                                <td>Files count Avaliable</td>
                                                <td>12</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Important Files (3)</td>
                                                <td colspan="2">
                                                    version.doc<br>
                                                    version.pdf<br>
                                                    client.doc<br>
                                                </td>
                                            </tr>
                                            <tr>
                                                <td colspan="4"><strong>Video Circuit Folder: <a href="#">[Download]</strong></a></td>
                                            </tr>
                                            <tr>
                                                <td>Folder Count Required</td>
                                                <td>7</td>
                                                <td>Folder Count Avaliable</td>
                                                <td>7</td>
                                            </tr>
                                            <tr>
                                                <td>Files Count Required</td>
                                                <td>12</td>
                                                <td>Files count Avaliable</td>
                                                <td>12</td>
                                            </tr>
                                            <tr>
                                                <td colspan="2">Important Files (3)</td>
                                                <td colspan="2">
                                                    version.doc<br>
                                                    version.pdf<br>
                                                    client.doc<br>
                                                </td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <label class="control-label">Created by Shanmugam on : 25/07/2018 13:25:55</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <label class="control-label">Record Last Modified by Jayakumar on : 27/07/2018 14:15:55</label>
                                </div>
                            </div>
                            <div class="form-group">
                                <div class="col-lg-12">
                                    <label class="control-label">Synchronization Failed due to Network Error</label>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap-select.min.js"></script>


</body>
</html>