<?php

defined('BASEPATH') OR exit('No direct script access allowed');

/*
  | -------------------------------------------------------------------------
  | URI ROUTING
  | -------------------------------------------------------------------------
  | This file lets you re-map URI requests to specific controller functions.
  |
  | Typically there is a one-to-one relationship between a URL string
  | and its corresponding controller class/method. The segments in a
  | URL normally follow this pattern:
  |https://www.youtube.com/watch?v=o6oWmhDMvi0&feature=youtu.be
  |	example.com/class/method/id/
  |
  | In some instances, however, you may want to remap this relationship
  | so that a different class/function is called than the one
  | corresponding to the URL.
  |
  | Please see the user guide for complete details:
  |
  |	https://codeigniter.com/user_guide/general/routing.html
  |
  | -------------------------------------------------------------------------
  | RESERVED ROUTES
  | -------------------------------------------------------------------------
  |
  | There are three reserved routes:
  |
  |	$route['Admin/default_controller'] = 'welcome';
  |
  | This route indicates which controller class should be loaded if the
  | URI contains no data. In the above example, the "welcome" class
  | would be loaded.
  |
  |	$route['Admin/404_override'] = 'errors/page_missing';
  |
  | This route will tell the Router which controller/method to use if those
  | provided in the URL cannot be matched to a valid route.
  |
  |	$route['Admin/translate_uri_dashes'] = FALSE;
  |
  | This is not exactly a route, but allows you to automatically route
  | controller and method names that contain dashes. '-' isn't a valid
  | class or method name character, so it requires translation.
  | When you set this option to TRUE, it will replace ALL dashes in the
  | controller and method URI segments.
  |
  | Examples:	my-controller/index	-> my_controller/index
  |		my-controller/my-method	-> my_controller/my_method
 */
$route['default_controller'] = 'Admin_Home/index';
$route['404_override'] = 'page_not_found/index';
$route['translate_uri_dashes'] = FALSE;

$route['Admin'] = 'Admin_Home/index';
$route['Admin/dashboard'] = 'Admin_Home/index';

$route['Admin/unauthorized'] = 'Admin_Home/unauthorized';
$route['Admin/connectivitynotexist'] = 'Admin_Home/connectivitynotexist';
$route['Admin/connectivitynotexist/(:any)'] = 'Admin_Home/connectivitynotexist/$1';

$route['Admin/sync-success'] = 'Admin_Home/syncsuccess';

$route['Admin/Division/(:any)/(:any)'] = 'Admin_Home/dashboard_division/$1/$2';
$route['Admin/Vendor/(:any)/(:any)'] = 'Admin_Home/dashboard_vendor/$1/$2';
$route['Admin_home/check_security_level'] = 'Admin_Home/check_security_level';
$route["admin/update_module_security"] = 'Admin_Home/update_module_security';

$route['Admin/Notifications'] = 'Admin_Home/Notifications';


$route['Admin/login'] = 'Admin_Login_Register/login';
$route['Admin/logout'] = 'Admin_Home/logout';



$route['Admin/vendor'] = 'Admin_Home/vendor';
$route['Admin/create-vendor'] = 'Admin_Home/create_vendor';
$route['Admin/view-vendor'] = 'Admin_Home/view_vendor';
$route['Admin/view-vendor-detail/(:any)'] = 'Admin_Home/view_vendor_detail/$1';
$route['Admin/edit-vendor/(:any)'] = 'Admin_Home/edit_vendor/$1';
$route['Admin/delete-vendor'] = 'Admin_Home/delete_vendor';



$route['Admin/help'] = 'Admin_Home/help';
$route['Admin/create-help'] = 'Admin_Home/create_help';
$route['Admin/view-help'] = 'Admin_Home/view_help';
$route['Admin/view-help-detail/(:any)'] = 'Admin_Home/view_help_detail/$1';
$route['Admin/edit-help/(:any)'] = 'Admin_Home/edit_help/$1';
$route['Admin/delete-help'] = 'Admin_Home/delete_help';



$route['Admin/create-user'] = 'Admin_Home/create_user';
$route['Admin/edit-user/(:any)'] = 'Admin_Home/edit_user/$1';
$route['Admin/delete-user'] = 'Admin_Home/delete_user';
$route['Admin/view-user-detail/(:any)'] = 'Admin_Home/view_user_detail/$1';
$route['Admin/user-profile'] = 'Admin_Home/user_profile';
$route['Admin/view-user'] = 'Admin_Home/view_user';
$route['Admin/select_users'] = 'Admin_Home/select_user';




$route['Admin/create-version-logic'] = 'Admin_Home/create_version_logic';
$route['Admin/view-version-logic'] = 'Admin_Home/view_version_logic';
$route['Admin/edit-version-logic/(:any)/(:any)/(:any)/(:any)'] = 'Admin_Home/edit_version_logic/$1/$2/$3/$4';
$route['Admin/delete-version-logic'] = 'Admin_Home/delete_version_logic';
$route['Admin/view-version-logic-detail/(:any)/(:any)/(:any)/(:any)'] = 'Admin_Home/view_version_logic_detail/$1/$2/$3/$4';




$route['Admin/view-version'] = 'Admin_Home/view_version';
$route['Admin/detail-version-view/(:any)/(:any)/(:any)/(:any)/(:any)/(:any)'] = 'Admin_Home/detail_version_view/$1/$2/$3/$4/$5/$6';
$route['Admin/detail-version-approve/(:any)/(:any)/(:any)/(:any)/(:any)/(:any)/(:any)'] = 'Admin_Home/detail_version_approve/$1/$2/$3/$4/$5/$6/$7';
$route['Admin/data-entry'] = 'Admin_Home/data_entry';
$route['Admin/add-new-version'] = 'Admin_Home/add_new_version';
$route['Admin/addnew-version'] = 'Admin_Home/addnew_version';
$route['Admin/edit-version/(:any)/(:any)/(:any)/(:any)/(:any)'] = 'Admin_Home/edit_version/$1/$2/$3/$4/$5';
$route['Admin/delete-version'] = 'Admin_Home/delete_version';
$route['Admin/add-new-version/preview'] = 'Admin_Home/add_new_version/preview';


$route['Admin/error-report'] = 'Admin_Home/error_report';
$route['Admin/user-rights'] = 'Admin_Home/user_rights';
$route['Admin/create-role'] = 'Admin_Home/create_role';
$route['Admin/edit-role/(:any)/(:any)/(:any)'] = 'Admin_Home/edit_role/$1/$2/$3';
$route['Admin/delete-role'] = 'Admin_Home/delete_role';

$route['Admin/settings-ip'] = 'Admin_Home/settings_ip';
$route['Admin/settings-ips'] = 'Admin_Home/settings_ips';
$route['Admin/settings-ipnew'] = 'Admin_Home/settings_ipnew';
$route['Admin/settings-version'] = 'Admin_Home/settings_version';
$route['Admin/security-settings'] = 'Admin_Home/security_settings';
$route['Admin/edit-security-settings/(:any)'] = 'Admin_Home/edit_security_settings/$1';
$route['Admin/level1-security-settings'] = 'Admin_Home/level1_security_settings';
$route['Admin/level2-security-settings'] = 'Admin_Home/level2_security_settings';
$route['Admin/level3-security-settings'] = 'Admin_Home/level3_security_settings';
$route['Admin/module_security_level'] = 'Admin_Home/module_security_level';

$route['Admin/edit-settings-ip/(:any)/(:any)'] = 'Admin_Home/edit_settings_ip/$1/$2';


$route['Admin/user-loggedin-details'] = 'Admin_Home/userloggedindetails';

$route['Admin/version-desc-exec'] = 'Admin_Home/version_desc_exec';
$route['Admin/version-file-names'] = 'Admin_Home/version_file_names';
$route['Admin/version-req-fields'] = 'Admin_Home/version_req_fields';
$route['Admin/version-file-types'] = 'Admin_Home/version_file_types';
$route['Admin/AjaxForm/(:any)'] = 'AJaxController/runmethod/$1';
$route['Admin/AjaxForm/(:any)/(:any)'] = 'AJaxController/runmethod/$1/$2';
$route['Admin/AjaxForm/checkserverip'] = 'AJaxController/checkserverip';

// VersionFileNames

$route['Admin/connectivity'] = 'Admin_Home/connectivity';
$route['Admin/ip-settings'] = 'Admin_Home/ip_settings';



$route['Admin/division'] = 'Admin_Home/division';
$route['Admin/create-division'] = 'Admin_Home/create_division';
$route['Admin/view-division'] = 'Admin_Home/view_division';
$route['Admin/edit-division/(:any)/(:any)'] = 'Admin_Home/edit_division/$1/$2';
$route['Admin/delete-division'] = 'Admin_Home/delete_division';
$route['Admin/view-division-detail/(:any)/(:any)'] = 'Admin_Home/view_division_detail/$1/$2';
$route['Admin/division-sync'] = 'Admin_Home/division_sync';
$route['Admin/division-sync-detail'] = 'Admin_Home/division_sync_detail';


$route['Admin/Check_Username'] = 'Admin_Home/Check_Username';

$route['Admin/Zone_Chg_Dashboard'] = 'Admin_Home/Zone_Chg_Dashboard';
$route['Admin/Zone_Chg_Division'] = 'Admin_Home/Zone_Chg_Division';
$route['Admin/Zone_Chg_Work_Fields'] = 'Admin_Home/Zone_Chg_Work_Fields';
$route['Admin/Zone_Chg_Fields'] = 'Admin_Home/Zone_Chg_Fields';
$route['Admin/Division_Chg_Station'] = 'Admin_Home/Division_Chg_Station';
$route['Admin/Level_Chg_Designation'] = 'Admin_Home/Level_Chg_Designation';
$route['Admin/Vendor_Chg_Version'] = 'Admin_Home/Vendor_Chg_Version';
$route['Admin/Station_Chg'] = 'Admin_Home/Station_Chg';
$route['Admin/userlogin_Chg_Station'] = 'Admin_Home/userlogin_Chg_Station';

$route['Admin/create-station'] = 'Admin_Home/create_station';
$route['Admin/view-station'] = 'Admin_Home/view_station';
$route['Admin/edit-station/(:any)/(:any)/(:any)'] = 'Admin_Home/edit_station/$1/$2/$3';
$route['Admin/delete-station'] = 'Admin_Home/delete_station';
$route['Admin/view-station-detail/(:any)/(:any)/(:any)'] = 'Admin_Home/view_station_detail/$1/$2/$3';



$route['Admin/view-designation'] = 'Admin_Home/view_designation';
$route['Admin/view-designation-detail/(:any)'] = 'Admin_Home/view_designation_detail/$1';
$route['Admin/create-designation'] = 'Admin_Home/create_designation';
$route['Admin/edit-designation/(:any)'] = 'Admin_Home/edit_designation/$1';
$route['Admin/delete-designation'] = 'Admin_Home/delete_designation';


$route['Admin/view-sessiontimeout'] = 'Admin_Home/view_sessiontimeout';
$route['Admin/view-sessiontimeout-detail/(:any)'] = 'Admin_Home/view_sessiontimeout_detail/$1';
$route['Admin/edit-sessiontimeout/(:any)'] = 'Admin_Home/edit_sessiontimeout/$1';


$route['Admin/view-versionmodificationlimit'] = 'Admin_Home/view_versionmodificationlimit';
$route['Admin/view-versionmodificationlimit-detail/(:any)'] = 'Admin_Home/view_versionmodificationlimit_detail/$1';
$route['Admin/edit-versionmodificationlimit/(:any)'] = 'Admin_Home/edit_versionmodificationlimit/$1';

$route['Admin/view-zone'] = 'Admin_Home/view_zone';
$route['Admin/view-zone-detail/(:any)'] = 'Admin_Home/view_zone_detail/$1';
$route['Admin/create-zone'] = 'Admin_Home/create_zone';
$route['Admin/edit-zone/(:any)'] = 'Admin_Home/edit_zone/$1';
$route['Admin/delete-zone'] = 'Admin_Home/delete_zone';

$route['Admin/uploadFile'] = 'Admin_Home/uploadAnyFile';
$route['Admin/uploadimage'] = 'Admin_Home/uploadimage';
$route['Admin/delete-parameter'] = 'Admin_Home/delete_parameter';
$route['Admin/delete-cpu'] = 'Admin_Home/delete_cpu';

$route['Admin/index_chart'] = 'Admin_Home/index_chart';

//EI desc and exec
$route['Admin/EI_description_view'] = 'Admin_Home/EI_description_view';
$route['Admin/delete-version-desc-fields'] = 'Admin_Home/delete_version_desc_fields';
$route['Admin/edit_version_desc/(:any)'] = 'Admin_Home/edit_version_desc/$1';

$route['Admin/Show_On_Hover_Table_Details'] = 'Admin_Home/Show_On_Hover_Table_Details';


