<?php

class AJaxController extends CI_Controller {

	public function runmethod($function, $d = "") {
		if ($d == "") {
			$this -> {$function}();
		} else {
			$this -> {$function}($d);
		}
	}
	
	public function saveversionmodificationlimit(){
		$id = 1;
    	$data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID");
        if (count($data['versionmodificationlimit']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('NoOfDays', 'VersionModificationLimit Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'NoOfDays' => $this->input->post('NoOfDays'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("ID", $id, $data_to_store, "tblversionmodificationlimit")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "VersionModificationLimit Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-versionmodificationlimit'));
        }
		redirect("Admin/version-file-names");
    }
	
	public function checkserverip()
	{
	if($this->input->post("serverip"))
		{
		   if($this->common_model->availableUrl($this->input->post("serverip"))!=1){ 
		   	$data_to_store= array(
			   		"ConnectionStatus" => 0,
			   		"LastConnectionCheck" => date("Y-m-d H:i:s")
		   		);
		   		$this->common_model->update_details("ID", $this->input->get("ID"), $data_to_store, "tblserveripdivisionwise");
			  echo 0;

		   }
		   else{
			   	$data_to_store= array(
			   		"ConnectionStatus" => 1,
			   		"LastConnectionCheck" => date("Y-m-d H:i:s")
		   		);
		   		$this->common_model->update_details("ID", $this->input->get("ID"), $data_to_store, "tblserveripdivisionwise");
			   echo "1";
		   }
		}
		else{
			echo 0;
		}
	}
	private function removeversionfile(){
		if ($this->input->post("VendorID")) {
            if ($this->input->post("VendorID") != "") 
			{
            	$vendorID = $this->input->post("VendorID");
				$versionid = $this->input->post("versionfileid");
				$this->common_model->delete_cond_details("FileID = '".$versionid."'","tblversionfilenames");
				$this->session->set_flashdata("success_done", "Deleted SuccessFully");
				echo "1";
			} 
			else 
			{
				echo "0";
			}
		}
	//	redirect(site_url()."Admin/version-file-names");
	}
	
	private function getVendorConditions(){
		$response = "";
		if ($this->input->post("VendorID")) {
            if ($this->input->post("VendorID") != "") {
            	$vendorID = $this->input->post("VendorID");
				$vfnames = $this->common_model->find_details("VendorID = '".$vendorID."'","tblversionfilenames","FileName, FileType, MinCount, MaxCount");
				foreach($vfnames as $vfname){
					$response .= "<tr><td>".$vfname['FileName']."</td>";
					$ftype = "Folder";
					if($vfname['FileType'] != '-1'){
						$ftype = $vfname['FileType'];
					}
					$response .= "<td>".$ftype."</td>";
					$response .= "<td>".$vfname['MinCount']."</td>";
					$response .= "<td>".$vfname['MaxCount']."</td></tr>";
				}
			}
		}
		echo $response;
	}
	
	private function getVendorFileNames(){
		$response = "";
		if ($this->input->post("VendorID")) {
            if ($this->input->post("VendorID") != "") {
            	$vendorID = $this->input->post("VendorID");
                $cond = array("RecordStatus" => "1", "VendorID" => $this->input->post("VendorID"));
                $vfilenames = $this->common_model->find_details($cond, "tblversionfilenames", "FileID,FileName, FileType, MinCount, MaxCount, FolderName, VendorID, VersionFileNamesID");
				$filetypes = $this->common_model->find_details("","tbl_version_file_types","id, file_type, type_value");
				foreach($vfilenames as $vfilename){
					$response .= "<tr>
                        <td> <input class='form-control ParameterName' name='VersionFileNamesID[]' type='hidden' value='".$vfilename['VersionFileNamesID']."'></td>
<td> <input class='form-control ParameterName' name='FileNameOld[]' type='text' maxlength='40' value='".$vfilename['FileName']."' onchange='warn_message(this.value, 1);'></td>
<td>
<select class='form-control' data-show-subtext='true' data-live-search='true' name='FileTypeOld[]'>";
foreach($filetypes as $ft){
	$selected = "";
	if(strtolower($vfilename['FileType']) == strtolower($ft['type_value'])){
		$selected = "selected";
	}
	$response .="<option value='".$ft['type_value']."' ".$selected.">".$ft['file_type']."</option>";
}
$response .="</select></td>
<td> <input type='hidden' class='form-control actualval' value='".$vfilename['MinCount']."' >
<input type='number' class='form-control ParameterName presentval' name='MinCountOld[]'  value='".$vfilename['MinCount']."'></td>
<td> <input type='hidden' class='form-control actualvalue' value='".$vfilename['MaxCount']."' >
<input type='number' class='form-control ParameterName presentvalue' name='MaxCountOld[]' value='".$vfilename['MaxCount']."'></td>
<td>
<button type='button' onclick='remove_version_file(".$vfilename['FileID'].",".$vendorID.",this)' class='btn btn-warning'>Delete</button>



<form method='post' action='".site_url()."Admin/AjaxForm/removeversionfile'><input name='VendorID' value='".$vendorID."' type='hidden'><input name='versionfileid' type='hidden' value='".$vfilename['FileID']."' /></form></td>
</tr>";
				}
			}
		}
		echo $response;
	}

	private function getVendorFields() {
		$vendor_id = $this -> input -> post("VendorID");
		$fields = $this -> common_model -> find_details("RecordStatus = 1 and VendorID = '" . $vendor_id . "'", "tbl_versionfields_vendor_map", "VendorID, field_id, is_visible, is_mandatory");
		$data = array();
		foreach ($fields as $field) {
			$f = $this -> common_model -> find_details("RecordStatus = 1 and VersionFieldsMasterID = '" . $field['field_id'] . "'", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, is_autofield", "", "", "1");
			if(count($f) > 0){
			$d = array("fname" => $f[0]["field_name"], "is_autofield" => $f[0]["is_autofield"], "is_visible" => $field["is_visible"], "is_mandatory" => $field["is_mandatory"]);
			array_push($data, $d);
			}
		}
		echo json_encode($data, true);
	}

	private function VendorChgFIELDS() {
		$response = "";
		$vendor_id = $this -> input -> post("VendorID");
		if ($vendor_id != "") {
			$rfields = $this -> common_model -> find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield");

			foreach ($rfields as $field) {

				//Check Field With Vendor
				$is_visible = "";
				$is_mandatory = "";

				$vfield = $this -> common_model -> find_details("VendorID = '" . $vendor_id . "' and field_id = '" . $field["VersionFieldsMasterID"] . "'", "tbl_versionfields_vendor_map", "VendorID,field_id,is_visible,is_mandatory");
				foreach ($vfield as $v) {
					if ($v["is_visible"] == 1) {
						$is_visible = "checked";
					}
					if ($v["is_mandatory"] == 1) {
						$is_mandatory = "checked";
					}
				}

				$response .= "<tr><td></td>";
				$response .= "<td>" . $field["field_display_name"] . "</td>";
				$response .= "<td><div class='checkbox'><input " . $is_visible . " class='form-control minimal' onchange='visibleCheck(" . $field["VersionFieldsMasterID"] . ")' name='field_visible_" . $field["VersionFieldsMasterID"] . "' id='field_visible_" . $field["VersionFieldsMasterID"] . "' type='checkbox' value='1'></div></td>";
				$response .= "<td><div class='checkbox'><input " . $is_mandatory . " class='form-control' onchange='mandatoryCheck(" . $field["VersionFieldsMasterID"] . ")' name='field_mandatory_" . $field["VersionFieldsMasterID"] . "' id='field_mandatory_" . $field["VersionFieldsMasterID"] . "' type='checkbox' value='1'></div></td>";
				$response .= "<td></td></tr>";
			}
		}
		echo $response;
	}

	private function SoftwarefileUpload() {
	    ini_set('max_execution_time', 3000);
		$vendorID = $this -> input -> post("VendorID");
		$filename = $this -> input -> post("ApplicationFile");
		$foldername = substr($filename, 0, -4);
		$zip = new ZipArchive();
		$zip -> open("uploads/files/" . $filename);
		//Get All Data
		$senddata = array(
			"FilePath" => $filename,
			"valid" => false,
			"other" => array()
		);
		
		
		$data = array();
		$vnames = $this -> common_model -> find_details("VendorID = '" . $vendorID . "'", "tblversionfilenames", "VendorID, FileName, FileType, MinCount, MaxCount");
		
		
		foreach ($vnames as $vname) {
			$a = array("starting_name" => $vname["FileName"], "FileType" => $vname["FileType"], "is_valid" => false,"other" => "","valid_count" => 0,"min"=>$vname["MinCount"],"max" => $vname["MaxCount"],"f_filetype" => "","f_name" => "", "f" => array());
			$count = 0;
		
		for ($i = 0; $i < $zip -> numFiles; $i++) {
			$fileInfo = $zip -> statIndex($i);
			//$zip -> extractTo("uploads/files/" . $foldername);
			
			//New COde to Read
			$file = $fileInfo["name"];
			$type = "File";
			$extention = "";
		    $a["f_name"] = $file;
			
			if(substr($fileInfo["name"],-1) === "/"){ $type = "Folder";
					$type = "Folder";
					$a["f_filetype"] = "Folder";
					$name = strtolower(basename($file));
					if ($vname["FileType"] == "-1") {
					    if($vname["FileName"] === "*"){
							$a["is_valid"] = true;
							$count++;
						}else{
						if (strpos($name, strtolower($vname["FileName"])) === 0) {
							$a["is_valid"] = true;
							$count++;
						}
						}
					}
				}else {
					$filename = strtolower(basename($file));
					$ext = strlen($vname["FileType"]);
					$filenameitems = explode(".", $filename);
					//$extention = substr($filename, -$ext);
					$extention = $filenameitems[count($filenameitems) - 1];
					$a["f_filetype"] = $extention;
					if($extention == "docx"){
						$extention = "doc";
					}
					if($extention == "xlsx"){
						$extention = "xls";
					}
					if($extention == "pptx"){
						$extention = "ppt";
					}
					if(strtolower($vname["FileType"]) === strtolower($extention)){
						if($vname["FileName"] === "*"){
							$a["is_valid"] = true;
							$count++;
						}else{
						if (strpos($filename, strtolower($vname["FileName"])) === 0) {
							$a["is_valid"] = true;
							$count++;
						}
						}
					}
				}
				$file_arr = array(
					"path" => $file,
					"type" =>  $type,
					"count" => $count,
					"ext" => $extention
				);
				array_push($a["f"],$file_arr);
			}
			$a["valid_count"] = $count;
			array_push($data, $a);
		}
		$valid = "false";
		foreach($data as $d){
			if($d["max"] == 0 && $d["min"] != 0){
					if($d["valid_count"] >= $d["min"]){
						$valid = true;
					}else{ $valid = false; break; }
				
			}else if($d["min"]==0 && $d["max"] != 0){
				if($d["valid_count"] <= $d["max"]){
					$valid = true;
				}else{ $valid = false; break; }
			}else{
				if($d["valid_count"] >= $d["min"] && $d["valid_count"] <= $d["max"]){
				$valid = "true";
			}else{
				$valid = "false";
				break;
			}
			}
			
		}
		
		$senddata["other"] = $data;
		
		$senddata["valid"] = $valid;
	
		echo json_encode($senddata);
	
/*
		$valid = false;
		$source = "uploads/files/" . $foldername;
		$source = realpath($source);
		$iterator = new RecursiveDirectoryIterator($source);
		$iterator -> setFlags(RecursiveDirectoryIterator::SKIP_DOTS);
		$files = new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::SELF_FIRST);
		
		$data = array();
		$vnames = $this -> common_model -> find_details("VendorID = '" . $vendorID . "'", "tblversionfilenames", "VendorID, FileName, FileType, MinCount, MaxCount");
		
		foreach ($vnames as $vname) {
			$a = array("starting_name" => $vname["FileName"], "FileType" => $vname["FileType"], "is_valid" => false,"other" => "","valid_count" => 0,"min"=>$vname["MinCount"],"max" => $vname["MaxCount"],"f_filetype" => "","f_name" => "", "f" => array());
			$count = 0;
			foreach ($files as $file) {
				
				//Min Check Break
				if($count >= $vname["MinCount"]){
				    break;
				}
				
				$file = realpath($file);
				$type = "File";
				$extention = "";
				$a["f_name"] = $file;
				if(is_dir($file)){
					$type = "Folder";
					$a["f_filetype"] = "Folder";
					$name = strtolower(basename($file));
					if ($vname["FileType"] == "-1") {
					    if($vname["FileName"] === "*"){
							$a["is_valid"] = true;
							$count++;
						}else{
						if (strpos($name, strtolower($vname["FileName"])) === 0) {
							$a["is_valid"] = true;
							$count++;
						}
						}
					}
				}else {
					$filename = strtolower(basename($file));
					$ext = strlen($vname["FileType"]);
					$filenameitems = explode(".", $filename);
					//$extention = substr($filename, -$ext);
					$extention = $filenameitems[count($filenameitems) - 1];
					$a["f_filetype"] = $extention;
					if($extention == "docx"){
						$extention = "doc";
					}
					if($extention == "xlsx"){
						$extention = "xls";
					}
					if($extention == "pptx"){
						$extention = "ppt";
					}
					if(strtolower($vname["FileType"]) === strtolower($extention)){
						if($vname["FileName"] === "*"){
							$a["is_valid"] = true;
							$count++;
						}else{
						if (strpos($filename, strtolower($vname["FileName"])) === 0) {
							$a["is_valid"] = true;
							$count++;
						}
						}
					}
				}
				$file_arr = array(
					"path" => $file,
					"type" =>  $type,
					"count" => $count,
					"ext" => $extention
				);
				array_push($a["f"],$file_arr);
			}
			$a["valid_count"] = $count;
			array_push($data, $a);
		}
		$valid = "false";
		foreach($data as $d){
			if($d["max"] == 0 && $d["min"] != 0){
					if($d["valid_count"] >= $d["min"]){
						$valid = true;
					}else{ $valid = false; break; }
				
			}else if($d["min"]==0 && $d["max"] != 0){
				if($d["valid_count"] <= $d["max"]){
					$valid = true;
				}else{ $valid = false; break; }
			}else{
				if($d["valid_count"] >= $d["min"] && $d["valid_count"] <= $d["max"]){
				$valid = "true";
			}else{
				$valid = "false";
				break;
			}
			}
			
		}
		
		$senddata["other"] = $data;
		
		$senddata["valid"] = $valid;
		
		echo json_encode($senddata);*/

	}

}
