<?php $this->load->view('Admin/header'); ?>
<?php $this->load->view('Admin/sidebar'); $menusetting = $this->common_model->getMenuSettings(3); ?>
<section id="main-content">
    <section class="wrapper">
        <div class="row">
            <div class="col-xs-12">
                <!--user info table start-->
               
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Server IP Details</h3>
                    </div>
                    <div class="panel-body">
                        <p class="notes"><i class="fa fa-lightbulb-o" aria-hidden="true"></i>Note: *Level <?php echo $menusetting["LevelNo"]; ?> security code is required for IP Settings.</p>
                         <span id="error" style="color: red;font-size: 20px"></span>
                        <form class="form-horizontal" method="post"   id="ip_form"  role="form">
                        	<h3 id="message_val" style="display: <?php echo $display_value; ?>;background:<?php echo $color_code; ?>;">
                                <?php echo $message; ?>
                                <i class="fa fa-close" style="" onclick="close_header()"></i>
                            </h3>
                        	<?php
                        	$serverips = $this->common_model->getbyCondition("tblserveripdetails", "", "", "ServerID", "asc");
							foreach($serverips as $serverip){
								?>
								<div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label"><?php echo $serverip->ServerName; ?></label>
                                <div class="col-lg-4">
									<input name="ServerID[]"  type="hidden" value="<?php echo $serverip->ServerID; ?>">
                                    <input name="ip_detail[]"  type="text" class="form-control ip_detail" placeholder="" value="<?php echo $serverip->ServerIP; ?>">
                                </div>
                            </div>
								<?php
							}
                        	?>
                            
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-lg-4">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                    <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
            
            <div class="col-xs-12">
                <!--user info table start-->
                <section class="panel">
                    <div class="title">
                        <h3 class="pull-left">Other Server IP Details</h3>
                    </div>
                    <div class="panel-body">
                        <form class="form-horizontal" role="form">
                        	<p><i>Notes: THe Connectivity status can be checked for the following servers</i></p>
                            <div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label">Server 1</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control   " id="server1" placeholder="" value="">  
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label">Server 2</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control   " id="server2" placeholder="" value="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label">Server 3</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control  " id="server3" placeholder="" value="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label">Server 4</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control " id="server4" placeholder="" value="">
                                </div>
                            </div>
                            <div class="form-group">
                                <label for="Chennai" class="col-lg-4 col-sm-2 control-label">Server 5</label>
                                <div class="col-lg-4">
                                    <input type="text" class="form-control " id="server5" placeholder="" value="">
                                </div>
                            </div>
                            
                            <div class="form-group">
                                <div class="col-lg-offset-4 col-lg-4">
                                    <button type="submit" class="btn btn-danger">Submit</button>
                                     <a href="<?php echo current_url(); ?>" class="btn btn-warning">Cancel</a>
                                </div>
                            </div>
                        </form>
                    </div>
                </section>
                <!--user info table end-->
            </div>
            
        </div>
    </section>
</section>

<?php $this->load->view('Admin/footer'); ?>

<!-- js placed at the end of the document so the pages load faster -->
<script src="<?php echo $asset_url; ?>js/jquery.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-ui-1.9.2.custom.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery-migrate-1.2.1.min.js"></script>
<script src="<?php echo $asset_url; ?>js/bootstrap.min.js"></script>
<script class="include" type="text/javascript" src="<?php echo $asset_url; ?>js/jquery.dcjqaccordion.2.7.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.scrollTo.min.js"></script>
<script src="<?php echo $asset_url; ?>js/jquery.nicescroll.js" type="text/javascript"></script>
<script type="text/javascript" language="javascript" src="<?php echo $asset_url; ?>assets/advanced-datatable/media/js/jquery.dataTables.js"></script>
<script type="text/javascript" src="<?php echo $asset_url; ?>assets/data-tables/DT_bootstrap.js"></script>
<script src="<?php echo $asset_url; ?>js/respond.min.js" ></script>
<!--right slidebar-->
<script src="<?php echo $asset_url; ?>js/slidebars.min.js"></script>
<!--dynamic table initialization -->
<script src="<?php echo $asset_url; ?>js/dynamic_table_init.js"></script>
<!--common script for all pages-->
<script src="<?php echo $asset_url; ?>js/common-scripts.js"></script>

<script type="text/javascript">
    
    $('#ip_form').find('input').each(function(){
   $(document).on("change",this,function(){
       
       if(!isUnique()){
        $("#error").html("Same ip address repeated");
       }else{
       	$("#error").html("");
       }
        });
});
    
        

         $(document).on("submit","#ip_form",function(event){
       
       if(!isUnique()){
        $("#error").html("enter unique Ip");
        event.preventDefault();
       }
	   else{
		   alert("Admin@01");
	   }
        });

    function isUnique( tableSelector ) {
    // Collect all values in an array
    var values = [] ;
    $(  "input[name*='ip_detail']").each( function(idx,val){ values.push($(val).val().trim()); } );

    // Sort it
    values.sort() ;
    console.log(values);

    // Check whether there are two equal values next to each other
    for( var k = 1; k < values.length; ++k ) {
        if( values[k] == values[k-1] ) return false ;
    }
    return true ;
}

   
</script>

<script src="//cdnjs.cloudflare.com/ajax/libs/jquery-form-validator/2.3.26/jquery.form-validator.min.js"></script>
<script src="<?php echo $asset_url; ?>js/LevelSecurity/level_security.js"></script>
<?php 
$menusetting = $this->common_model->getMenuSettings(3);
$slp = array(
	"setting" => $menusetting
);
$this->load->view('Admin/security_level_password',$slp); ?>
<script>

$(document).ready(function() {
				
				LevelSecurity.securityUrl = '<?=site_url($menusetting["url"])?>';
				LevelSecurity.init(false);
				$.validate({
                    lang: 'en',
                    modules: 'security',
                    onError : function($form) {
                    	console.log($form);
                    },
                    onSuccess : function($form) {
                    	LevelSecurity.showPassword();
                    	if(LevelSecurity.isPasswordOk == false){
                    		return false;
                    	}
                    }});
				
			});

</script>


</body>
</html>