<?php

class UI_Screen extends CI_Controller {

    private $upload_path = "./uploads/files";

    public function __construct() {
        parent::__construct();
        $this->load->library('encryption');
        $this->load->library('pagination');
        $this->load->library('session');
        $this->load->library('email');
        $this->load->library('upload');
        $this->load->helper(array('form', 'url'));
        $this->load->helper('string');
        $this->load->library('form_validation');
        date_default_timezone_set('Asia/Kolkata');
        $nowtime = date('Y-m-d H:i:s', time());
        $interval = 5000;
        if ($this->session->userdata('last_activity') != false) {
            if ($this->session->userdata('last_activity') < time() - $interval) {
                $this->session->unset_userdata('is_logged_in_session');
                $this->session->unset_userdata('last_activity');
            } else {
                $datas['last_activity'] = time();
                $this->session->set_userdata($datas);
            }
        } else {
            redirect(site_url() . 'login');
        }
    }

    public function Profile() {
        if ($this->session->userdata('is_admin') != 1) {
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Permission_Denied";
            $data['employee'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), 'employee');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('first_name', 'Initial', 'required');
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]');
                $this->form_validation->set_rules('re_password', 'Password Confirmation', 'trim|required|matches[password]');
                if ($this->form_validation->run()) {
                    $photos = $data['employee'][0]['photos'];
                    if (!empty($_FILES['photos'])) {
                        $uploadPath = 'uploads/files/';
                        $config['upload_path'] = $uploadPath;
                        $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        $img_name = "";
                        if ($this->upload->do_upload('photos')) {
                            $fileData = $this->upload->data();
                            $photos = $fileData['file_name'];
                        }
                    }
                    $data_to_store = array(
                        'first_name' => $this->input->post('first_name'),
                        'name' => $this->input->post('name'),
                        'photos' => $photos,
                        'password' => $this->encryption->encrypt($this->input->post('password')),
                    );
//if the insert has returned true then we show the flash message
                    $table = "employee";
                    if ($this->common_model->update_details("id", $this->session->userdata('id_session_list'), $data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Profile Updated";
                        header('Refresh:1; url= ' . site_url() . 'Profile/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $data['employee'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), 'employee');
            $this->load->view('Profile', $data);
        } else {
            redirect(site_url("Admin_Profile"));
        }
    }

    public function Admin_Profile() {
        if ($this->session->userdata('is_admin') == 1) {
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Permission_Denied";
            $data['admin'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), 'admin');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('Name', 'Name', 'required');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]');
                $this->form_validation->set_rules('re_password', 'Password Confirmation', 'trim|required|matches[password]');
                if ($this->form_validation->run()) {
                    $photos = $data['admin'][0]['profile_img'];
                    if (!empty($_FILES['photos'])) {
                        $uploadPath = 'uploads/files/';
                        $config['upload_path'] = $uploadPath;
                        $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        $img_name = "";
                        if ($this->upload->do_upload('photos')) {
                            $fileData = $this->upload->data();
                            $photos = $fileData['file_name'];
                        }
                    }
                    $data_to_store = array(
                        'Name' => $this->input->post('Name'),
                        'profile_img' => $photos,
                        'password' => $this->encryption->encrypt($this->input->post('password')),
                    );
//if the insert has returned true then we show the flash message
                    $table = "admin";
                    if ($this->common_model->update_details("id", $this->session->userdata('id_session_list'), $data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Profile Updated";
                        header('Refresh:1; url= ' . site_url() . 'Profile/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $data['admin'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), 'admin');
            $this->load->view('Admin_Profile', $data);
        } else {
            redirect(site_url("Permission_Denied"));
        }
    }

    public function Permission_Denied() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Permission_Denied";
        $this->load->view('Master/Permission_Denied', $data);
    }

    /* Machine_Hall Start */

    public function Machine_Hall() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Machine Hall";
        $data['machine_hall'] = array();
        $table = "machine_hall";
        $field = "";
        $value = "";
        $data['machine_hall'] = $this->common_model->find_details($field, $value, $table);
        $this->load->view('Master/Machine_Hall/View_Machine_Hall', $data);
    }

    public function Export_Machine_Hall() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Machine Hall";
        $data['machine_hall'] = array();
        $table = "machine_hall";
        $id = $this->uri->segment(4);
        if ($id != "") {
            $field = "id";
            $value = $id;
            $data['machine_hall'] = $this->common_model->find_details($field, $value, $table);
        } else {
            $data['machine_hall'] = $this->common_model->find_details("", "", $table);
        }
        $this->load->view('Master/Machine_Hall/View_Export_Machine_Hall', $data);
    }

    public function Add_Machine_Hall() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['this_page'] = "Machine Hall";
        $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $data['machine_hall'] = $this->common_model->find_details("parent", "0", "machine_hall");
        $data['location'] = $this->common_model->find_details("parent", "0", "location");
        $cur_time = $date->format('Y-m-d H:i:s');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('name', 'Name', 'trim|required|is_unique[machine_hall.name]', array(
                'required' => 'Code field  is required.',
                'is_unique' => 'This %s already exists.'
            ));
            $this->form_validation->set_rules('code', 'Code', 'required');
            $this->form_validation->set_rules('parent', 'Belongs To', 'required');
            $this->form_validation->set_rules('address', 'Address', 'required');
            $this->form_validation->set_rules('owner', 'Owner', 'required');

            if ($this->form_validation->run()) {
                if ($this->input->post('parent') == 0) {
                    $levels = 0;
                } else {
                    $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "machine_hall", "levels");
                }
                $levels = $levels + 1;
                $data_to_store = array(
                    'name' => $this->input->post('name'),
                    'code' => $this->input->post('code'),
                    'parent' => $this->input->post('parent'),
                    'address' => $this->input->post('address'),
                    'owner' => $this->input->post('owner'),
                    'remark' => $this->input->post('remark'),
                    'levels' => $levels,
                    'status' => 0,
                    'df' => 0,
                    'created_at' => $cur_time,
                );
//if the insert has returned true then we show the flash message
                $table = "machine_hall";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#57b91b";
                    $data['message'] = "Machine Hall added";
                    header('Refresh:1; url= ' . site_url() . 'Master/Machine_Hall/');
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Some problem occur please try again later";
                }
            } else {
                $data['flash_message'] = FALSE;
                $data['color_code'] = "#c50000";
                $data['message'] = "Validation Error";
            }
        }
        $this->load->view('Master/Machine_Hall/Add_Machine_Hall', $data);
    }

    public function Update_Machine_Hall() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $table = "machine_hall";
        $field = "id";
        $value = $this->uri->segment(4);
        $data['this_page'] = "Machine Hall";
        $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $cur_time = $date->format('Y-m-d H:i:s');
        $data['machine_hall_arr'] = $this->common_model->find_details("parent", "0", "machine_hall");
        $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
        $data['machine_hall'] = $this->common_model->find_details($field, $value, $table);
        if (count($data['machine_hall']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {

                $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'machine_hall', 'name');
                if ($data['machine_hall'][0]['name'] != $this->input->post('name')) {
                    if ($this->input->post('name') === $original_value1) {
                        $is_unique1 = '|is_unique[machine_hall.name]';
                    } else {
                        $is_unique1 = '';
                    }
                } else {
                    $is_unique1 = '';
                }
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('name', 'Name', 'trim|required' . $is_unique1, array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('code', 'Code', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                $this->form_validation->set_rules('address', 'Address', 'required');
                $this->form_validation->set_rules('owner', 'Owner', 'required');


                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "machine_hall", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'parent' => $this->input->post('parent'),
                        'address' => $this->input->post('address'),
                        'owner' => $this->input->post('owner'),
                        'levels' => $levels,
                        'remark' => $this->input->post('remark'),
                    );
                    $table = "machine_hall";
                    if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                        $data['machine_hall'] = $this->common_model->find_details($field, $value, $table);
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Machine_Hall Updated";
                        header('Refresh:1; url= ' . site_url() . 'Master/Machine_Hall/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
        } else {
            redirect(site_url());
        }
        $this->load->view('Master/Machine_Hall/Update_Machine_Hall', $data);
    }

    public function View_Single_Machine_Hall() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $table = "machine_hall";
        $field = "id";
        $value = $this->uri->segment(4);
        $data['main_id'] = $value;
        $data['this_page'] = "Machine Hall";
        $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $cur_time = $date->format('Y-m-d H:i:s');
        $data['machine_hall_arr'] = $this->common_model->find_details("parent", "0", "machine_hall");
        $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
        $data['machine_hall'] = $this->common_model->find_details($field, $value, $table);
        $this->load->view('Master/Machine_Hall/View_Single_Machine_Hall', $data);
    }

    public function Delete_Machine_Hall() {
        $field = "id";
        $value = $this->input->post('id');
        $table = "machine_hall";
        $data['this_page'] = "Machine Hall";
        $this->common_model->delete_details($field, $value, $table);
    }

    /* Machine_Hall End */


    /* Customer Start */

    public function Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer";
            $data['customer'] = array();
            $table = "customer";
            $field = "";
            $value = "";
            $data['customer'] = $this->common_model->find_customer_details();
            $this->load->view('Master/Customer/View_Customer', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer";
            $data['customer'] = array();
            $table = "customer";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $data['customer'] = $this->common_model->find_customer_details("customer.id = " . $id);
            } else {
                $data['customer'] = $this->common_model->find_customer_details("", "", $table);
            }
            $this->load->view('Master/Customer/View_Export_Customer', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['state'] = "";
            $data['city'] = "";
            $data['this_page'] = "Customer";
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['user_type'] = $this->common_model->find_details("", "", "user_type");
            $data['country'] = $this->common_model->find_all_details("", "country", "*", "name asc");
            $data['customer'] = $this->common_model->find_details("", "", "customer");
            $data['customer_category'] = $this->common_model->find_details("parent", "0", "customer_category");
            $data['customer_reporting_group'] = $this->common_model->find_details("parent", "0", "customer_reporting_group");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Customer Id', 'trim|required|is_unique[customer.code]', array(
                    'required' => 'Customer id is required',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Customer Name', 'required');
                $this->form_validation->set_rules('address', 'Address', 'required');
                $this->form_validation->set_rules('country', 'State', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('contacts', 'Contacts', 'required');
                $this->form_validation->set_rules('gst_details', 'GST_Details', 'required');
                $this->form_validation->set_rules('customer_category', 'Customer Category', 'required');
                $this->form_validation->set_rules('customer_reporting_group', 'Customer Reporting Group', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('bill_to_customer') != "") {
                        $bill_to_customer = $this->input->post('bill_to_customer');
                    } else {
                        $bill_to_customer = "";
                    }
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'Code' => $this->input->post('code'),
                        'address' => $this->input->post('address'),
                        'city' => $this->input->post('city'),
                        'state' => $this->input->post('state'),
                        'country' => $this->input->post('country'),
                        'location' => $this->input->post('location'),
                        'contacts' => $this->input->post('contacts'),
                        'gst_details' => $this->input->post('gst_details'),
                        'user_type' => $this->input->post('user_type'),
                        'customer_category' => $this->input->post('customer_category'),
                        'customer_reporting_group' => $this->input->post('customer_reporting_group'),
                        'bill_to_customer' => $bill_to_customer,
                        'created_on' => date('Y-m-d'),
                        'created_by' => "",
                    );
//if the insert has returned true then we show the flash message
                    $table = "customer";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Customer added";
                        $data['state'] = $this->input->post('state');
                        $data['city'] = $this->input->post('city');
                        $data['state_arr'] = $this->common_model->find_details("country_id", $this->input->post('country'), "state");
                        $data['city_arr'] = $this->common_model->find_details("state_id", $this->input->post('state'), "city");
                        header('Refresh:1; url= ' . site_url() . 'Master/Customer/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Customer/Add_Customer', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Customer";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['customer'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['customer']) > 0) {
                $data['customer_arr'] = $this->common_model->find_details("", "", "customer");
                $data['user_type'] = $this->common_model->find_details("", "", "user_type");
                $data['country'] = $this->common_model->find_details("", "", "country");
                $data['state'] = $data['customer'][0]['state'];
                $data['city'] = $data['customer'][0]['city'];
                $data['state_arr'] = $this->common_model->find_details("country_id", $data['customer'][0]['country'], "state");
                $data['city_arr'] = $this->common_model->find_details("state_id", $data['customer'][0]['state'], "city");
                $data['location'] = $this->common_model->find_details("", "", "location");
                $data['customer_category'] = $this->common_model->find_details("", "", "customer_category");
                $data['customer_reporting_group'] = $this->common_model->find_details("", "", "customer_reporting_group");
                if (count($data['customer']) > 0) {
                    if ($this->input->server('REQUEST_METHOD') === 'POST') {
                        $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'customer', 'code');
                        if ($data['customer'][0]['code'] != $this->input->post('code')) {
                            if ($this->input->post('code') === $original_value1) {
                                $is_unique1 = '|is_unique[customer.code]';
                            } else {
                                $is_unique1 = '';
                            }
                        } else {
                            $is_unique1 = '';
                        }
                        $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                        $this->form_validation->set_rules('name', 'Name', 'trim|required' . $is_unique1, array(
                            'required' => 'Code field  is required.',
                            'is_unique' => $error_msg
                        ));
                        $this->form_validation->set_rules('code', 'Code', 'required');
                        $this->form_validation->set_rules('address', 'Address', 'required');
                        $this->form_validation->set_rules('city', 'City', 'required');
                        $this->form_validation->set_rules('state', 'State', 'required');
                        $this->form_validation->set_rules('location', 'Location', 'required');
                        $this->form_validation->set_rules('contacts', 'Contacts', 'required');
                        $this->form_validation->set_rules('gst_details', 'GST_Details', 'required');
                        $this->form_validation->set_rules('customer_category', 'Customer Category', 'required');
                        $this->form_validation->set_rules('customer_reporting_group', 'Customer Reporting Group', 'required');
                        if ($this->form_validation->run()) {
                            if ($this->input->post('bill_to_customer') != "") {
                                $bill_to_customer = $this->input->post('bill_to_customer');
                            } else {
                                $bill_to_customer = "";
                            }

                            $data_to_store = array(
                                'name' => $this->input->post('name'),
                                'Code' => $this->input->post('code'),
                                'address' => $this->input->post('address'),
                                'city' => $this->input->post('city'),
                                'state' => $this->input->post('state'),
                                'country' => $this->input->post('country'),
                                'location' => $this->input->post('location'),
                                'contacts' => $this->input->post('contacts'),
                                'gst_details' => $this->input->post('gst_details'),
                                'user_type' => $this->input->post('user_type'),
                                'customer_category' => $this->input->post('customer_category'),
                                'customer_reporting_group' => $this->input->post('customer_reporting_group'),
                                    //'bill_to_customer' => $bill_to_customer,
                            );
                            $table = "customer";
                            if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                                $data['customer'] = $this->common_model->find_details($field, $value, $table);
                                $data['flash_message'] = TRUE;
                                $data['color_code'] = "#57b91b";
                                $data['message'] = "Customer added";
                                header('Refresh:1; url= ' . site_url() . 'Master/Customer/');
                            } else {
                                $data['flash_message'] = FALSE;
                                $data['color_code'] = "#c50000";
                                $data['message'] = "Some problem occur please try again later";
                            }
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Validation Error";
                        }
                    }
                } else {
                    redirect(site_url());
                }
                $this->load->view('Master/Customer/Update_Customer', $data);
            }
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Customer";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['customer'] = $this->common_model->find_customer_details("customer.id = " . $value);
            $this->load->view('Master/Customer/View_Single_Customer', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Customer() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "customer";
            $data['this_page'] = "Customer";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function select_State() {
        $state_id = $this->input->post('state_id');
        $country_id = $this->input->post('country_id');
        $data['this_page'] = "Customer";
        $option = "";
        if ($country_id != "") {
            $cond = array(
                "country_id" => $country_id
            );
            $data['state'] = $this->common_model->find_all_details($cond, "state", "*", "name asc");
        }
        if ($state_id != "") {
            $cond = array(
                "state_id" => $state_id
            );
            $data['city'] = $this->common_model->find_all_details($cond, "city", "*", "name asc");
        }
        $this->load->view('Master/Ajax/View_State_City', $data);
    }

    public function select_State_Update() {
        $state = $this->input->post('state');
        $country_id = $this->input->post('country_id');
        $data['this_page'] = "Customer";
        $option = "";
        if ($country_id != "") {
            $data['state'] = $this->common_model->find_details("country_id", $country_id, "state");
            foreach ($data['state'] as $val1) {
                $name = $val1['name'];
                $value = $val1['id'];
                $select = "";
                if ($val1['id'] == $state) {
                    $select = "Selected";
                }
                $option .= "<option value='$value'  $select >$name-$state</option>";
            }
            print_r($option);
            exit;
        }
        if ($state_id != "") {
            $data['city'] = $this->common_model->find_details("state_id", $state_id, "city");
            foreach ($data['city'] as $val1) {
                $name = $val1['name'];
                $value = $val1['id'];
                $option .= "<option value='$value' set_select('city',$value,False) >$name</option>";
            }
            print_r($option);
            exit;
        }
    }

    public function select_City() {
        $field = "id";
        $value = $this->input->post('id');
        $data['this_page'] = "Customer";
        $data['city'] = $this->common_model->find_details("state_id", $value, "city");
        $option = "";
        foreach ($data['city'] as $val1) {
            $name = $val1['name'];
            $value = $val1['id'];
            $option .= "<option value='$value'>$name</option>";
        }
        print_r($option);
    }

    /* Customer End */
    /* Item Start */

    public function Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item";
            $data['item'] = array();
            $table = "item";
            $field = "";
            $value = "";
            $data['item'] = $this->common_model->find_item_details();

            $this->load->view('Master/Item/View_Item', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item";
            $data['item'] = array();
            $table = "item";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $data['item'] = $this->common_model->find_item_details("item.id = " . $id);
            } else {
                $data['item'] = $this->common_model->find_item_details("", "", $table);
            }
            $this->load->view('Master/Item/View_Export_Item', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Item";
            $data['item'] = $this->common_model->find_details("parent", "0", "item");
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['uom'] = $this->common_model->find_details("", "", "uom");
            $data['customer'] = $this->common_model->find_details("", "", "customer");
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {

                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Item Code', 'trim|required|is_unique[item.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', ' Name', 'required');
                $this->form_validation->set_rules('uom', 'Unit Of Measurement', 'required');
                $this->form_validation->set_rules('parent', 'belongs_to', 'required');
                $this->form_validation->set_rules('item_group', 'Item Group', 'required');
                $this->form_validation->set_rules('item_category', 'Item Category', 'required');
                $this->form_validation->set_rules('gst_applicable', 'Gst Applicable', 'required');
                $this->form_validation->set_rules('item_type', 'Item Type', 'required');
                $this->form_validation->set_rules('customer[]', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('hsn_code[]', '<b>HSN Code</b>', 'required');
                $this->form_validation->set_rules('part_no[]', '<b>Part No</b>', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item", "levels");
                    }
                    $levels = $levels + 1;

                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'uom' => $this->input->post('uom'),
                        'description' => $this->input->post('description'),
                        'parent' => $this->input->post('parent'),
                        'cost_details' => $this->input->post('cost_details'),
                        'item_group' => $this->input->post('item_group'),
                        'item_category' => $this->input->post('item_category'),
                        'gst_applicable' => $this->input->post('gst_applicable'),
                        'item_type' => $this->input->post('item_type'),
                        'levels' => $levels,
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );

//if the insert has returned true then we show the flash message
                    $table = "item";
                    $last_insert_id = $this->common_model->store_details($data_to_store, $table);
                    $user_inp = $this->input->post();

                    if (isset($user_inp['part_no']) && !empty($user_inp['part_no'])) {
                        $i = 0;
                        foreach ($user_inp['part_no'] as $val => $key) {
                            $_FILES['files']['name'] = $_FILES['file']['name'][$val];
                            $_FILES['files']['type'] = $_FILES['file']['type'][$val];
                            $_FILES['files']['tmp_name'] = $_FILES['file']['tmp_name'][$val];
                            $_FILES['files']['error'] = $_FILES['file']['error'][$val];
                            $_FILES['files']['size'] = $_FILES['file']['size'][$val];
                            $uploadPath = 'uploads/files/';
                            $config['upload_path'] = $uploadPath;
                            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            $img_name = "";
                            if ($this->upload->do_upload('files')) {
                                $fileData = $this->upload->data();
                                $img_name = $fileData['file_name'];
                            }
                            $data_to_store = array(
                                'item_id' => $last_insert_id,
                                'name' => $user_inp['customer'][$val],
                                'hsn_code' => $user_inp['hsn_code'][$val],
                                "img_name" => $img_name,
                                "part_no" => $user_inp['part_no'][$val],
                                'status' => 0,
                                'df' => 0,
                                'created_at' => $cur_time,
                            );

                            $this->common_model->store_details($data_to_store, "item_customer_details");
                            $i++;
                        }
                    }
                    if ($last_insert_id) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Item added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Item/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }

            $this->load->view('Master/Item/Add_Item', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Item";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item'] = $this->common_model->item_details("item.id = " . $value);
            $data['item_arr'] = $this->common_model->find_details("parent", "0", "item");
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['uom'] = $this->common_model->find_details("", "", "uom");
            $data['customer'] = $this->common_model->find_details("", "", "customer");
            if (count($data['item']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'item', 'code');
                    if ($data['item'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[item.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Name', 'required');
                    $this->form_validation->set_rules('uom', 'Unit Of Measurement', 'required');
                    //$this->form_validation->set_rules('parent', 'belongs_to', 'required');
                    $this->form_validation->set_rules('item_group', 'Product Group', 'required');
                    $this->form_validation->set_rules('item_category', 'Item Category', 'required');
                    $this->form_validation->set_rules('gst_applicable', 'Gst Applicable', 'required');
                    $this->form_validation->set_rules('item_type', 'Item Type', 'required');
                    if ($this->form_validation->run()) {

                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'uom' => $this->input->post('uom'),
                            //'parent' => $this->input->post('parent'),
                            'tax_details' => $this->input->post('tax_details'),
                            'cost_details' => $this->input->post('cost_details'),
                            'gst_applicable' => $this->input->post('gst_applicable'),
                            'item_type' => $this->input->post('item_type'),
                            'item_group' => $this->input->post('item_group'),
                            'item_category' => $this->input->post('item_category'),
                                //'levels' => $levels,
                        );
                        $table = "item";
                        $update_data = $this->common_model->update_details($field, $value, $data_to_store, $table);
                        $user_inp = $this->input->post();
                        /* Insert Customer details */
                        if (isset($user_inp['customer']) && !empty($user_inp['customer'])) {
                            $i = 0;
                            foreach ($user_inp['customer'] as $val => $key) {
                                $img_name = "";
                                if (isset($_FILES['file']['name'][$val])) {
                                    $_FILES['files']['name'] = $_FILES['file']['name'][$val];
                                    $_FILES['files']['type'] = $_FILES['file']['type'][$val];
                                    $_FILES['files']['tmp_name'] = $_FILES['file']['tmp_name'][$val];
                                    $_FILES['files']['error'] = $_FILES['file']['error'][$val];
                                    $_FILES['files']['size'] = $_FILES['file']['size'][$val];
                                    $uploadPath = 'uploads/files/';
                                    $config['upload_path'] = $uploadPath;
                                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                                    $this->load->library('upload', $config);
                                    $this->upload->initialize($config);
                                    $img_name = "";
                                    if ($this->upload->do_upload('files')) {
                                        $fileData = $this->upload->data();
                                        $img_name = $fileData['file_name'];
                                    }
                                }
                                $data_to_store = array(
                                    'item_id' => $data['item'][0]['id'],
                                    'name' => $user_inp['customer'][$val],
                                    'hsn_code' => $user_inp['hsn_code'][$val],
                                    "img_name" => $img_name,
                                    "part_no" => $user_inp['part_no'][$val],
                                    'status' => 0,
                                    'df' => 0,
                                    'created_at' => $cur_time,
                                );
                                $this->common_model->store_details($data_to_store, "item_customer_details");
                                $i++;
                            }
                        }
                        /* Update Customer Details */
                        if (isset($user_inp['old_customer']) && !empty($user_inp['old_customer'])) {
                            $i = 0;
                            foreach ($user_inp['old_customer'] as $val => $key) {
                                $img_name = $user_inp['old_img_name'][$val];
                                if (isset($_FILES['old_file'])) {
                                    $_FILES['files']['name'] = $_FILES['old_file']['name'][$val];
                                    $_FILES['files']['type'] = $_FILES['old_file']['type'][$val];
                                    $_FILES['files']['tmp_name'] = $_FILES['old_file']['tmp_name'][$val];
                                    $_FILES['files']['error'] = $_FILES['old_file']['error'][$val];
                                    $_FILES['files']['size'] = $_FILES['old_file']['size'][$val];
                                    $uploadPath = 'uploads/files/';
                                    $config['upload_path'] = $uploadPath;
                                    $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                                    $this->load->library('upload', $config);
                                    $this->upload->initialize($config);
                                    if ($this->upload->do_upload('files')) {
                                        $fileData = $this->upload->data();
                                        $img_name = $fileData['file_name'];
                                    }
                                }
                                $value = $user_inp['old_item_id'][$val];
                                $data_to_store = array(
                                    'name' => $user_inp['old_customer'][$val],
                                    'part_no' => $user_inp['old_part_no'][$val],
                                    'img_name' => $img_name,
                                    'hsn_code' => $user_inp['old_hsn_code'][$val],
                                );
                                $update_data = $this->common_model->update_details("id", $value, $data_to_store, "item_customer_details");
                                $i++;
                            }
                        }
                        if ($update_data) {
                            $field = "id";
                            $value = $this->uri->segment(4);
                            $data['item'] = $this->common_model->item_details("item.id = " . $value);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Item added";
                            header('Refresh:1; url= ' . site_url() . 'Master/Item/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Item/Update_Item', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Item";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item'] = $this->common_model->find_item_details("item.id = " . $value);
            $this->load->view('Master/Item/View_Single_Item', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Item() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "item";
            $data['this_page'] = "Item";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Item_Customer_Details() {
        $field = "id";
        $value = $this->input->post('item_customer_det_id');
        $table = "item_customer_details";
        $data['this_page'] = "Item";
        $this->common_model->delete_details($field, $value, $table);
        echo "1";
    }

    /* Item End */

    /* Product_Mapping Start */

    public function Product_Mapping() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Product_Mapping";
        $data['product_mapping'] = array();
        $this->load->view('Master/Product_Mapping/View_Product_Mapping', $data);
    }

    public function Add_Product_Mapping() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['this_page'] = "Product_Mapping";
        $data['this_page'] = "Product_Mapping";
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('price', 'Price', 'required');
            $this->form_validation->set_rules('category', 'Category', 'required');
            $this->form_validation->set_rules('mrp', 'MRP', 'required');
            $this->form_validation->set_rules('hsn_code', 'HSN Code', 'required');
            $this->form_validation->set_rules('gst_percentage', 'GST Percentage', 'required');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'category' => $this->input->post('category'),
                    'model_no' => $this->input->post('model_no'),
                    'hsn_code' => $this->input->post('hsn_code'),
                    'gst_percentage' => $this->input->post('gst_percentage'),
                    'price' => $this->input->post('price'),
                    'mrp' => $this->input->post('mrp'),
                    'description' => $this->input->post('description'),
                );
//if the insert has returned true then we show the flash message
                $table = "product_mapping";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#57b91b";
                    $data['message'] = "Product Mapping added";
                    header('Refresh:1; url= ' . site_url() . 'Admin/Product_Mapping/');
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Some problem occur please try again later";
                }
            } else {
                $data['flash_message'] = FALSE;
                $data['color_code'] = "#c50000";
                $data['message'] = "Validation Error";
            }
        }
        $this->load->view('Master/Product_Mapping/Add_Product_Mapping', $data);
    }

    /* Product_Mapping End */

    /* Item_Group Start */

    public function Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item Group";
            $data['item_group'] = array();
            $table = "item_group";
            $field = "";
            $value = "";
            $data['item_group'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Item_Group/View_Item_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item Group";
            $data['item_group'] = array();
            $table = "item_group";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['item_group'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['item_group'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Item_Group/View_Export_Item_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Item Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $data['item_group'] = $this->common_model->find_details("parent", "0", "item_group");
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {

                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[item_group.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Item Group Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item_group", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'parent' => $this->input->post('parent'),
                        'remark' => $this->input->post('remark'),
                        'levels' => $levels,
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "item_group";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Item Group added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Item_Group/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Item_Group/Add_Item_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Item Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['item_group'] = $this->common_model->find_details($field, $value, $table);
            $data['item_group_arr'] = $this->common_model->find_details("parent", "0", "item_group");
            if (count($data['item_group']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'item_group', 'code');
//  print_r($original_value1);exit;
                    if ($data['item_group'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[item_group.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Item Group Name', 'required');
                    // $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                    if ($this->form_validation->run()) {
                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item_group", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                                // 'parent' => $this->input->post('parent'),
                                //'levels' => $levels,
                        );
                        $table = "item_group";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['item_group'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Item Group Updated Sucessfully";
                            header('Refresh:1; url= ' . site_url() . 'Master/Item_Group/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Item_Group/Update_Item_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Item Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details($field, $value, $table);
            $data['item_group_arr'] = $this->common_model->find_details("parent", "0", "item_group");
            $this->load->view('Master/Item_Group/View_Single_Item_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Item_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_group_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "item_group";
            $data['this_page'] = "Item Group";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Item_Group End */
    /* Item_Category Start */

    public function Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item Category";
            $data['item_category'] = array();
            $table = "item_category";
            $field = "";
            $value = "";
            $data['item_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Item_Category/View_Item_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Item Category";
            $data['item_category'] = array();
            $table = "item_category";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['item_category'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['item_category'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Item_Category/View_Export_Item_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Item Category";
            $data['item_category'] = $this->common_model->find_details("parent", "0", "item_category");
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[item_category.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Item Category Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item_category", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'remark' => $this->input->post('remark'),
                        'parent' => $this->input->post('parent'),
                        'levels' => $levels,
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "item_category";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Item Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Item_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Item_Category/Add_Item_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Item Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_category_arr'] = $this->common_model->find_details("parent", "0", "item_category");
            $data['item_category'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['item_category']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'item_category', 'code');
                    if ($data['item_category'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[item_category.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Asset Category Name', 'required');
                    if ($this->form_validation->run()) {
                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "item_category", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                                // 'parent' => $this->input->post('parent'),
                                //'levels' => $levels,
                        );
                        $table = "item_category";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['item_category'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Item Category Updated Successfully";
                            header('Refresh:1; url= ' . site_url() . 'Master/Item_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Item_Category/Update_Item_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "item_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Item Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_category_arr'] = $this->common_model->find_details("parent", "0", "item_category");
            $data['item_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Item_Category/View_Single_Item_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Item_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'item_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $field = "id";
            $value = $this->input->post('id');
            $table = "item_category";
            $data['this_page'] = "Item Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Item_Category End */
    /* Operation_Name Start */

    public function Operation_Name() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Operation Name";
        $data['operation_name'] = array();
        $table = "operation name";
        $field = "";
        $value = "";
        $data['operation_name'] = $this->common_model->find_operation_name_details();
        $this->load->view('Master/Operation_Name/View_Operation_Name', $data);
    }

    public function Export_Operation_Name() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Operation Name";
        $data['operation_name'] = array();
        $table = "operation_name";
        $field = "";
        $value = "";

        $id = $this->uri->segment(4);
        if ($id != "") {
            $field = "id";
            $value = $id;
            $data['operation_name'] = $this->common_model->find_operation_name_details("operation_name.id = " . $id);
        } else {
            $data['operation_name'] = $this->common_model->find_operation_name_details();
        }
        $this->load->view('Master/Operation_Name/View_Export_Operation_Name', $data);
    }

    public function Add_Operation_Name() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['this_page'] = "Operation_Name";
        $data['location'] = $this->common_model->find_details("parent", "0", "location");
        $data['asset'] = $this->common_model->find_details("", "", "asset");
        $data['time'] = $this->common_model->find_details("", "", "time");
        $data['location'] = $this->common_model->find_details("", "", "location");
        $data['item'] = $this->common_model->find_details("", "", "item");
        $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $cur_time = $date->format('Y-m-d H:i:s');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('item_code', 'Item Code', 'required');
            $this->form_validation->set_rules('machine_code', 'Machine Code', 'required');
            $this->form_validation->set_rules('location', 'Location', 'required');
            $this->form_validation->set_rules('operation_desc', 'Operation Description', 'required');
            $this->form_validation->set_rules('cycle_time', 'Cycle Time ', 'required');
            $this->form_validation->set_rules('setting_time', 'Setting Time', 'required');
            $error_msg = 'This %s <b>(' . $this->input->post("operation_code") . ')</b> already exists.';
            $this->form_validation->set_rules('operation_code', 'Operation Code', 'trim|required|is_unique[cycle_time.operation_code]', array(
                'required' => 'Code is required',
                'is_unique' => $error_msg
            ));
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'item_code' => $this->input->post('item_code'),
                    'location' => $this->input->post('location'),
                    'operation_code' => $this->input->post('operation_code'),
                    'operation_desc' => $this->input->post('operation_desc'),
                    'setting_time' => $this->input->post('setting_time'),
                    'cycle_time' => $this->input->post('cycle_time'),
                    'machine_code' => $this->input->post('machine_code'),
                    'status' => 0,
                    'df' => 0,
                    'created_at' => $cur_time,
                );
//if the insert has returned true then we show the flash message
                $table = "cycle_time";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#57b91b";
                    $data['message'] = "Cycle Time added";
                    header('Refresh:1; url= ' . site_url() . 'Master/Operation_Name/');
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Some problem occur please try again later";
                }
            } else {
                $data['flash_message'] = FALSE;
                $data['color_code'] = "#c50000";
                $data['message'] = "Validation Error";
            }
        }
        $this->load->view('Master/Operation_Name/Add_Operation_Name', $data);
    }

    public function Update_Operation_Name() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $table = "operation_name";
        $field = "id";
        $value = $this->uri->segment(4);
        $data['this_page'] = "Operation Name";
        $data['location'] = $this->common_model->find_details("", "", "location");
        $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
        $data['asset'] = $this->common_model->find_details("", "", "asset");
        $data['time'] = $this->common_model->find_details("", "", "time");
        $data['operation_name'] = $this->common_model->find_details($field, $value, $table);
// print_r($data['operation_name']);exit;
        $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
        $cur_time = $date->format('Y-m-d H:i:s');
        if (count($data['operation_name']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {

                $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'operation_name', 'code');
                if ($data['operation_name'][0]['code'] != $this->input->post('code')) {
                    if ($this->input->post('code') === $original_value1) {
                        $is_unique1 = '|is_unique[operation_name.code]';
                    } else {
                        $is_unique1 = '';
                    }
                } else {
                    $is_unique1 = '';
                }
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'code', 'trim|required' . $is_unique1, array(
                    'required' => 'Code is required',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('asset', 'Asset', 'required');
                $this->form_validation->set_rules('time', 'Time', 'required');

                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'location' => $this->input->post('location'),
                        'asset' => $this->input->post('asset'),
                        'time' => $this->input->post('time'),
                    );
                    $table = "operation_name";
                    if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                        $data['operation_name'] = $this->common_model->find_details($field, $value, $table);
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Operation Name Updated Successfully";
                        header('Refresh:1; url= ' . site_url() . 'Master/Operation_Name/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
        } else {
            redirect(site_url());
        }
        $this->load->view('Master/Operation_Name/Update_Operation_Name', $data);
    }

    public function View_Single_Operation_Name() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $table = "operation_name";
        $field = "id";
        $value = $this->uri->segment(4);
        $data['this_page'] = "Operation Name";
        $data['location'] = $this->common_model->find_details("", "", "location");
        $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
        $data['asset'] = $this->common_model->find_details("", "", "asset");
        $data['time'] = $this->common_model->find_details("", "", "time");
        $data['operation_name'] = $this->common_model->find_details($field, $value, $table);
        $this->load->view('Master/Operation_Name/View_Single_Operation_Name', $data);
    }

    public function Delete_Operation_Name() {
        $field = "id";
        $value = $this->input->post('id');
        $table = "operation_name";
        $data['this_page'] = "Operation Name";
        $this->common_model->delete_details($field, $value, $table);
    }

    /* Operation_Name End */
    /* Operation_Mapping Start */

    public function Operation_Mapping() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['this_page'] = "Operation_Mapping";
        $data['operation_mapping'] = array();
        $this->load->view('Master/Operation_Mapping/View_Operation_Mapping', $data);
    }

    public function Add_Operation_Mapping() {
        $data['empty'] = "";
        $data['this_page_head'] = "Master";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['this_page'] = "Operation_Mapping";
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('price', 'Price', 'required');
            $this->form_validation->set_rules('category', 'Category', 'required');
            $this->form_validation->set_rules('mrp', 'MRP', 'required');
            $this->form_validation->set_rules('hsn_code', 'HSN Code', 'required');
            $this->form_validation->set_rules('gst_percentage', 'GST Percentage', 'required');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'category' => $this->input->post('category'),
                    'model_no' => $this->input->post('model_no'),
                    'hsn_code' => $this->input->post('hsn_code'),
                    'gst_percentage' => $this->input->post('gst_percentage'),
                    'price' => $this->input->post('price'),
                    'mrp' => $this->input->post('mrp'),
                    'description' => $this->input->post('description'),
                );
//if the insert has returned true then we show the flash message
                $table = "operation_mapping";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#57b91b";
                    $data['message'] = "Operation_Mapping added";
                    header('Refresh:1; url= ' . site_url() . 'Admin/Operation_Mapping/');
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Some problem occur please try again later";
                }
            } else {
                $data['flash_message'] = FALSE;
                $data['color_code'] = "#c50000";
                $data['message'] = "Validation Error";
            }
        }
        $this->load->view('Master/Operation_Mapping/Add_Operation_Mapping', $data);
    }

    /* Operation_Mapping End */

    /* Employee Start */

    public function Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee";
            $data['employee'] = array();
            $table = "employee";
            $field = "";
            $value = "";
//$data['employee'] = $this->common_model->find_details($field, $value, $table);
            $data['employee'] = $this->common_model->find_employee_details();
            $this->load->view('Master/Employee/View_Employee', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee";
            $data['employee'] = array();
            $table = "employee";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $data['employee'] = $this->common_model->find_employee_details("employee.id = " . $id);
            } else {
                $data['employee'] = $this->common_model->find_employee_details();
            }
            $this->load->view('Master/Employee/View_Export_Employee', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Employee";
            $data['location'] = $this->common_model->find_details("", "", "location");
            $data['employee_category'] = $this->common_model->find_details("", "", "employee_category");
            $data['employee_group'] = $this->common_model->find_details("", "", "employee_group");
            $data['employee'] = $this->common_model->find_details("parent", "0", "employee");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['department'] = $this->common_model->find_details("", "", "department");
            $data['emp_user_type'] = $this->common_model->find_details("", "", "emp_user_type");
            $data['employee_role'] = $this->common_model->find_details("", "", "employee_role");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'code', 'trim|required|is_unique[employee.code]', array(
                    'required' => 'Code is required',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]');
                $this->form_validation->set_rules('re_password', 'Password Confirmation', 'trim|required|matches[password]');
                $this->form_validation->set_rules('first_name', 'Initial', 'required');
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('group', 'Group', 'required');
                $this->form_validation->set_rules('category', 'Category', 'required');
                $this->form_validation->set_rules('department', 'Departments', 'required');
                $this->form_validation->set_rules('parent', 'Reporting_To', 'required');
                $this->form_validation->set_rules('location', 'location', 'required');
                $this->form_validation->set_rules('cost_centre', 'Cost centre', 'required');
                $this->form_validation->set_rules('address', 'Address', 'required');
                $this->form_validation->set_rules('contacts', 'Contacts', 'required');
                $this->form_validation->set_rules('employee_role', 'Employee Role', 'required');


                if ($this->form_validation->run()) {
                    $photos = "";
                    if (!empty($_FILES['photos'])) {
                        $uploadPath = 'uploads/files/';
                        $config['upload_path'] = $uploadPath;
                        $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                        $this->load->library('upload', $config);
                        $this->upload->initialize($config);
                        $img_name = "";
                        if ($this->upload->do_upload('photos')) {
                            $fileData = $this->upload->data();
                            $photos = $fileData['file_name'];
                        }
                    }
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'first_name' => $this->input->post('first_name'),
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'group' => $this->input->post('group'),
                        'category' => $this->input->post('category'),
                        'department' => $this->input->post('department'),
                        'parent' => $this->input->post('parent'),
                        'location' => $this->input->post('location'),
                        'cost_centre' => $this->input->post('cost_centre'),
                        'address' => $this->input->post('address'),
                        'contacts' => $this->input->post('contacts'),
                        'employee_role' => $this->input->post('employee_role'),
                        'password' => $this->encryption->encrypt($this->input->post('password')),
                        'photos' => $photos,
                        'emp_user_type' => $this->input->post('emp_user_type'),
                        'levels' => $levels,
                    );
                    $table = "employee";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Employee added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Employee/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Employee/Add_Employee', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Employee";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['department'] = $this->common_model->find_details("", "", "department");
            $data['emp_user_type'] = $this->common_model->find_details("", "", "emp_user_type");
            $data['employee'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("", "", "location");
            $data['employee_role'] = $this->common_model->find_details("", "", "employee_role");
            $data['employee_category_arr'] = $this->common_model->find_details("", "", "employee_category");
            $data['employee_group_arr'] = $this->common_model->find_details("", "", "employee_group");
            $data['employee_arr'] = $this->common_model->find_details("", "", "employee");
            if (count($data['employee']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'employee', 'code');
                    if ($data['employee'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[employee.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('first_name', 'Initial', 'required');
                    $this->form_validation->set_rules('name', 'Name', 'required');
                    $this->form_validation->set_rules('group', 'Group', 'required');
                    $this->form_validation->set_rules('category', 'Category', 'required');
                    $this->form_validation->set_rules('department', 'Department', 'required');
                    // $this->form_validation->set_rules('parent', 'Reporting_To', 'required');
                    $this->form_validation->set_rules('location', 'Location_Mapping', 'required');
                    $this->form_validation->set_rules('cost_centre', 'Cost_centre', 'required');
                    $this->form_validation->set_rules('address', 'Address', 'required');
                    $this->form_validation->set_rules('contacts', 'Contacts', 'required');
                    $this->form_validation->set_rules('emp_user_type', 'User_Type', 'required');
                    $this->form_validation->set_rules('employee_role', 'Employee Role', 'required');
                    $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[4]');
                    $this->form_validation->set_rules('re_password', 'Password Confirmation', 'trim|required|matches[password]');

                    if ($this->form_validation->run()) {
                        $photos = $data['employee'][0]['photos'];
                        if (!empty($_FILES['photos'])) {
                            $uploadPath = 'uploads/files/';
                            $config['upload_path'] = $uploadPath;
                            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            $img_name = "";
                            if ($this->upload->do_upload('photos')) {
                                $fileData = $this->upload->data();
                                $photos = $fileData['file_name'];
                            }
                        }
                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'first_name' => $this->input->post('first_name'),
                            'code' => $this->input->post('code'),
                            'group' => $this->input->post('group'),
                            'category' => $this->input->post('category'),
                            'department' => $this->input->post('department'),
                            //'parent' => $this->input->post('parent'),
                            'location' => $this->input->post('location'),
                            'cost_centre' => $this->input->post('cost_centre'),
                            'address' => $this->input->post('address'),
                            'contacts' => $this->input->post('contacts'),
                            'photos' => $photos,
                            'emp_user_type' => $this->input->post('emp_user_type'),
                            'employee_role' => $this->input->post('employee_role'),
                            'password' => $this->encryption->encrypt($this->input->post('password')),
                                // 'levels' => $levels,
                        );
                        $table = "employee";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['employee'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee added";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                        var_dump(validation_errors());
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Employee/Update_Employee', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Employee";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['department'] = $this->common_model->find_details("", "", "department");
            $data['emp_user_type'] = $this->common_model->find_details("", "", "emp_user_type");
            $data['employee'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("", "", "location");
            $data['employee_category_arr'] = $this->common_model->find_details("", "", "employee_category");
            $data['employee_group_arr'] = $this->common_model->find_details("", "", "employee_group");
            $data['employee_arr'] = $this->common_model->find_details("", "", "employee");
            $this->load->view('Master/Employee/View_Single_Employee', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Employee() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "employee";
            $data['this_page'] = "Employee";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Employee End */


    /* Employee_Category Start */

    public function Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee Category";
            $data['employee_category'] = array();
            $table = "employee_category";
            $field = "";
            $value = "";
            $data['employee_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Employee_Category/View_Employee_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee Category";
            $data['employee_category'] = array();
            $table = "employee_category";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['employee_category'] = $this->common_model->find_details($field, $value, $table);
            } else {

                $data['employee_category'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Employee_Category/View_Export_Employee_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Employee Category";
            $data['employee_category'] = $this->common_model->find_details("parent", "0", "employee_category");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[employee_category.code]', array(
                    'required' => 'Code is required',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');

                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee_category", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'parent' => $this->input->post('parent'),
                        'remark' => $this->input->post('remark'),
                        'levels' => $levels,
                    );
//if the insert has returned true then we show the flash message
                    $table = "employee_category";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Employee Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Employee_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Employee_Category/Add_Employee_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Employee_Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['employee_category'] = $this->common_model->find_details($field, $value, $table);
            $data['employee_category_arr'] = $this->common_model->find_details("", "", "employee_category");
            if (count($data['employee_category']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'employee_category', 'name');
                    if ($data['employee_category'][0]['name'] != $this->input->post('name')) {
                        if ($this->input->post('name') === $original_value1) {
                            $is_unique1 = '|is_unique[employee_category.name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Name', 'required');
                    // $this->form_validation->set_rules('parent', 'Belongs To', 'required');


                    if ($this->form_validation->run()) {
                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee_category", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            //  'parent' => $this->input->post('parent'),
                            'remark' => $this->input->post('remark'),
                                // 'levels' => $levels,
                        );
                        $table = "employee_category";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['employee_category'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee Category Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Employee_Category/Update_Employee_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Employee Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['employee_category'] = $this->common_model->find_details($field, $value, $table);
            $data['employee_category_arr'] = $this->common_model->find_details("", "", "employee_category");
            $this->load->view('Master/Employee_Category/View_Single_Employee_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Employee_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "employee_category";
            $data['this_page'] = "Employee Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Employee_Category End */
    /* Employee_Group Start */

    public function Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee_Group";
            $data['employee_group'] = array();
            $table = "employee_group";
            $field = "";
            $value = "";
            $data['employee_group'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Employee_Group/View_Employee_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee_Group";
            $data['employee_group'] = array();
            $table = "employee_group";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['employee_group'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['employee_group'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Employee_Group/View_Export_Employee_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Employee Group";
            $data['employee_group'] = $this->common_model->find_details("parent", "0", "employee_group");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[employee_group.code]', array(
                    'required' => 'Code is required',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                if ($this->form_validation->run()) {

                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee_group", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'parent' => $this->input->post('parent'),
                        'remark' => $this->input->post('remark'),
                        'levels' => $levels,
                    );
//if the insert has returned true then we show the flash message
                    $table = "employee_group";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Employee Group added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Employee_Group/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Employee_Group/Add_Employee_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Employee Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['employee_group'] = $this->common_model->find_details($field, $value, $table);
            $data['employee_group_arr'] = $this->common_model->find_details("", "", "employee_group");
            if (count($data['employee_group']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'employee_group', 'code');
                    if ($data['employee_group'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[employee_group.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required ',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Name', 'required');
                    //$this->form_validation->set_rules('parent', 'Belongs To', 'required');
                    if ($this->form_validation->run()) {
                        if ($this->input->post('parent') == 0) {
                            $levels = 0;
                        } else {
                            $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "employee_group", "levels");
                        }
                        $levels = $levels + 1;
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            // 'parent' => $this->input->post('parent'),
                            'remark' => $this->input->post('remark'),
                                // 'levels' => $levels,
                        );
                        $table = "employee_group";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['employee_group'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee Group Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee_Group/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Employee_Group/Update_Employee_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Employee Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['employee_group'] = $this->common_model->find_details($field, $value, $table);
            $data['employee_group_arr'] = $this->common_model->find_details("", "", "employee_group");
            $this->load->view('Master/Employee_Group/View_Single_Employee_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Employee_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'employee_group_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "employee_group";
            $data['this_page'] = "Employee Group";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Employee_Group End */

    private $count_level = 0;

    /* Location Start */

    public function Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Location";
            $data['location'] = array();
            $table = "location";
            $data['location'] = $this->common_model->find_details("", "", $table);
            $this->load->view('Master/Location/View_Location', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Location";
            $data['location'] = array();
            $table = "location";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['location'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['location'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Location/View_Export_Location', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Location";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[location.code]', array(
                    'required' => 'Location Code is required ',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Location Name', 'required');
                $this->form_validation->set_rules('description', 'Description', 'required');
                $this->form_validation->set_rules('address', 'Address ', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
//$this->form_validation->set_rules('contact', 'Contact', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "location", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'description' => $this->input->post('description'),
                        'parent' => $this->input->post('parent'),
                        'address' => $this->input->post('address'),
                        'contact' => $this->input->post('contact'),
                        'levels' => $levels,
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "location";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $last_id = $this->common_model->find_insert_id();
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Location added";
                        if ($this->input->post('new_level') == "on") {
                            $cond = array(
                                "parent" => $this->input->post('parent'),
                                "id!=" => $last_id
                            );
                            $new_level_arr = $this->common_model->find_all_details($cond, "location", "parent, id, levels");
                            foreach ($new_level_arr as $rows) {
                                $U_Level_Id = $rows['levels'] + 1;
                                $value = $rows['id'];
                                $data_to_store = array(
                                    "levels" => $U_Level_Id,
                                    "parent" => $last_id
                                );
                                $this->common_model->update_details("id", $value, $data_to_store, "location");
                                $this->common_model->updateLevelRecursively($rows, "location");
                            }
                        }
                        header('Refresh:1; url= ' . site_url() . 'Master/Location/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Location/Add_Location', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "location";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Location";
            $data['location'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
            if (count($data['location']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'location', 'code');
                    if ($data['location'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[location.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Location name', 'required');
                    $this->form_validation->set_rules('description', 'Description', 'required');
                    $this->form_validation->set_rules('address', 'Address ', 'required');
// $this->form_validation->set_rules('contact', 'Contact', 'required');
                    if ($this->form_validation->run()) {
                        if ($this->input->post('parent') == 0) {
                            $levels = 0;
                        } else {
                            $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "location", "levels");
                        }
                        $levels = $levels + 1;
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'description' => $this->input->post('description'),
                            'levels' => $levels,
                            'address' => $this->input->post('address'),
                            'contact' => $this->input->post('contact'),
                        );
                        $table = "location";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['location'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Location Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Location/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Location/Update_Location', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "location";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Location";
            $data['location'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
            $this->load->view('Master/Location/View_Single_Location', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Location() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'location_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "location";
            $data['this_page'] = "Location";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Location End */
    /* Asset End */

    public function Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset";
            $data['asset'] = array();
            $table = "asset";
            $field = "";
            $value = "";
            $data['asset'] = $this->common_model->find_asset_details();
            $this->load->view('Master/Asset/View_Asset', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset";
            $data['asset'] = array();
            $table = "asset";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $data['asset'] = $this->common_model->find_asset_details("asset.id = " . $id);
            } else {
                $data['asset'] = $this->common_model->find_asset_details("", "", $table);
            }

            $this->load->view('Master/Asset/View_Export_Asset', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Asset";
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['asset_group'] = $this->common_model->find_details("", "", "asset_group");
            $data['asset_category'] = $this->common_model->find_details("", "", "asset_category");
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
// echo "<pre>";  print_r($data['location']);exit;
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[asset.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Asset Name', 'required');
                $this->form_validation->set_rules('make', 'Make', 'required');
                $this->form_validation->set_rules('model', 'Model', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('asset_group', 'Asset Group', 'required');
                $this->form_validation->set_rules('asset_category', 'Asset Category', 'required');
                $this->form_validation->set_rules('serial_no', 'Serial Number', 'required');
                $this->form_validation->set_rules('install_date', 'Installation Date', 'required');
                $this->form_validation->set_rules('yom', 'Year Of Manufacturing', 'required');
                $this->form_validation->set_rules('owner', 'Owner', 'required');
                $this->form_validation->set_rules('machine_type', 'Machine Type', 'required');

                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'make' => $this->input->post('make'),
                        'model' => $this->input->post('model'),
                        'location' => $this->input->post('location'),
                        'asset_group' => $this->input->post('asset_group'),
                        'asset_category' => $this->input->post('asset_category'),
                        'serial_no' => $this->input->post('serial_no'),
                        'install_date' => $this->input->post('install_date'),
                        'yom' => $this->input->post('yom'),
                        'owner' => $this->input->post('owner'),
                        'machine_type' => $this->input->post('machine_type'),
                        'remark' => $this->input->post('remark'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );

//if the insert has returned true then we show the flash message
                    $table = "asset";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Asset added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Asset/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Asset/Add_Asset', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Asset";
            $data['location'] = $this->common_model->find_details("", "", "location");
            $data['asset_group'] = $this->common_model->find_details("", "", "asset_group");
            $data['asset_category'] = $this->common_model->find_details("", "", "asset_category");
            $data['asset'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("", "", "location");
// print_r($data['asset']);exit;
            if (count($data['asset']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'asset', 'code');
                    if ($data['asset'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[asset.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Asset Name', 'required');
                    $this->form_validation->set_rules('make', 'Make', 'required');
                    $this->form_validation->set_rules('model', 'Model', 'required');
                    $this->form_validation->set_rules('location', 'Location', 'required');
                    $this->form_validation->set_rules('asset_group', 'Asset Group', 'required');
                    $this->form_validation->set_rules('asset_category', 'Asset Category', 'required');
                    $this->form_validation->set_rules('serial_no', 'Serial Number', 'required');
                    $this->form_validation->set_rules('install_date', 'Installation Date', 'required');
                    $this->form_validation->set_rules('yom', 'Year Of Manufacturing', 'required');
                    $this->form_validation->set_rules('owner', 'Owner', 'required');
                    $this->form_validation->set_rules('machine_type', 'Machine Type', 'required');


                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'make' => $this->input->post('make'),
                            'model' => $this->input->post('model'),
                            'location' => $this->input->post('location'),
                            'asset_group' => $this->input->post('asset_group'),
                            'asset_category' => $this->input->post('asset_category'),
                            'serial_no' => $this->input->post('serial_no'),
                            'install_date' => $this->input->post('install_date'),
                            'yom' => $this->input->post('yom'),
                            'owner' => $this->input->post('owner'),
                            'machine_type' => $this->input->post('machine_type'),
                            'remark' => $this->input->post('remark'),
                        );
                        $table = "asset";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['asset'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Asset Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Asset/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Asset/Update_Asset', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Asset";
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['asset_group'] = $this->common_model->find_details("", "", "asset_group");
            $data['asset_category'] = $this->common_model->find_details("", "", "asset_category");
            $data['asset'] = $this->common_model->find_details($field, $value, $table);
            $data['location_arr'] = $this->common_model->find_details("parent", "0", "location");
            $this->load->view('Master/Asset/View_Single_Asset', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Asset() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "asset";
            $data['this_page'] = "Asset";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Asset End */

    /* Asset_Group Start */

    public function Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset Group";
            $data['asset_group'] = array();
            $table = "asset_group";
            $field = "";
            $value = "";
            $data['asset_group'] = $this->common_model->find_details($field, $value, $table);

            $this->load->view('Master/Asset_Group/View_Asset_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset Group";
            $data['asset_group'] = array();
            $table = "asset_group";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['asset_group'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['asset_group'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Asset_Group/View_Export_Asset_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Asset Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Asser Group Name', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[asset_group.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'remark' => $this->input->post('remark'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "asset_group";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Asset Group added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Asset_Group/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Asset_Group/Add_Asset_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Asset Group";

            $data['asset_group'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['asset_group']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'asset_group', 'code');
                    if ($data['asset_group'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[asset_group.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Asset Group Name', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                        );
                        $table = "asset_group";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['asset_group'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Asset Group Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Asset_Group/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Asset_Group/Update_Asset_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Asset Group";
            $data['asset_group'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Asset_Group/View_Single_Asset_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Asset_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_group_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "asset_group";
            $data['this_page'] = "Asset Group";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Asset_Group End */
    /* Asset_Category Start */

    public function Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset Category";
            $data['asset_category'] = array();
            $table = "asset_category";
            $field = "";
            $value = "";
            $data['asset_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Asset_Category/View_Asset_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Asset Category";
            $data['asset_category'] = array();
            $table = "asset_category";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['asset_category'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['asset_category'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Asset_Category/View_Export_Asset_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Asset Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Asset Category Name', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[asset_category.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'remark' => $this->input->post('remark'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "asset_category";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Asset Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Asset_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Asset_Category/Add_Asset_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Asset Category";
            $data['asset_category'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['asset_category']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'asset_category', 'code');
                    if ($data['asset_category'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[asset_category.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Asset Category Name', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                        );
                        $table = "asset_category";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['asset_category'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Asset Category Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Asset_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Asset_Category/Update_Asset_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function view_Single_Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "asset_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Asset Category";
            $data['asset_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Asset_Category/view_Single_Asset_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Asset_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'asset_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "asset_category";
            $data['this_page'] = "Asset Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Asset_Category End */

    public function Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Shift";
            $table = "shift";
            $field = "Status";
            $value = "Active";
            $data['shift'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Shift/View_Shift', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Shift";
            $table = "shift";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['shift'] = $this->common_model->shift_details("shift.id = " . $value);
            } else {
                $data['shift'] = $this->common_model->shift_details("", "", $table);
            }
            $this->load->view('Master/Shift/View_Export_Shift', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function break_details() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Shift";
            $table = "shift_break";
            $field = "shift_primary_id";
            $value = $this->uri->segment(4);
            $data['shift'] = $this->common_model->find_details_break($field, $value, $table);
            $this->load->view('Master/Shift/shift_break', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function update_break_details() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Shift";
            $table = "shift_break";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['shift'] = $this->common_model->update_details_break($field, $value, $table);
            $this->load->view('Master/Shift/update_Shift_break', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Shift";
            if ($this->input->server('REQUEST_METHOD') === 'POST') {

                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[shift.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('timing_from', 'Timing_from', 'required');
                $this->form_validation->set_rules('timing_to', 'Timing_to', 'required');
                $this->form_validation->set_rules('summ[]', '<b>Break Time Info - From Time</b>', 'required');
                $this->form_validation->set_rules('summ1[]', '<b>Break Time Info - To Time</b>', 'required');
                $this->form_validation->set_rules('summ2[]', '<b>Break Time Info - Description</b>', 'required');
                if ($this->form_validation->run()) {
                    $user_inp = $this->input->post();
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'timing_from' => $this->input->post('timing_from'),
                        'timing_to' => $this->input->post('timing_to'),
                        'remark' => $this->input->post('remark'),
                        'created_on' => date('Y-m-d'),
                        'created_time' => date('H:i:s'),
                        'created_by' => "",
                    );
//if the insert has returned true then we show the flash message
                    $table = "shift";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $last_id = $this->common_model->find_insert_id();
                        foreach ($user_inp['summ'] as $key => $val) {
                            if (!empty($val)) {
                                $data_to_store = array('shift_primary_id' => $last_id, 'strt_time' => $val, 'end_time' => $user_inp['summ1'][$key], 'description' => $user_inp['summ2'][$key], 'created_on' => date('Y-m-d'), 'created_time' => date('H:i:s'), 'created_by' => ""); //echo "<pre>";print_r($data);
                                $table = "shift_break";
                                $this->common_model->store_details($data_to_store, $table);
                            }
                        }
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Shift  added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Shift/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Shift/Add_Shift', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "shift";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Shift";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['shift'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['shift']) > 0) {
                $table = "shift_break";
                $field = "shift_primary_id";
                $value = $data['shift'][0]['id'];
                $data['shift_break'] = $this->common_model->find_details($field, $value, $table);
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'shift', 'code');
                    if ($data['shift'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[shift.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Name', 'required');
                    $this->form_validation->set_rules('timing_from', 'Timing_from', 'required');
                    $this->form_validation->set_rules('timing_to', 'Timing_to', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'timing_from' => $this->input->post('timing_from'),
                            'timing_to' => $this->input->post('timing_to'),
                            'remark' => $this->input->post('remark'),
                        );
                        $table = "shift";
                        if ($this->common_model->update_details("id", $value, $data_to_store, "shift")) {
                            $user_inp = $this->input->post();
                            if (isset($user_inp['summ'])) {
                                foreach ($user_inp['summ'] as $key => $val) {
                                    if (!empty($val)) {
                                        $data_to_store = array('shift_primary_id' => $value, 'strt_time' => $val, 'end_time' => $user_inp['summ1'][$key], 'description' => $user_inp['summ2'][$key], 'created_on' => date('Y-m-d'), 'created_time' => date('H:i:s'), 'created_by' => ""); //echo "<pre>";print_r($data);
                                        $table = "shift_break";
                                        $this->common_model->store_details($data_to_store, "shift_break");
                                    }
                                }
                            }
                            if ($user_inp['old_summ'] != "") {
                                foreach ($user_inp['shift_break_id'] as $key => $val) {
                                    if (!empty($val)) {
                                        $data_to_store = array('shift_primary_id' => $value, 'strt_time' => $user_inp['old_summ'][$key], 'end_time' => $user_inp['old_summ1'][$key], 'description' => $user_inp['old_summ2'][$key], 'created_on' => date('Y-m-d'), 'created_time' => date('H:i:s'), 'created_by' => ""); //echo "<pre>";print_r($data);
                                        $table = "shift_break";
                                        $this->common_model->update_details("id", $val, $data_to_store, "shift_break");
                                    }
                                }
                            }
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Shift Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Shift/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Shift/Update_Shift', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "shift";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Shift";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['item_group'] = $this->common_model->find_details("", "", "item_group");
            $data['item_category'] = $this->common_model->find_details("", "", "item_category");
            $data['shift'] = $this->common_model->find_details($field, $value, $table);
            $table = "shift_break";
            $field = "shift_primary_id";
            $value = $data['shift'][0]['id'];
            $data['shift_break'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Shift/View_Single_Shift', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Shift() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'shift_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "shift";
            $data['this_page'] = "Shift";
            $this->common_model->delete_details($field, $value, $table);
            $this->common_model->delete_details("shift_primary_id", $value, "shift_break");
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Shift_Break_Ajax() {
        $field = "id";
        $value = $this->input->post('shift_break_id');
        $table = "shift_break";
        $this->common_model->delete_details($field, $value, $table);
    }

    /* Customer_Reporting_Group Start */

    public function Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_reporting_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer Reporting Group";
            $data['customer_reporting_group'] = array();
            $table = "customer_reporting_group";
            $field = "";
            $value = "";
            $data['customer_reporting_group'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Customer_Reporting_Group/View_Customer_Reporting_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_reporting_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer Reporting Group";
            $data['customer_reporting_group'] = array();
            $table = "customer_reporting_group";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['customer_reporting_group'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['customer_reporting_group'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Customer_Reporting_Group/View_Export_Customer_Reporting_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Customer Reporting Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $data['customer_reporting_group'] = $this->common_model->find_details("parent", "0", "customer_reporting_group");
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Product Group Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[customer_reporting_group.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {

                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "customer_reporting_group", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'parent' => $this->input->post('parent'),
                        'remark' => $this->input->post('remark'),
                        'status' => 0,
                        'levels' => $levels,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "customer_reporting_group";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Product Group added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Customer_Reporting_Group/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Customer_Reporting_Group/Add_Customer_Reporting_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_reporting_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer_reporting_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Customer Reporting Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['customer_reporting_group'] = $this->common_model->find_details($field, $value, $table);
            $data['customer_reporting_group_arr'] = $this->common_model->find_details("parent", "0", "customer_reporting_group");
            if (count($data['customer_reporting_group']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    //$this->form_validation->set_rules('parent', 'Belongs To', 'required');
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'customer_reporting_group', 'code');
//  print_r($original_value1);exit;
                    if ($data['customer_reporting_group'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[customer_reporting_group.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Product Group Name', 'required');
                    if ($this->form_validation->run()) {
                        /* if ($this->input->post('parent') == 0) {
                          $levels = 0;
                          } else {
                          $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "customer_reporting_group", "levels");
                          }
                          $levels = $levels + 1; */
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                                //'parent' => $this->input->post('parent'),
                                // 'levels' => $levels,
                        );
                        $table = "customer_reporting_group";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['customer_reporting_group'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Customer_Reporting_Group Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Customer_Reporting_Group/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Customer_Reporting_Group/Update_Customer_Reporting_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_reporting_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer_reporting_group";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Customer_Reporting_Group";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['customer_reporting_group'] = $this->common_model->find_details($field, $value, $table);
            $data['customer_reporting_group_arr'] = $this->common_model->find_details("parent", "0", "customer_reporting_group");
            $this->load->view('Master/Customer_Reporting_Group/View_Single_Customer_Reporting_Group', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Customer_Reporting_Group() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_reporting_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "customer_reporting_group";
            $data['this_page'] = "Customer_Reporting_Group";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Customer_Reporting_Group End */

    /* Customer_Category Start */

    public function Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer Category";
            $data['customer_category'] = array();
            $table = "customer_category";
            $field = "";
            $value = "";
            $data['customer_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Customer_Category/View_Customer_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Customer Category";
            $id = $this->uri->segment(4);
            $data['customer_category'] = array();
            $table = "customer_category";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['customer_category'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['customer_category'] = $this->common_model->customer_category_details();
            }

            $this->load->view('Master/Customer_Category/View_Export_Customer_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Customer Category";
            $data['customer_category'] = $this->common_model->find_details("parent", "0", "customer_category");
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('parent', 'Belongs To', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[customer_category.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    if ($this->input->post('parent') == 0) {
                        $levels = 0;
                    } else {
                        $levels = $this->common_model->find_single_value("id", $this->input->post('parent'), "customer_category", "levels");
                    }
                    $levels = $levels + 1;
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'remark' => $this->input->post('remark'),
                        'parent' => $this->input->post('parent'),
                        'levels' => $levels,
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "customer_category";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Customer Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Customer_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Customer_Category/Add_Customer_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Customer Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['customer_category_arr'] = $this->common_model->find_details("parent", "0", "customer_category");
            $data['customer_category'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['customer_category']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    //$this->form_validation->set_rules('parent', 'Belongs To', 'required');
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'customer_category', 'code');
                    if ($data['customer_category'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[customer_category.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Customer Category Name', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'remark' => $this->input->post('remark'),
                                // 'parent' => $this->input->post('parent'),
                        );
                        $table = "customer_category";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['customer_category'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Customer Category Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Customer_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Customer_Category/Update_Customer_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "customer_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Customer Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['customer_category_arr'] = $this->common_model->find_details("parent", "0", "customer_category");
            $data['customer_category'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Customer_Category/View_Single_Customer_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Customer_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'customer_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "customer_category";
            $data['this_page'] = "Customer Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Customer_Category End */

    /* Failure_Type Start */

    public function Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Failure Type";
            $data['failure_type'] = array();
            $table = "failure_type";
            $field = "";
            $value = "";
            $data['failure_type'] = $this->common_model->find_details($field, $value, $table);

            $this->load->view('Master/Failure_Type/View_Failure_Type', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Failure Type";
            $data['failure_type'] = array();
            $table = "failure_type";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['failure_type'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['failure_type'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Failure_Type/View_Export_Failure_Type', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Failure Type";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('description', 'Description Code', 'required');
                $this->form_validation->set_rules('name', 'Name ', 'required');


                $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                $this->form_validation->set_rules('name', 'Name', 'trim|required|is_unique[failure_type.name]', array(
                    'required' => 'Name field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'description' => $this->input->post('description'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "failure_type";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Failure Type added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Failure_Type/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Failure_Type/Add_Failure_Type', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "failure_type";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Failure Type";

            $data['failure_type'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['failure_type']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'failure_type', 'name');
                    if ($data['failure_type'][0]['name'] != $this->input->post('name')) {
                        if ($this->input->post('name') === $original_value1) {
                            $is_unique1 = '|is_unique[failure_type.name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                    $this->form_validation->set_rules('name', 'Name', 'trim|required' . $is_unique1, array(
                        'required' => 'Name field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('description', 'Description Code', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'description' => $this->input->post('description'),
                        );
                        $table = "failure_type";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['failure_type'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Failure Type Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Failure_Type/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Failure_Type/Update_Failure_Type', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "failure_type";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Failure Type";
            $data['failure_type'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Failure_Type/View_Single_Failure_Type', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Failure_Type() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'failure_type_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "failure_type";
            $data['this_page'] = "Failure Type";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Failure_Type End */

    /* Daily_Production_Screen Start */

    public function Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Daily_Production_Screen";
            $data['this_page'] = "Daily_Production_Screen";
// $data['daily_production_screen'] = array();
            $table = "daily_production_details";
            $field = "";
            $value = "";
            $data['daily_production_details'] = $this->common_model->find_details($field, $value, $table);

            $this->load->view('Master/Daily_Production_Screen/View_Daily_Production_Screen', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "daily_production_details";
            $data['this_page'] = "daily_production_details";
            $data['daily_production_screen'] = array();
            $table = "daily_production_details ";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['daily_production_screen'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['daily_production_screen'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Daily_Production_Screen/View_Export_Daily_Production_Screen', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Daily_Production_Screen";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Daily_Production_Screen";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $data['operation_details'] = "";
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['reason_for_stoppages'] = $this->common_model->find_all_details("", "reason_for_stoppages", "", "id asc", "");
            $data['down_time'] = $this->common_model->find_all_details("", "down_time", "", "s_no asc", "");
            $data['defect_details'] = $this->common_model->find_all_details("", "defect_details", "", "id asc", "");
            $data['customer'] = $this->common_model->find_details("", "", "customer");
            $data['item'] = $this->common_model->find_details("parent", "0", "item");
            $data['employee'] = $this->common_model->find_details("parent", "0", "employee");
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['shift'] = $this->common_model->find_details("", "", "shift");
            $data['cycle_time'] = $this->common_model->find_details("", "", "cycle_time");
            $where = array('location' => $data['employee_array'][0]['location'],
                'machine_code' => $data['employee_array'][0]['cost_centre'],
            );
            $data['itme_cycle_time'] = $this->common_model->cycle_time_details($where);
            //echo "<pre>";print_r( $data['itme_cycle_time']);exit;
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $data['defect_category'] = $this->common_model->find_details("", "", "defect_category");
            $data['material_defect'] = $this->common_model->find_details("defect_type", "1", "defect_category");
            $data['machining_defect'] = $this->common_model->find_details("defect_type", "2", "defect_category");
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {


                $this->form_validation->set_rules('shift', 'Shift', 'required');
                $this->form_validation->set_rules('employee_name', 'Name', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('cost_center', 'Cost Center', 'required');
                $this->form_validation->set_rules('item', 'Item', 'required');
                $this->form_validation->set_rules('operation_code', 'Operation Code', 'required');
                $this->form_validation->set_rules('defect_type[]', '<b>Defect Type</b>', 'required');
                $this->form_validation->set_rules('defect_category[]', '<b>Defect Category</b>', 'required');
                $this->form_validation->set_rules('defect_quantity[]', '<b>Defect Quantity</b>', 'required');
                $this->form_validation->set_rules('product_serial_no[]', '<b>Product Serial No</b>', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'date' => date('Y-m-d'),
                        'shift' => $this->input->post('shift'),
                        'employee_name' => $this->input->post('employee_name'),
                        'employee_id' => $this->input->post('employee_id'),
                        'location' => $this->input->post('location'),
                        'cost_center' => $this->input->post('cost_center'),
                        'item' => $this->input->post('item'),
                        'operation_code' => $this->input->post('operation_code'),
                        'fully_accepted' => $this->input->post('fully_accepted'),
                        'conditionally_accepted' => $this->input->post('conditionally_accepted'),
                        'rework' => $this->input->post('rework'),
                        'material_defect' => $this->input->post('material_defect'),
                        'machining_defect' => $this->input->post('machining_defect'),
                        'total_machine_quantity' => $this->input->post('total_machine_quantity'),
                        'from_serial_no' => $this->input->post('from_serial_no'),
                        'to_serial_no' => $this->input->post('to_serial_no'),
                        'standard_cycle_time' => $this->input->post('standard_cycle_time'),
                        'machining_time' => $this->input->post('machining_time'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => date('Y-m-d H:i:s'),
                    );
//if the insert has returned true then we show the flash message
                    $table = "daily_production_details";
                    $last_insert_id = $this->common_model->store_details($data_to_store, $table);
                    if ($last_insert_id) {
                        foreach ($data['down_time'] as $rows) {
                            $data_to_store = array(
                                'title' => $rows['id'],
                                'value' => $this->input->post('dynamic_minitus_' . $rows['id']),
                                'total_minitues' => $this->input->post('total_minitues'),
                                'daily_production_id' => $last_insert_id,
                                'created_at' => date('Y-m-d H:i:s'),
                            );
                            $this->common_model->store_details($data_to_store, "daily_production_downtime_details");
                        }

                        $user_inp = $this->input->post();
                        if (isset($user_inp['defect_type']) && !empty($user_inp['defect_type'])) {
                            foreach ($user_inp['defect_type'] as $val => $key) {
//$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                $data_to_store = array(
                                    'defect_type' => $user_inp['defect_type'][$val],
                                    'defect_category' => $user_inp['defect_category'][$val],
                                    'defect_quantity' => $user_inp['defect_quantity'][$val],
                                    'product_serial_no' => $user_inp['product_serial_no'][$val],
                                    'daily_production_id' => $last_insert_id,
                                    'created_at' => date('Y-m-d H:i:s'),
                                );
                                $this->common_model->store_details($data_to_store, "daily_production_defect_details");
                            }
                        }
                    }

                    if ($last_insert_id) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Daily Production added";
                        $cond = array(
                            "item_code" => $this->input->post('item')
                        );
                        $data['operation_details_arr'] = $this->common_model->find_all_details($cond, "cycle_time", "*", "id asc");
                        header('Refresh:1; url= ' . site_url() . 'Master/Daily_Production_Screen/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Daily_Production_Screen/Add_Daily_Production_Screen', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Daily_Production_Screen";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "daily_production_screen";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Daily_Production_Screen";

            $data['daily_production_screen'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['daily_production_screen']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'daily_production_screen', 'name');
                    if ($data['daily_production_screen'][0]['name'] != $this->input->post('name')) {
                        if ($this->input->post('name') === $original_value1) {
                            $is_unique1 = '|is_unique[daily_production_screen.name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $this->form_validation->set_rules('name', 'Name', 'trim|required' . $is_unique1, array(
                        'required' => 'name is required.',
                        'is_unique' => 'This %s already exists.'
                    ));
                    $this->form_validation->set_rules('code', 'Failure Type Code', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'description' => $this->input->post('description'),
                        );
                        $table = "daily_production_screen";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['daily_production_screen'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Failure Type Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Daily_Production_Screen/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Daily_Production_Screen/Update_Daily_Production_Screen', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Daily_Production_Screen";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Daily_Production_Screen";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['reason_for_stoppages'] = $this->common_model->find_all_details("", "reason_for_stoppages", "", "id asc", "");
            $data['down_time'] = $this->common_model->find_all_details("", "down_time", "", "s_no asc", "");
            $data['defect_details'] = $this->common_model->find_all_details("", "defect_details", "", "id asc", "");
            $data['customer'] = $this->common_model->find_details("", "", "customer");
            $data['item'] = $this->common_model->find_details("parent", "0", "item");
            $data['employee'] = $this->common_model->find_details("parent", "0", "employee");
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['location'] = $this->common_model->find_details("parent", "0", "location");
            $data['shift'] = $this->common_model->find_details("", "", "shift");
            $data['cycle_time'] = $this->common_model->find_details("", "", "cycle_time");
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");

            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Daily_Production_Screen";
            $data['daily_production_details'] = $this->common_model->daily_production_details($value);
            $data['daily_production_downtime_details'] = $this->common_model->daily_production_downtime_details($value);
            $data['daily_production_defect_details'] = $this->common_model->daily_production_defect_details($value);
            $this->load->view('Master/Daily_Production_Screen/View_Single_Daily_Production_Screen', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Daily_Production_Screen() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'daily_production_screen_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "daily_production_screen";
            $data['this_page'] = "Daily Production Screen";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Select_Operation_Code() {
        $item_code = $this->input->post('item_code');
        $data['this_page'] = "Daily Production Screen";
        $option = "";
        if ($item_code != "") {
            $cond = array(
                "item_code" => $item_code
            );
            $data['operation_details'] = $this->common_model->find_all_details($cond, "cycle_time", "*", "id asc");
        }

        $this->load->view('Master/Ajax/Daily_Entry_Screen', $data);
    }

    public function Select_Defect_Category() {
        $item_code = $this->input->post('item_code');
        $defect_category = $this->common_model->find_details('id', $id, 'defect_category');
        $option = ' <select ui-jq="chosen" class="w-full defect_category" name="defect_category[]"  >';
        foreach ($defect_category as $val1) {
            $name = $val1['name'];
            $value = $val1['id'];
            $option .= "<option value='" . $value . "' set_select('defect_category','" . $value . "',False) >" . $name . "</option>";
        }
        $option .= "</select>";
        print_r($option);
    }

    public function Get_Std_Cyclic_Time() {
        $id = $this->input->post('id');
        $cyclic_time = $this->common_model->find_single_value('id', $id, 'cycle_time', 'cycle_time');
        echo $cyclic_time;
    }

    /* Daily_Production_Screen End */

    /* Cycle_Time Start */

    public function Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Cycle Time";
            $table = "cycle_time";
            $data['cycle_time'] = $this->common_model->cycle_time_det();
//echo "<pre>";print_r($data['cycle_time']);exit;
            $this->load->view('Master/Cycle_Time/View_Cycle_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Cycle Time";
            $data['cycle_time'] = array();
            $table = "cycle_time";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['cycle_time'] = $this->common_model->cycle_time_det("cycle_time.id = " . $id);
            } else {
                $data['cycle_time'] = $this->common_model->cycle_time_det();
            }
            $this->load->view('Master/Cycle_Time/View_Export_Cycle_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Cycle Time";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['location'] = $this->common_model->find_details("", "", "location");
            $data['item'] = $this->common_model->find_details("", "", "item");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $data['cycle_time'] = $this->common_model->find_details("", "", "cycle_time");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("operation_code") . ')</b> already exists.';
                $this->form_validation->set_rules('operation_code', 'operation_code', 'trim|required|is_unique[cycle_time.operation_code]', array(
                    'required' => 'Code is required',
                    'is_unique' => $error_msg
                ));

                $this->form_validation->set_rules('item_code', 'Item Code ', 'required');
                $this->form_validation->set_rules('location', 'Location', 'required');
                $this->form_validation->set_rules('operation_desc', 'Operation Description', 'required');
                $this->form_validation->set_rules('setting_time', 'Setting Time', 'required');
                $this->form_validation->set_rules('cycle_time', 'Cycle Time', 'required');
                $this->form_validation->set_rules('machine_code', 'Machine Code', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'item_code' => $this->input->post('item_code'),
                        'location' => $this->input->post('location'),
                        'operation_code' => $this->input->post('operation_code'),
                        'operation_desc' => $this->input->post('operation_desc'),
                        'setting_time' => $this->input->post('setting_time'),
                        'cycle_time' => $this->input->post('cycle_time'),
                        'machine_code' => $this->input->post('machine_code'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "cycle_time";
                    if ($this->common_model->store_details($data_to_store, $table)) {

                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Cycle_Time added";

                        header('Refresh:1; url= ' . site_url() . 'Master/Cycle_Time/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Cycle_Time/Add_Cycle_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "cycle_time";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Cycle Time";
            $data['cycle_time'] = $this->common_model->find_details($field, $value, $table);
            $data['location'] = $this->common_model->find_details("", "", "location");
            $data['item'] = $this->common_model->find_details("", "", "item");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            if (count($data['cycle_time']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {



                    $original_value1 = $this->common_model->find_single_value('operation_code', $this->input->post('operation_code'), 'cycle_time', 'operation_code');
                    if ($data['cycle_time'][0]['operation_code'] != $this->input->post('operation_code')) {
                        if ($this->input->post('operation_code') === $original_value1) {
                            $is_unique1 = '|is_unique[cycle_time.operation_code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("operation_code") . ')</b> already exists.';
                    $this->form_validation->set_rules('operation_code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code is required ',
                        'is_unique' => $error_msg
                    ));

                    $this->form_validation->set_rules('item_code', 'Item Code ', 'required');
                    $this->form_validation->set_rules('location', 'Location', 'required');

                    $this->form_validation->set_rules('operation_desc', 'Operation Description', 'required');
                    $this->form_validation->set_rules('setting_time', 'Setting Time', 'required');
                    $this->form_validation->set_rules('cycle_time', 'Cycle Time', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'item_code' => $this->input->post('item_code'),
                            'location' => $this->input->post('location'),
                            'operation_code' => $this->input->post('operation_code'),
                            'operation_desc' => $this->input->post('operation_desc'),
                            'setting_time' => $this->input->post('setting_time'),
                            'cycle_time' => $this->input->post('cycle_time'),
                            'machine_code' => $this->input->post('machine_code'),
                        );
                        $table = "cycle_time";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['cycle_time'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Cycle_Time Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Cycle_Time/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Cycle_Time/Update_Cycle_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "cycle_time";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Cycle Time";
            $data['cycle_time'] = $this->common_model->find_details($field, $value, $table);
            $data['location'] = $this->common_model->find_details("", "", "location");
            $data['item'] = $this->common_model->find_details("", "", "item");
            $data['asset'] = $this->common_model->find_details("", "", "asset");
            $this->load->view('Master/Cycle_Time/View_Single_Cycle_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Cycle_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'cycle_time_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "cycle_time";
            $data['this_page'] = "Cycle Time";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Cycle_Time End */

    /* Down_Time Start */

    public function Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Down Time";
            $table = "down_time";
            $field = "";
            $value = "";
            $data['down_time'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Down_Time/View_Down_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Down Time";
            $data['down_time'] = array();
            $table = "down_time";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['down_time'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['down_time'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Down_Time/View_Export_Down_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Down Time";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('s_no', 'Sequence Number', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[down_time.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        's_no' => $this->input->post('s_no'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "down_time";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Down Time added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Down_Time/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Down_Time/Add_Down_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "down_time";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Down Time";

            $data['down_time'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['down_time']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'down_time', 'code');
                    if ($data['down_time'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[down_time.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Down Time Name', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            's_no' => $this->input->post('s_no'),
                        );
                        $table = "down_time";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['down_time'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Down Time Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Down_Time/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Down_Time/Update_Down_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "down_time";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Down Time";
            $data['down_time'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Down_Time/View_Single_Down_Time', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Down_Time() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'down_time_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "down_time";
            $data['this_page'] = "Down Time";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Down_Time End */

    /* Defect_Category Start */

    public function Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Defect Category";
            $table = "defect_category";
            $field = "";
            $value = "";
            $data['defect_category'] = $this->common_model->defect_category_details();
            $this->load->view('Master/Defect_Category/View_Defect_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Defect Category";
            $data['defect_category'] = array();
            $table = "defect_category";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['defect_category'] = $this->common_model->defect_category_details("defect_category.id = " . $id);
            } else {
                $data['defect_category'] = $this->common_model->defect_category_details();
            }
            $this->load->view('Master/Defect_Category/View_Export_Defect_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Defect Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('name', 'Name', 'required');
                $this->form_validation->set_rules('defect_type', 'Defect  Type', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                $this->form_validation->set_rules('code', 'Code', 'trim|required|is_unique[defect_category.code]', array(
                    'required' => 'Code field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'code' => $this->input->post('code'),
                        'defect_type' => $this->input->post('defect_type'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "defect_category";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Defect Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Defect_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Defect_Category/Add_Defect_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "defect_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Defect Category";
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $data['defect_category'] = $this->common_model->find_details($field, $value, $table);
            $data['defect_category'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['defect_category']) > 0) {
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('code', $this->input->post('code'), 'defect_category', 'code');
                    if ($data['defect_category'][0]['code'] != $this->input->post('code')) {
                        if ($this->input->post('code') === $original_value1) {
                            $is_unique1 = '|is_unique[defect_category.code]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("code") . ')</b> already exists.';
                    $this->form_validation->set_rules('code', 'Code', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    $this->form_validation->set_rules('name', 'Defect Category Name', 'required');
                    $this->form_validation->set_rules('defect_type', 'Defect Type ', 'required');

                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'defect_type' => $this->input->post('defect_type'),
                        );
                        $table = "defect_category";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['defect_category'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Defect Category Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Defect_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Defect_Category/Update_Defect_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "defect_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Defect Category";
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $data['defect_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Defect_Category/View_Single_Defect_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Defect_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'defect_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "defect_category";
            $data['this_page'] = "Defect Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Employee_Role Start */

    public function Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee Role";
            $table = "employee_role";
            $field = "";
            $value = "";
            $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Employee_Role/View_Employee_Role', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Employee Role";
            $data['employee_role'] = array();
            $table = "employee_role";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            }
            $this->load->view('Master/Employee_Role/View_Export_Employee_Role', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Employee Role";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $update = $this->uri->segment(4);
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                if ($update != "") {
                    $data['employee_role'] = $this->common_model->find_details("id", $update, "employee_role");
                    $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'employee_role', 'name');
                    if ($data['employee_role'][0]['name'] != $this->input->post('name')) {
                        if ($this->input->post('name') === $original_value1) {
                            $is_unique1 = '|is_unique[employee_role.name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                    $this->form_validation->set_rules('name', 'Role Name', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                } else {
                    $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                    $this->form_validation->set_rules('name', 'Role Name', 'trim|required|is_unique[employee_role.name]', array(
                        'required' => 'Name field  is required.',
                        'is_unique' => $error_msg
                    ));
                }
                if ($this->form_validation->run()) {
                    $location_add = 0;
                    if ($this->input->post('location_add')) {
                        $location_add = $this->input->post('location_add');
                    }
                    $location_edit = 0;
                    if ($this->input->post('location_edit')) {
                        $location_edit = $this->input->post('location_edit');
                    }
                    $location_view = 0;
                    if ($this->input->post('location_view')) {
                        $location_view = $this->input->post('location_view');
                    }

                    $location_delete = 0;
                    if ($this->input->post('location_delete')) {
                        $location_delete = $this->input->post('location_delete');
                    }

                    $shift_add = 0;
                    if ($this->input->post('shift_add')) {
                        $shift_add = $this->input->post('shift_add');
                    }

                    $shift_edit = 0;
                    if ($this->input->post('shift_edit')) {
                        $shift_edit = $this->input->post('shift_edit');
                    }

                    $shift_view = 0;
                    if ($this->input->post('shift_view')) {
                        $shift_view = $this->input->post('shift_view');
                    }

                    $shift_delete = 0;
                    if ($this->input->post('shift_delete')) {
                        $shift_delete = $this->input->post('shift_delete');
                    }

                    $customer_category_add = 0;
                    if ($this->input->post('customer_category_add')) {
                        $customer_category_add = $this->input->post('customer_category_add');
                    }

                    $customer_category_edit = 0;
                    if ($this->input->post('customer_category_edit')) {
                        $customer_category_edit = $this->input->post('customer_category_edit');
                    }

                    $customer_category_view = 0;
                    if ($this->input->post('customer_category_view')) {
                        $customer_category_view = $this->input->post('customer_category_view');
                    }

                    $customer_category_delete = 0;
                    if ($this->input->post('customer_category_delete')) {
                        $customer_category_delete = $this->input->post('customer_category_delete');
                    }

                    $customer_reporting_add = 0;
                    if ($this->input->post('customer_reporting_add')) {
                        $customer_reporting_add = $this->input->post('customer_reporting_add');
                    }

                    $customer_reporting_edit = 0;
                    if ($this->input->post('customer_reporting_edit')) {
                        $customer_reporting_edit = $this->input->post('customer_reporting_edit');
                    }


                    $customer_reporting_view = 0;
                    if ($this->input->post('customer_reporting_view')) {
                        $customer_reporting_view = $this->input->post('customer_reporting_view');
                    }

                    $customer_reporting_delete = 0;
                    if ($this->input->post('customer_reporting_delete')) {
                        $customer_reporting_delete = $this->input->post('customer_reporting_delete');
                    }

                    $customer_add = 0;
                    if ($this->input->post('customer_add')) {
                        $customer_add = $this->input->post('customer_add');
                    }

                    $customer_edit = 0;
                    if ($this->input->post('customer_edit')) {
                        $customer_edit = $this->input->post('customer_edit');
                    }

                    $customer_view = 0;
                    if ($this->input->post('customer_view')) {
                        $customer_view = $this->input->post('customer_view');
                    }

                    $customer_delete = 0;
                    if ($this->input->post('customer_delete')) {
                        $customer_delete = $this->input->post('customer_delete');
                    }

                    $asset_category_add = 0;
                    if ($this->input->post('asset_category_add')) {
                        $asset_category_add = $this->input->post('asset_category_add');
                    }

                    $asset_category_edit = 0;
                    if ($this->input->post('asset_category_edit')) {
                        $asset_category_edit = $this->input->post('asset_category_edit');
                    }

                    $asset_category_view = 0;
                    if ($this->input->post('asset_category_view')) {
                        $asset_category_view = $this->input->post('asset_category_view');
                    }

                    $asset_category_delete = 0;
                    if ($this->input->post('asset_category_delete')) {
                        $asset_category_delete = $this->input->post('asset_category_delete');
                    }

                    $asset_group_add = 0;
                    if ($this->input->post('asset_group_add')) {
                        $asset_group_add = $this->input->post('asset_group_add');
                    }

                    $asset_group_edit = 0;
                    if ($this->input->post('asset_group_edit')) {
                        $asset_group_edit = $this->input->post('asset_group_edit');
                    }

                    $asset_group_view = 0;
                    if ($this->input->post('asset_group_view')) {
                        $asset_group_view = $this->input->post('asset_group_view');
                    }

                    $asset_group_delete = 0;
                    if ($this->input->post('asset_group_delete')) {
                        $asset_group_delete = $this->input->post('asset_group_delete');
                    }

                    $asset_add = 0;
                    if ($this->input->post('asset_add')) {
                        $asset_add = $this->input->post('asset_add');
                    }

                    $asset_edit = 0;
                    if ($this->input->post('asset_edit')) {
                        $asset_edit = $this->input->post('asset_edit');
                    }

                    $asset_view = 0;
                    if ($this->input->post('asset_view')) {
                        $asset_view = $this->input->post('asset_view');
                    }

                    $asset_delete = 0;
                    if ($this->input->post('asset_delete')) {
                        $asset_delete = $this->input->post('asset_delete');
                    }

                    $employee_category_add = 0;
                    if ($this->input->post('employee_category_add')) {
                        $employee_category_add = $this->input->post('employee_category_add');
                    }

                    $employee_category_edit = 0;
                    if ($this->input->post('employee_category_edit')) {
                        $employee_category_edit = $this->input->post('employee_category_edit');
                    }


                    $employee_category_view = 0;
                    if ($this->input->post('employee_category_view')) {
                        $employee_category_view = $this->input->post('employee_category_view');
                    }

                    $employee_category_delete = 0;
                    if ($this->input->post('employee_category_delete')) {
                        $employee_category_delete = $this->input->post('employee_category_delete');
                    }


                    $employee_group_add = 0;
                    if ($this->input->post('employee_group_add')) {
                        $employee_group_add = $this->input->post('employee_group_add');
                    }

                    $employee_group_edit = 0;
                    if ($this->input->post('employee_group_edit')) {
                        $employee_group_edit = $this->input->post('employee_group_edit');
                    }

                    $employee_group_view = 0;
                    if ($this->input->post('employee_group_view')) {
                        $employee_group_view = $this->input->post('employee_group_view');
                    }

                    $employee_group_delete = 0;
                    if ($this->input->post('employee_group_delete')) {
                        $employee_group_delete = $this->input->post('employee_group_delete');
                    }

                    $employee_add = 0;
                    if ($this->input->post('employee_add')) {
                        $employee_add = $this->input->post('employee_add');
                    }

                    $employee_edit = 0;
                    if ($this->input->post('employee_edit')) {
                        $employee_edit = $this->input->post('employee_edit');
                    }

                    $employee_view = 0;
                    if ($this->input->post('employee_view')) {
                        $employee_view = $this->input->post('employee_view');
                    }


                    $employee_delete = 0;
                    if ($this->input->post('employee_delete')) {
                        $employee_delete = $this->input->post('employee_delete');
                    }

                    $item_category_add = 0;
                    if ($this->input->post('item_category_add')) {
                        $item_category_add = $this->input->post('item_category_add');
                    }

                    $item_category_edit = 0;
                    if ($this->input->post('item_category_edit')) {
                        $item_category_edit = $this->input->post('item_category_edit');
                    }

                    $item_category_view = 0;
                    if ($this->input->post('item_category_view')) {
                        $item_category_view = $this->input->post('item_category_view');
                    }


                    $item_category_delete = 0;
                    if ($this->input->post('item_category_delete')) {
                        $item_category_delete = $this->input->post('item_category_delete');
                    }

                    $item_group_add = 0;
                    if ($this->input->post('item_group_add')) {
                        $item_group_add = $this->input->post('item_group_add');
                    }

                    $item_group_edit = 0;
                    if ($this->input->post('item_group_edit')) {
                        $item_group_edit = $this->input->post('item_group_edit');
                    }

                    $item_group_view = 0;
                    if ($this->input->post('item_group_view')) {
                        $item_group_view = $this->input->post('item_group_view');
                    }


                    $item_group_delete = 0;
                    if ($this->input->post('item_group_delete')) {
                        $item_group_delete = $this->input->post('item_group_delete');
                    }

                    $item_add = 0;
                    if ($this->input->post('item_add')) {
                        $item_add = $this->input->post('item_add');
                    }

                    $item_edit = 0;
                    if ($this->input->post('item_edit')) {
                        $item_edit = $this->input->post('item_edit');
                    }

                    $item_view = 0;
                    if ($this->input->post('item_view')) {
                        $item_view = $this->input->post('item_view');
                    }


                    $item_delete = 0;
                    if ($this->input->post('item_delete')) {
                        $item_delete = $this->input->post('item_delete');
                    }

                    $failure_type_add = 0;
                    if ($this->input->post('failure_type_add')) {
                        $failure_type_add = $this->input->post('failure_type_add');
                    }

                    $failure_type_edit = 0;
                    if ($this->input->post('failure_type_edit')) {
                        $failure_type_edit = $this->input->post('failure_type_edit');
                    }

                    $failure_type_view = 0;
                    if ($this->input->post('failure_type_view')) {
                        $failure_type_view = $this->input->post('failure_type_view');
                    }


                    $failure_type_delete = 0;
                    if ($this->input->post('failure_type_delete')) {
                        $failure_type_delete = $this->input->post('failure_type_delete');
                    }


                    $cycle_time_add = 0;
                    if ($this->input->post('cycle_time_add')) {
                        $cycle_time_add = $this->input->post('cycle_time_add');
                    }

                    $cycle_time_edit = 0;
                    if ($this->input->post('cycle_time_edit')) {
                        $cycle_time_edit = $this->input->post('cycle_time_edit');
                    }

                    $cycle_time_view = 0;
                    if ($this->input->post('cycle_time_view')) {
                        $cycle_time_view = $this->input->post('cycle_time_view');
                    }


                    $cycle_time_delete = 0;
                    if ($this->input->post('cycle_time_delete')) {
                        $cycle_time_delete = $this->input->post('cycle_time_delete');
                    }

                    $down_time_add = 0;
                    if ($this->input->post('down_time_add')) {
                        $down_time_add = $this->input->post('down_time_add');
                    }

                    $down_time_edit = 0;
                    if ($this->input->post('down_time_edit')) {
                        $down_time_edit = $this->input->post('down_time_edit');
                    }

                    $down_time_view = 0;
                    if ($this->input->post('down_time_view')) {
                        $down_time_view = $this->input->post('down_time_view');
                    }


                    $down_time_delete = 0;
                    if ($this->input->post('down_time_delete')) {
                        $down_time_delete = $this->input->post('down_time_delete');
                    }

                    $defect_category_add = 0;
                    if ($this->input->post('defect_category_add')) {
                        $defect_category_add = $this->input->post('defect_category_add');
                    }

                    $defect_category_edit = 0;
                    if ($this->input->post('defect_category_edit')) {
                        $defect_category_edit = $this->input->post('defect_category_edit');
                    }

                    $defect_category_view = 0;
                    if ($this->input->post('defect_category_view')) {
                        $defect_category_view = $this->input->post('defect_category_view');
                    }


                    $defect_category_delete = 0;
                    if ($this->input->post('defect_category_delete')) {
                        $defect_category_delete = $this->input->post('defect_category_delete');
                    }

                    $daily_production_screen_add = 0;
                    if ($this->input->post('daily_production_screen_add')) {
                        $daily_production_screen_add = $this->input->post('daily_production_screen_add');
                    }

                    $daily_production_screen_edit = 0;
                    if ($this->input->post('daily_production_screen_edit')) {
                        $daily_production_screen_edit = $this->input->post('daily_production_screen_edit');
                    }

                    $daily_production_screen_view = 0;
                    if ($this->input->post('daily_production_screen_view')) {
                        $daily_production_screen_view = $this->input->post('daily_production_screen_view');
                    }


                    $daily_production_screen_delete = 0;
                    if ($this->input->post('daily_production_screen_delete')) {
                        $daily_production_screen_delete = $this->input->post('daily_production_screen_delete');
                    }

                    $service_request_category_add = 0;
                    if ($this->input->post('service_request_category_add')) {
                        $service_request_category_add = $this->input->post('service_request_category_add');
                    }
                    $service_request_category_edit = 0;
                    if ($this->input->post('service_request_category_edit')) {
                        $service_request_category_edit = $this->input->post('service_request_category_edit');
                    }
                    $service_request_category_view = 0;
                    if ($this->input->post('service_request_category_view')) {
                        $service_request_category_view = $this->input->post('service_request_category_view');
                    }

                    $service_request_category_delete = 0;
                    if ($this->input->post('service_request_category_delete')) {
                        $service_request_category_delete = $this->input->post('service_request_category_delete');
                    }

                    $service_request_add = 0;
                    if ($this->input->post('service_request_add')) {
                        $service_request_add = $this->input->post('service_request_add');
                    }
                    $service_request_edit = 0;
                    if ($this->input->post('service_request_edit')) {
                        $service_request_edit = $this->input->post('service_request_edit');
                    }
                    $service_request_view = 0;
                    if ($this->input->post('service_request_view')) {
                        $service_request_view = $this->input->post('service_request_view');
                    }

                    $service_request_delete = 0;
                    if ($this->input->post('service_request_delete')) {
                        $service_request_delete = $this->input->post('service_request_delete');
                    }

                    $service_request_mapping_add = 0;
                    if ($this->input->post('service_request_mapping_add')) {
                        $service_request_mapping_add = $this->input->post('service_request_mapping_add');
                    }
                    $service_request_mapping_edit = 0;
                    if ($this->input->post('service_request_mapping_edit')) {
                        $service_request_mapping_edit = $this->input->post('service_request_mapping_edit');
                    }
                    $service_request_mapping_view = 0;
                    if ($this->input->post('service_request_mapping_view')) {
                        $service_request_mapping_view = $this->input->post('service_request_mapping_view');
                    }

                    $service_request_mapping_delete = 0;
                    if ($this->input->post('service_request_mapping_delete')) {
                        $service_request_mapping_delete = $this->input->post('service_request_mapping_delete');
                    }

                    $production_add = 0;
                    if ($this->input->post('production_add')) {
                        $production_add = $this->input->post('production_add');
                    }
                    $production_edit = 0;
                    if ($this->input->post('production_edit')) {
                        $production_edit = $this->input->post('production_edit');
                    }
                    $production_view = 0;
                    if ($this->input->post('production_view')) {
                        $production_view = $this->input->post('production_view');
                    }

                    $production_delete = 0;
                    if ($this->input->post('production_delete')) {
                        $production_delete = $this->input->post('production_delete');
                    }

                    $packing_add = 0;
                    if ($this->input->post('packing_add')) {
                        $packing_add = $this->input->post('packing_add');
                    }
                    $packing_edit = 0;
                    if ($this->input->post('packing_edit')) {
                        $packing_edit = $this->input->post('packing_edit');
                    }
                    $packing_view = 0;
                    if ($this->input->post('packing_view')) {
                        $packing_view = $this->input->post('packing_view');
                    }

                    $packing_delete = 0;
                    if ($this->input->post('packing_delete')) {
                        $packing_delete = $this->input->post('packing_delete');
                    }
                    $despatch_add = 0;
                    if ($this->input->post('despatch_add')) {
                        $despatch_add = $this->input->post('despatch_add');
                    }
                    $despatch_edit = 0;
                    if ($this->input->post('despatch_edit')) {
                        $despatch_edit = $this->input->post('despatch_edit');
                    }
                    $despatch_view = 0;
                    if ($this->input->post('despatch_view')) {
                        $despatch_view = $this->input->post('despatch_view');
                    }

                    $despatch_delete = 0;
                    if ($this->input->post('despatch_delete')) {
                        $despatch_delete = $this->input->post('despatch_delete');
                    }

                    $inward_add = 0;
                    if ($this->input->post('inward_add')) {
                        $inward_add = $this->input->post('inward_add');
                    }
                    $inward_edit = 0;
                    if ($this->input->post('inward_edit')) {
                        $inward_edit = $this->input->post('inward_edit');
                    }
                    $inward_view = 0;
                    if ($this->input->post('inward_view')) {
                        $inward_view = $this->input->post('inward_view');
                    }

                    $inward_delete = 0;
                    if ($this->input->post('inward_delete')) {
                        $inward_delete = $this->input->post('inward_delete');
                    }
                    $machine_rejection_despatch_add = 0;
                    if ($this->input->post('machine_rejection_despatch_add')) {
                        $machine_rejection_despatch_add = $this->input->post('machine_rejection_despatch_add');
                    }
                    $machine_rejection_despatch_edit = 0;
                    if ($this->input->post('machine_rejection_despatch_edit')) {
                        $machine_rejection_despatch_edit = $this->input->post('machine_rejection_despatch_edit');
                    }
                    $machine_rejection_despatch_view = 0;
                    if ($this->input->post('machine_rejection_despatch_view')) {
                        $machine_rejection_despatch_view = $this->input->post('machine_rejection_despatch_view');
                    }

                    $machine_rejection_despatch_delete = 0;
                    if ($this->input->post('machine_rejection_despatch_delete')) {
                        $machine_rejection_despatch_delete = $this->input->post('machine_rejection_despatch_delete');
                    }

                    $material_rejection_despatch_add = 0;
                    if ($this->input->post('material_rejection_despatch_add')) {
                        $material_rejection_despatch_add = $this->input->post('material_rejection_despatch_add');
                    }
                    $material_rejection_despatch_edit = 0;
                    if ($this->input->post('material_rejection_despatch_edit')) {
                        $material_rejection_despatch_edit = $this->input->post('material_rejection_despatch_edit');
                    }
                    $material_rejection_despatch_view = 0;
                    if ($this->input->post('material_rejection_despatch_view')) {
                        $material_rejection_despatch_view = $this->input->post('material_rejection_despatch_view');
                    }

                    $material_rejection_despatch_delete = 0;
                    if ($this->input->post('material_rejection_despatch_delete')) {
                        $material_rejection_despatch_delete = $this->input->post('material_rejection_despatch_delete');
                    }
                    $inspection_completed_add = 0;
                    if ($this->input->post('inspection_completed_add')) {
                        $inspection_completed_add = $this->input->post('inspection_completed_add');
                    }
                    $inspection_completed_edit = 0;
                    if ($this->input->post('inspection_completed_edit')) {
                        $inspection_completed_edit = $this->input->post('inspection_completed_edit');
                    }
                    $inspection_completed_view = 0;
                    if ($this->input->post('inspection_completed_view')) {
                        $inspection_completed_view = $this->input->post('inspection_completed_view');
                    }

                    $inspection_completed_delete = 0;
                    if ($this->input->post('inspection_completed_delete')) {
                        $inspection_completed_delete = $this->input->post('inspection_completed_delete');
                    }

                    $master_module_add = 0;
                    if ($this->input->post('master_module_add')) {
                        $master_module_add = $this->input->post('master_module_add');
                    }
                    $master_module_edit = 0;
                    if ($this->input->post('master_module_edit')) {
                        $master_module_edit = $this->input->post('master_module_edit');
                    }
                    $master_module_view = 0;
                    if ($this->input->post('master_module_view')) {
                        $master_module_view = $this->input->post('master_module_view');
                    }

                    $master_module_delete = 0;
                    if ($this->input->post('master_module_delete')) {
                        $master_module_delete = $this->input->post('master_module_delete');
                    }
                    $schedule_add = 0;
                    if ($this->input->post('schedule_add')) {
                        $schedule_add = $this->input->post('schedule_add');
                    }
                    $schedule_edit = 0;
                    if ($this->input->post('schedule_edit')) {
                        $schedule_edit = $this->input->post('schedule_edit');
                    }
                    $schedule_view = 0;
                    if ($this->input->post('schedule_view')) {
                        $schedule_view = $this->input->post('schedule_view');
                    }

                    $schedule_delete = 0;
                    if ($this->input->post('schedule_delete')) {
                        $schedule_delete = $this->input->post('schedule_delete');
                    }


                    $data_to_store = array(
                        'name' => $this->input->post('name'),
                        'location_add' => $location_add,
                        'location_edit' => $location_edit,
                        'location_view' => $location_view,
                        'location_delete' => $location_delete,
                        'shift_add' => $shift_add,
                        'shift_edit' => $shift_edit,
                        'shift_view' => $shift_view,
                        'shift_delete' => $shift_delete,
                        'customer_category_add' => $customer_category_add,
                        'customer_category_edit' => $customer_category_edit,
                        'customer_category_view' => $customer_category_view,
                        'customer_category_delete' => $customer_category_delete,
                        'customer_reporting_add' => $customer_reporting_add,
                        'customer_reporting_edit' => $customer_reporting_edit,
                        'customer_reporting_view' => $customer_reporting_view,
                        'customer_reporting_delete' => $customer_reporting_delete,
                        'customer_add' => $customer_add,
                        'customer_edit' => $customer_edit,
                        'customer_view' => $customer_view,
                        'customer_delete' => $customer_delete,
                        'asset_category_add' => $asset_category_add,
                        'asset_category_edit' => $asset_category_edit,
                        'asset_category_view' => $asset_category_view,
                        'asset_category_delete' => $asset_category_delete,
                        'asset_group_add' => $asset_group_add,
                        'asset_group_edit' => $asset_group_edit,
                        'asset_group_view' => $asset_group_view,
                        'asset_group_delete' => $asset_group_delete,
                        'asset_add' => $asset_add,
                        'asset_edit' => $asset_edit,
                        'asset_view' => $asset_view,
                        'asset_delete' => $asset_delete,
                        'employee_category_add' => $employee_category_add,
                        'employee_category_edit' => $employee_category_edit,
                        'employee_category_view' => $employee_category_view,
                        'employee_category_delete' => $employee_category_delete,
                        'employee_group_add' => $employee_group_add,
                        'employee_group_edit' => $employee_group_edit,
                        'employee_group_view' => $employee_group_view,
                        'employee_group_delete' => $employee_group_delete,
                        'employee_add' => $employee_add,
                        'employee_edit' => $employee_edit,
                        'employee_view' => $employee_view,
                        'employee_delete' => $employee_delete,
                        'item_category_add' => $item_category_add,
                        'item_category_edit' => $item_category_edit,
                        'item_category_view' => $item_category_view,
                        'item_category_delete' => $item_category_delete,
                        'item_group_add' => $item_group_add,
                        'item_group_edit' => $item_group_edit,
                        'item_group_view' => $item_group_view,
                        'item_group_delete' => $item_group_delete,
                        'item_add' => $item_add,
                        'item_edit' => $item_edit,
                        'item_view' => $item_view,
                        'item_delete' => $item_delete,
                        'failure_type_add' => $failure_type_add,
                        'failure_type_edit' => $failure_type_edit,
                        'failure_type_view' => $failure_type_view,
                        'failure_type_delete' => $failure_type_delete,
                        'cycle_time_add' => $cycle_time_add,
                        'cycle_time_edit' => $cycle_time_edit,
                        'cycle_time_view' => $cycle_time_view,
                        'cycle_time_delete' => $cycle_time_delete,
                        'down_time_add' => $down_time_add,
                        'down_time_edit' => $down_time_edit,
                        'down_time_view' => $down_time_view,
                        'down_time_delete' => $down_time_delete,
                        'defect_category_add' => $defect_category_add,
                        'defect_category_edit' => $defect_category_edit,
                        'defect_category_view' => $defect_category_view,
                        'defect_category_delete' => $defect_category_delete,
                        'daily_production_screen_add' => $daily_production_screen_add,
                        'daily_production_screen_edit' => $daily_production_screen_edit,
                        'daily_production_screen_view' => $daily_production_screen_view,
                        'daily_production_screen_delete' => $daily_production_screen_delete,
                        'service_request_category_add' => $service_request_category_add,
                        'service_request_category_edit' => $service_request_category_edit,
                        'service_request_category_view' => $service_request_category_view,
                        'service_request_category_delete' => $service_request_category_delete,
                        'service_request_add' => $service_request_add,
                        'service_request_edit' => $service_request_edit,
                        'service_request_view' => $service_request_view,
                        'service_request_delete' => $service_request_delete,
                        'service_request_mapping_add' => $service_request_mapping_add,
                        'service_request_mapping_edit' => $service_request_mapping_edit,
                        'service_request_mapping_view' => $service_request_mapping_view,
                        'service_request_mapping_delete' => $service_request_mapping_delete,
                        'production_add' => $production_add,
                        'production_edit' => $production_edit,
                        'production_view' => $production_view,
                        'production_delete' => $production_delete,
                        'packing_add' => $packing_add,
                        'packing_edit' => $packing_edit,
                        'packing_view' => $packing_view,
                        'packing_delete' => $packing_delete,
                        'despatch_add' => $despatch_add,
                        'despatch_edit' => $despatch_edit,
                        'despatch_view' => $despatch_view,
                        'despatch_delete' => $despatch_delete,
                        'inward_add' => $inward_add,
                        'inward_edit' => $inward_edit,
                        'inward_view' => $inward_view,
                        'inward_delete' => $inward_delete,
                        'machine_rejection_despatch_add' => $machine_rejection_despatch_add,
                        'machine_rejection_despatch_edit' => $machine_rejection_despatch_edit,
                        'machine_rejection_despatch_view' => $machine_rejection_despatch_view,
                        'machine_rejection_despatch_delete' => $machine_rejection_despatch_delete,
                        'material_rejection_despatch_add' => $material_rejection_despatch_add,
                        'material_rejection_despatch_edit' => $material_rejection_despatch_edit,
                        'material_rejection_despatch_view' => $material_rejection_despatch_view,
                        'material_rejection_despatch_delete' => $material_rejection_despatch_delete,
                        'inspection_completed_add' => $inspection_completed_add,
                        'inspection_completed_edit' => $inspection_completed_edit,
                        'inspection_completed_view' => $inspection_completed_view,
                        'inspection_completed_delete' => $inspection_completed_delete,
                        'master_module_add' => $master_module_add,
                        'master_module_edit' => $master_module_edit,
                        'master_module_view' => $master_module_view,
                        'master_module_delete' => $master_module_delete,
                        'schedule_add' => $schedule_add,
                        'schedule_edit' => $schedule_edit,
                        'schedule_view' => $schedule_view,
                        'schedule_delete' => $schedule_delete,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "employee_role";

                    if ($update != "") {
                        if ($this->common_model->update_details("id", $update, $data_to_store, $table)) {
                            $data['employee_role'] = $this->common_model->find_details("id", $update, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee Role Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee_Role/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        if ($this->common_model->store_details($data_to_store, $table)) {
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee Role added";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee_Role/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            if ($update != "") {

                $data['employee_role'] = $this->common_model->find_details("id", $update, "employee_role");
                if (count($data['employee_role']) > 0) {
                    $this->load->view('Master/Employee_Role/Update_Employee_Role', $data);
                } else {
                    redirect(site_url("Master/Employee_Role"));
                }
            } else {
                $this->load->view('Master/Employee_Role/Add_Employee_Role', $data);
            }
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_role";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Employee Role";
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['employee_role']) > 0) {
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $original_value1 = $this->common_model->find_single_value('name', $this->input->post('name'), 'employee_role', 'name');
                    if ($data['employee_role'][0]['name'] != $this->input->post('name')) {
                        if ($this->input->post('name') === $original_value1) {
                            $is_unique1 = '|is_unique[employee_role.name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("name") . ')</b> already exists.';
                    $this->form_validation->set_rules('name', 'Role Name', 'trim|required' . $is_unique1, array(
                        'required' => 'Code field  is required.',
                        'is_unique' => $error_msg
                    ));
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'name' => $this->input->post('name'),
                            'code' => $this->input->post('code'),
                            'defect_type' => $this->input->post('defect_type'),
                        );
                        $table = "employee_role";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Employee Role Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Employee_Role/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Employee_Role/Update_Employee_Role', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "employee_role";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Employee Role";
            $data['defect_type'] = $this->common_model->find_details("", "", "defect_type");
            $data['employee_role'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Employee_Role/View_Single_Employee_Role', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Employee_Role() {
        $user_role = $this->session->userdata('role_value');
        if ($this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "employee_role";
            $data['this_page'] = "Employee Role";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function image() {
        $user_inp = $this->input->post();

        if (isset($user_inp['customer']) && !empty($user_inp['customer'])) {
            $i = 0;
            foreach ($user_inp['customer'] as $val => $key) {
                $file = $_FILES['file']['name'][$i];
                $_FILES['file']['type'] = $_FILES['file']['type'][$i];
                $_FILES['file']['tmp_name'] = $_FILES['file']['tmp_name'][$i];
                $_FILES['file']['error'] = $_FILES['file']['error'][$i];
                $_FILES['file']['size'] = $_FILES['file']['size'][$i];

                $uploadPath = 'uploads/files/';
                $config['upload_path'] = $uploadPath;
                $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                $this->load->library('upload', $config);
                $this->upload->initialize($config);
                $img_name = "";
                if ($this->upload->do_upload('file')) {

                    $fileData = $this->upload->data();
                    $img_name = $fileData['file_name'];
                    $uploadData[$val]['file_name'] = $fileData['file_name'];
                    $uploadData[$val]['uploaded_on'] = date("Y-m-d H:i:s");
                }
// $this->common_model->store_details($data_to_store, "item_customer_details");
                $i++;
            }
            exit;
        }
    }

    public function logout() {
        if ($this->session->userdata('is_admin') == 0) {
            $this->session->unset_userdata('name_session_list');
            $this->session->unset_userdata('is_admin');
            $this->session->unset_userdata('id_session_list');
            $this->session->unset_userdata('role_value');
            $this->session->unset_userdata('role_array');
            $this->session->unset_userdata('last_activity');
            $this->session->unset_userdata('code_session_list');
            $this->session->unset_userdata('is_logged_in_session');
            redirect(site_url() . 'login');
        } else {
            redirect(site_url() . 'Admin/logout');
        }
    }

    public function Admin_logout() {
        if ($this->session->userdata('is_admin') == 1) {
            $this->session->unset_userdata('name_session_list');
            $this->session->unset_userdata('is_admin');
            $this->session->unset_userdata('role_value');
            $this->session->unset_userdata('role_array');
            $this->session->unset_userdata('id_session_list');
            $this->session->unset_userdata('last_activity');
            $this->session->unset_userdata('code_session_list');
            $this->session->unset_userdata('is_logged_in_session');
            redirect(site_url() . 'Admin/login');
        } else {
            redirect(site_url() . 'Permission_Denied');
        }
    }

    /* Defect_Category End */

    /* Service_Request_Category Start */

    public function Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request Category";
            $data['service_request_category'] = array();
            $table = "service_request_category";
            $field = "";
            $value = "";
            $data['service_request_category'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Service_Request_Category/View_Service_Request_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request Category";
            $data['service_request_category'] = array();
            $table = "service_request_category";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['service_request_category'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['service_request_category'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Service_Request_Category/View_Export_Service_Request_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['employee_role'] = $this->common_model->find_details('', '', 'employee_role');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['status'] = $this->common_model->find_details('', '', 'status');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Service Request Category";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $error_msg = 'This %s <b>(' . $this->input->post("category_name") . ')</b> already exists.';
                $this->form_validation->set_rules('category_name', 'Category Name', 'trim|required|is_unique[service_request_category.category_name]', array(
                    'required' => 'Category Name field  is required.',
                    'is_unique' => $error_msg
                ));
                $this->form_validation->set_rules('category_description', 'Category Description', 'required');
                $this->form_validation->set_rules('department', 'Department', 'required');
                $this->form_validation->set_rules('default_criticality', ' Default Criticality', 'required');
                $this->form_validation->set_rules('multiple_role_notification[]', '<b>Multiple Role Notification</b>', 'required');
                $this->form_validation->set_rules('location[]', '<b>Location </b>', 'required');
                $this->form_validation->set_rules('notification_message[]', '<b>Notification Message</b>', 'required');
                $this->form_validation->set_rules('criticality[]', '<b>Criticality</b>', 'required');
                $this->form_validation->set_rules('assignment_rights[]', '<b>Assignment Rights</b>', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'category_name' => $this->input->post('category_name'),
                        'category_description' => $this->input->post('category_description'),
                        'department' => $this->input->post('department'),
                        'default_criticality' => $this->input->post('default_criticality'),
                        'status' => 1,
                        'df' => 0,
                        'created_at' => date('Y-m-d H:i:s'),
                    );
//if the insert has returned true then we show the flash message
                    $table = "service_request_category";
                    $last_insert_id = $this->common_model->store_details($data_to_store, $table);
                    if ($last_insert_id) {
                        $user_inp = $this->input->post();
                        if (isset($user_inp['multiple_role_notification']) && !empty($user_inp['multiple_role_notification'])) {
                            foreach ($user_inp['multiple_role_notification'] as $val => $key) {
//$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                $data_to_store = array(
                                    'multiple_role_notification' => $user_inp['multiple_role_notification'][$val],
                                    'location' => $user_inp['location'][$val],
                                    'notification_message' => $user_inp['notification_message'][$val],
                                    'criticality' => $user_inp['criticality'][$val],
                                    'service_request_id' => $last_insert_id,
                                    'created_at' => date('Y-m-d H:i:s'),
                                    'status' => 1,
                                    'df' => 0
                                );
                                $this->common_model->store_details($data_to_store, "notification_role");
                            }
                        }

                        if (isset($user_inp['assignment_rights']) && !empty($user_inp['assignment_rights'])) {
                            foreach ($user_inp['assignment_rights'] as $val => $key) {
                                //$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                $data_to_store = array(
                                    'assignment_rights' => $user_inp['assignment_rights'][$val],
                                    'service_request_id' => $last_insert_id,
                                );
                                $this->common_model->store_details($data_to_store, "assignment_role");
                            }
                        }




                        for ($i = 0; $i < count($_FILES['file']['name']); $i++) {
                            $_FILES['files']['name'] = $_FILES['file']['name'][$i];
                            $_FILES['files']['type'] = $_FILES['file']['type'][$i];
                            $_FILES['files']['tmp_name'] = $_FILES['file']['tmp_name'][$i];
                            $_FILES['files']['error'] = $_FILES['file']['error'][$i];
                            $_FILES['files']['size'] = $_FILES['file']['size'][$i];
                            $uploadPath = 'uploads/files/';
                            $config['upload_path'] = $uploadPath;
                            $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                            $this->load->library('upload', $config);
                            $this->upload->initialize($config);
                            $img_name = "";
                            if ($this->upload->do_upload('files')) {
                                $fileData = $this->upload->data();
                                $img_name = $fileData['file_name'];
                            }
                            $data_to_store = array(
                                "file" => $img_name,
                                'service_request_id' => $last_insert_id,
                            );

                            $this->common_model->store_details($data_to_store, "service_request_attachment");
                        }





                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Service Request Category added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Service_Request_Category/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Service_Request_Category/Add_Service_Request_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['employee_role'] = $this->common_model->find_details('', '', 'employee_role');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['status'] = $this->common_model->find_details('', '', 'status');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Service Request Category";
            $data['service_request_category'] = $this->common_model->service_request_category_details("service_request_category.id = " . $value);
            // echo "<pre>";print_r($data['service_request_category']);exit;
            if (count($data['service_request_category']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $original_value1 = $this->common_model->find_single_value('category_name', $this->input->post('category_name'), 'service_request_category', 'category_name');
                    if ($data['service_request_category'][0]['category_name'] != $this->input->post('category_name')) {
                        if ($this->input->post('category_name') === $original_value1) {
                            $is_unique1 = '|is_unique[service_request_category.category_name]';
                        } else {
                            $is_unique1 = '';
                        }
                    } else {
                        $is_unique1 = '';
                    }
                    $error_msg = 'This %s <b>(' . $this->input->post("category_name") . ')</b> already exists.';
                    $this->form_validation->set_rules('category_name', 'Category_Name', 'trim|required' . $is_unique1, array(
                        'required' => 'Category_Name field  is required.',
                        'is_unique' => $error_msg
                    ));


                    $this->form_validation->set_rules('category_description', 'Category Description', 'required');
                    $this->form_validation->set_rules('department', 'Department', 'required');
                    $this->form_validation->set_rules('default_criticality', ' Default Criticality', 'required');
                    $this->form_validation->set_rules('old_multiple_role_notification[]', '<b>Multiple Role Notification</b>', 'required');
                    $this->form_validation->set_rules('old_location[]', '<b>Location </b>', 'required');
                    $this->form_validation->set_rules('old_notification_message[]', '<b>Notification Message</b>', 'required');
                    $this->form_validation->set_rules('old_criticality[]', '<b>Criticality</b>', 'required');
                    $this->form_validation->set_rules('old_assignment_rights[]', '<b>Assignment Rights</b>', 'required');

                    if ($this->form_validation->run()) {

                        $data_to_store = array(
                            'category_name' => $this->input->post('category_name'),
                            'category_description' => $this->input->post('category_description'),
                            'department' => $this->input->post('department'),
                            'default_criticality' => $this->input->post('default_criticality'),
                        );
//if the insert has returned true then we show the flash message
                        $table = "service_request_category";
                        $this->common_model->update_details("id", $value, $data_to_store, $table);
                        $last_insert_id = $value;
                        if ($last_insert_id) {
                            $user_inp = $this->input->post();

                            /* insert role notifications */
                            if (isset($user_inp['multiple_role_notification']) && !empty($user_inp['multiple_role_notification'])) {
                                foreach ($user_inp['multiple_role_notification'] as $val => $key) {
//$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                    $data_to_store = array(
                                        'multiple_role_notification' => $user_inp['multiple_role_notification'][$val],
                                        'location' => $user_inp['location'][$val],
                                        'notification_message' => $user_inp['notification_message'][$val],
                                        'criticality' => $user_inp['criticality'][$val],
                                        'service_request_id' => $last_insert_id,
                                        'created_at' => date('Y-m-d H:i:s'),
                                        'status' => 1,
                                        'df' => 0
                                    );
                                    $this->common_model->store_details($data_to_store, "notification_role");
                                }
                            }


                            /* Update Role Notifications */

                            if (isset($user_inp['old_multiple_role_notification']) && !empty($user_inp['old_multiple_role_notification'])) {
                                foreach ($user_inp['old_multiple_role_notification'] as $val => $key) {
//$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                    $data_to_store = array(
                                        'multiple_role_notification' => $user_inp['old_multiple_role_notification'][$val],
                                        'location' => $user_inp['old_location'][$val],
                                        'notification_message' => $user_inp['old_notification_message'][$val],
                                        'criticality' => $user_inp['old_criticality'][$val],
                                        'service_request_id' => $last_insert_id,
                                    );
                                    $value = $user_inp['notification_role_id'][$val];
                                    $this->common_model->update_details("id", $value, $data_to_store, "notification_role");
                                }
                            }

                            /* Insert Assignment Rights */
                            if (isset($user_inp['assignment_rights']) && !empty($user_inp['assignment_rights'])) {
                                foreach ($user_inp['assignment_rights'] as $val => $key) {
                                    //$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                    $data_to_store = array(
                                        'assignment_rights' => $user_inp['assignment_rights'][$val],
                                        'service_request_id' => $last_insert_id,
                                    );
                                    $this->common_model->store_details($data_to_store, "assignment_role");
                                }
                            }

                            /* Update Assignment Rights */

                            if (isset($user_inp['old_assignment_rights']) && !empty($user_inp['old_assignment_rights'])) {
                                foreach ($user_inp['old_assignment_rights'] as $val => $key) {
                                    //$data = array('cd_id' => $cost_id, 'attr_id' => $key, 'a_unit_value' => $user_inp['a_unit_value'][$val], 'unit_value_attribute' => $user_inp['unit_val'][$val], 'attr_cost' => $user_inp['a_cost'][$val], 'post_dt' => $cur_time);
                                    $data_to_store = array(
                                        'assignment_rights' => $user_inp['old_assignment_rights'][$val],
                                        'service_request_id' => $last_insert_id,
                                    );
                                    $value = $user_inp['assignment_role_id'][$val];
                                    $this->common_model->update_details("id", $value, $data_to_store, "assignment_role");
                                }
                            }
                            for ($i = 0; $i < count($_FILES['file']['name']); $i++) {
                                $_FILES['files']['name'] = $_FILES['file']['name'][$i];
                                $_FILES['files']['type'] = $_FILES['file']['type'][$i];
                                $_FILES['files']['tmp_name'] = $_FILES['file']['tmp_name'][$i];
                                $_FILES['files']['error'] = $_FILES['file']['error'][$i];
                                $_FILES['files']['size'] = $_FILES['file']['size'][$i];
                                $uploadPath = 'uploads/files/';
                                $config['upload_path'] = $uploadPath;
                                $config['allowed_types'] = 'jpg|jpeg|png|gif|pdf';
                                $this->load->library('upload', $config);
                                $this->upload->initialize($config);
                                $img_name = "";

                                if ($this->upload->do_upload('files')) {
                                    $fileData = $this->upload->data();
                                    $img_name = $fileData['file_name'];
                                }
                                if ($img_name != "") {
                                    $data_to_store = array(
                                        "file" => $img_name,
                                        'service_request_id' => $last_insert_id,
                                    );

                                    $this->common_model->store_details($data_to_store, "service_request_attachment");
                                }
                            }

                            $data['service_request_category'] = $this->common_model->service_request_category_details("service_request_category.id = " . $this->uri->segment(4));

                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Service Request Category Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Service_Request_Category/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Service_Request_Category/Update_Service_Request_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function view_Single_Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['employee_role'] = $this->common_model->find_details('', '', 'employee_role');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['status'] = $this->common_model->find_details('', '', 'status');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request_category";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Service Request Category";
            $data['service_request_category'] = $this->common_model->service_request_category_details("service_request_category.id = " . $value);
            $this->load->view('Master/Service_Request_Category/view_Single_Service_Request_Category', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Service_Request_Category() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "service_request_category";
            $data['this_page'] = "Service Request Category";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Notification_Role() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('notification_role_id');
            $table = "notification_role";
            $data['this_page'] = "Service Request Category";
            $this->common_model->delete_details($field, $value, $table);
            echo 1;
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Assignment_Role() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('assignment_role_id');
            $table = "assignment_role";
            $data['this_page'] = "Service Request Category";
            $this->common_model->delete_details($field, $value, $table);
            echo 1;
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Attachment_Files() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_category_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "service_request_attachment";
            $data['this_page'] = "Service Request Category";
            $this->common_model->delete_details($field, $value, $table);
            echo 1;
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Service_Request Category End */


    /* Service_Request Start */

    public function Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request";
            $data['service_request'] = array();
            $table = "service_request";
            $field = "";
            $value = "";
            $data['service_request'] = $this->common_model->service_request_details();
            $this->load->view('Master/Service_Request/View_Service_Request', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request";
            $data['service_request'] = array();
            $table = "service_request";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['service_request'] = $this->common_model->service_request_details("service_request.id=" . $value);
            } else {
                $data['service_request'] = $this->common_model->service_request_details();
            }
            $this->load->view('Master/Service_Request/View_Export_Service_Request', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['service_request_category'] = $this->common_model->find_details('', '', 'service_request_category');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $service_request = $this->common_model->find_last_insert_id('service_request');

            if (count($service_request) > 0) {
                $data['service_id'] = $service_request[0]['id'] + 1;
            } else {
                $data['service_id'] = 1;
            }
            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Service Request";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('service_id', '<b>Service id</b>', 'required');
                $this->form_validation->set_rules('service_creation_date', '<b>Service Creation Date</b>', 'required');
                $this->form_validation->set_rules('user_name', '<b>User Name</b>', 'required');
                $this->form_validation->set_rules('department', '<b>Department</b>', 'required');
                $this->form_validation->set_rules('service_department', '<b>Service Department</b>', 'required');
                $this->form_validation->set_rules('service_category', '<b>Service Request Category</b>', 'required');
                $this->form_validation->set_rules('default_criticality', '<b>Default Criticality</b>', 'required');
                $this->form_validation->set_rules('target_date', '<b>Target Date</b>', 'required');
                $this->form_validation->set_rules('service_summary', '<b>Service Summary</b>', 'required');
                $this->form_validation->set_rules('service_description', '<b>service Description</b>', 'required');
                $this->form_validation->set_rules('asset', '<b>Asset</b>', 'required');
                if ($this->form_validation->run()) {
                    if ($this->session->userdata('is_admin') == 1) {
                        $created_by = 0; //Admin
                    } else {
                        $created_by = $this->session->userdata('id_session_list');
                    }
                    $data_to_store = array(
                        'service_id' => $this->input->post('service_id'),
                        'service_creation_date' => date("Y-m-d", strtotime($this->input->post('service_creation_date'))),
                        'user_name' => $this->input->post('user_name'),
                        'department' => $this->input->post('department'),
                        'service_department' => $this->input->post('service_department'),
                        'service_category' => $this->input->post('service_category'),
                        'default_criticality' => $this->input->post('default_criticality'),
                        'target_date' => date("Y-m-d", strtotime($this->input->post('target_date'))),
                        'service_summary' => $this->input->post('service_summary'),
                        'service_description' => $this->input->post('service_description'),
                        'asset' => $this->input->post('asset'),
                        'status' => 1,
                        'df' => 0,
                        'created_at' => date('Y-m-d H:i:s'),
                        'created_by' => $created_by,
                    );

                    $service_category = $this->common_model->service_request_category_details('service_request_category.id =' . $this->input->post('service_category'));

//if the insert has returned true then we show the flash message
                    $table = "service_request";
                    $last_insert_id = $this->common_model->store_details($data_to_store, $table);
                    if ($last_insert_id) {
                        foreach ($service_category[0]['notification_role'] as $notification_role) {
                            $data_to_store = array(
                                'service_request_id' => $last_insert_id,
                                'notification_from' => $this->input->post('user_name'),
                                'notification_to' => $notification_role['multiple_role_notification'],
                                'location' => $notification_role['location'],
                            );
                            $this->common_model->store_details($data_to_store, "notification");
                        }

                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Service Request added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Service_Request/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Service_Request/Add_Service_Request', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['service_request_category'] = $this->common_model->find_details('', '', 'service_request_category');
            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $service_request = $this->common_model->find_last_insert_id('service_request');
            if (count($service_request) > 0) {
                $data['service_id'] = $service_request[0]['id'] + 1;
            } else {
                $data['service_id'] = 1;
            }

            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Service Request";
            $data['service_request'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['service_request']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $this->form_validation->set_rules('service_id', '<b>Service id</b>', 'required');
                    $this->form_validation->set_rules('service_creation_date', '<b>Service Creation Date</b>', 'required');
                    $this->form_validation->set_rules('user_name', '<b>User Name</b>', 'required');
                    $this->form_validation->set_rules('department', '<b>Department</b>', 'required');
                    $this->form_validation->set_rules('service_department', '<b>Service Department</b>', 'required');
                    $this->form_validation->set_rules('service_category', '<b>Service Request Category</b>', 'required');
                    $this->form_validation->set_rules('default_criticality', '<b>Default Criticality</b>', 'required');
                    $this->form_validation->set_rules('target_date', '<b>Target Date</b>', 'required');
                    $this->form_validation->set_rules('service_summary', '<b>Service Summary</b>', 'required');
                    $this->form_validation->set_rules('service_description', '<b>service Description</b>', 'required');
                    $this->form_validation->set_rules('asset', '<b>Asset</b>', 'required');
                    if ($this->session->userdata('is_admin') == 1) {
                        $created_by = 0; //Admin
                    } else {
                        $created_by = $this->session->userdata('id_session_list');
                    }
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'service_id' => $this->input->post('service_id'),
                            'service_creation_date' => date("Y-m-d", strtotime($this->input->post('service_creation_date'))),
                            'user_name' => $this->input->post('user_name'),
                            'department' => $this->input->post('department'),
                            'service_department' => $this->input->post('service_department'),
                            'service_category' => $this->input->post('service_category'),
                            'default_criticality' => $this->input->post('default_criticality'),
                            'target_date' => date("Y-m-d", strtotime($this->input->post('target_date'))),
                            'service_summary' => $this->input->post('service_summary'),
                            'service_description' => $this->input->post('service_description'),
                            'asset' => $this->input->post('asset'),
                            'updated_at' => date('Y-m-d H:i:s'),
                            'updated_by' => $created_by,
                        );
                        $table = "service_request";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['service_request'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Service Request Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Service_Request/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Service_Request/Update_Service_Request', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Notification() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['service_request_category'] = $this->common_model->find_details('', '', 'service_request_category');
            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $service_request = $this->common_model->find_last_insert_id('service_request');
            if (count($service_request) > 0) {
                $data['service_id'] = $service_request[0]['id'] + 1;
            } else {
                $data['service_id'] = 1;
            }

            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Service Request";
            $data['service_request'] = $this->common_model->find_details($field, $value, $table);
            $data['employee'] = $this->common_model->find_details("parent", $this->session->userdata('id_session_list'), "employee");
            $data['service_request_notifications'] = $this->common_model->service_request_notification_details_for_role_assign("service_request.id=" . $value . "");
            $service_request_id = $this->uri->segment(4);
            $notification_to = $this->uri->segment(5);
            $location = $this->uri->segment(6);
            $field = "service_request_id";
            $value = $service_request_id;
            $field1 = "location";
            $value1 = $location;
            $field2 = "notification_to";
            $value2 = $notification_to;
            $table = "notification";
            $data['this_page'] = "Service Request";
            $data_to_store = array('status' => 1);

            $this->common_model->update_notification_details($field, $value, $field1, $value1, $field2, $value2, $data_to_store, $table);


            if (count($data['service_request']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $this->form_validation->set_rules('service_id', '<b>Service id</b>', 'required');
                    $this->form_validation->set_rules('service_creation_date', '<b>Service Creation Date</b>', 'required');
                    $this->form_validation->set_rules('user_name', '<b>User Name</b>', 'required');
                    $this->form_validation->set_rules('department', '<b>Department</b>', 'required');
                    $this->form_validation->set_rules('service_department', '<b>Service Department</b>', 'required');
                    $this->form_validation->set_rules('service_category', '<b>Service Request Category</b>', 'required');
                    $this->form_validation->set_rules('default_criticality', '<b>Default Criticality</b>', 'required');
                    $this->form_validation->set_rules('target_date', '<b>Target Date</b>', 'required');
                    $this->form_validation->set_rules('service_summary', '<b>Service Summary</b>', 'required');
                    $this->form_validation->set_rules('service_description', '<b>service Description</b>', 'required');
                    $this->form_validation->set_rules('asset', '<b>Asset</b>', 'required');
                    if ($this->session->userdata('is_admin') == 1) {
                        $created_by = 0; //Admin
                    } else {
                        $created_by = $this->session->userdata('id_session_list');
                    }
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'service_id' => $this->input->post('service_id'),
                            'service_creation_date' => date("Y-m-d", strtotime($this->input->post('service_creation_date'))),
                            'user_name' => $this->input->post('user_name'),
                            'department' => $this->input->post('department'),
                            'service_department' => $this->input->post('service_department'),
                            'service_category' => $this->input->post('service_category'),
                            'default_criticality' => $this->input->post('default_criticality'),
                            'target_date' => date("Y-m-d", strtotime($this->input->post('target_date'))),
                            'service_summary' => $this->input->post('service_summary'),
                            'service_description' => $this->input->post('service_description'),
                            'asset' => $this->input->post('asset'),
                            'updated_at' => date('Y-m-d H:i:s'),
                            'updated_by' => $created_by,
                        );
                        $table = "service_request";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['service_request'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Service Request Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Service_Request/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Service_Request/Notification', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function view_Single_Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['department'] = $this->common_model->find_details('', '', 'department');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $data['service_request_category'] = $this->common_model->find_details('', '', 'service_request_category');
            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['default_criticality'] = $this->common_model->find_details('', '', 'default_criticality');
            $service_request = $this->common_model->find_last_insert_id('service_request');
            if (count($service_request) > 0) {
                $data['service_id'] = $service_request[0]['id'] + 1;
            } else {
                $data['service_id'] = 1;
            }

            $data['asset'] = $this->common_model->find_details('', '', 'asset');
            $data['employee_array'] = $this->common_model->find_details("id", $this->session->userdata('id_session_list'), "employee");
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Service Request";
            $data['service_request'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Service_Request/view_Single_Service_Request', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Service_Request() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "service_request";
            $data['this_page'] = "Service Request";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Notification_status() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "service_request_id";
            $value = $this->input->post('service_request_id');

            $field1 = "location";
            $value1 = $this->session->userdata('location');
            $field2 = "notification_to";
            $value2 = $this->session->userdata('role_value');
            $table = "service_request";
            $data['this_page'] = "Service Request";
            $data_to_store = array('status' => 1);
            echo $value2;
            exit;
            $this->common_model->update_notification_details($field, $value, $field1, $value1, $field2, $value2, $data_to_store, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Service_Request End */


    /* Service_Request_Mapping Start */

    public function Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request Mapping";
            $data['service_request_mapping'] = array();
            $table = "service_request_mapping";
            $field = "";
            $value = "";
            $data['service_request_mapping'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Service_Request_Mapping/View_Service_Request_Mapping', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Service Request Mapping";
            $data['service_request_mapping'] = array();
            $table = "service_request_mapping";
            $field = "";
            $value = "";
            $id = $this->uri->segment(4);
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['service_request_mapping'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['service_request_mapping'] = $this->common_model->find_details("", "", $table);
            }
            $this->load->view('Master/Service_Request_Mapping/View_Export_Service_Request_Mapping', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Service Request Mapping";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('category_description', 'Category Description', 'required');
                $error_msg = 'This %s <b>(' . $this->input->post("category_name") . ')</b> already exists.';
                $this->form_validation->set_rules('category_name', 'Category_Name', 'trim|required|is_unique[service_request_mapping.category_name]', array(
                    'required' => 'Category_Name field  is required.',
                    'is_unique' => $error_msg
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'category_name' => $this->input->post('category_name'),
                        'category_description' => $this->input->post('category_description'),
                        // 'remark' => $this->input->post('remark'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "service_request_mapping";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Service Request Mapping added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Service_Request_Mapping/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Service_Request_Mapping/Add_Service_Request_Mapping', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request_mapping";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Service Request Mapping";
            $data['service_request_mapping'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['service_request_mapping']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {




                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'category_description' => $this->input->post('category_description'),
                            'category_name' => $this->input->post('category_name'),
                        );
                        $table = "service_request_mapping";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['service_request_mapping'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Service Request Mapping Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Service_Request_Mapping/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Service_Request_Mapping/Update_Service_Request_Mapping', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function view_Single_Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "service_request_mapping";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Service Request Mapping";
            $data['service_request_mapping'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Service_Request_Mapping/view_Single_Service_Request_Mapping', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Service_Request_Mapping() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'service_request_mapping_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "service_request_mapping";
            $data['this_page'] = "Service Request Mapping";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function uploadimage() {
        if (!empty($_FILES)) {
            $config['upload_path'] = './uploads/files/';
            $config['allowed_types'] = 'gif|jpg|png';
            $config['max_size'] = '100000';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload("file")) {
                echo $this->upload->display_errors();
            } else {
                $upload_data = $this->upload->data();
                $str = $upload_data['file_name'];
                $this->gallery_path = realpath(APPPATH . '../uploads/files/'); //fetching path
                $config1 = array(
                    'source_image' => $upload_data['full_path'], //get original image
                    'new_image' => $this->gallery_path . '/thumbs', //save as new image //need to create thumbs first
                    'maintain_ratio' => true,
                    'width' => 650,
                    'height' => 450
                );
                $this->load->library('image_lib', $config1); //load library
                $this->image_lib->resize(); //generating thumb                
                echo ltrim($str, " ");
            }
        }
    }

    public function deletepropertyimage() {
        $field = "id";
        $value = $this->input->post('image_id');
        $table = "properties_images";
        $fetch_data = "url";
        $img_name = $this->common_model->find_single_value($field, $value, $table, $fetch_data);
        if ($img_name && file_exists($this->upload_path . "/" . $img_name)) {
            unlink($this->upload_path . "/" . $img_name);
        }
        if ($img_name && file_exists($this->upload_path . "/thumbs/" . $img_name)) {
            unlink($this->upload_path . "/thumbs/" . $img_name);
        }
        $field = "id";
        $value = $this->input->post('image_id');
        $table = "properties_images";
        $this->common_model->delete_details($field, $value, $table);
    }

    /* Service_Request_Mapping End */

    /* Customer_Reporting_Group End */

    /* Production Start */

    public function Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Production";
            $data['production'] = array();
            $table = "production";
            $field = "";
            $value = "";
            $data['production'] = $this->common_model->production_details();
            $this->load->view('Master/Production/View_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Production";
            $id = $this->uri->segment(4);
            $data['production'] = array();
            $table = "production";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['production'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['production'] = $this->common_model->production_details();
            }

            $this->load->view('Master/Production/View_Export_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Production";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                $this->form_validation->set_rules('production_quantity', '<b>Production Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_production', '<b>Daily Production</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                        'production_quantity' => $this->input->post('production_quantity'),
                        'daily_production' => $this->input->post('daily_production'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "production";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Production added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Production/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Production/Add_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "production";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Production";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['production'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['production']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('production_quantity', '<b>Production Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_production', '<b>Daily Production</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'production_quantity' => $this->input->post('production_quantity'),
                            'daily_production' => $this->input->post('daily_production'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "production";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['production'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Production Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Production/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Production/Update_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "production";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Production";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['production'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['production']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('production_quantity', '<b>Production Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_production', '<b>Daily Production</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'production_quantity' => $this->input->post('production_quantity'),
                            'daily_production' => $this->input->post('daily_production'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "production";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['production'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Production Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Production/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Production/Daily_Entry_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "production";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Production";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['production'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Production/View_Single_Production', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Production() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'production_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "production";
            $data['this_page'] = "Production";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Production End */



    /* Packing Start */

    public function Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Packing";
            $data['packing'] = array();
            $table = "packing";
            $field = "";
            $value = "";
            $data['packing'] = $this->common_model->packing_details();
            $this->load->view('Master/Packing/View_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Packing";
            $id = $this->uri->segment(4);
            $data['packing'] = array();
            $table = "packing";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['packing'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['packing'] = $this->common_model->packing_details();
            }

            $this->load->view('Master/Packing/View_Export_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Packing";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_packing', '<b>Daily Packing</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_packing' => $this->input->post('daily_packing'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "packing";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Packing added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Packing/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Packing/Add_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "packing";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Packing";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['packing'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['packing']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_packing', '<b>Daily Packing</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_packing' => $this->input->post('daily_packing'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "packing";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['packing'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Packing Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Packing/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Packing/Update_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Packing() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "packing";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Packing";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['packing'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['packing']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_packing', '<b>Daily Packing</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_packing' => $this->input->post('daily_packing'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "packing";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['packing'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Packing Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Packing/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Packing/Daily_Entry_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "packing";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Packing";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['packing'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Packing/View_Single_Packing', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Packing() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'packing_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "packing";
            $data['this_page'] = "Packing";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Packing End */

    /* Despatch Start */

    public function Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Despatch";
            $data['despatch'] = array();
            $table = "despatch";
            $field = "";
            $value = "";
            $data['despatch'] = $this->common_model->despatch_details();
            $this->load->view('Master/Despatch/View_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Despatch";
            $id = $this->uri->segment(4);
            $data['despatch'] = array();
            $table = "despatch";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['despatch'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['despatch'] = $this->common_model->despatch_details();
            }

            $this->load->view('Master/Despatch/View_Export_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Despatch";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_despatch', '<b>Daily Despatch</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_despatch' => $this->input->post('daily_despatch'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "despatch";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Despatch added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Despatch/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Despatch/Add_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_despatch', '<b>Daily Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_despatch' => $this->input->post('daily_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Despatch/Update_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Despatch() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');
                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_despatch', '<b>Daily Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_despatch' => $this->input->post('daily_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Despatch/Daily_Entry_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['despatch'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Despatch/View_Single_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'despatch_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "despatch";
            $data['this_page'] = "Despatch";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Despatch End */


    /* Inward Start */

    public function Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Inward";
            $data['inward'] = array();
            $table = "inward";
            $field = "";
            $value = "";
            $data['inward'] = $this->common_model->inward_details();
            $this->load->view('Master/Inward/View_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Inward";
            $id = $this->uri->segment(4);
            $data['inward'] = array();
            $table = "inward";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['inward'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['inward'] = $this->common_model->inward_details();
            }

            $this->load->view('Master/Inward/View_Export_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Inward";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_inward', '<b>Daily Inward</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_inward' => $this->input->post('daily_inward'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "inward";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Inward added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Inward/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Inward/Add_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inward";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Inward";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['inward'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['inward']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_inward', '<b>Daily Inward</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_inward' => $this->input->post('daily_inward'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "inward";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['inward'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Inward Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Inward/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Inward/Update_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Inward() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inward";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Inward";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['inward'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['inward']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_inward', '<b>Daily Inward</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_inward' => $this->input->post('daily_inward'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "inward";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['inward'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Inward Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Inward/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Inward/Daily_Entry_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inward";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Inward";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['inward'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Inward/View_Single_Inward', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Inward() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inward_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "inward";
            $data['this_page'] = "Inward";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Inward End */

    /* Machine_Rejection_Despatch Start */

    public function Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Machine_Rejection_Despatch";
            $data['machine_rejection_despatch'] = array();
            $table = "machine_rejection_despatch";
            $field = "";
            $value = "";
            $data['machine_rejection_despatch'] = $this->common_model->machine_rejection_despatch_details();
            $this->load->view('Master/Machine_Rejection_Despatch/View_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Machine_Rejection_Despatch";
            $id = $this->uri->segment(4);
            $data['machine_rejection_despatch'] = array();
            $table = "machine_rejection_despatch";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['machine_rejection_despatch'] = $this->common_model->machine_rejection_despatch_details();
            }

            $this->load->view('Master/Machine_Rejection_Despatch/View_Export_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Machine_Rejection_Despatch";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_machine_rejection_despatch', '<b>Daily Machine_Rejection_Despatch</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_machine_rejection_despatch' => $this->input->post('daily_machine_rejection_despatch'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "machine_rejection_despatch";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Machine_Rejection_Despatch added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Machine_Rejection_Despatch/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Machine_Rejection_Despatch/Add_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "machine_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Machine_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['machine_rejection_despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_machine_rejection_despatch', '<b>Daily Machine_Rejection_Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_machine_rejection_despatch' => $this->input->post('daily_machine_rejection_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "machine_rejection_despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Machine_Rejection_Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Machine_Rejection_Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Machine_Rejection_Despatch/Update_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Machine_Rejection_Despatch() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "machine_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Machine_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['machine_rejection_despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_machine_rejection_despatch', '<b>Daily Machine_Rejection_Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_machine_rejection_despatch' => $this->input->post('daily_machine_rejection_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "machine_rejection_despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Machine_Rejection_Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Machine_Rejection_Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Machine_Rejection_Despatch/Daily_Entry_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "machine_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Machine_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['machine_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Machine_Rejection_Despatch/View_Single_Machine_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Machine_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'machine_rejection_despatch_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "machine_rejection_despatch";
            $data['this_page'] = "Machine_Rejection_Despatch";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Machine_Rejection_Despatch End */

    /* Material_Rejection_Despatch Start */

    public function Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Material_Rejection_Despatch";
            $data['material_rejection_despatch'] = array();
            $table = "material_rejection_despatch";
            $field = "";
            $value = "";
            $data['material_rejection_despatch'] = $this->common_model->material_rejection_despatch_details();
            $this->load->view('Master/Material_Rejection_Despatch/View_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Material_Rejection_Despatch";
            $id = $this->uri->segment(4);
            $data['material_rejection_despatch'] = array();
            $table = "material_rejection_despatch";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['material_rejection_despatch'] = $this->common_model->material_rejection_despatch_details();
            }

            $this->load->view('Master/Material_Rejection_Despatch/View_Export_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Material_Rejection_Despatch";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_material_rejection_despatch', '<b>Daily Material_Rejection_Despatch</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_material_rejection_despatch' => $this->input->post('daily_material_rejection_despatch'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "material_rejection_despatch";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Material_Rejection_Despatch added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Material_Rejection_Despatch/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Material_Rejection_Despatch/Add_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "material_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Material_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['material_rejection_despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_material_rejection_despatch', '<b>Daily Material_Rejection_Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_material_rejection_despatch' => $this->input->post('daily_material_rejection_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "material_rejection_despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Material_Rejection_Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Material_Rejection_Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Material_Rejection_Despatch/Update_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Material_Rejection_Despatch() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "material_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Material_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['material_rejection_despatch']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_material_rejection_despatch', '<b>Daily Material_Rejection_Despatch</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_material_rejection_despatch' => $this->input->post('daily_material_rejection_despatch'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "material_rejection_despatch";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Material_Rejection_Despatch Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Material_Rejection_Despatch/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Material_Rejection_Despatch/Daily_Entry_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "material_rejection_despatch";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Material_Rejection_Despatch";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['material_rejection_despatch'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Material_Rejection_Despatch/View_Single_Material_Rejection_Despatch', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Material_Rejection_Despatch() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'material_rejection_despatch_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "material_rejection_despatch";
            $data['this_page'] = "Material_Rejection_Despatch";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Material_Rejection_Despatch End */


    /* Inspection_Completed Start */

    public function Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Inspection_Completed";
            $data['inspection_completed'] = array();
            $table = "inspection_completed";
            $field = "";
            $value = "";
            $data['inspection_completed'] = $this->common_model->inspection_completed_details();
            $this->load->view('Master/Inspection_Completed/View_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Inspection_Completed";
            $id = $this->uri->segment(4);
            $data['inspection_completed'] = array();
            $table = "inspection_completed";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['inspection_completed'] = $this->common_model->inspection_completed_details();
            }

            $this->load->view('Master/Inspection_Completed/View_Export_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Inspection_Completed";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                $this->form_validation->set_rules('daily_inspection_completed', '<b>Daily Inspection_Completed</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'total_quantity' => $this->input->post('total_quantity'),
                        'daily_inspection_completed' => $this->input->post('daily_inspection_completed'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "inspection_completed";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Inspection_Completed added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Inspection_Completed/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Inspection_Completed/Add_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inspection_completed";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Inspection_Completed";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['inspection_completed']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_inspection_completed', '<b>Daily Inspection_Completed</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_inspection_completed' => $this->input->post('daily_inspection_completed'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "inspection_completed";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Inspection_Completed Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Inspection_Completed/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Inspection_Completed/Update_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Inspection_Completed() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inspection_completed";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Inspection_Completed";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['inspection_completed']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('date', '<b>Date</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('total_quantity', '<b>Total Quantity</b>', 'required');
                    $this->form_validation->set_rules('daily_inspection_completed', '<b>Daily Inspection_Completed</b>', 'required');
                    if ($this->form_validation->run()) {
                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'date' => date("Y-m-d", strtotime($this->input->post('date'))),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'total_quantity' => $this->input->post('total_quantity'),
                            'daily_inspection_completed' => $this->input->post('daily_inspection_completed'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "inspection_completed";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Inspection_Completed Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Inspection_Completed/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Inspection_Completed/Daily_Entry_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "inspection_completed";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Inspection_Completed";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['inspection_completed'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Inspection_Completed/View_Single_Inspection_Completed', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Inspection_Completed() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'inspection_completed_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "inspection_completed";
            $data['this_page'] = "Inspection_Completed";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Inspection_Completed End */

    /* Master_Module Start */

    public function Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Master_Module";
            $data['master_module'] = array();
            $table = "master_module";
            $field = "";
            $value = "";
            $data['master_module'] = $this->common_model->find_details($field, $value, $table);
            $this->load->view('Master/Master_Module/View_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Master_Module";
            $id = $this->uri->segment(4);
            $data['master_module'] = array();
            $table = "master_module";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['master_module'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['master_module'] = $this->common_model->find_details($field, $value, $table);
            }

            $this->load->view('Master/Master_Module/View_Export_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Master_Module";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                $this->form_validation->set_rules('part_no', '<b>Part No</b>', 'required');
                $this->form_validation->set_rules('customer_code', '<b>Customer Code</b>', 'required');
                $this->form_validation->set_rules('part_code', '<b>Part Code</b>', 'required');
                $this->form_validation->set_rules('location', '<b>Location</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'category' => $this->input->post('category'),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'part_no' => $this->input->post('part_no'),
                        'customer_code' => $this->input->post('customer_code'),
                        'part_code' => $this->input->post('part_code'),
                        'location' => $this->input->post('location'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "master_module";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Master Module added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Master_Module/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Master_Module/Add_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "master_module";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Master_Module";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['master_module'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['master_module']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('part_no', '<b>Part No</b>', 'required');
                    $this->form_validation->set_rules('customer_code', '<b>Customer Code</b>', 'required');
                    $this->form_validation->set_rules('part_code', '<b>Part Code</b>', 'required');
                    $this->form_validation->set_rules('location', '<b>Location</b>', 'required');

                    if ($this->form_validation->run()) {

                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'category' => $this->input->post('category'),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'part_no' => $this->input->post('part_no'),
                            'customer_code' => $this->input->post('customer_code'),
                            'part_code' => $this->input->post('part_code'),
                            'location' => $this->input->post('location'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "master_module";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['master_module'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Master Module Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Master_Module/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Master_Module/Update_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Master_Module() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "master_module";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Master_Module";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['master_module'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['master_module']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {
                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');
                    $this->form_validation->set_rules('part_no', '<b>Part No</b>', 'required');
                    $this->form_validation->set_rules('customer_code', '<b>Customer Code</b>', 'required');
                    $this->form_validation->set_rules('part_code', '<b>Part Code</b>', 'required');
                    $this->form_validation->set_rules('location', '<b>Location</b>', 'required');

                    if ($this->form_validation->run()) {

                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'category' => $this->input->post('category'),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'part_no' => $this->input->post('part_no'),
                            'customer_code' => $this->input->post('customer_code'),
                            'part_code' => $this->input->post('part_code'),
                            'location' => $this->input->post('location'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "master_module";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['master_module'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Master_Module Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Master_Module/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Master_Module/Daily_Entry_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['location'] = $this->common_model->find_details('', '', 'location');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "master_module";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Master_Module";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['master_module'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Master_Module/View_Single_Master_Module', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Master_Module() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'master_module_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "master_module";
            $data['this_page'] = "Master_Module";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Master_Module End */

    /* Schedule Start */

    public function Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Schedule";
            $data['schedule'] = array();
            $table = "schedule";
            $field = "";
            $value = "";
            $data['schedule'] = $this->common_model->schedule_details();
            $this->load->view('Master/Schedule/View_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Export_Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');

            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['this_page'] = "Schedule";
            $id = $this->uri->segment(4);
            $data['schedule'] = array();
            $table = "schedule";
            $field = "";
            $value = "";
            if ($id != "") {
                $field = "id";
                $value = $id;
                $data['schedule'] = $this->common_model->find_details($field, $value, $table);
            } else {
                $data['schedule'] = $this->common_model->schedule_details();
            }

            $this->load->view('Master/Schedule/View_Export_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Add_Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_add');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $data['this_page'] = "Schedule";

            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');

                if ($this->form_validation->run()) {

                    $data_to_store = array(
                        'customer' => $this->input->post('customer'),
                        'category' => $this->input->post('category'),
                        'part_name' => $this->input->post('part_name'),
                        'drawing_no' => $this->input->post('drawing_no'),
                        'revision_no' => $this->input->post('revision_no'),
                        'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                        'status' => 0,
                        'df' => 0,
                        'created_at' => $cur_time,
                    );
//if the insert has returned true then we show the flash message
                    $table = "schedule";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#57b91b";
                        $data['message'] = "Schedule added";
                        header('Refresh:1; url= ' . site_url() . 'Master/Schedule/');
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Some problem occur please try again later";
                    }
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['message'] = "Validation Error";
                }
            }
            $this->load->view('Master/Schedule/Add_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Update_Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "schedule";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Schedule";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['schedule'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['schedule']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');

                    if ($this->form_validation->run()) {

                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'category' => $this->input->post('category'),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "schedule";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['schedule'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Schedule Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Schedule/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Schedule/Update_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Daily_Entry_Schedule() {

        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_edit');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "schedule";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['this_page'] = "Schedule";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');

            $data['schedule'] = $this->common_model->find_details($field, $value, $table);
            if (count($data['schedule']) > 0) {
// $data['category'] = $this->common_model->find_details("", "", "category");
                if ($this->input->server('REQUEST_METHOD') === 'POST') {

                    $this->form_validation->set_rules('customer', '<b>Customer</b>', 'required');
                    $this->form_validation->set_rules('category', '<b>Category</b>', 'required');
                    $this->form_validation->set_rules('part_name', '<b>Part Name</b>', 'required');
                    $this->form_validation->set_rules('drawing_no', '<b>Drawing No</b>', 'required');
                    $this->form_validation->set_rules('revision_no', '<b>Revision No</b>', 'required');

                    $this->form_validation->set_rules('scheduled_quantity', '<b>Scheduled Quantity</b>', 'required');

                    if ($this->form_validation->run()) {

                        $data_to_store = array(
                            'customer' => $this->input->post('customer'),
                            'category' => $this->input->post('category'),
                            'part_name' => $this->input->post('part_name'),
                            'drawing_no' => $this->input->post('drawing_no'),
                            'revision_no' => $this->input->post('revision_no'),
                            'scheduled_quantity' => $this->input->post('scheduled_quantity'),
                            'status' => 0,
                            'df' => 0,
                            'created_at' => $cur_time,
                        );
                        $table = "schedule";
                        if ($this->common_model->update_details($field, $value, $data_to_store, $table)) {
                            $data['schedule'] = $this->common_model->find_details($field, $value, $table);
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['message'] = "Schedule Updated";
                            header('Refresh:1; url= ' . site_url() . 'Master/Schedule/');
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['message'] = "Some problem occur please try again later";
                        }
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['message'] = "Validation Error";
                    }
                }
            } else {
                redirect(site_url());
            }
            $this->load->view('Master/Schedule/Daily_Entry_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function View_Single_Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_view');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $data['customer'] = $this->common_model->find_details('', '', 'customer');
            $data['item_category'] = $this->common_model->find_details('', '', 'item_category');
            $data['empty'] = "";
            $data['this_page_head'] = "Master";
            $data['color_code'] = "";
            $data['message'] = "";
            $table = "schedule";
            $field = "id";
            $value = $this->uri->segment(4);
            $data['main_id'] = $value;
            $data['this_page'] = "Schedule";
            $date = new DateTime('now', new DateTimeZone('Asia/Kolkata'));
            $cur_time = $date->format('Y-m-d H:i:s');
            $data['schedule'] = $this->common_model->find_details($field, $value, $table);


            $this->load->view('Master/Schedule/View_Single_Schedule', $data);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    public function Delete_Schedule() {
        $user_role = $this->session->userdata('role_value');
        $user_permissions_view_customer = $this->common_model->find_single_value('id', $user_role, 'employee_role', 'schedule_delete');
        if ($user_permissions_view_customer == 1 || $this->session->userdata('is_admin') == 1) {
            $data['user_role_details'] = $this->common_model->find_details('id', $user_role, 'employee_role');
            $field = "id";
            $value = $this->input->post('id');
            $table = "schedule";
            $data['this_page'] = "Schedule";
            $this->common_model->delete_details($field, $value, $table);
        } else {
            redirect(site_url('Permission_Denied'));
        }
    }

    /* Schedule End */
}
