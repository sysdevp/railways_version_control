<?php

class Admin_Home extends CI_Controller {

    private $upload_path = "./uploads/files";

    public function __construct() {
        parent::__construct();
        date_default_timezone_set('Asia/Kolkata');
     //   print_r($this->session->userdata());exit;
        $nowtime = date('Y-m-d H:i:s', time());
        $Minutes = $this->common_model->find_single_value("SessionTimeOutID", "1", "tblsessiontimeoutmaster", "Minutes");
        $interval = $Minutes * 60;
        if (!$this->session->userdata('HelpSession')) {
            $data_session = array(
                "HelpSession" => $this->common_model->find_details("RecordStatus = 1", "tblhelpmaster", "HelpName, HelpID")
            );
            $this->session->set_userdata($data_session);
        }
        if ($this->session->userdata('last_activity') != false) {
            if ($this->session->userdata('last_activity') < time() - $interval) {
                $this->session->unset_userdata('is_logged_in_session');
                $this->session->unset_userdata('last_activity');
                redirect(site_url() . 'Admin/login');
            } else {
                $datas['last_activity'] = time();
                $this->session->set_userdata($datas);
            }
        } else {
            redirect(site_url() . 'Admin/login');
        }
        if ($this->uri->segment(2) == "addnew-version") {

            $datatostore = array(
                "VersionID",
                "RailwayID",
                "DivisionID",
                'StationID',
                'VendorID',
                "ApplicationDownloadPath",
                "ApplicationFolderCountAvailable",
                "ApplicationFileCountAvailable",
                "ApplicationImportantFilesAvailable",
                "InterfaceDownloadPath",
                "InterfaceFolderCountAvailable",
                "InterfaceFileCountAvailable",
                "InterfaceImportantFilesAvailable",
                "VduDownloadPath",
                "VduFolderCountAvailable",
                "VduFileCountAvailable",
                "VduImportantFilesAvailable",
                "NoOfCPU",
                "isDistributedVersionType",
                'SignalPlanNumber',
                "InstallationAlterationDate",
                "DescriptionOfWork",
                'WorkExecutedBy',
                "PreviousESwVersion",
                "PreviousESwChecksum",
                'CurrentESwVersion',
                "CurrentESwChecksum",
                'CreatedBy',
                'ModifiedBy',
                'CreatedOn',
                'ModifiedOn',
                'temp_parameter_details',
                "temp_cpu_details",
                "ApplicationFolderVal",
                "ApplicationFileVal",
                "ApplicationImportantFilesVal",
                "InterfaceFolderVal",
                "InterfaceFileVal",
                "InterfaceImportantFilesVal",
                "VduFolderVal",
                "VduFileVal",
                "VduImportantFilesVal",
                "VersionID",
                "ApplicationFileImportant",
                "InterfaceFileImportant",
                "VduFileImportant",
            );
            $this->session->unset_userdata($datatostore);
        }
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        
        if($this->session->userdata("UserRole")!="Admin")
        {
            $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
            if (count($user_details) > 0) {
                $cond = array(
                    "DesignationID" => $user_details[0]['DesignationID'],
                    "LevelID" => $user_details[0]['LevelID'],
                );
                $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
                if (count($user_role_details) > 0) {
                    if ((strpos($this->uri->segment(2), "edit") === 0 && strpos($this->uri->segment(2), "edit-role") !== 0 && strpos($this->uri->segment(2), "edit-designation") !== 0) && $user_role_details[0]['Edit'] != 1) {
                        redirect(site_url('Admin/unauthorized'));
                    }
                    if ((strpos($this->uri->segment(2), "view") === 0 || strpos($this->uri->segment(2), "user-rights") === 0 || strpos($this->uri->segment(2), "error-report") === 0 || strpos($this->uri->segment(2), "settings-ip") === 0 || strpos($this->uri->segment(2), "settings-version") === 0 || strpos($this->uri->segment(2), "security-settings") === 0 || strpos($this->uri->segment(2), "version-file-names") === 0 || strpos($this->uri->segment(2), "version-desc-exec") === 0 || strpos($this->uri->segment(2), "version-req-fields") === 0 || strpos($this->uri->segment(2), "view-versionmodificationlimit") === 0) && $user_role_details[0]['View'] != 1) {
                        redirect(site_url('Admin/unauthorized'));
                    }

                    if ((strpos($this->uri->segment(2), "create") === 0 || strpos($this->uri->segment(2), "addnew") === 0 || strpos($this->uri->segment(2), "version-file-types") === 0) && $user_role_details[0]['Save'] != 1) {
                        redirect(site_url('Admin/unauthorized'));
                    }


                    if (strpos($this->uri->segment(2), "delete") === 0 && $user_role_details[0]['Remove'] != 1) {
                        redirect(site_url('Admin/unauthorized'));
                    }
                }
            }
        }

    //    ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);
    }

    function update_module_security() {
        $post = $this->input->post();
        foreach ($post["menu_id"] as $key => $value) {
            $this->db->update("tbl_menu_security_setting", array("security_level" => $post["security_level"][$key]), array("menu_id" => $value));
        }
        $this->session->set_flashdata("success_done", 'Succesfully Updated');

        redirect('Admin/module_security_level');
    }

    public function module_security_level() {

        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "menu_security_level";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');



        $data["security"] = $this->common_model->find_details("", "tblsecuritysettings", "*");



        $this->db->order_by("menu_id", "asc");
        $data["modules"] = $this->common_model->find_details("", "tbl_menu_security_setting", "*");
        $data['color_code'] = "#3a5a9c";
        $data['display_value'] = "block";
        $data['message'] = "Division Added";
        $data['flash_message'] = TRUE;

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            $data['edit_button_rights'] = $user_role_details[0]['Edit'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
        $this->load->view('Admin/module_security', $data, FALSE);
    }

    public function select_user() {

        $post = $this->input->post();

        $cond = array("RailwayID" => $post["RailwayID"], "DivisionID" => $post["DivisionID"], "StationID" => $post["StationID"]);

        $data['user'] = $this->common_model->find_details($cond, "tblusermaster", "*");
        $this->load->view('Admin/Ajax/Users_list', $data);
    }

    public function unauthorized() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/unauthorized', $data);
    }
	
	public function connectivitynotexist($status = "") {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
		$state = 0;
		if(isset($status) && $status != '')
		{
			$state = 1;
		}
        $data['state'] = $state;
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/noconnection', $data);
    }

    public function syncsuccess() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/syncsuccess', $data);
    }

    public function index() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['tour_visible'] = "active";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');
		$data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
		
        $this->load->view('Admin/index', $data);
    }

    public function Zone_Chg_Dashboard() {
		
		$value = $this->input->post("id");
        if ($value != "") {
            $RailwaySelectID = $value;
			$query_0 = "create temporary table temp0
	select MAX(tblversiondefine.ID) as 'ID' from tblversiondefine where tblversiondefine.RecordStatus=1 AND tblversiondefine.RailwayID= " . $value . " GROUP by 
	tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID";
	$this->db->query($query_0);
			$query_1 = "create temporary table temp1
	select temp0.ID, tblversiondefine.VendorID,tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID from 
temp0 inner join tblversiondefine on temp0.ID=tblversiondefine.ID";
	/*$query_1 = "create temporary table temp1
	select MAX(tblversiondefine.CreatedOn), tblversiondefine.ID as 'ID',tblversiondefine.VendorID,tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID from tblversiondefine where tblversiondefine.RecordStatus=1 AND tblversiondefine.RailwayID=" . $value . " GROUP by 
	tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID";*/
    $this->db->query($query_1);
   // print_r($query_1); echo nl2br("\n");
    $query_2 = "create temporary table temp2
    select temp1.RailwayID,temp1.DivisionID,temp1.StationID, temp1.VendorID, count(temp1.ID) as 'count' from temp1 
    GROUP by temp1.VendorID";
   // print_r($query_2); echo nl2br("\n");
    $this->db->query($query_2);
    
    $query = "select temp2.VendorID, tblvendormaster.VendorName,IFNULL(temp2.count, 0) as 'count',temp2.RailwayID,temp2.DivisionID,temp2.StationID  from tblvendormaster left join temp2 on 
    tblvendormaster.VendorID=temp2.VendorId"; 
//print_r($query); 
				$cond3 = array(
					"RailwayID" => $value
				);

				$zone_name = '- '.$this->common_model->find_details($cond3, "tblrailwaymaster", "RailwayName")[0]["RailwayName"];
			
			
			$data['zoneid'] = $value;
			$data['zone_name'] = $zone_name;
			$data['dashboard'] = $this->common_model->find_dashboard_det($query);
			
			$connectivity_qry = $this->common_model->find_details(array("RailwayId"=>1), "tblserveripdivisionwise", "DivisionId,ConnectionStatus");
			$connectivity = [];
			$connectivity['MAS'] = 0;
		    $connectivity['TPJ'] = 0;
		    $connectivity['MDU'] = 0;
		    $connectivity['PGT'] = 0;
		    $connectivity['SA'] = 0;
		    $connectivity['TVC'] = 0;
			foreach($connectivity_qry as $row) { 
			    if($row['DivisionId']==1) { 
			        $connectivity['MAS'] = $row['ConnectionStatus'];
			    }
			    if($row['DivisionId']==2) {
			        $connectivity['TPJ'] = $row['ConnectionStatus'];
			    }
			    if($row['DivisionId']==3) {
			        $connectivity['MDU'] = $row['ConnectionStatus'];
			    }
			    if($row['DivisionId']==4) {
			        $connectivity['PGT'] = $row['ConnectionStatus'];
			    }
			    if($row['DivisionId']==5) {
			        $connectivity['SA'] = $row['ConnectionStatus'];
			    }
			    if($row['DivisionId']==6) {
			        $connectivity['TVC'] = $row['ConnectionStatus'];
			    }
			}
			$data['connectivity'] = $connectivity;
            
            $this->load->view('Admin/Ajax/Zone_Chg_Dashboard', $data);
        } else {
            echo "0";
        }
	}
	
    public function check_security_level() {

        $post = $this->input->post();
        $check = $this->common_model->find_details(array("RailwayID" => $post["zone"], "DivisionID" => $post["division"], "StationID" => $post["station"]), "tblversiondefine", "count(RailwayID) cnt")[0];
        if ($check["cnt"] > 0) {
            $level = 1;
        } else {
            $level = 2;
        }
        die(json_encode(array("level" => $level)));
    }

    public function LoadAjax($file = "") {
        if ($file != "") {
            $data['empty'] = "";
            echo $this->load->view('Admin/Ajax/' . $file, $data);
        }
    }

    public function dashboard_division($rid, $did, $vid = "", $sid = "", $verid = "") {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');
        $query = "create TEMPORARY TABLE tempmain
            select CurrentESwChecksum, InstallationAlterationDate, isDistributedVersionType, VersionNo, RailwayID,DivisionID,StationID,VendorID,MAX(VersionID)as 'VersionID' from tblversiondefine where  RecordStatus = 1 group by RailwayID,DivisionID,StationID,VendorID";
        $query_select = "create TEMPORARY TABLE tempmain2 select RailwayID,DivisionID,StationID,VendorID,VersionID from tempmain where RailwayID='" . $rid . "' and DivisionID='" . $did . "'";
        $query_2 = "SELECT `tblversiondefine`.`VersionNO`, `tbldivisionmaster`.`DivisionID`, `tbldivisionmaster`.`DivisionCode`, `tbldivisionmaster`.`DivisionName`, `tblrailwaymaster`.`RailwayID`, `tblrailwaymaster`.`RailwayCode`, `tblrailwaymaster`.`RailwayName`, `tblstationmaster`.`StationID`, `tblstationmaster`.`StationCode`, `tblstationmaster`.`StationName`, `tblvendormaster`.`VendorID`, `tblvendormaster`.`VendorName`, `tblversiondefine`.`InstallationAlterationDate`, `tblversiondefine`.`WorkExecutedBy` ,`tblversiondefine`.`VersionNo`, `tblversiondefine`.`CurrentESwChecksum`, `tblversiondefine`.`isDistributedVersionType`, `tblversiondefine`.`VersionID` FROM `tempmain2` INNER JOIN `tblversiondefine` ON `tblversiondefine`.`RailwayID`=`tempmain2`.`RailwayID` AND `tempmain2`.`DivisionID`=`tblversiondefine`.`DivisionID` AND `tempmain2`.`StationID`=`tblversiondefine`.`StationID` AND `tempmain2`.`VendorID`=`tblversiondefine`.`VendorID` AND `tempmain2`.`VersionID`=`tblversiondefine`.`VersionID` INNER JOIN `tblrailwaymaster` ON `tblrailwaymaster`.`RailwayID`=`tblversiondefine`.`RailwayID` INNER JOIN `tbldivisionmaster` ON `tbldivisionmaster`.`RailwayID`=`tblversiondefine`.`RailwayID` AND `tbldivisionmaster`.`DivisionID`=`tblversiondefine`.`DivisionID` INNER JOIN `tblstationmaster` ON `tblstationmaster`.`RailwayID`=`tblversiondefine`.`RailwayID` AND `tblstationmaster`.`DivisionID`=`tblversiondefine`.`DivisionID` AND `tblstationmaster`.`StationID`=`tblversiondefine`.`StationID` INNER JOIN `tblvendormaster` ON `tblvendormaster`.`VendorID`=`tblversiondefine`.`VendorID`";
        $data['dashboard'] = $this->common_model->find_dashboard_details("", $query, $query_select, $query_2);
        //$data['dashboard'] = $this->common_model->find_version_details_latest();
        $this->load->view('Admin/Division/division', $data);
    }

    public function dashboard_vendor($vid, $RailwayID) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['vendor'] = $this->common_model->find_details("VendorID = '" . $vid . "'", "tblvendormaster");
        $data['asset_url'] = site_url('assets/themes/');
		$qq = "create TEMPORARY TABLE temp0
	select MAX(tblversiondefine.ID) as 'ID' from tblversiondefine where tblversiondefine.RecordStatus=1 GROUP by 
	tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID";
	$this->db->query($qq);
        $query = "create TEMPORARY TABLE tempmain
            select CurrentESwChecksum, InstallationAlterationDate, isDistributedVersionType, VersionNo, RailwayID,DivisionID,StationID,VendorID,VersionID as 'VersionID' 
from temp0 inner join tblversiondefine on temp0.ID=tblversiondefine.id";
			/*$query = "create TEMPORARY TABLE tempmain
            select CurrentESwChecksum, InstallationAlterationDate, isDistributedVersionType, VersionNo, RailwayID,DivisionID,StationID,VendorID,MAX(CreatedOn) as 'CreatedOn',VersionID from tblversiondefine where  tblversiondefine.RecordStatus = 1 group by tblversiondefine.RailwayID,tblversiondefine.DivisionID,tblversiondefine.StationID";*/

        $userdtet = $this->common_model->find_details(array("UserID" => $this->session->userdata('id_session_list')), "tblusermaster", "RailwayID,LevelID")[0];
        if ($userdtet["LevelID"] == "1") {
            $query_select = "create TEMPORARY TABLE tempmain2 select RailwayID,DivisionID,StationID,VendorID,VersionID from tempmain where VendorID='" . $vid . "'";
        } else {
            $query_select = "create TEMPORARY TABLE tempmain2 select RailwayID,DivisionID,StationID,VendorID,VersionID from tempmain where VendorID='" . $vid . "' AND RailwayID='" . $RailwayID . "'";
        }



        $query_2 = "SELECT tblversiondefine.WorkExecutedBy, `tblversiondefine`.`VersionNO`, `tbldivisionmaster`.`DivisionID`, `tbldivisionmaster`.`DivisionCode`, `tbldivisionmaster`.`DivisionName`, `tblrailwaymaster`.`RailwayID`, `tblrailwaymaster`.`RailwayCode`, `tblrailwaymaster`.`RailwayName`, `tblstationmaster`.`StationID`, `tblstationmaster`.`StationCode`, `tblstationmaster`.`StationName`, `tblvendormaster`.`VendorID`, `tblvendormaster`.`VendorName`, `tblversiondefine`.`InstallationAlterationDate`, `tblversiondefine`.`VersionNo`, `tblversiondefine`.`CurrentESwChecksum`, `tblversiondefine`.`isDistributedVersionType`, `tblversiondefine`.`VersionID` FROM `tempmain2` INNER JOIN `tblversiondefine` ON `tblversiondefine`.`RailwayID`=`tempmain2`.`RailwayID` AND `tempmain2`.`DivisionID`=`tblversiondefine`.`DivisionID` AND `tempmain2`.`StationID`=`tblversiondefine`.`StationID` AND `tempmain2`.`VendorID`=`tblversiondefine`.`VendorID` AND `tempmain2`.`VersionID`=`tblversiondefine`.`VersionID` INNER JOIN `tblrailwaymaster` ON `tblrailwaymaster`.`RailwayID`=`tblversiondefine`.`RailwayID` INNER JOIN `tbldivisionmaster` ON `tbldivisionmaster`.`RailwayID`=`tblversiondefine`.`RailwayID` AND `tbldivisionmaster`.`DivisionID`=`tblversiondefine`.`DivisionID` INNER JOIN `tblstationmaster` ON `tblstationmaster`.`RailwayID`=`tblversiondefine`.`RailwayID` AND `tblstationmaster`.`DivisionID`=`tblversiondefine`.`DivisionID` AND `tblstationmaster`.`StationID`=`tblversiondefine`.`StationID` INNER JOIN `tblvendormaster` ON `tblvendormaster`.`VendorID`=`tblversiondefine`.`VendorID`";
        $data['dashboard'] = $this->common_model->find_dashboard_details("", $query, $query_select, $query_2);
        $this->load->view('Admin/Vendor/vendor', $data);
    }

    public function Notifications() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Dashboard";
        $data['title'] = "Dashboard";
        $data['asset_url'] = site_url('assets/themes/');
        $cond_user = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond_user, "tblusermaster", "LevelID, DesignationID");
        $message = "";

        $notifications = array();
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Approve_Reject");
            if (count($user_role_details) > 0) {
                if ($user_role_details[0]['Approve_Reject'] == 1) {
                    $cond = array(
                        "NotificationTo" => $user_details[0]['LevelID'],
                        "Status" => "Pending",
                        "ReadStatus" => "0",
                    );
                    $notifications = $this->common_model->find_details($cond, "tblnotifications");
                }
            }
        }
        $data['notifications'] = $this->common_model->find_dashboard_details("", $query, $query_select);
        $this->load->view('Admin/Vendor/vendor', $data);
    }

    public function login() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Login";
        $data['asset_url'] = site_url('assets/themes/');
        //$this->common_model->insert_user("RaviRaj");
        $this->load->view('Admin/login', $data);
    }

    public function division() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Division";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/Division/division', $data);
    }

    public function division_sync() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Division Sync";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/Division/division-sync', $data);
    }

    public function division_sync_detail() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Division Sync Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/Division/division-sync-detail', $data);
    }

    public function create_division() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Division";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Create Division";
        $data['asset_url'] = site_url('assets/themes/');
        $RailwayID = $this->session->userdata("railway_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                redirect(site_url('Admin/unauthorized'));
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                
                redirect(site_url('Admin/unauthorized'));
            }
        } 
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('DivisionName', 'Railway Zone Name', 'required');
            $this->form_validation->set_rules('RailwayID', 'Railway Zone', 'required');
            $this->form_validation->set_rules('DivisionCode', 'Division Code', 'required|is_unique[tbldivisionmaster.DivisionCode]');
            if ($this->form_validation->run()) {
                $division_details = $this->common_model->find_details("RailwayID = " . $this->input->post('RailwayID'), "tbldivisionmaster", "max(DivisionID) as DivisionID");
                if (count($division_details) > 0) {
                    $DivisionID = $division_details[0]['DivisionID'] + 1;
                } else {
                    $DivisionID = 1;
                }
                $data_to_store = array(
                    'DivisionName' => $this->input->post('DivisionName'),
                    'DivisionID' => $DivisionID,
                    'DivisionCode' => $this->input->post('DivisionCode'),
                    "RailwayID" => $this->input->post('RailwayID'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tbldivisionmaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Division Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Division/create-division', $data);
    }

    public function view_division() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Division";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Division";
        $data['asset_url'] = site_url('assets/themes/');

		$cond = array(
            "tbldivisionmaster.RecordStatus" => "1",
            "tbldivisionmaster.RailwayID" => $this->session->userdata("railway_session_list"),
        );
        $data['RailwaySelectID'] = 0;
        $data['division'] = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID");
		$data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID", "RailwayName Asc");
		if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('RailwayID', 'Railway Name', 'required');
            if ($this->form_validation->run()) {
                $data['RailwaySelectID'] = $this->input->post("RailwayID");
                $cond = array(
                    "tbldivisionmaster.RecordStatus" => "1",
                    "tbldivisionmaster.RailwayID" => $this->input->post("RailwayID"),
                );
				$data['division'] = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID");
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
		
		
        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");                
        if (count($user_details_header) > 0) {   
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {                                              
                $data['create_button_rights'] = 0;
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {                               
                $data['edit_button_rights'] = 0;
                $data['create_button_rights'] = 0;
            }
        }
        
        $this->load->view('Admin/Division/view-division', $data);
    }

    public function edit_division($id, $did) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Division";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Division";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array("RecordStatus" => "1", "DivisionID" => $did, "RailwayID" => $id);
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");                
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                if($RailwayID != $id)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                if($DivisionID != $did || $RailwayID != $id)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {                                
                    redirect(site_url('Admin/unauthorized'));
            }
        }
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['division'] = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID");
        if (count($data['division']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("DivisionID", $did, "tbldivisionmaster", "DivisionCode", $cond);
                if ($this->input->post('DivisionCode') != $original_value) {
                    $is_unique = '|is_unique[tbldivisionmaster.DivisionCode]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('DivisionCode', 'Division Code', 'trim|required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                $this->form_validation->set_rules('DivisionName', 'Division Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'DivisionName' => $this->input->post('DivisionName'),
                        'DivisionCode' => $this->input->post('DivisionCode'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_cond_details($cond, $data_to_store, "tbldivisionmaster")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Division Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['division'] = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errorss s";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-division'));
        }
        $this->load->view('Admin/Division/edit-division', $data);
    }

    public function view_division_detail($id, $did) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Division";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Division Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array("RecordStatus" => "1", "DivisionID" => $did, "RailwayID" => $id);
        $data['division'] = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['division']) > 0) {
            $this->load->view('Admin/Division/view-division-detail', $data);
        } else {
            redirect(site_url('Admin/view-division'));
        }
    }

    public function Zone_Chg_Division() {

        $value = $this->input->post("id");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
       

        if ($value != "") {
            if ($this->input->post('multiple')) {
                $data['multiple'] = "1";
            }
            $div = "";
            if ($this->input->post('div')) {
                $div = $this->input->post('div');
            }
            $data['DivisionID'] = $div;

            //Restrict Zone, Division, Station Select data according to login level Id
            $RailwayID = $value;
            $DivisionID = $this->session->userdata("division_session_list");
            $cond_user_header = array(
                "UserID" => $this->session->userdata("id_session_list"),
            );
            $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID","","","",$db);
            $cond_div = array(
                "RecordStatus" => 1,
                "RailwayID" => $RailwayID,
            );
            if (count($user_details_header) > 0) {
                $data['levelid'] = $user_details_header[0]['LevelID'];
                if (($user_details_header[0]['LevelID'] == 3 || $user_details_header[0]['LevelID'] == 4) && $this->session->userdata("UserRole")!="Admin" && !isset($_REQUEST['page'])) {
                    $cond_div = array(
                        "RecordStatus" => 1,
                        "RailwayID" => $RailwayID,
                        "DivisionID" => $DivisionID,
                    );
                }
            }
            $data['division'] = $this->common_model->find_details($cond_div, "tbldivisionmaster", "DivisionCode, DivisionName, DivisionID, RailwayID", "DivisionName Asc","","",$db);
            $this->load->view('Admin/Ajax/Zone_Chg_Division', $data);
        } else {
            echo "0";
        }
    }
	
	public function Zone_Chg_Work_Fields() {
        $value = $this->input->post("id");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        if ($value != "") {

            $RailwayID = $value;
			
            $cond = array(
                "RecordStatus" => 1,
                "RailwayID" => $value,
            );
            $data['extrafields'] = $this->common_model->find_details($cond, "tbl_version_fields", "for_field, field_value","","","",$db);
			
			
            $this->load->view('Admin/Ajax/Zone_Chg_Work_Fields', $data);
        } else {
            echo "0";
        }
    }
	
	public function Zone_Chg_Fields() {
        $value = $this->input->post("id");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        if ($value != "") {

            $RailwayID = $value;
			
			$cond_ver = array(
                "RecordStatus" => 1,
                "RailwayID" => $value,
                "for_field" => 2,
            );
            $data['verified_master'] = $this->common_model->find_details($cond_ver, "tbl_version_fields", "field_value as text","","","",$db);
			$cond_appr = array(
                "RecordStatus" => 1,
                "RailwayID" => $value,
                "for_field" => 3,
            );
			$data['approved_master'] = $this->common_model->find_details($cond_appr, "tbl_version_fields", "field_value as text","","","",$db);
			
            $this->load->view('Admin/Ajax/Zone_Chg_Fields', $data);
        } else {
            echo "0";
        }
    }

    public function userlogin_Chg_Station() {
        $value = $this->input->post("id");

        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        $did = $this->input->post("did");
        $selid = "";
        if ($this->input->post("selst")) {
            $selid = $this->input->post("selst");
        }
        $data['station_select'] = $selid;
        if ($value != "") {
            if ($this->input->post('multiple')) {
                $data['multiple'] = "1";
            }
			if ($this->input->post('userids')) {
                $data['userids'] = "1";
            }

            $this->db->group_by("tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");
            $this->db->join("tblversiondefine", "tblversiondefine.RailwayID=tblstationmaster.RailwayID and tblversiondefine.DivisionID=tblstationmaster.DivisionID and tblversiondefine.StationID=tblstationmaster.StationID", "left");
            $data['station'] = $this->common_model->find_details(array("tblstationmaster.RecordStatus" => "1", "tblstationmaster.RailwayID" => $value, "tblstationmaster.DivisionID" => $did), "tblstationmaster", "tblstationmaster.StationCode, tblstationmaster.StationName, tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID,tblversiondefine.StationID as is_include","","","",$db);

            $this->load->view('Admin/Ajax/stations', $data);
        } else {
            echo "0";
        }
    }

    public function Division_Chg_Station() {
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }

        $sessionData = array(
                "RailwayIDIP" => $value,
                "DivisionIDIP" => $did

            );
        $this->session->set_userdata($sessionData);

        $selid = "";
        if ($this->input->post("selst")) {
            $selid = $this->input->post("selst");
        }
        $data['station_select'] = $selid;
        if ($value != "") {
            if ($this->input->post('multiple')) {
                $data['multiple'] = "1";
            }

            //Restrict Zone, Division, Station Select data according to login level Id
            $RailwayID = $this->session->userdata("railway_session_list");
            $DivisionID = $this->session->userdata("division_session_list");
            $StationID = $this->session->userdata("station_session_list");
            $cond_user_header = array(
                "UserID" => $this->session->userdata("id_session_list"),
            );
            $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID","","","",$db);
            $cond_stn = array(
                "tblstationmaster.RecordStatus" => "1",
                "tblstationmaster.RailwayID" => $value,
                "tblstationmaster.DivisionID" => $did
            );
            if (count($user_details_header) > 0) {
                $data['levelid'] = $user_details_header[0]['LevelID'];
                if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                    $cond_stn = array(
                        "tblstationmaster.RecordStatus" => "1",
                        "tblstationmaster.RailwayID" => $RailwayID,
                        "tblstationmaster.DivisionID" => $DivisionID,
                        "tblstationmaster.ID" => $StationID,
                    );
                }
            }
            
            $this->db->group_by("tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");
            //$this->db->join("tblversiondefine","tblversiondefine.RailwayID=tblstationmaster.RailwayID and tblversiondefine.DivisionID=tblstationmaster.DivisionID and tblversiondefine.StationID=tblstationmaster.StationID","left");
            //$data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "tblstationmaster.StationCode, tblstationmaster.StationName, tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID,tblversiondefine.StationID as is_include");
            $data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "tblstationmaster.StationCode, tblstationmaster.StationName, tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID","","","",$db);

            $this->load->view('Admin/Ajax/Division_Chg_Station', $data);
        } else {
            echo "0";
        }
    }

    public function Level_Chg_Designation() {
        $did = $this->input->post("did");

        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        
        if ($did != "") {

            $cond_stn = array(
                "tbldesignationmaster.RecordStatus" => "1",
                "tbldesignationmaster.LevelID" => $did
            );

            //$this->db->group_by("tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");
            //$this->db->join("tbluserrolemaster","tbluserrolemaster.DesignationID=tbldesignationmaster.DesignationID","left");
            $data['designation'] = $this->common_model->find_details($cond_stn, "tbldesignationmaster", "tbldesignationmaster.DesignationID, tbldesignationmaster.DesignationName","","","",$db);


            //$data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "tblstationmaster.StationCode, tblstationmaster.StationName, tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");

            $this->load->view('Admin/Ajax/Level_Chg_Designation', $data);
        } else {
            echo "0";
        }
    }

    public function Station_Chg() {
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $sid = $this->input->post("sid");
        if ($value != "") {
            $data['station'] = $this->common_model->find_details(array("RecordStatus" => "1", "RailwayID" => $value, "DivisionID" => $did, "StationID" => $sid), "tblversionfilenames", "VersionFilesApplicationLogic, VersionFilesInterfaceLogic, VersionFilesVduLogic",$db);
            if (count($data['station']) > 0) {
                echo json_encode($data['station']);
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function Vendor_Chg_Version() {
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        if ($this->input->post("VendorID")) {
            if ($this->input->post("VendorID") != "") {
                $cond = array("RecordStatus" => "1", "VendorID" => $this->input->post("VendorID"));
                $data['version_logic'] = $this->common_model->find_details($cond, "tblversionfilenames", "FileName, FileType, MinCount, MaxCount, FolderName, VendorID, VersionFileNamesID","","","",$db);
                if (count($data['version_logic']) > 0) {
                    echo json_encode($data['version_logic']);
                } else {
                    echo "s2";
                }
            } else {
                echo "s0";
            }
        } else {
            $id = $this->input->post("id");
            $did = $this->input->post("did");
            $sid = $this->input->post("sid");
            $vid = $this->input->post("vid");
            if ($id != "") {
                $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VendorID" => $vid, "tblversiondefine.StationID" => $sid);
                $data['version_logic'] = $this->common_model->find_version_logic_details_with_main($cond,"another_db");
                if (count($data['version_logic']) > 0) {
                    echo json_encode($data['version_logic']);
                } else {
                    echo "2";
                }
            } else {
                echo "0";
            }
        }
    }

    public function delete_division() {
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $output = 0;
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {                
                if($RailwayID != $value)
                {
                    $output =  "2";
                }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                if($DivisionID != $did || $RailwayID != $value)
                {
                    $output = "2";
                }
            }
        } 
        if ($value != "" && $output == 0) {
            if ($this->common_model->delete_cond_details(array("DivisionID" => $did, "RailwayID" => $value), "tbldivisionmaster")) {
                $this->session->set_flashdata("success_done", "Division Details Deleted SuccessFully");
                $output = "1";
            } else {
                $output = "0";
            }
        } 
        echo $output;
    }

    public function vendor() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Vendor";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/Vendor/vendor', $data);
    }

    public function create_station() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Station";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Create Station";
        $data['asset_url'] = site_url('assets/themes/');
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $data['cond_div'] = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $data['cond_div'] = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                redirect(site_url('Admin/unauthorized'));
            }
        } 
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['division_div']=  $this->common_model->find_details($data['cond_div'], "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('StationName', 'Railway Zone Name', 'required');
            $this->form_validation->set_rules('RailwayID', 'Railway Zone', 'required');
            $this->form_validation->set_rules('DivisionID', 'Division Code', 'required');
            $this->form_validation->set_rules('StationCode', 'Station Code', 'required|is_unique[tblstationmaster.StationCode]');
            $data['division'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID")), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
            if ($this->form_validation->run()) {
                $station_details = $this->common_model->find_details("RailwayID = " . $this->input->post('RailwayID') . " and DivisionID = " . $this->input->post('DivisionID'), "tblstationmaster", "max(StationID) as StationID");
                if (count($station_details) > 0) {
                    $StationID = $station_details[0]['StationID'] + 1;
                } else {
                    $StationID = 1;
                }
                $data_to_store = array(
                    'StationID' => $StationID,
                    'StationName' => $this->input->post('StationName'),
                    'StationCode' => $this->input->post('StationCode'),
                    "RailwayID" => $this->input->post('RailwayID'),
                    "DivisionID" => $this->input->post('DivisionID'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblstationmaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Station Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Station/create-station', $data);
    }

    public function view_station() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Station";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Station";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array(
            "tblstationmaster.RecordStatus" => "1",
            "tblstationmaster.DivisionID" => $this->session->userdata("division_session_list"),
            "tblstationmaster.RailwayID" => $this->session->userdata("railway_session_list"),
        );
        $data['RailwaySelectID'] = 0;
        $data['station'] = $this->common_model->find_station_details("", $cond);
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID", "RailwayName Asc");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('DivisionID', 'Division Code', 'trim|required');
            $this->form_validation->set_rules('RailwayID', 'Railway Name', 'required');
            if ($this->form_validation->run()) {
                $data['division'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID")), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                $data['RailwaySelectID'] = $this->input->post("RailwayID");
                $cond = array(
                    "tblstationmaster.RecordStatus" => "1",
                    "tblstationmaster.DivisionID" => $this->input->post("DivisionID"),
                    "tblstationmaster.RailwayID" => $this->input->post("RailwayID"),
                );
                $data['station'] = $this->common_model->find_station_details("", $cond);
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");                
        if (count($user_details_header) > 0) {            
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {               
                $data['create_button_rights'] = 0;
            }
        }
        $this->load->view('Admin/Station/view-station', $data);
    }

    public function edit_station($id, $did, $sid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Station";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Station";
        $data['asset_url'] = site_url('assets/themes/');
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                if($RailwayID != $id)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $data['cond_div'] = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                if($DivisionID != $did || $RailwayID != $id)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {                
                if($DivisionID != $did || $RailwayID != $id || $StationID != $sid)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
        } 
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['division_div']=  $this->common_model->find_details($data['cond_div'], "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
        $cond = array("RecordStatus" => "1", "RailwayID" => $id, "DivisionID" => $did, "StationID" => $sid);
        $data['station'] = $this->common_model->find_details($cond, "tblstationmaster", "StationCode, StationName, StationID, RailwayID, DivisionID");
        if (count($data['station']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("StationID", $id, "tblstationmaster", "StationCode", $cond);
                if ($this->input->post('StationCode') != $original_value) {
                    $is_unique = '|is_unique[tblstationmaster.StationCode]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('StationCode', 'Station Code', 'trim|required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                $this->form_validation->set_rules('StationName', 'Station Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'StationName' => $this->input->post('StationName'),
                        'StationCode' => $this->input->post('StationCode'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_cond_details($cond, $data_to_store, "tblstationmaster")) {
                        $data['flash_message'] = TRUE;

                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Station Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['station'] = $this->common_model->find_details($cond, "tblstationmaster", "StationCode, StationName, StationID, RailwayID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-station'));
        }
        $this->load->view('Admin/Station/edit-station', $data);
    }

    public function view_station_detail($id, $did, $sid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Station";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Station Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array("RecordStatus" => "1", "RailwayID" => $id, "DivisionID" => $did, "StationID" => $sid);
        $data['station'] = $this->common_model->find_details($cond, "tblstationmaster", "StationCode, StationName, StationID, RailwayID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn, DivisionID");
        if (count($data['station']) > 0) {
            $this->load->view('Admin/Station/view-station-detail', $data);
        } else {
            redirect(site_url('Admin/view-station'));
        }
    }

    public function delete_station() {
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $sid = $this->input->post("sid");
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $output = 0;
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {                
                if($RailwayID != $value)
                {
                    $output =  "2";
                }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                if($DivisionID != $did || $RailwayID != $value)
                {
                    $output = "2";
                }
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                if($DivisionID != $did || $RailwayID != $value || $StationID != $sid)
                {
                    $output = "2";
                }
            }
        } 
        if ($value != "" && $output == 0) {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            if ($this->common_model->delete_cond_details(array("StationID" => $sid, "DivisionID" => $did, "RailwayID" => $value), "tblstationmaster", $data_to_store)) {
                $this->session->set_flashdata("success_done", "Station Details Deleted SuccessFully");
                $output = "1";
            } else {
                $output = "0";
            }
        }
        echo  $output;
    }

    public function create_vendor() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Vendor";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Create Vendor";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('VendorName', 'Vendor Name', 'required');
            $this->form_validation->set_rules('PrimaryPhone', 'Primary Phone No', 'required');
            $this->form_validation->set_rules('SecondaryPhone', 'Secondary Phone No', 'required');
            $this->form_validation->set_rules('EMail', 'EMail', 'valid_email');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'VendorName' => $this->input->post('VendorName'),
                    'PrimaryPhone' => $this->input->post('PrimaryPhone'),
                    'SecondaryPhone' => $this->input->post('SecondaryPhone'),
                    'EMail' => $this->input->post('EMail'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblvendormaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Vendor Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Vendor/create-vendor', $data);
    }

    public function view_vendor() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Vendor";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Vendor";
        $data['asset_url'] = site_url('assets/themes/');

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, EMail, VendorID, PrimaryPhone, SecondaryPhone");
        $this->load->view('Admin/Vendor/view-vendor', $data);
    }

    public function view_vendor_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Vendor";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Vendor Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['vendor'] = $this->common_model->find_details(array("RecordStatus" => "1", "VendorID" => $id), "tblvendormaster", "VendorName, EMail, VendorID, PrimaryPhone, SecondaryPhone, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['vendor']) > 0) {
            
        } else {
            redirect(site_url('Admin/view-vendor'));
        }
        $this->load->view('Admin/Vendor/view-vendor-detail', $data);
    }

    public function edit_vendor($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Vendor";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Vendor";
        $data['asset_url'] = site_url('assets/themes/');
        $data['vendor'] = $this->common_model->find_details(array("RecordStatus" => "1", "VendorID" => $id), "tblvendormaster", "VendorName, EMail, VendorID, PrimaryPhone, SecondaryPhone");
        if (count($data['vendor']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('VendorName', 'Vendor Name', 'required');
                $this->form_validation->set_rules('PrimaryPhone', 'Primary Phone No', 'required');
                $this->form_validation->set_rules('SecondaryPhone', 'Secondary Phone No', 'required');
                $this->form_validation->set_rules('EMail', 'EMail', 'valid_email');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'VendorName' => $this->input->post('VendorName'),
                        'PrimaryPhone' => $this->input->post('PrimaryPhone'),
                        'SecondaryPhone' => $this->input->post('SecondaryPhone'),
                        'EMail' => $this->input->post('EMail'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("VendorID", $id, $data_to_store, "tblvendormaster")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Vendor Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['vendor'] = $this->common_model->find_details(array("RecordStatus" => "1", "VendorID" => $id), "tblvendormaster", "VendorName, EMail, VendorID, PrimaryPhone, SecondaryPhone");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-vendor'));
        }
        $this->load->view('Admin/Vendor/edit-vendor', $data);
    }

    public function delete_vendor() {
        $value = $this->input->post("id");
        if ($value != "") {
            if ($this->common_model->delete_details('VendorID', $value, "tblvendormaster")) {
                $this->session->set_flashdata("success_done", "Vendor Details Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function create_version_logic() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Create VersionLogic";
        $data['asset_url'] = site_url('assets/themes/');
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('VersionNo', 'Version No', 'required');
            $this->form_validation->set_rules('RailwayID', 'Railway ID', 'required');
            $this->form_validation->set_rules('DivisionID', 'Division ID', 'required');
            $this->form_validation->set_rules('StationID', 'Station ID', 'required');
            $this->form_validation->set_rules('ApplicationFolderCountRequired', 'Application Folder Count Required', 'required');
            $this->form_validation->set_rules('ApplicationFileCountRequired', 'Application File Count Required', 'required');
            $this->form_validation->set_rules('InterfaceFolderCountRequired', 'Interface Folder Count Required', 'required');
            $this->form_validation->set_rules('InterfaceFileCountRequired', 'Interface Folder Count Required', 'required');
            $this->form_validation->set_rules('VduFolderCountRequired', 'Vdu Folder Count Required', 'required');
            $this->form_validation->set_rules('VduFileCountRequired', 'Vdu Folder Count Required', 'required');
            $data['division'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID")), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
            $data['station'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID"), "DivisionID" => $this->input->post("DivisionID")), "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
            if ($this->form_validation->run()) {
                $version_logic_details = $this->common_model->find_details("RailwayID = " . $this->input->post('RailwayID') . " and DivisionID = " . $this->input->post('DivisionID') . " and StationID = " . $this->input->post('StationID'), "tblversiondefine", "max(VersionID) as VersionID");
                if (count($version_logic_details) > 0) {
                    $VersionLogicID = $version_logic_details[0]['VersionID'] + 1;
                } else {
                    $VersionLogicID = 1;
                }
                $ImportantCount = count($this->input->post('ApplicationImportantFilesRequired'));
                $ImportantCountA = 0;
                $ApplicationImportantFilesRequired = "";
                for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                    $ImportantCountA++;
                    if ($important_C == 0) {
                        $ApplicationImportantFilesRequired = $this->input->post('ApplicationImportantFilesRequired')[$important_C];
                    } else {
                        $ApplicationImportantFilesRequired .= "," . $this->input->post('ApplicationImportantFilesRequired')[$important_C];
                    }
                }
                $ImportantCountA = count(explode(",", $ApplicationImportantFilesRequired));
                $ImportantCount = count($this->input->post('InterfaceImportantFilesRequired'));
                $ImportantCountI = 0;
                $InterfaceImportantFilesRequired = "";
                for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                    if ($important_C == 0) {
                        $InterfaceImportantFilesRequired = $this->input->post('InterfaceImportantFilesRequired')[$important_C];
                    } else {
                        $InterfaceImportantFilesRequired .= "," . $this->input->post('InterfaceImportantFilesRequired')[$important_C];
                    }
                }
                $ImportantCountI = count(explode(",", $InterfaceImportantFilesRequired));
                $ImportantCount = count($this->input->post('VduImportantFilesRequired'));
                $VduImportantFilesRequired = "";
                $ImportantCountV = 0;
                for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                    $ImportantCountV++;
                    if ($important_C == 0) {
                        $VduImportantFilesRequired = $this->input->post('VduImportantFilesRequired')[$important_C];
                    } else {
                        $VduImportantFilesRequired .= "," . $this->input->post('VduImportantFilesRequired')[$important_C];
                    }
                }
                $ImportantCountV = count(explode(",", $VduImportantFilesRequired));
                $data_to_store = array(
                    'VersionID' => $VersionLogicID,
                    'VersionNo' => $this->input->post('VersionNo'),
                    "RailwayID" => $this->input->post('RailwayID'),
                    "DivisionID" => $this->input->post('DivisionID'),
                    'StationID' => $this->input->post('StationID'),
                    'VendorID' => $this->input->post('VendorID'),
                    "ApplicationFolderCountRequired" => $this->input->post('ApplicationFolderCountRequired'),
                    "ApplicationFileCountRequired" => $this->input->post('ApplicationFileCountRequired'),
                    'ApplicationImportantFilesRequired' => $ApplicationImportantFilesRequired,
                    "InterfaceFolderCountRequired" => $this->input->post('InterfaceFolderCountRequired'),
                    "InterfaceFileCountRequired" => $this->input->post('InterfaceFileCountRequired'),
                    'InterfaceImportantFilesRequired' => $InterfaceImportantFilesRequired,
                    "VduFolderCountRequired" => $this->input->post('VduFolderCountRequired'),
                    "VduFileCountRequired" => $this->input->post('VduFileCountRequired'),
                    'VduImportantFilesRequired' => $VduImportantFilesRequired,
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'ApplicationImportantFilesCount' => $ImportantCountA,
                    'VduImportantFilesCount' => $ImportantCountV,
                    'InterfaceImportantFilesCount' => $ImportantCountI,
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblversiondefine";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Version Logic Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Version/create-version-logic', $data);
    }

    public function view_version_logic() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View VersionLogic";
        $data['title'] = "View VersionLogic";
        $data['asset_url'] = site_url('assets/themes/');
        $data['version_logic'] = $this->common_model->find_version_logic_details("","another_db");
        $this->load->view('Admin/Version/view-version-logic', $data);
    }

    public function edit_version_logic($id, $did, $sid, $vid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Edit VersionLogic";
        $data['asset_url'] = site_url('assets/themes/');
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VersionID" => $vid, "tblversiondefine.StationID" => $sid);
        $data['version_logic'] = $this->common_model->find_version_logic_details($cond,"another_db");
        if (count($data['version_logic']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('VersionNo', 'Version No', 'required');
                $this->form_validation->set_rules('ApplicationFolderCountRequired', 'Application Folder Count Required', 'required');
                $this->form_validation->set_rules('ApplicationFileCountRequired', 'Application File Count Required', 'required');
                $this->form_validation->set_rules('InterfaceFolderCountRequired', 'Interface Folder Count Required', 'required');
                $this->form_validation->set_rules('InterfaceFileCountRequired', 'Interface Folder Count Required', 'required');
                $this->form_validation->set_rules('VduFolderCountRequired', 'Vdu Folder Count Required', 'required');
                $this->form_validation->set_rules('VduFileCountRequired', 'Vdu Folder Count Required', 'required');

                if ($this->form_validation->run()) {
                    $ImportantCount = count($this->input->post('ApplicationImportantFilesRequired'));
                    $ImportantCountA = 0;
                    $ApplicationImportantFilesRequired = "";
                    for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                        $ImportantCountA++;
                        if ($important_C == 0) {
                            $ApplicationImportantFilesRequired = $this->input->post('ApplicationImportantFilesRequired')[$important_C];
                        } else {
                            $ApplicationImportantFilesRequired .= "," . $this->input->post('ApplicationImportantFilesRequired')[$important_C];
                        }
                    }
                    $ImportantCountA = count(explode(",", $ApplicationImportantFilesRequired));
                    $ImportantCount = count($this->input->post('InterfaceImportantFilesRequired'));
                    $ImportantCountI = 0;
                    $InterfaceImportantFilesRequired = "";
                    for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                        if ($important_C == 0) {
                            $InterfaceImportantFilesRequired = $this->input->post('InterfaceImportantFilesRequired')[$important_C];
                        } else {
                            $InterfaceImportantFilesRequired .= "," . $this->input->post('InterfaceImportantFilesRequired')[$important_C];
                        }
                    }
                    $ImportantCountI = count(explode(",", $InterfaceImportantFilesRequired));
                    $ImportantCount = count($this->input->post('VduImportantFilesRequired'));
                    $VduImportantFilesRequired = "";
                    $ImportantCountV = 0;
                    for ($important_C = 0; $important_C < $ImportantCount; $important_C++) {
                        $ImportantCountV++;
                        if ($important_C == 0) {
                            $VduImportantFilesRequired = $this->input->post('VduImportantFilesRequired')[$important_C];
                        } else {
                            $VduImportantFilesRequired .= "," . $this->input->post('VduImportantFilesRequired')[$important_C];
                        }
                    }
                    $ImportantCountV = count(explode(",", $VduImportantFilesRequired));
                    $data_to_store = array(
                        'VersionNo' => $this->input->post('VersionNo'),
                        "ApplicationFolderCountRequired" => $this->input->post('ApplicationFolderCountRequired'),
                        "ApplicationFileCountRequired" => $this->input->post('ApplicationFileCountRequired'),
                        "InterfaceFolderCountRequired" => $this->input->post('InterfaceFolderCountRequired'),
                        "InterfaceFileCountRequired" => $this->input->post('InterfaceFileCountRequired'),
                        "VduFolderCountRequired" => $this->input->post('VduFolderCountRequired'),
                        "VduFileCountRequired" => $this->input->post('VduFileCountRequired'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'InterfaceImportantFilesRequired' => $InterfaceImportantFilesRequired,
                        'ApplicationImportantFilesRequired' => $ApplicationImportantFilesRequired,
                        'VduImportantFilesRequired' => $VduImportantFilesRequired,
                        'ApplicationImportantFilesCount' => $ImportantCountA,
                        'VduImportantFilesCount' => $ImportantCountV,
                        'InterfaceImportantFilesCount' => $ImportantCountI,
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    $cond = array("RecordStatus" => "1", "RailwayID" => $id, "DivisionID" => $did, "VersionID" => $vid, "StationID" => $sid);
                    if ($this->common_model->update_cond_details($cond, $data_to_store, "tblversiondefine")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "VersionLogic Details Updated";
                        $data['flash_message'] = TRUE;
                        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VersionID" => $vid, "tblversiondefine.StationID" => $sid);
                        $data['version_logic'] = $this->common_model->find_version_logic_details($cond,"another_db");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    var_dump(validation_errors());
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-version-logic'));
        }
        $this->load->view('Admin/Version/edit-version-logic', $data);
    }

    public function view_version_logic_detail($id, $did, $sid, $vid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "View VersionLogic Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VersionID" => $vid, "tblversiondefine.StationID" => $sid);
        $data['version_logic'] = $this->common_model->find_version_logic_details($cond,"another_db");
        if (count($data['version_logic']) > 0) {
            $this->load->view('Admin/Version/view-version-logic-detail', $data);
        } else {
            redirect(site_url('Admin/view-version-logic'));
        }
    }

    public function delete_version_logic() {
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $sid = $this->input->post("sid");
        $vid = $this->input->post("vid");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        if ($value != "") {
            if ($this->common_model->delete_cond_details(array("VersionID" => $vid, "DivisionID" => $did, "RailwayID" => $value, "StationID" => $sid), "tblversiondefine","",$db)) {
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function delete_version() {
        $value = $this->input->post("id");
        $did = $this->input->post("did");
        $sid = $this->input->post("sid");
        $vid = $this->input->post("vid");
        $verid = $this->input->post("verid");
        $user_input=$this->input->post();
        if(isset($user_input["db"])){
        $db=$this->input->post("db");
        }else{
           $db=""; 
        }
        if ($value != "") {
            $cond = array("VersionID" => $verid, "VendorID" => $vid, "DivisionID" => $did, "RailwayID" => $value, "StationID" => $sid);
            $this->common_model->delete_cond_details($cond, "tblversiondefine","",$db);
            $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu","",$db);
            $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters","",$db);
            $this->session->set_flashdata("success_done", "Version Details Deleted SuccessFully");
            echo "1";
        } else {
            echo "0";
        }
    }

    public function detail_version_view($id, $did, $sid, $vid, $verid, $his) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Detail Version";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VersionID" => $verid, "tblversiondefine.StationID" => $sid, "tblversiondefine.VendorID" => $vid);
        $version = $this->common_model->find_version_details($cond,"","another_db");
        $data['version'] = $version;
        $cond = array("RailwayID" => $id, "DivisionID" => $did, "VersionID" => $verid, "StationID" => $sid, "VendorID" => $vid);
        $data['versionsubuserdefinedparameters'] = $this->common_model->find_details($cond, "tbl_versionsubuserdefinedparameters");
        $data['versionsubcpu'] = $this->common_model->find_details($cond, "tbl_versionsubcpu","","","","","another_db");
        $data['VendorID'] = $vid;
        $fields = $this->common_model->find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield","","","","another_db");
        $data['fields'] = $fields;
        $data['custom_fields'] = $this->common_model->find_details("define_id = '" . $version[0]["ID"] . "'", "tblversiondefine_custom_fields", "define_id, field_id, field_name, field_dis, field_value","","","","another_db");
        if ($his == 1) {
            $data['version_history'] = $this->common_model->find_version_history($id, $did, $sid,"another_db");
        }

        $condip = array("RailwayID" => $id, "DivisionID" => $did);
        $iptabledata = $this->common_model->find_details($condip, "tblserveripdivisionwise", "ServerIP","","","","another_db");
        if(count($iptabledata) > 0)
        {
        	$ipdownload = $iptabledata[0]['ServerIP']."/railways-v1";
            $data['ipdownload'] = $ipdownload;
        }

        $this->load->view('Admin/Version/detail-version-view', $data);
    }

    public function detail_version_approve($id, $did, $sid, $vid, $verid, $nid, $uid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Detail Version";
        $data['NotificationType'] = "";
        $data['status'] = "Pending";
        $data['remarks'] = "";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID","","","","another_db");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('Remarks', 'Remarks', 'required');
            if ($this->form_validation->run()) {
                if ($this->input->post("Approve")) {
                    $data_to_store = array(
                        'Remarks' => $this->input->post('Remarks'),
                        'Status' => "Approved",
                        "ActionBy" => $this->session->userdata("id_session_list"),
                        "ActionOn" => date("Y-m-d H:i:s"),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                } elseif ($this->input->post("Decline")) {
                    $data_to_store = array(
                        'Remarks' => $this->input->post('Remarks'),
                        'Status' => "Declined",
                        "ActionBy" => $this->session->userdata("id_session_list"),
                        "ActionOn" => date("Y-m-d H:i:s"),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                }
                $table = "tblnotifications";
                $cond = array(
                    "Status" => "Pending",
                    "RailwayID" => $id,
                    "DivisionID" => $did,
                    "VersionID" => $verid,
                    "StationID" => $sid,
                    "VendorID" => $vid,
                    "NID" => $nid,
                );
                if ($this->common_model->update_cond_details($cond, $data_to_store, $table,"another_db")) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Notification Updated";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        if (count($user_details) > 0) {
            $cond = array(
                "RailwayID" => $id,
                "DivisionID" => $did,
                "VersionID" => $verid,
                "StationID" => $sid,
                "VendorID" => $vid,
                "NID" => $nid,
                "CreatedBy" => $uid,
                "NotificationTo" => $user_details[0]['LevelID']
            );
            $data_to_store = array(
                "ReadStatus" => 1,
            );
            if ($this->common_model->update_cond_details($cond, $data_to_store, "tblnotifications","another_db")) {
                
            }
            $cond = array(
                "RailwayID" => $id,
                "DivisionID" => $did,
                "VersionID" => $verid,
                "StationID" => $sid,
                "VendorID" => $vid,
                "NID" => $nid,
                "CreatedBy" => $this->session->userdata("id_session_list"),
                "NotificationFrom" => $user_details[0]['LevelID']
            );
            $data_to_store = array(
                "ReadStatusFrom" => 1,
            );
            if ($this->common_model->update_cond_details($cond, $data_to_store, "tblnotifications","another_db")) {
                
            }
            $cond = array(
                "RailwayID" => $id,
                "DivisionID" => $did,
                "VersionID" => $verid,
                "StationID" => $sid,
                "VendorID" => $vid,
                "NID" => $nid,
                "CreatedBy" => $uid,
            );
            $data['version_notify'] = $this->common_model->find_details($cond, "tblnotifications", "Remarks, Status, NotificationContent, NotificationType","another_db");
            if (count($data['version_notify']) > 0) {
                $data['NotificationType'] = $data['version_notify'][0]['NotificationType'];
                $data['status'] = $data['version_notify'][0]['Status'];
                $data['remarks'] = $data['version_notify'][0]['Remarks'];
                $data_full = json_decode($data['version_notify'][0]['NotificationContent'], False);
                if (count($data_full) > 0) {
                    $data['version'] = $data_full->fulldata;
                    $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VersionID" => $verid, "tblversiondefine.StationID" => $sid, "tblversiondefine.VendorID" => $vid);
                    $data['version_details'] = $this->common_model->find_version_details($cond,"","another_db");
                    $data['version_cpu_details'] = $data_full->cpu_details;
                    $data['version_parameter_details'] = $data_full->parameter_details;
                    if ($this->input->server('REQUEST_METHOD') === 'POST') {
                        if ($this->input->post("Approve")) {
                            $this->common_model->update_cond_details($cond, $data['version'], "tblversiondefine","another_db");
                            $Count = count($data['version_cpu_details']);
                            $cond = array("RailwayID" => $id, "DivisionID" => $did, "VersionID" => $verid, "StationID" => $sid, "VendorID" => $vid);
                            if ($Count > 0) {
                                $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu","","another_db");
                            }
                            foreach ($data['version_cpu_details'] as $cpu_row) {
                                $data_to_store = $cpu_row;
                                $table = "tbl_versionsubcpu";
                                $this->common_model->store_details($data_to_store, $table,"another_db");
                            }
                            $Count = count($data['version_parameter_details']);
                            if ($Count > 0) {
                                $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters","","another_db");
                            }
                            foreach ($data['version_parameter_details'] as $parameter_row) {
                                $data_to_store = $parameter_row;
                                $table = "tbl_versionsubuserdefinedparameters";
                                $this->common_model->store_details($data_to_store, $table,"another_db");
                            }
                        }
                    }
                } else {
                    //  redirect(site_url('Admin/view-version'));
                }
            } else {
                //redirect(site_url('Admin/view-version'));
            }

            $this->load->view('Admin/Version/detail-version-approve', $data);
        }
    }

    public function data_entry() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Data Entry";
        $data['title'] = "Data Entry";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/data-entry', $data);
    }

    public function version_file_types() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "EI - S/W Files";
        $data['title'] = "Data Entry";
        $data['asset_url'] = site_url('assets/themes/');

        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('file_type', 'File Type', "required|is_unique[tbl_version_file_types.file_type]");
            if ($this->form_validation->run()) {
                $ftype = $this->input->post("file_type");
                $idata = array(
                    "file_type" => $ftype,
                    "type_value" => strtolower($ftype)
                );
                $this->common_model->store_details($idata, "tbl_version_file_types");
                $data['color_code'] = "#3a5a9c";
                $data['display_value'] = "block";
                $data['message'] = "Version File Type Added SuccessFully";
                $data['flash_message'] = FALSE;
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = validation_errors();
                $data['flash_message'] = FALSE;
            }
        }

        $data['file_types'] = $this->common_model->find_details("", "tbl_version_file_types", "id, file_type, type_value");
        $this->load->view('Admin/Version/version-file-types', $data);
    }

    public function settings_ips() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Server IP Details";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Server IP Details";
        $data['asset_url'] = site_url('assets/themes/');

        $data['zoneID'] = $this->session->userdata("railway_session_list");
        //edit button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            $data['edit_button_rights'] = $user_role_details[0]['Edit'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
        
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        $cond_zone = "RecordStatus = 1";
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2) {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 4) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if($this->session->userdata("UserRole")=="Admin")
            {
                $cond_zone = "RecordStatus = 1";
            }
        }

        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");

        if ($this->input->post("RailwayID")) {
            $zoneid = $this->input->post("RailwayID");
            $data['zoneID'] = $zoneid;
            $cond = array(
                "tblrailwaymaster.RailwayID" => $zoneid
            );
            $data['submit'] = "";
            $data['fields'] = $this->common_model->find_division_details($cond);
        } 
        else
        {
            $cond = array(
                "tblrailwaymaster.RailwayID" => $data['zoneID'] 
            );
            $data['zoneID'] = "";
            $data['submit'] = "";
            $data['fields'] = array();
        }
        $this->load->view('Admin/serveripdivisionwise', $data);
    }

    public function Zone_Chg_ServerIP() {
        $zoneid = $this->input->post("zoneid");

        if ($zoneid != "") {

            $cond = array(
                "tblserveripdivisionwise.RailwayID" => $zoneid
            );

            $data['fields'] = $this->common_model->find_division_details($cond_stn);


            $this->load->view('Admin/Ajax/EI_description_view', $data);
        } else {
            echo "0";
        }
    }

    public function addnew_version() {
      
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";

        $data['this_page'] = "View Version";
        $data['tour_visible'] = "active";
        $data['title'] = "Add New Version";
        $data['asset_url'] = site_url('assets/themes/');

        $data['current_user'] = $this->session->userdata("id_session_list");
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID","","","","another_db");
        $cond_zone = "RecordStatus = 1";
        $cond_div = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        $cond_stn = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
            "DivisionID" => $DivisionID,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2) {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 4) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                $cond_stn = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                    "StationID" => $StationID,
                );
            }
            if($this->session->userdata("UserRole")=="Admin")
            {
                $cond_zone = "RecordStatus = 1";
            }
        }

        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID","","","","another_db");


        //$data['verified_master'] = $this->common_model->find_details(array("for_field" => 2), "tbl_version_fields", "field_value as text");
        //$data['approved_master'] = $this->common_model->find_details(array("for_field" => 3), "tbl_version_fields", "field_value as text");

        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID","","","","another_db");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID","","","","another_db");

        $fields = $this->common_model->find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield","","","","another_db");
        //$data['extrafields'] = $this->common_model->find_details("", "tbl_version_fields");
        $data['fields'] = $fields;
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('RailwayID', 'Railway ID', 'required');
            $this->form_validation->set_rules('DivisionID', 'Division ID', 'required');
            $this->form_validation->set_rules('StationID', 'Station ID', 'required');
            $this->form_validation->set_rules('VendorID', 'Vendor ID', 'required');
            $data['division'] = $this->common_model->find_details($cond_div, "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID","","","","another_db");




            $cond_stn = array(
                "tblstationmaster.RecordStatus" => 1,
                "tblstationmaster.RailwayID" => $this->input->post("RailwayID"),
                "tblstationmaster.DivisionID" => $this->input->post("DivisionID"),
            );

            

            $RailwayID=$this->input->post('RailwayID');
            $DivisionID=$this->input->post("DivisionID");


           // $this->db->group_by("tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");
           // $this->db->join("tblversiondefine", "tblversiondefine.RailwayID=tblstationmaster.RailwayID and tblversiondefine.DivisionID=tblstationmaster.DivisionID and tblversiondefine.StationID=tblstationmaster.StationID", "left");

           // $data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "tblstationmaster.StationName, tblstationmaster.StationCode, tblstationmaster.StationID, tblstationmaster.RailwayID,tblversiondefine.StationID as is_include","","","","another_db");


           // $data['station']="select tblstationmaster.StationName, tblstationmaster.StationCode, tblstationmaster.StationID, tblstationmaster.RailwayID,tblversiondefine.StationID as is_include from tblstationmaster left join tblversiondefine on tblversiondefine.RailwayID=tblstationmaster.RailwayID and tblversiondefine.DivisionID=tblstationmaster.DivisionID and tblversiondefine.StationID=tblstationmaster.StationID where tblstationmaster.RecordStatus = 1 and tblstationmaster.RailwayID = $RailwayID and  tblstationmaster.DivisionID => $DivisionID group by tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID";
//print_r($data['station']);exit;
            
            if ($this->form_validation->run()) {

                //Version ID
                $VersionLogicID = 1;
                $version_logic_details = $this->common_model->find_details("RailwayID = " . $this->input->post('RailwayID') . " and DivisionID = " . $this->input->post('DivisionID') . " and StationID = " . $this->input->post('StationID'), "tblversiondefine", "max(VersionID) as VersionID","","","","another_db");
                if (count($version_logic_details) > 0) {
                    $VersionLogicID = $version_logic_details[0]['VersionID'] + 1;
                } else {
                    $VersionLogicID = 1;
                }

                $VendorID = $this->input->post("VendorID");
                $vendorFields = $this->common_model->find_details("RecordStatus = 1 and VendorID = '" . $VendorID . "'", "tbl_versionfields_vendor_map", "VendorID, field_id, is_visible, is_mandatory","","","","another_db");
                $valid = true;
                foreach ($vendorFields as $vfield) {
                    $field = $this->common_model->find_details("RecordStatus = 1 and VersionFieldsMasterID = '" . $vfield["field_id"] . "'", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, is_autofield", "", "", "1","another_db");
                    if ($field[0]["is_autofield"] == 1) {
                        if ($vfield["is_mandatory"] == "1") {
                            $field_data = $this->input->post($field[0]["field_name"]);
                            if ($field_data === "") {
                                $valid = false;
                                break;
                            } else {
                                $valid = true;
                            }
                        }
                    }
                }

                $nocpu = "0";
                if ($this->input->post('NoOfCPU')) {
                    if ($this->input->post('NoOfCPU') != "") {

                        $nocpu = $this->input->post('NoOfCPU');
                    }
                }
               

                $datatostore = array(
                    "VersionID" => $VersionLogicID,
                    "RailwayID" => $this->input->post('RailwayID'),
                    "DivisionID" => $this->input->post('DivisionID'),
                    'StationID' => $this->input->post('StationID'),
                    'VendorID' => $this->input->post('VendorID'),
                    "NoOfCPU" => $nocpu,
                    "isDistributedVersionType" => $this->input->post('isDistributedVersionType'),
                    'SignalPlanNumber' => $this->input->post('SignalPlanNumber'),
                    "InstallationAlterationDate" => $this->input->post('InstallationAlterationDate'),
                    "DescriptionOfWork" => $this->input->post('DescriptionOfWork'),
                    'WorkExecutedBy' => $this->input->post('WorkExecutedBy'),
                    //"PreviousESwVersion" => $this->input->post('PreviousESwVersion'),
                    //"PreviousESwChecksum" => $this->input->post('PreviousESwChecksum'),
                    'CurrentESwVersion' => $this->input->post('CurrentESwVersion'),
                    "CurrentESwChecksum" => $this->input->post('CurrentESwChecksum'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                    "CertificateDownloadPath" => $this->input->post("CertificateDownloadPath"),
                    "OthersDownloadPath" => $this->input->post("OthersDownloadPath"),
                    "SoftwareFileDownloadPath" => $this->input->post("SoftwareFileDownloadPath")
                );
               
                $this->session->set_userdata($datatostore);
                $Count = count($this->input->post("CurrentVital"));
                $data_cpu_details = array();
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store = array(
                        'VendorID' => $this->input->post('VendorID'),
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VersionID' => $VersionLogicID,
                        'CpuNo' => $i + 1,
                        //"PreviousVital" => $this->input->post('PreviousVital')[$i],
                        //'PreviousNonVital' => $this->input->post('PreviousNonVital')[$i],
                        "CurrentVital" => $this->input->post('CurrentVital')[$i],
                        "CurentNonVital" => $this->input->post('CurentNonVital')[$i],
                    );
                    array_push($data_cpu_details, $data_to_store);
                }
                //var_dump($data_cpu_details);
                $data_cpu_details_session['temp_cpu_details'] = $data_cpu_details;
                $this->session->set_userdata($data_cpu_details_session);
                $Count = count($this->input->post("ParameterValue"));
                $data_parameter_details = array();
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store = array(
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VendorID' => $this->input->post('VendorID'),
                        'VersionID' => $VersionLogicID,
                        "ParameterId" => $i + 1,
                        "ParameterName" => $this->input->post('ParameterName')[$i],
                        'ParameterValue' => $this->input->post('ParameterValue')[$i],
                    );
                    array_push($data_parameter_details, $data_to_store);
                }
                $data_parameter_details_session['temp_parameter_details'] = $data_parameter_details;
                $this->session->set_userdata($data_parameter_details_session);
                if ($valid) {
                    
                    //Get Last id
                    $lastid_res = $this->common_model->rawQuery("SELECT ID FROM tblversiondefine order by ID desc limit 1;","another_db");
                    
                    $newid = $lastid_res[0]->ID+1; //New ID Increment
                    
                    $data_to_store = array(
                        "ID" => $newid,
                        "VersionID" => $VersionLogicID,
                        "RailwayID" => $this->session->userdata('RailwayID'),
                        "DivisionID" => $this->session->userdata('DivisionID'),
                        'StationID' => $this->session->userdata('StationID'),
                        'VendorID' => $this->session->userdata('VendorID'),
                        "NoOfCPU" => $this->session->userdata('NoOfCPU'),
                        "isDistributedVersionType" => $this->session->userdata('isDistributedVersionType'),
                        'SignalPlanNumber' => $this->session->userdata('SignalPlanNumber'),
                        "InstallationAlterationDate" => $this->session->userdata('InstallationAlterationDate'),
                        "DescriptionOfWork" => $this->session->userdata('DescriptionOfWork'),
                        'WorkExecutedBy' => $this->session->userdata('WorkExecutedBy'),
                        //"PreviousESwVersion" => $this->session->userdata('PreviousESwVersion'),
                        //"PreviousESwChecksum" => $this->session->userdata('PreviousESwChecksum'),
                        'CurrentESwVersion' => $this->session->userdata('CurrentESwVersion'),
                        "CurrentESwChecksum" => $this->session->userdata('CurrentESwChecksum'),
                        'CreatedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'CreatedOn' => $this->session->userdata("CreatedOn"),
                        'ModifiedOn' => $this->session->userdata("ModifiedOn"),
                        "IsCurrentVersion" => 0,
                        "Remarks" => "",
                        "SyncRequiredOnHeadServer" => 0,
                        "CertificateDownloadPath" => $this->session->userdata("CertificateDownloadPath"),
                        "OthersDownloadPath" => $this->session->userdata("OthersDownloadPath"),
                        "softwarefileDownloadPath" => $this->session->userdata("SoftwareFileDownloadPath")
                    );
                    $table = "tblversiondefine";
                    $insid = $this->common_model->store_details($data_to_store, $table,"another_db");
                    //	var_dump($data_to_store);
                    foreach ($vendorFields as $vfield) {
                        $field = $this->common_model->find_details("RecordStatus = 1 and VersionFieldsMasterID = '" . $vfield["field_id"] . "'", "tbl_versionfields_master", "field_display_name,VersionFieldsMasterID, field_name, is_autofield", "", "", "1","another_db");
                        if ($field[0]["is_autofield"] == 1) {
                            //if($vfield["is_mandatory"] == "1"){
                            $field_data = $this->input->post($field[0]["field_name"]);
                            if ($field_data != "") {
                                $cust_data = array(
                                    "define_id" => $insid,
                                    "field_id" => $field[0]["VersionFieldsMasterID"],
                                    "field_dis" => $field[0]["field_display_name"],
                                    "field_name" => $field[0]["field_name"],
                                    "field_value" => $field_data
                                );
                                $this->common_model->store_details($cust_data, "tblversiondefine_custom_fields","another_db");
                            }
                            //}
                        }
                    }
                    $Count = count($this->session->userdata("temp_cpu_details"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->session->userdata('RailwayID'), "DivisionID" => $this->session->userdata('DivisionID'), "VersionID" => $VersionLogicID, "StationID" => $this->session->userdata('StationID'), "VendorID" => $this->session->userdata('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu","","another_db");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = $this->session->userdata("temp_cpu_details")[$i];
                        $table = "tbl_versionsubcpu";
                        $this->common_model->store_details($data_to_store, $table,"another_db");
                    }
                    $Count = count($this->session->userdata("temp_parameter_details"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->session->userdata('RailwayID'), "DivisionID" => $this->session->userdata('DivisionID'), "VersionID" => $VersionLogicID, "StationID" => $this->session->userdata('StationID'), "VendorID" => $this->session->userdata('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters","","another_db");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = $this->session->userdata("temp_parameter_details")[$i];
                        $table = "tbl_versionsubuserdefinedparameters";
                        $this->common_model->store_details($data_to_store, $table,"another_db");
                    }
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Version Details Added SuccessFully";
                    $data['flash_message'] = FALSE;
                    $this->session->set_flashdata("success_done", "Version Details Added SuccessFully");
                    redirect(base_url() . "Admin/addnew-version");
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            } else {
                var_dump(validation_errors());
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $session_unset = array(
            "VersionID" =>"",
            "RailwayID" => "",
            "DivisionID" => "",
            'StationID' => "",
            'VendorID' => "",
            "NoOfCPU" => "",
            "isDistributedVersionType" => "",
            'SignalPlanNumber' => "",
            "InstallationAlterationDate" => "",
            "DescriptionOfWork" => "",
            'WorkExecutedBy' => "",
            //"PreviousESwVersion" => $this->input->post('PreviousESwVersion'),
            //"PreviousESwChecksum" => $this->input->post('PreviousESwChecksum'),
            'CurrentESwVersion' => "",
            "CurrentESwChecksum" => "",
            'CreatedBy' => "",
            'ModifiedBy' => "",
            'CreatedOn' => "",
            'ModifiedOn' => "",
            "CertificateDownloadPath" => "",
            "OthersDownloadPath" => "",
            "SoftwareFileDownloadPath" => ""
        );
        $this->session->set_userdata($session_unset);
        $this->load->view('Admin/Version/addnew-version', $data);
    }

    public function add_new_version($preview = "") {
        exit;
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Add New Version";
        $data['asset_url'] = site_url('assets/themes/');
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID");
        if ($preview != "preview" && $preview == "") {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('RailwayID', 'Railway ID', 'required');
                $this->form_validation->set_rules('DivisionID', 'Division ID', 'required');
                $this->form_validation->set_rules('StationID', 'Station ID', 'required');
                $this->form_validation->set_rules('VendorID', 'Vendor ID', 'required');
                $this->form_validation->set_rules('isDistributedVersionType', 'Distributed Version Type', 'required');
                $this->form_validation->set_rules('SignalPlanNumber', 'Signal Plan Number', 'required');
                $this->form_validation->set_rules('InstallationAlterationDate', 'Installation Alteration Date', 'required');
                $this->form_validation->set_rules('DescriptionOfWork', 'Description Of Work', 'required');
                $this->form_validation->set_rules('WorkExecutedBy', 'Work Executed By', 'required');
                $data['division'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID")), "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
                $data['station'] = $this->common_model->find_details(array("RecordStatus" => 1, "RailwayID" => $this->input->post("RailwayID"), "DivisionID" => $this->input->post("DivisionID")), "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
                if ($this->form_validation->run()) {
                    $datatostore = array(
                        "VersionID" => $this->input->post('VersionID'),
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VendorID' => $this->input->post('VendorID'),
                        "ApplicationDownloadPath" => $this->input->post('ApplicationDownloadPath'),
                        "ApplicationFolderCountAvailable" => $this->input->post('ApplicationFolderCountAvailable'),
                        "ApplicationFileCountAvailable" => $this->input->post('ApplicationFileCountAvailable'),
                        "ApplicationImportantFilesAvailable" => $this->input->post('ApplicationImportantFilesAvailable'),
                        "InterfaceDownloadPath" => $this->input->post('InterfaceDownloadPath'),
                        "InterfaceFolderCountAvailable" => $this->input->post('InterfaceFolderCountAvailable'),
                        "InterfaceFileCountAvailable" => $this->input->post('InterfaceFileCountAvailable'),
                        "InterfaceImportantFilesAvailable" => $this->input->post('InterfaceImportantFilesAvailable'),
                        "VduDownloadPath" => $this->input->post('VduDownloadPath'),
                        "VduFolderCountAvailable" => $this->input->post('VduFolderCountAvailable'),
                        "VduFileCountAvailable" => $this->input->post('VduFileCountAvailable'),
                        "VduImportantFilesAvailable" => $this->input->post('VduImportantFilesAvailable'),
                        "NoOfCPU" => $this->input->post('NoOfCPU'),
                        "isDistributedVersionType" => $this->input->post('isDistributedVersionType'),
                        'SignalPlanNumber' => $this->input->post('SignalPlanNumber'),
                        "InstallationAlterationDate" => $this->input->post('InstallationAlterationDate'),
                        "DescriptionOfWork" => $this->input->post('DescriptionOfWork'),
                        'WorkExecutedBy' => $this->input->post('WorkExecutedBy'),
                        "PreviousESwVersion" => $this->input->post('PreviousESwVersion'),
                        "PreviousESwChecksum" => $this->input->post('PreviousESwChecksum'),
                        'CurrentESwVersion' => $this->input->post('CurrentESwVersion'),
                        "CurrentESwChecksum" => $this->input->post('CurrentESwChecksum'),
                        'CreatedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'CreatedOn' => date("Y-m-d H:i:s"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                        "ApplicationFolderVal" => $this->input->post("ApplicationFolderVal"),
                        "ApplicationFileVal" => $this->input->post("ApplicationFileVal"),
                        "ApplicationImportantFilesVal" => $this->input->post("ApplicationImportantFilesVal"),
                        "InterfaceFolderVal" => $this->input->post("InterfaceFolderVal"),
                        "InterfaceFileVal" => $this->input->post("InterfaceFileVal"),
                        "InterfaceImportantFilesVal" => $this->input->post("InterfaceImportantFilesVal"),
                        "VduFolderVal" => $this->input->post("VduFolderVal"),
                        "VduFileVal" => $this->input->post("VduFileVal"),
                        "VduImportantFilesVal" => $this->input->post("VduImportantFilesVal"),
                        "VersionID" => $this->input->post("VersionID"),
                        "ApplicationFileImportant" => $this->input->post("ApplicationFileImportant"),
                        "InterfaceFileImportant" => $this->input->post("InterfaceFileImportant"),
                        "VduFileImportant" => $this->input->post("VduFileImportant"),
                        "CertificateDownloadPath" => $this->input->post("CertificateDownloadPath"),
                        "OthersDownloadPath" => $this->input->post("OthersDownloadPath"),
                    );
                    $this->session->set_userdata($datatostore);
                    $Count = count($this->input->post("PreviousVital"));
                    $data_cpu_details = array();
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = array(
                            'VendorID' => $this->input->post('VendorID'),
                            "RailwayID" => $this->input->post('RailwayID'),
                            "DivisionID" => $this->input->post('DivisionID'),
                            'StationID' => $this->input->post('StationID'),
                            'VersionID' => $this->input->post('VersionID'),
                            'CpuNo' => $i + 1,
                            "PreviousVital" => $this->input->post('PreviousVital')[$i],
                            'PreviousNonVital' => $this->input->post('PreviousNonVital')[$i],
                            "CurrentVital" => $this->input->post('CurrentVital')[$i],
                            "CurentNonVital" => $this->input->post('CurentNonVital')[$i],
                        );
                        array_push($data_cpu_details, $data_to_store);
                    }
                    $data_cpu_details_session['temp_cpu_details'] = $data_cpu_details;
                    $this->session->set_userdata($data_cpu_details_session);
                    $Count = count($this->input->post("ParameterValue"));
                    $data_parameter_details = array();
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = array(
                            "RailwayID" => $this->input->post('RailwayID'),
                            "DivisionID" => $this->input->post('DivisionID'),
                            'StationID' => $this->input->post('StationID'),
                            'VendorID' => $this->input->post('VendorID'),
                            'VersionID' => $this->input->post('VersionID'),
                            "ParameterId" => $i + 1,
                            "ParameterName" => $this->input->post('ParameterName')[$i],
                            'ParameterValue' => $this->input->post('ParameterValue')[$i],
                        );
                        array_push($data_parameter_details, $data_to_store);
                    }
                    $data_parameter_details_session['temp_parameter_details'] = $data_parameter_details;
                    $this->session->set_userdata($data_parameter_details_session);
                } else {
                    var_dump(validation_errors());
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
                redirect(site_url("Admin/add-new-version/preview"));
            }
            $this->load->view('Admin/Version/add-new-version', $data);
        } else {
            $cond = array(
                "tblversiondefine.RecordStatus" => "1",
                "tblversiondefine.RailwayID" => $this->session->userdata("RailwayID"),
                "tblversiondefine.DivisionID" => $this->session->userdata("DivisionID"),
                "tblversiondefine.VersionID" => $this->session->userdata("VersionID"),
                "tblversiondefine.StationID" => $this->session->userdata("StationID"),
                "tblversiondefine.VendorID" => $this->session->userdata("VendorID")
            );
            $data['version'] = $this->common_model->find_version_details($cond,"","another_db");
            $data['temp_parameter_details'] = $this->session->userdata("temp_parameter_details");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $cond = array("RecordStatus" => "1", "RailwayID" => $this->session->userdata('RailwayID'), "DivisionID" => $this->session->userdata('DivisionID'), "VersionID" => $this->session->userdata('VersionID'), "StationID" => $this->session->userdata('StationID'), "VendorID" => $this->session->userdata('VendorID'));
                $data_to_store = array(
                    "VersionID" => $this->session->userdata('VersionID'),
                    "RailwayID" => $this->session->userdata('RailwayID'),
                    "DivisionID" => $this->session->userdata('DivisionID'),
                    'StationID' => $this->session->userdata('StationID'),
                    'VendorID' => $this->session->userdata('VendorID'),
                    "ApplicationDownloadPath" => $this->session->userdata('ApplicationDownloadPath'),
                    "ApplicationFolderCountAvailable" => $this->session->userdata('ApplicationFolderCountAvailable'),
                    "ApplicationFileCountAvailable" => $this->session->userdata('ApplicationFileCountAvailable'),
                    "ApplicationImportantFilesAvailable" => $this->session->userdata('ApplicationImportantFilesAvailable'),
                    "InterfaceDownloadPath" => $this->session->userdata('InterfaceDownloadPath'),
                    "InterfaceFolderCountAvailable" => $this->session->userdata('InterfaceFolderCountAvailable'),
                    "InterfaceFileCountAvailable" => $this->session->userdata('InterfaceFileCountAvailable'),
                    "InterfaceImportantFilesAvailable" => $this->session->userdata('InterfaceImportantFilesAvailable'),
                    "VduDownloadPath" => $this->session->userdata('VduDownloadPath'),
                    "VduFolderCountAvailable" => $this->session->userdata('VduFolderCountAvailable'),
                    "VduFileCountAvailable" => $this->session->userdata('VduFileCountAvailable'),
                    "VduImportantFilesAvailable" => $this->session->userdata('VduImportantFilesAvailable'),
                    "NoOfCPU" => $this->session->userdata('NoOfCPU'),
                    "isDistributedVersionType" => $this->session->userdata('isDistributedVersionType'),
                    'SignalPlanNumber' => $this->session->userdata('SignalPlanNumber'),
                    "InstallationAlterationDate" => $this->session->userdata('InstallationAlterationDate'),
                    "DescriptionOfWork" => $this->session->userdata('DescriptionOfWork'),
                    'WorkExecutedBy' => $this->session->userdata('WorkExecutedBy'),
                    "PreviousESwVersion" => $this->session->userdata('PreviousESwVersion'),
                    "PreviousESwChecksum" => $this->session->userdata('PreviousESwChecksum'),
                    'CurrentESwVersion' => $this->session->userdata('CurrentESwVersion'),
                    "CurrentESwChecksum" => $this->session->userdata('CurrentESwChecksum'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => $this->session->userdata("CreatedOn"),
                    'ModifiedOn' => $this->session->userdata("ModifiedOn"),
                    "CertificateDownloadPath" => $this->session->userdata("CertificateDownloadPath"),
                    "OthersDownloadPath" => $this->session->userdata("OthersDownloadPath"),
                );
                $table = "tblversiondefine";
                if ($this->common_model->update_cond_details($cond, $data_to_store, $table)) {

                    $Count = count($this->session->userdata("temp_cpu_details"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->session->userdata('RailwayID'), "DivisionID" => $this->session->userdata('DivisionID'), "VersionID" => $this->session->userdata('VersionID'), "StationID" => $this->session->userdata('StationID'), "VendorID" => $this->session->userdata('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = $this->session->userdata("temp_cpu_details")[$i];
                        $table = "tbl_versionsubcpu";
                        $this->common_model->store_details($data_to_store, $table);
                    }
                    $Count = count($this->session->userdata("temp_parameter_details"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->session->userdata('RailwayID'), "DivisionID" => $this->session->userdata('DivisionID'), "VersionID" => $this->session->userdata('VersionID'), "StationID" => $this->session->userdata('StationID'), "VendorID" => $this->session->userdata('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = $this->session->userdata("temp_parameter_details")[$i];
                        $table = "tbl_versionsubuserdefinedparameters";
                        $this->common_model->store_details($data_to_store, $table);
                    }
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Version Added";
                    $data['flash_message'] = TRUE;
                    header('Refresh:1; url= ' . site_url() . 'Admin/view-version/');
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            }
            $this->load->view('Admin/Version/add-new-version-preview', $data);
        }
    }

    public function view_version() {
		
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['tour_visible'] = "active";
        $data['title'] = "View Version";
        $data['asset_url'] = site_url('assets/themes/');
		$data['version']=array();
        //$data['version'] = $this->common_model->find_version_details_latest();
        $zoneID = "";
        $DivisionID = "";
		$StationID = "";
        if ($this->input->server('REQUEST_METHOD') === 'GET') 
		{
            $zoneID = $this->input->get("RailwayID");
			$DivisionID = $this->input->get("DivisionID");
				
			 /*$this->form_validation->set_rules('RailwayID', 'Railway ID', 'required');
			 $this->form_validation->set_rules('DivisionID', 'Division ID', 'required');
			 if ($this->form_validation->run()) 
			 {*/
				 $cond_user_header = array(
					"UserID" => $this->session->userdata("id_session_list"),
				);
				$user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
				if (count($user_details_header) > 0) {
					$levelid = $user_details_header[0]['LevelID'];
					
					
					if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole") != "Admin") {
						$StationID = $this->session->userdata("station_session_list");
					}
				}
				
				$data['version'] = $this->common_model->find_version_details_latest_new($zoneID, $DivisionID, $StationID,"another_db");
			// }
        }
        $data['zoneID'] = $zoneID;
        $data['DivisionID'] = $DivisionID;

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID","","","","another_db");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject","","","","another_db");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
        
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID","","","","another_db");
        $cond_zone = "RecordStatus = 1";
        $cond_div = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        $cond_stn = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
            "DivisionID" => $DivisionID,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2) {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 4) {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                $cond_stn = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                    "StationID" => $StationID,
                );
            }
            if($this->session->userdata("UserRole")=="Admin")
            {
                $cond_zone = "RecordStatus = 1";
            }
        }

        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID","","","","another_db");


        $this->load->view('Admin/Version/view-version', $data);
    }

    public function edit_version($id, $did, $sid, $vid, $verid) {
     $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Edit Version";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array(
            "tblversiondefine.RecordStatus" => "1",
            "tblversiondefine.RailwayID" => $id,
            "tblversiondefine.DivisionID" => $did,
            "tblversiondefine.VersionID" => $verid,
            "tblversiondefine.StationID" => $sid,
            "tblversiondefine.VendorID" => $vid
        );
        

        $define_record = $this->common_model->find_details($cond, "tblversiondefine", "ID,RecordStatus,RailwayID,DivisionID,VersionID,StationID,VendorID,CreatedOn","","","","another_db");

		$data['verified_master'] = $this->common_model->find_details(array("for_field" => 2, "RailwayID" => $define_record[0]['RailwayID']), "tbl_version_fields", "field_value as text","","","","another_db");
        $data['approved_master'] = $this->common_model->find_details(array("for_field" => 3, "RailwayID" => $define_record[0]['RailwayID']), "tbl_version_fields", "field_value as text","","","","another_db");
		
        $data['verifiedby_the'] = $this->common_model->find_details("define_id='" . $define_record[0]['ID'] . "' and field_id=23", "tblversiondefine_custom_fields", "*","","","","another_db");
        $data['approved_by_the'] = $this->common_model->find_details("define_id='" . $define_record[0]['ID'] . "' and field_id=24", "tblversiondefine_custom_fields", "*","","","","another_db");


        $data['extrafields'] = $this->common_model->find_details(array("RailwayID" => $define_record[0]['RailwayID']), "tbl_version_fields","","","","","another_db");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $cond = array("RecordStatus" => "1", "RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
            $define_record = $this->common_model->find_details($cond, "tblversiondefine", "ID,RecordStatus,RailwayID,DivisionID,VersionID,StationID,VendorID,CreatedOn","","","","another_db");
            $versionmodificationlimit = $this->common_model->find_details("RecordStatus = 1", "tblversionmodificationlimit", "NoOfDays, ID","","","","another_db");
            //$now = time();
            $now = strtotime(date("Y-m-d H:i:s"));
            $created_date = $define_record[0]['CreatedOn'];
            $exp_date = date('Y-m-d H:i:s', strtotime($created_date));
            $datediff = $now - strtotime($exp_date);
            $dc = round($datediff / (60 * 60 * 24));
            if ($dc <= $versionmodificationlimit[0]['NoOfDays']) {

                //Valid has days
                //$message = "System has " . $dc . " Days Left for Expiry";

                $nocpu = "0";
                if ($this->input->post('NoOfCPU')) {
                    if ($this->input->post('NoOfCPU') != "") {
                        $nocpu = $this->input->post('NoOfCPU');
                    }
                }

                $define_record_id = $define_record[0]["ID"];
                $data_to_store = array(
                    "VersionID" => $this->input->post('VersionID'),
                    "RailwayID" => $this->input->post('RailwayID'),
                    "DivisionID" => $this->input->post('DivisionID'),
                    'StationID' => $this->input->post('StationID'),
                    'VendorID' => $this->input->post('VendorID'),
                    'VersionID' => $this->input->post('VersionID'),
                    "NoOfCPU" => $nocpu,
                    "isDistributedVersionType" => $this->input->post('isDistributedVersionType'),
                    'SignalPlanNumber' => $this->input->post('SignalPlanNumber'),
                    "InstallationAlterationDate" => $this->input->post('InstallationAlterationDate'),
                    "DescriptionOfWork" => $this->input->post('DescriptionOfWork'),
                    'WorkExecutedBy' => $this->input->post('WorkExecutedBy'),
                    "PreviousESwVersion" => $this->input->post('PreviousESwVersion'),
                    "PreviousESwChecksum" => $this->input->post('PreviousESwChecksum'),
                    'CurrentESwVersion' => $this->input->post('CurrentESwVersion'),
                    "CurrentESwChecksum" => $this->input->post('CurrentESwChecksum'),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedOn' => $this->input->post("ModifiedOn"),
                    "CertificateDownloadPath" => $this->input->post("CertificateDownloadPath"),
                    "OthersDownloadPath" => $this->input->post("OthersDownloadPath"),
                    "softwarefileDownloadPath" => $this->input->post("SoftwareFileDownloadPath")
                );
                $user_input=$this->input->post();
                if(isset($user_input["PreviousVital"])){
                    $Count = count($user_input["PreviousVital"]);
                }else{
                    $Count=0;
                }
               
                $data_to_store_cpu_array = array();
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store_cpu = array(
                        'VendorID' => $this->input->post('VendorID'),
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VersionID' => $this->input->post('VersionID'),
                        'CpuNo' => $i + 1,
                        "PreviousVital" => $this->input->post('PreviousVital')[$i],
                        'PreviousNonVital' => $this->input->post('PreviousNonVital')[$i],
                        "CurrentVital" => $this->input->post('CurrentVital')[$i],
                        "CurentNonVital" => $this->input->post('CurentNonVital')[$i],
                    );
                    array_push($data_to_store_cpu_array, $data_to_store_cpu);
                }
                $Count = count($this->input->post("ParameterName"));
                $data_to_store_parameter_array = array();
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store_parameter = array(
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VendorID' => $this->input->post('VendorID'),
                        'VersionID' => $this->input->post('VersionID'),
                        "ParameterId" => $i + 1,
                        "ParameterName" => $this->input->post('ParameterName')[$i],
                        'ParameterValue' => $this->input->post('ParameterValue')[$i],
                    );
                    array_push($data_to_store_parameter_array, $data_to_store_parameter);
                }
                $data_content = array(
                    "fulldata" => $data_to_store,
                    "cpu_details" => $data_to_store_cpu_array,
                    "parameter_details" => $data_to_store_parameter_array,
                );
                $cond_user = array(
                    "UserID" => $this->session->userdata("id_session_list"),
                );
                $user_details = $this->common_model->find_details($cond_user, "tblusermaster", "LevelID, DesignationID","","","","another_db");
                $message = "";
                if (count($user_details) > 0) {
                    $cond_level = array(
                        "LevelID <" => $user_details[0]['LevelID'],
                    );
                    $user_Level_details = $this->common_model->find_details("", "tbllevelmaster", "LevelID","","","","another_db");
                    /* if (count($user_Level_details) > 0) {
                      $cond_check = array("Status" => "Pending", 'CreatedBy' => $this->session->userdata("id_session_list"), "RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
                      $user_notification_details = $this->common_model->find_details($cond_check, "tblnotifications", "DivisionID");
                      if (count($user_notification_details) > 0) {
                      $message = "Already Send for Approval";
                      } else {
                      $noti_details = $this->common_model->find_details("RailwayID = " . $this->input->post('RailwayID') . " and DivisionID = " . $this->input->post('DivisionID') . " and StationID = " . $this->input->post('StationID') . " and VersionID = " . $this->input->post('VersionID') . " and VendorID = " . $this->input->post('VendorID'), "tblnotifications", "max(NID) as NID");
                      if (count($noti_details) > 0) {
                      $NID = $noti_details[0]['NID'] + 1;
                      } else {
                      $NID = 1;
                      }
                      foreach ($user_Level_details as $rows) {
                      $data_to_add = array(
                      "NotificationFrom" => $this->session->userdata("id_session_list"),
                      "NotificationTo" => $rows['LevelID'],
                      "NotificationContent" => json_encode($data_content),
                      'CreatedBy' => $this->session->userdata("id_session_list"),
                      'ModifiedBy' => $this->session->userdata("id_session_list"),
                      'CreatedOn' => $this->input->post("CreatedOn"),
                      'ModifiedOn' => $this->input->post("ModifiedOn"),
                      'NotificationFrom' => $user_details[0]['LevelID'],
                      "RailwayID" => $this->input->post('RailwayID'),
                      "DivisionID" => $this->input->post('DivisionID'),
                      'StationID' => $this->input->post('StationID'),
                      'VendorID' => $this->input->post('VendorID'),
                      'VersionID' => $this->input->post('VersionID'),
                      'NotificationType' => "Edit",
                      "NID" => $NID
                      );
                      $table = "tblnotifications";
                      if ($this->common_model->store_details($data_to_add, $table)) {

                      }
                      }
                      $message = "Request for approve to edit details";
                      }
                      } else { */
                    $this->common_model->update_cond_details($cond, $data_to_store,"tblversiondefine","another_db");
                    $vendorFields = $this->common_model->find_details("RecordStatus = 1 and VendorID = '" . $this->input->post('VendorID') . "'", "tbl_versionfields_vendor_map", "VendorID, field_id, is_visible, is_mandatory","","","","another_db");
                    foreach ($vendorFields as $vfield) {
                        $field = $this->common_model->find_details("RecordStatus = 1 and VersionFieldsMasterID = '" . $vfield["field_id"] . "'", "tbl_versionfields_master", "field_display_name,VersionFieldsMasterID, field_name, is_autofield", "", "", "1","another_db");
                        if ($field[0]["is_autofield"] == 1) {
                            //if($vfield["is_mandatory"] == "1"){
                            $field_data = $this->input->post($field[0]["field_name"]);
                            if ($field_data != "") {
                                $cust_data = array(
                                    "define_id" => $define_record_id,
                                    "field_id" => $field[0]["VersionFieldsMasterID"],
                                    "field_dis" => $field[0]["field_display_name"],
                                    "field_name" => $field[0]["field_name"],
                                    "field_value" => $field_data
                                );
                                $checkfield_exists = $this->common_model->find_details("define_id = '" . $define_record_id . "' and field_id = '" . $field[0]["VersionFieldsMasterID"] . "'", "tblversiondefine_custom_fields","","","","another_db");
                                if (count($checkfield_exists) > 0) {
                                    //Update
                                    $this->common_model->update_cond_details("define_id = '" . $define_record_id . "' and field_id = '" . $field[0]["VersionFieldsMasterID"] . "'", $cust_data, "tblversiondefine_custom_fields","another_db");
                                } else {
                                    //Insert
                                    $this->common_model->store_details($cust_data, "tblversiondefine_custom_fields","another_db");
                                }
                            }
                            //}
                        }
                    }

                    $Count = count($this->input->post("PreviousVital"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu","","another_db");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = array(
                            'VendorID' => $this->input->post('VendorID'),
                            "RailwayID" => $this->input->post('RailwayID'),
                            "DivisionID" => $this->input->post('DivisionID'),
                            'StationID' => $this->input->post('StationID'),
                            'VersionID' => $this->input->post('VersionID'),
                            'CpuNo' => $i + 1,
                            "PreviousVital" => $this->input->post('PreviousVital')[$i],
                            'PreviousNonVital' => $this->input->post('PreviousNonVital')[$i],
                            "CurrentVital" => $this->input->post('CurrentVital')[$i],
                            "CurentNonVital" => $this->input->post('CurentNonVital')[$i]
                        );
                        $table = "tbl_versionsubcpu";
                        $this->common_model->store_details($data_to_store, $table,"another_db");
                    }
                    $Count = count($this->input->post("ParameterName"));
                    if ($Count > 0) {
                        $cond = array("RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
                        $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters","","another_db");
                    }
                    for ($i = 0; $i < $Count; $i++) {
                        $data_to_store = array(
                            "RailwayID" => $this->input->post('RailwayID'),
                            "DivisionID" => $this->input->post('DivisionID'),
                            'StationID' => $this->input->post('StationID'),
                            'VendorID' => $this->input->post('VendorID'),
                            'VersionID' => $this->input->post('VersionID'),
                            "ParameterId" => $i + 1,
                            "ParameterName" => $this->input->post('ParameterName')[$i],
                            'ParameterValue' => $this->input->post('ParameterValue')[$i],
                        );
                        $table = "tbl_versionsubuserdefinedparameters";
                        $this->common_model->store_details($data_to_store, $table,"another_db");
                    }
                    $message = "Version Updated";
                    //}
                }
                $data['color_code'] = "#3a5a9c";
                $data['display_value'] = "block";
                $data['message'] = $message;
                $data['flash_message'] = TRUE;
            } else {

                //Expired
                $data['color_code'] = "#3a5a9c";
                $data['display_value'] = "block";
                $data['message'] = "Modification Limit Reached";
                //$data['message'] = ;
                $data['flash_message'] = TRUE;
            }
        }
        $cond = array(
            "tblversiondefine.RecordStatus" => "1",
            "tblversiondefine.RailwayID" => $id,
            "tblversiondefine.DivisionID" => $did,
            "tblversiondefine.VersionID" => $verid,
            "tblversiondefine.StationID" => $sid,
            "tblversiondefine.VendorID" => $vid
        );
        $data['version'] = $this->common_model->find_version_details($cond,"","another_db");


        $fields = $this->common_model->find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield","","","","another_db");
        $data['fields'] = $fields;

        $cond = array(
            "RailwayID" => $id,
            "DivisionID" => $did,
            "VersionID" => $verid,
            "StationID" => $sid,
            "VendorID" => $vid
        );
        $data['cpu_details'] = $this->common_model->find_details($cond, "tbl_versionsubcpu","","","","","another_db");
        $data['parameter_details'] = $this->common_model->find_details($cond, "tbl_versionsubuserdefinedparameters","","","","","another_db");
        $data['current_user'] = $this->session->userdata("id_session_list");
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID","","","","another_db");
        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1,
            "RailwayID" => $id,
        );
        $data['cond_stn'] = array(
            "tblstationmaster.RecordStatus" => 1,
            "tblstationmaster.RailwayID" => $id,
            "tblstationmaster.DivisionID" => $did,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                // $cond_zone = "RecordStatus = 1";
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $data['cond_div'] = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $data['cond_div'] = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                $data['cond_stn'] = array(
                    "tblstationmaster.RecordStatus" => 1,
                    "tblstationmaster.RailwayID" => $id,
                    "tblstationmaster.DivisionID" => $did,
                    "tblstationmaster.StationID" => $StationID,
                );
            }
        }
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID","","","","another_db");
        $data['division_div']=  $this->common_model->find_details($data['cond_div'], "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID","","","","another_db");
       
        /*$this->db->group_by("tblstationmaster.StationID, tblstationmaster.DivisionID, tblstationmaster.RailwayID");
        $this->db->join("tblversiondefine","tblversiondefine.RailwayID=tblstationmaster.RailwayID and tblversiondefine.DivisionID=tblstationmaster.DivisionID and tblversiondefine.StationID=tblstationmaster.StationID","left");
                             
        $data['station_div'] = $this->common_model->find_details($data['cond_stn'], "tblstationmaster", "tblstationmaster.StationName, tblstationmaster.StationCode, tblstationmaster.StationID, tblstationmaster.RailwayID,tblversiondefine.StationID as is_include");
        */
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID","","","","another_db");
        
        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VendorID" => $vid, "tblversiondefine.StationID" => $sid);
        $data['version_logic'] = $this->common_model->find_version_logic_details_with_main($cond,"another_db");

        $cust_field_rec = $this->common_model->find_details("define_id='" . $data['version_logic'][0]['ID'] . "'", "tblversiondefine_custom_fields", "*","","","","another_db");
        $data['cust_field'] = $cust_field_rec;



        $this->load->view('Admin/Version/edit-version', $data);
    }

    public function edit_version_approved($id, $did, $sid, $vid, $verid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Edit Version";
        $data['asset_url'] = site_url('assets/themes/');
        $cond = array(
            "tblversiondefine.RecordStatus" => "1",
            "tblversiondefine.RailwayID" => $id,
            "tblversiondefine.DivisionID" => $did,
            "tblversiondefine.VersionID" => $verid,
            "tblversiondefine.StationID" => $sid,
            "tblversiondefine.VendorID" => $vid
        );
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $cond = array("RecordStatus" => "1", "RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
            $data_to_store = array(
                "VersionID" => $this->input->post('VersionID'),
                "RailwayID" => $this->input->post('RailwayID'),
                "DivisionID" => $this->input->post('DivisionID'),
                'StationID' => $this->input->post('StationID'),
                'VendorID' => $this->input->post('VendorID'),
                "NoOfCPU" => $this->input->post('NoOfCPU'),
                "isDistributedVersionType" => $this->input->post('isDistributedVersionType'),
                'SignalPlanNumber' => $this->input->post('SignalPlanNumber'),
                "InstallationAlterationDate" => $this->input->post('InstallationAlterationDate'),
                "DescriptionOfWork" => $this->input->post('DescriptionOfWork'),
                'WorkExecutedBy' => $this->input->post('WorkExecutedBy'),
                "PreviousESwVersion" => $this->input->post('PreviousESwVersion'),
                "PreviousESwChecksum" => $this->input->post('PreviousESwChecksum'),
                'CurrentESwVersion' => $this->input->post('CurrentESwVersion'),
                "CurrentESwChecksum" => $this->input->post('CurrentESwChecksum'),
                'CreatedBy' => $this->session->userdata("id_session_list"),
                'ModifiedBy' => $this->session->userdata("id_session_list"),
                'CreatedOn' => $this->input->post("CreatedOn"),
                'ModifiedOn' => $this->input->post("ModifiedOn"),
                "CertificateDownloadPath" => $this->input->post("CertificateDownloadPath"),
                "OthersDownloadPath" => $this->input->post("OthersDownloadPath"),
            );
            $table = "tblversiondefine";
            if ($this->common_model->update_cond_details($cond, $data_to_store, $table)) {

                $Count = count($this->input->post("PreviousVital"));
                if ($Count > 0) {
                    $cond = array("RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
                    $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu");
                }
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store = array(
                        'VendorID' => $this->input->post('VendorID'),
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VersionID' => $this->input->post('VersionID'),
                        'CpuNo' => $i + 1,
                        "PreviousVital" => $this->input->post('PreviousVital')[$i],
                        'PreviousNonVital' => $this->input->post('PreviousNonVital')[$i],
                        "CurrentVital" => $this->input->post('CurrentVital')[$i],
                        "CurentNonVital" => $this->input->post('CurentNonVital')[$i],
                    );
                    $table = "tbl_versionsubcpu";
                    $this->common_model->store_details($data_to_store, $table);
                }
                $Count = count($this->input->post("ParameterName"));
                if ($Count > 0) {
                    $cond = array("RailwayID" => $this->input->post('RailwayID'), "DivisionID" => $this->input->post('DivisionID'), "VersionID" => $this->input->post('VersionID'), "StationID" => $this->input->post('StationID'), "VendorID" => $this->input->post('VendorID'));
                    $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters");
                }
                for ($i = 0; $i < $Count; $i++) {
                    $data_to_store = array(
                        "RailwayID" => $this->input->post('RailwayID'),
                        "DivisionID" => $this->input->post('DivisionID'),
                        'StationID' => $this->input->post('StationID'),
                        'VendorID' => $this->input->post('VendorID'),
                        'VersionID' => $this->input->post('VersionID'),
                        "ParameterId" => $i + 1,
                        "ParameterName" => $this->input->post('ParameterName')[$i],
                        'ParameterValue' => $this->input->post('ParameterValue')[$i],
                    );
                    $table = "tbl_versionsubuserdefinedparameters";
                    $this->common_model->store_details($data_to_store, $table);
                }
                $data['color_code'] = "#3a5a9c";
                $data['display_value'] = "block";
                $data['message'] = "Version Added";
                $data['flash_message'] = TRUE;
            } else {
                $data['flash_message'] = FALSE;
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
            }
        }
        $cond = array(
            "tblversiondefine.RecordStatus" => "1",
            "tblversiondefine.RailwayID" => $id,
            "tblversiondefine.DivisionID" => $did,
            "tblversiondefine.VersionID" => $verid,
            "tblversiondefine.StationID" => $sid,
            "tblversiondefine.VendorID" => $vid
        );
        $data['version'] = $this->common_model->find_version_details($cond,"","another_db");
        
        $cond = array(
            "RailwayID" => $id,
            "DivisionID" => $did,
            "VersionID" => $verid,
            "StationID" => $sid,
            "VendorID" => $vid
        );

        $data['cpu_details'] = $this->common_model->find_details($cond, "tbl_versionsubcpu");
        $data['parameter_details'] = $this->common_model->find_details($cond, "tbl_versionsubuserdefinedparameters");
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID");
        $cond = array("tblversiondefine.RecordStatus" => "1", "tblversiondefine.RailwayID" => $id, "tblversiondefine.DivisionID" => $did, "tblversiondefine.VendorID" => $vid, "tblversiondefine.StationID" => $sid);
        $data['version_logic'] = $this->common_model->find_version_logic_details_with_main($cond,"another_db");
        $this->load->view('Admin/Version/edit-version', $data);
    }

    public function add_new_version_preview() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "View Version";
        $data['title'] = "Add New Version Preview";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/Version/add-new-version-preview', $data);
    }

    public function error_report() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Report";
        $data['title'] = "Error Report";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/error-report', $data);
    }

    public function create_user() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View User";
        $data['this_page_middle'] = "User";
        $data['title'] = "Create User";
        $data['asset_url'] = site_url('assets/themes/');
        $data['level'] = $this->common_model->find_level_details();
        $data['designation'] = $this->common_model->find_designation_details();
        //Restrict Zone, Division, Station Select data according to login level Id
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        $cond_zone = "RecordStatus = 1";
        $cond_div = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        $cond_stn = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
            "DivisionID" => $DivisionID,
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
            }

            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                );
                $cond_stn = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                    "DivisionID" => $DivisionID,
                    "StationID" => $StationID,
                );
            }
        }
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('LoginPassword', 'Please Enter password', 'required');
            $this->form_validation->set_rules('LoginPassword_confirmation', 'Password Confirmation', 'trim|required|matches[LoginPassword]');
            $this->form_validation->set_rules('LoginName', 'User Name', 'trim|required|is_unique[tblusermaster.LoginName]', array(
                'required' => 'You have not provided %s.',
                'is_unique' => 'This %s already exists.'
            ));
            $this->form_validation->set_rules('EmployeeName', 'Employee Name', 'required');
            //$this->form_validation->set_rules('RailwayID', 'Railway Zone', 'required');
            //$this->form_validation->set_rules('StationID', 'Station Name', 'required');
            //$this->form_validation->set_rules('DivisionID', 'Division Name', 'required');

            $this->form_validation->set_rules('LevelID', 'Level ID', 'required');
            $this->form_validation->set_rules('DesignationID', 'Designation ID', 'required');
            $data['division'] = $this->common_model->find_details($cond_div, "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
            $data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "StationName, StationCode, StationID, RailwayID");

            if ($this->form_validation->run()) {
                $rail_id = $this->input->post('RailwayID');
                $divi_id = $this->input->post('DivisionID');
                $stat_id = $this->input->post('StationID');
                if ($rail_id == 0 || $rail_id == NULL || $rail_id == '') {
                    $RailwayID = 1;
                } else {
                    $RailwayID = $this->input->post('RailwayID');
                }
                if ($divi_id == 0 || $divi_id == NULL || $divi_id == '') {
                    $DivisionID = 1;
                } else {
                    $DivisionID = $this->input->post('DivisionID');
                }
                if ($stat_id == 0 || $stat_id == NULL || $stat_id == '') {
                    $StationID = 1;
                } else {
                    $StationID = $this->input->post('StationID');
                }
                $data_to_store = array(
                    'LoginName' => $this->input->post('LoginName'),
                    'RailwayID' => $RailwayID,
                    'DivisionID' => $DivisionID,
                    'StationID' => $StationID,
                    'EmployeeName' => $this->input->post('EmployeeName'),
                    'LevelID' => $this->input->post('LevelID'),
                    'DesignationID' => $this->input->post('DesignationID'),
                    'LoginPassword' => $this->encryption->encrypt($this->input->post('LoginPassword')),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                    'IsAdmin' => ($this->input->post('IsAdmin') != NULL ? 1 : 0),
                );
                $table = "tblusermaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "User Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {

                //  echo validation_errors();exit;
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/User/create-user', $data);
    }

    public function Check_Username() {
        $value = $this->input->post("mobile");
        if ($value != "") {

            $total_count = $this->common_model->find_details(array("RecordStatus" => "1", "LoginName" => $value), "tblusermaster", "UserID");
            if (count($total_count) > 0) {
                echo 1;
            } else {
                echo 0;
            }
        }
    }

    public function view_user() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View User";
        $data['this_page_middle'] = "User";
        $data['title'] = "View User";
        $data['asset_url'] = site_url('assets/themes/');
		
		//Filter data based on login user level
		$RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        $cond_filter = "tblusermaster.RecordStatus = 1";
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.LevelID IN (2,3,4)";
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.DivisionID = ".$DivisionID." AND tblusermaster.LevelID IN (3,4)";
            }

            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.DivisionID = ".$DivisionID." AND tblusermaster.StationID = ".$StationID." AND tblusermaster.LevelID IN (4)";
            }
        }
		
        $data['user'] = $this->common_model->find_user_master_details($cond_filter);
	
        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/User/view-user', $data);
    }

    public function view_user_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View User";
        $data['this_page_middle'] = "User";
        $data['title'] = "View User Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $id));
        if (count($data['user']) > 0) {
            $this->load->view('Admin/User/view-user-detail', $data);
        } else {
            redirect(site_url('Admin/view-user'));
        }
    }
	
	public function user_profile() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['title'] = "View User Profile";
        $data['asset_url'] = site_url('assets/themes/');
        $data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $this->session->userdata("id_session_list")));
		if (count($data['user']) > 0) 
		{
			if ($this->input->server('REQUEST_METHOD') === 'POST') 
			{
				 $this->form_validation->set_rules('OldPassword', 'Old Password', 'required');
				 $this->form_validation->set_rules('LoginPassword', 'Login Password', 'required');
				 if ($this->form_validation->run()) 
				 {
					$oldpassword = $this->input->post('OldPassword');
					$decrypt = $this->encryption->decrypt($data['user'][0]['LoginPassword']);
					if($decrypt == $oldpassword)
					{
						 
						 if ($this->input->post('LoginPassword') != "" && $this->input->post('LoginRePassword')!="") 
						 {
							if ($this->input->post('LoginPassword') != $this->input->post('LoginRePassword') || $this->input->post('LoginRePassword') == "") 
							{
								$cond_check = true;
							} else {
								$cond_check = false;
							}
						}
						
						if (isset($cond_check)) 
						{
							if ($cond_check == false) 
							{
								$id = $this->session->userdata("id_session_list");
								$data_to_store = array(
									'LoginPassword' => $this->encryption->encrypt($this->input->post('LoginPassword')),
									'ModifiedBy' => $this->session->userdata("id_session_list"),
									'ModifiedOn' => date("Y-m-d H:i:s"),
								);
								if ($this->common_model->update_details("UserID", $id, $data_to_store, "tblusermaster")) {
									$data['flash_message'] = TRUE;
									$data['color_code'] = "#3a5a9c";
									$data['display_value'] = "block";
									$data['message'] = "Password Changed";
									$data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $id));
									
									redirect(site_url('Admin/logout'));
								} else {
									$data['flash_message'] = FALSE;
									$data['color_code'] = "#c50000";
									$data['display_value'] = "block";
									$data['message'] = "Validation Errors";
								}
							} else {
								$data['flash_message'] = FALSE;
								$data['color_code'] = "#c50000";
								$data['display_value'] = "block";
								$data['message'] = "Invalid Password Credentials";
							}
						} 
                    }
					else
					{
						$data['color_code'] = "#c50000";
						$data['display_value'] = "block";
						$data['message'] = "Current Password is incorrect";
						$data['flash_message'] = FALSE;
					}
				} else {
					$data['color_code'] = "#c50000";
					$data['display_value'] = "block";
					$data['message'] = "Validation Errors";
					$data['flash_message'] = FALSE;
				}	
			}
		}
		else 
		{
            redirect(site_url('Admin/'));
        }
		$this->load->view('Admin/User/user-profile', $data);
    }

    public function edit_user($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View User";
        $data['this_page_middle'] = "User";
        $data['title'] = "Edit User";
        $data['asset_url'] = site_url('assets/themes/');
        $data['level'] = $this->common_model->find_level_details();
        //$data['designation'] = $this->common_model->find_designation_details();
        $data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $id));

        $cond_stn = array(
            "RecordStatus" => "1",
            "LevelID" => $data['user'][0]['LevelID']
        );
        $data['designation'] = $this->common_model->find_details($cond_stn, "tbldesignationmaster", "DesignationID, DesignationName,DesignationID as is_include");


        if (count($data['user']) > 0) {
			$RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        $cond_zone = "RecordStatus = 1";
        $cond_div = array(
            "RecordStatus" => 1,
            "RailwayID" => $data['user'][0]['RailwayID'],
        );
        $cond_stn = array(
            "RecordStatus" => 1,
            "RailwayID" => $data['user'][0]['RailwayID'],
            "DivisionID" => $data['user'][0]['DivisionID'],
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                );
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                    "DivisionID" => $data['user'][0]['DivisionID'],
                );
            }

            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                );
                $cond_div = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                    "DivisionID" => $data['user'][0]['DivisionID'],
                );
                $cond_stn = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $data['user'][0]['RailwayID'],
                    "DivisionID" => $data['user'][0]['DivisionID'],
                    "StationID" => $data['user'][0]['StationID'],
                );
            }
        }
        $data['zone'] = $this->common_model->find_details($cond_zone, "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
		
            $data['division'] = $this->common_model->find_details($cond_div, "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
            $data['station'] = $this->common_model->find_details($cond_stn, "tblstationmaster", "StationName, StationCode, StationID, RailwayID");
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("UserID", $id, "tblusermaster", "LoginName");
                if ($this->input->post('LoginName') != $original_value) {
                    $is_unique = '|is_unique[tblusermaster.LoginName]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('LoginName', 'Login Name', 'trim|required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                $this->form_validation->set_rules('EmployeeName', 'Employee Name', 'required');
                //$this->form_validation->set_rules('StationID', 'Station Name', 'required');
                $this->form_validation->set_rules('LevelID', 'Level ID', 'required');
                $this->form_validation->set_rules('DesignationID', 'Designation ID', 'required');
                if ($this->form_validation->run()) {
                    if ($this->input->post('LoginPassword') != "" && $this->input->post('LoginRePassword')!="") {
                        if ($this->input->post('LoginPassword') != $this->input->post('LoginRePassword') || $this->input->post('LoginRePassword') == "") {
                            $cond_check = true;
                        } else {
                            $cond_check = false;
                        }
                    }
					 
					$rail_id = $this->input->post('RailwayID');
					$divi_id = $this->input->post('DivisionID');
					$stat_id = $this->input->post('StationID');
					if ($rail_id == 0 || $rail_id == NULL || $rail_id == '') {
						$RailwayID = 1;
					} else {
						$RailwayID = $this->input->post('RailwayID');
					}
					if ($divi_id == 0 || $divi_id == NULL || $divi_id == '') {
						$DivisionID = 1;
					} else {
						$DivisionID = $this->input->post('DivisionID');
					}
					if ($stat_id == 0 || $stat_id == NULL || $stat_id == '') {
						$StationID = 1;
					} else {
						$StationID = $this->input->post('StationID');
					}
                    if (isset($cond_check)) {
                        if ($cond_check == false) {
                            $data_to_store = array(
                                'LoginName' => $this->input->post('LoginName'),
                                'RailwayID' => $RailwayID,
                                'DivisionID' => $DivisionID,
                                'StationID' => $StationID,
                                'EmployeeName' => $this->input->post('EmployeeName'),
                                'LevelID' => $this->input->post('LevelID'),
                                'DesignationID' => $this->input->post('DesignationID'),
                                'LoginPassword' => $this->encryption->encrypt($this->input->post('LoginPassword')),
                                'ModifiedBy' => $this->session->userdata("id_session_list"),
                                'ModifiedOn' => date("Y-m-d H:i:s"),
                                'IsAdmin' => ($this->input->post('IsAdmin') != NULL ? 1 : 0),
                            );
                            if ($this->common_model->update_details("UserID", $id, $data_to_store, "tblusermaster")) {
                                $data['flash_message'] = TRUE;
                                $data['color_code'] = "#3a5a9c";
                                $data['display_value'] = "block";
                                $data['message'] = "User Details Updated";
                                $data['flash_message'] = TRUE;
                                $data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $id));
                            } else {
                                $data['flash_message'] = FALSE;
                                $data['color_code'] = "#c50000";
                                $data['display_value'] = "block";
                                $data['message'] = "Validation Errors";
                            }
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['display_value'] = "block";
                            $data['message'] = "Invalid Password Credentials";
                        }
                    } else {
                        $data_to_store = array(
                            'LoginName' => $this->input->post('LoginName'),
							'RailwayID' => $RailwayID,
                            'DivisionID' => $DivisionID,
                            'StationID' => $StationID,
                            'LevelID' => $this->input->post('LevelID'),
                            'EmployeeName' => $this->input->post('EmployeeName'),
                            'DesignationID' => $this->input->post('DesignationID'),
                            'UserRole' => $this->input->post('UserRole'),
                            'ModifiedBy' => $this->session->userdata("id_session_list"),
                            'ModifiedOn' => date("Y-m-d H:i:s"),
                            'IsAdmin' => ($this->input->post('IsAdmin') != NULL ? 1 : 0),
                        );
                        if ($this->common_model->update_details("UserID", $id, $data_to_store, "tblusermaster")) {
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#3a5a9c";
                            $data['display_value'] = "block";
                            $data['message'] = "User Details Updated";
                            $data['flash_message'] = TRUE;
                            $data['user'] = $this->common_model->find_user_master_details(array("tblusermaster.RecordStatus" => "1", "tblusermaster.UserID" => $id));
                        } else {
                            $data['flash_message'] = FALSE;
                            $data['color_code'] = "#c50000";
                            $data['display_value'] = "block";
                            $data['message'] = "Validation Errors";
                        }
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-user'));
        }
        $this->load->view('Admin/User/edit-user', $data);
    }

    public function delete_user() {
        $value = $this->input->post("id");
        if ($value != "") {
            if ($this->common_model->delete_details('UserID', $value, "tblusermaster")) {
                $this->session->set_flashdata("success_done", "User Details Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function delete_parameter() {
        $cond = array(
            "ParameterId" => $this->input->post("ID"),
            "RailwayID" => $this->input->post("RailwayID"),
            "VendorID" => $this->input->post("VendorID"),
            "DivisionID" => $this->input->post("DivisionID"),
            "StationID" => $this->input->post("StationID"),
            "VersionID" => $this->input->post("VersionID"),
        );
        if ($cond) {
            $this->common_model->delete_cond_details($cond, "tbl_versionsubuserdefinedparameters");
            echo "1";
        } else {
            echo "0";
        }
    }

    public function delete_cpu() {
        $cond = array(
            "CpuNo" => $this->input->post("ID"),
            "RailwayID" => $this->input->post("RailwayID"),
            "VendorID" => $this->input->post("VendorID"),
            "DivisionID" => $this->input->post("DivisionID"),
            "StationID" => $this->input->post("StationID"),
            "VersionID" => $this->input->post("VersionID"),
        );
        if ($cond) {
            $this->common_model->delete_cond_details($cond, "tbl_versionsubcpu");
            echo "1";
        } else {
            echo "0";
        }
    }

    public function user_rights() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "User Rights";
        $data['this_page_middle'] = "User";
        $data['title'] = "User Rights";
        $data['asset_url'] = site_url('assets/themes/');
        $data['user_rights'] = $this->common_model->find_user_rights_details();

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/Role/user-rights', $data);
    }

    public function create_role() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "User Rights";
        $data['this_page_middle'] = "User";
        $data['title'] = "Create New Role";
        $data['asset_url'] = site_url('assets/themes/');
        $data['level'] = $this->common_model->find_details("RecordStatus = 1", "tbllevelmaster", "LevelName, LevelDescription, LevelID");
        $data['designation'] = $this->common_model->find_details("RecordStatus = 1", "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('LevelID', 'Level ID', 'required');
            $this->form_validation->set_rules('DesignationID', 'Designation ID', 'required');
            if ($this->form_validation->run()) {
                $role_details = $this->common_model->find_details("LevelID = " . $this->input->post('LevelID') . " and DesignationID = " . $this->input->post('DesignationID'), "tbluserrolemaster", "UserRoleID");
                if (count($role_details) > 0) {
                    $update = true;
                } else {
                    $update = false;
                }
                if ($update == true) {
                    $cond = array(
                        "tbluserrolemaster.RecordStatus" => "1",
                        "tbluserrolemaster.LevelID" => $this->input->post('LevelID'),
                        "tbluserrolemaster.DesignationID" => $this->input->post('DesignationID'),
                        "tbluserrolemaster.UserRoleID" => $role_details[0]['UserRoleID'],
                    );
                    $data_to_store = array(
                        'RoleDescription' => $this->input->post('RoleDescription'),
                        "LevelID" => $this->input->post('LevelID'),
                        "DesignationID" => $this->input->post('DesignationID'),
                        "View" => ($this->input->post('View') === 'Y') ? 1 : 0,
                        "Save" => ($this->input->post('Save') === 'Y') ? 1 : 0,
                        "Edit" => ($this->input->post('Edit') === 'Y') ? 1 : 0,
                        "Remove" => ($this->input->post('Remove') === 'Y') ? 1 : 0,
                        "Approve_Reject" => ($this->input->post('Approve_Reject') === 'Y') ? 1 : 0,
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    $table = "tbluserrolemaster";
                    if ($this->common_model->update_cond_details($cond, $data_to_store, $table)) {
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Role Updated";
                        $data['flash_message'] = TRUE;
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data_to_store = array(
                        'RoleDescription' => $this->input->post('RoleDescription'),
                        "LevelID" => $this->input->post('LevelID'),
                        "DesignationID" => $this->input->post('DesignationID'),
                        "View" => ($this->input->post('View') === 'Y') ? 1 : 0,
                        "Save" => ($this->input->post('Save') === 'Y') ? 1 : 0,
                        "Edit" => ($this->input->post('Edit') === 'Y') ? 1 : 0,
                        "Remove" => ($this->input->post('Remove') === 'Y') ? 1 : 0,
                        "Approve_Reject" => ($this->input->post('Approve_Reject') === 'Y') ? 1 : 0,
                        'CreatedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'CreatedOn' => date("Y-m-d H:i:s"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    $table = "tbluserrolemaster";
                    if ($this->common_model->store_details($data_to_store, $table)) {
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Role Added";
                        $data['flash_message'] = TRUE;
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Role/create-role', $data);
    }

    public function edit_role($lid, $did, $rid) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "User Rights";
        $data['this_page_middle'] = "User";
        $data['title'] = "Edit Role";
        $data['asset_url'] = site_url('assets/themes/');
		
		//Login User Level based edit access
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details_header) > 0) {
            if ($user_details_header[0]['LevelID'] > $lid && $this->session->userdata("UserRole")!="Admin") {
				redirect(site_url('Admin/unauthorized'));
			}
			else 
			{	
				$cond = array(
				"tbluserrolemaster.RecordStatus" => "1",
				"tbluserrolemaster.LevelID" => $lid,
				"tbluserrolemaster.DesignationID" => $did,
				"tbluserrolemaster.UserRoleID" => $rid,
				);
				$data['level'] = $this->common_model->find_details("RecordStatus = 1", "tbllevelmaster", "LevelName, LevelDescription, LevelID");
				$data['designation'] = $this->common_model->find_details("RecordStatus = 1", "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID");
				if ($this->input->server('REQUEST_METHOD') === 'POST') {
					$this->form_validation->set_rules('LevelID', 'Level ID', 'required');
					$this->form_validation->set_rules('DesignationID', 'Designation ID', 'required');
					if ($this->form_validation->run()) {
						$data_to_store = array(
							'RoleDescription' => $this->input->post('RoleDescription'),
							"LevelID" => $this->input->post('LevelID'),
							"DesignationID" => $this->input->post('DesignationID'),
							"View" => ($this->input->post('View') === 'Y') ? 1 : 0,
							"Save" => ($this->input->post('Save') === 'Y') ? 1 : 0,
							"Edit" => ($this->input->post('Edit') === 'Y') ? 1 : 0,
							"Remove" => ($this->input->post('Remove') === 'Y') ? 1 : 0,
							"Approve_Reject" => ($this->input->post('Approve_Reject') === 'Y') ? 1 : 0,
							'ModifiedBy' => $this->session->userdata("id_session_list"),
							'ModifiedOn' => date("Y-m-d H:i:s"),
						);
						$table = "tbluserrolemaster";
						if ($this->common_model->update_cond_details($cond, $data_to_store, $table)) {
							$data['color_code'] = "#3a5a9c";
							$data['display_value'] = "block";
							$data['message'] = "Role Updated";
							$data['flash_message'] = TRUE;
						} else {
							$data['flash_message'] = FALSE;
							$data['color_code'] = "#c50000";
							$data['display_value'] = "block";
							$data['message'] = "Validation Errors";
						}
					} else {
						$data['color_code'] = "#c50000";
						$data['display_value'] = "block";
						$data['message'] = "Validation Errors";
						$data['flash_message'] = FALSE;
					}
				}
				$data['user_rights'] = $this->common_model->find_user_rights_details($cond);
				$this->load->view('Admin/Role/edit-role', $data);
			}
        }
		
    }

    public function delete_role() {
        $lid = $this->input->post("lid");
        $did = $this->input->post("did");
        $rid = $this->input->post("rid");
        if ($lid != "") {
            $cond = array(
                "tbluserrolemaster.RecordStatus" => "1",
                "tbluserrolemaster.LevelID" => $lid,
                "tbluserrolemaster.DesignationID" => $did,
                "tbluserrolemaster.UserRoleID" => $rid,
            );
            if ($this->common_model->delete_cond_details($cond, "tbluserrolemaster")) {
                $this->session->set_flashdata("success_done", "Role Details Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function settings_ip() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Server IP Details";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Server IP Details";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            /* $this->form_validation->set_rules('ip_detail[]', 'Server Ip Address', 'trim|required');
              if ($this->form_validation->run()) { */
            for ($i = 0; $i < count($this->input->post('ip_detail')); $i++) {
                $data_to_store = array(
                    'ServerIP' => $this->input->post('ip_detail')[$i]
                );
                $this->common_model->update_details("ServerID", $this->input->post('ServerID')[$i], $data_to_store, "tblserveripdetails");
            }
            $data['flash_message'] = TRUE;
            $data['color_code'] = "#3a5a9c";
            $data['display_value'] = "block";
            $data['message'] = "Settings IP Details Updated";
            $data['flash_message'] = TRUE;
            /* } else {
              $data['color_code'] = "#c50000";
              $data['display_value'] = "block";
              $data['message'] = "Validation Errors";
              $data['flash_message'] = FALSE;
              } */
        }

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            $data['edit_button_rights'] = $user_role_details[0]['Edit'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/settings-ip', $data);
    }
    
     public function settings_ipnew() {
        echo $this->availableUrl("182.50.132.53");
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Server IP Details";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Server IP Details";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            /* $this->form_validation->set_rules('ip_detail[]', 'Server Ip Address', 'trim|required');
              if ($this->form_validation->run()) { */
            for ($i = 0; $i < count($this->input->post('ip_detail')); $i++) {
                $data_to_store = array(
                    'ServerIP' => $this->input->post('ip_detail')[$i]
                );
                $this->common_model->update_details("ServerID", $this->input->post('ServerID')[$i], $data_to_store, "tblserveripdetails");
            }
            $data['flash_message'] = TRUE;
            $data['color_code'] = "#3a5a9c";
            $data['display_value'] = "block";
            $data['message'] = "Settings IP Details Updated";
            $data['flash_message'] = TRUE;
            /* } else {
              $data['color_code'] = "#c50000";
              $data['display_value'] = "block";
              $data['message'] = "Validation Errors";
              $data['flash_message'] = FALSE;
              } */
        }

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            $data['edit_button_rights'] = $user_role_details[0]['Edit'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/settings-ipnew', $data);
    }
    
    function availableUrl($host, $port=80, $timeout=10) { 
  $fp = fSockOpen($host, $port, $errno, $errstr, $timeout); 
  return $fp!=false;
}



    public function settings_version() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Restrict Version Modification";
        $data['title'] = "Restrict Version Modification";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/settings-version', $data);
    }

    public function connectivity() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Connectivity";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/connectivity', $data);
    }

    public function ip_settings() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "IP Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $this->load->view('Admin/ip-settings', $data);
    }

    public function create_zone() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Zone";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Create Zone";
        $data['asset_url'] = site_url('assets/themes/');
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
               redirect(site_url('Admin/unauthorized'));
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                redirect(site_url('Admin/unauthorized'));
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                
                redirect(site_url('Admin/unauthorized'));
            }
        } 
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('RailwayName', 'Railway Zone Name', 'required');
            $this->form_validation->set_rules('RailwayCode', 'Railway Zone Code', 'required|is_unique[tblrailwaymaster.RailwayCode]');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'RailwayName' => $this->input->post('RailwayName'),
                    'RailwayCode' => $this->input->post('RailwayCode'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblrailwaymaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Zone Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Zone/create-zone', $data);
    }

    public function view_zone() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Zone";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Zone";
        $data['asset_url'] = site_url('assets/themes/');

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }
         $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
               $data['edit_button_rights'] = 0;
                $data['create_button_rights'] = 0;
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                
                $data['edit_button_rights'] = 0;
                $data['create_button_rights'] = 0;
            }
        } 

        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $this->load->view('Admin/Zone/view-zone', $data);
    }

    public function view_zone_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Zone";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Zone Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['zone'] = $this->common_model->find_details(array("RecordStatus" => "1", "RailwayID" => $id), "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['zone']) > 0) {
            
        } else {
            redirect(site_url('Admin/view-zone'));
        }
        $this->load->view('Admin/Zone/view-zone-detail', $data);
    }

    public function edit_zone($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Zone";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Zone";
        $data['asset_url'] = site_url('assets/themes/');
        $RailwayID = $this->session->userdata("railway_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1
        );
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
               if($RailwayID != $id)
               {
                   redirect(site_url('Admin/unauthorized'));
               }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                redirect(site_url('Admin/unauthorized'));
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                redirect(site_url('Admin/unauthorized'));
            }
        }
        $data['zone'] = $this->common_model->find_details(array("RecordStatus" => "1", "RailwayID" => $id), "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        if (count($data['zone']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("RailwayID", $id, "tblrailwaymaster", "RailwayCode");
                if ($this->input->post('RailwayCode') != $original_value) {
                    $is_unique = '|is_unique[tblrailwaymaster.RailwayCode]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('RailwayCode', 'Railway Zone Code', 'trim|required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                $this->form_validation->set_rules('RailwayName', 'Railway Zone Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'RailwayName' => $this->input->post('RailwayName'),
                        'RailwayCode' => $this->input->post('RailwayCode'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("RailwayID", $id, $data_to_store, "tblrailwaymaster")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Zone Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['zone'] = $this->common_model->find_details(array("RecordStatus" => "1", "RailwayID" => $id), "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-zone'));
        }
        $this->load->view('Admin/Zone/edit-zone', $data);
    }

    public function delete_zone() {
        $value = $this->input->post("id");
        $RailwayID = $this->session->userdata("railway_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");        
        $cond_zone = "RecordStatus = 1";
        $data['cond_div'] = array(
            "RecordStatus" => 1
        );
        $output = 0;
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
               if($RailwayID != $id)
               {
                   $output = "2";
               }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                $output = "2";
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
                $output = "2";
            }
        }
        if ($value != "" && $output == 0) {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            if ($this->common_model->delete_details('RailwayID', $value, "tblrailwaymaster", $data_to_store)) {
                $this->session->set_flashdata("success_done", "Zone Details Deleted SuccessFully");
                $output = "1";
            } else {
                $output = "0";
            }
        } 
        echo $output;
    }

    public function delete_version_desc_fields() {
        $value = $this->input->post("id");
        if ($value != "") {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            if ($this->common_model->delete_details('id', $value, "tbl_version_fields", $data_to_store)) {
                $this->session->set_flashdata("success_done", "Record Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function create_designation() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Designation";
        $data['this_page_middle'] = "User";
        $data['title'] = "Create Designation";
        $data['asset_url'] = site_url('assets/themes/');
        $data['level'] = $this->common_model->find_details("RecordStatus = 1", "tbllevelmaster", "LevelName, LevelDescription, LevelID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('LevelID', 'Level ID', 'required');
            $this->form_validation->set_rules('DesignationName', 'Designation Name', 'required|callback_check_designation', array(
                'required' => 'This %s under the above Level Id already exists.',
                'callback_check_designation' => 'This %s already exists.'
            ));
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'DesignationName' => $this->input->post('DesignationName'),
                    'DesignationDescription' => $this->input->post('DesignationDescription'),
                    'LevelID' => $this->input->post('LevelID'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tbldesignationmaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Designation Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Designation/create-designation', $data);
    }

    //To check if the designaion already exist under the same level
    function check_designation() {
        $LevelID = $this->input->post('LevelID');
        $DesignationName = $this->input->post('DesignationName');
        $this->db->select('DesignationID');
        $this->db->from('tbldesignationmaster');
        $this->db->where('DesignationName', $DesignationName);
        $this->db->where('LevelID', $LevelID);
        $query = $this->db->get();
        $num = $query->num_rows();
        if ($num > 0) {
            //return FALSE;
            $data['color_code'] = "#c50000";
            $data['display_value'] = "block";
            $data['message'] = "Validation Errors";
            $data['flash_message'] = FALSE;
        } else {
            return TRUE;
        }
    }

    public function view_designation() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Designation";
        $data['this_page_middle'] = "User";
        $data['title'] = "View Designation";
        $data['asset_url'] = site_url('assets/themes/');
        $data['designation'] = $this->common_model->find_details("RecordStatus = 1", "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID");

        $this->db->join("tbllevelmaster", "tbllevelmaster.LevelID=tbldesignationmaster.LevelID", "left");
        $this->db->order_by("tbldesignationmaster.DesignationID", "asc");
        $data['designation'] = $this->common_model->find_details("tbldesignationmaster.RecordStatus = 1", "tbldesignationmaster", "tbldesignationmaster.DesignationName, tbldesignationmaster.DesignationDescription, tbldesignationmaster.DesignationID, tbldesignationmaster.LevelID, tbllevelmaster.LevelName, tbllevelmaster.LevelID as is_include");

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/Designation/view-designation', $data);
    }

    public function view_designation_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Designation";
        $data['this_page_middle'] = "User";
        $data['title'] = "View Designation Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['designation'] = $this->common_model->find_details(array("RecordStatus" => "1", "DesignationID" => $id), "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['designation']) > 0) {
            
        } else {
            redirect(site_url('Admin/view-designation'));
        }
        $this->load->view('Admin/Designation/view-designation-detail', $data);
    }

    public function edit_designation($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Designation";
        $data['this_page_middle'] = "User";
        $data['title'] = "Edit Designation";
        $data['asset_url'] = site_url('assets/themes/');
        $data['level'] = $this->common_model->find_details("RecordStatus = 1", "tbllevelmaster", "LevelName, LevelDescription, LevelID");
        $data['designation'] = $this->common_model->find_details(array("RecordStatus" => "1", "DesignationID" => $id), "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID, LevelID");
        if (count($data['designation']) > 0) {
			$desig = $data['designation'];
			//Login User Level based edit access
			$cond_user_header = array(
				"UserID" => $this->session->userdata("id_session_list"),
			);
			$user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
			if (count($user_details_header) > 0) {
				if ($user_details_header[0]['LevelID'] > $desig[0]['LevelID'] && $this->session->userdata("UserRole")!="Admin") {
					redirect(site_url('Admin/unauthorized'));
				}
				else 
				{
					 if ($this->input->server('REQUEST_METHOD') === 'POST') {
						$cond = array(
							"DesignationID" => $id,
							"DesignationName" => $this->input->post('DesignationName'),
							"LevelID" => $this->input->post('LevelID'),
						);
						$original_value = $this->common_model->find_details($cond, "tbldesignationmaster", "DesignationName, LevelID");
						if (count($original_value) > 0) {
							$is_unique = 'required';
						} else {
							$is_unique = 'required|callback_check_designation';
						}
						$this->form_validation->set_rules('LevelID', 'Level ID', 'required');
						$this->form_validation->set_rules('DesignationName', 'Designation Name', $is_unique, array(
							'required' => 'This %s under the above Level Id already exists.',
							'callback_check_designation' => 'This %s already exists.'
						));
						if ($this->form_validation->run()) {
							$data_to_store = array(
								'DesignationName' => $this->input->post('DesignationName'),
								'DesignationDescription' => $this->input->post('DesignationDescription'),
								'LevelID' => $this->input->post('LevelID'),
								'ModifiedBy' => $this->session->userdata("id_session_list"),
								'ModifiedOn' => date("Y-m-d H:i:s"),
							);
							if ($this->common_model->update_details("DesignationID", $id, $data_to_store, "tbldesignationmaster")) {
								$data['flash_message'] = TRUE;
								$data['color_code'] = "#3a5a9c";
								$data['display_value'] = "block";
								$data['message'] = "Designation Details Updated";
								$data['flash_message'] = TRUE;
								$data['designation'] = $this->common_model->find_details(array("RecordStatus" => "1", "DesignationID" => $id), "tbldesignationmaster", "DesignationName, DesignationDescription, DesignationID");
							} else {
								$data['flash_message'] = FALSE;
								$data['color_code'] = "#c50000";
								$data['display_value'] = "block";
								$data['message'] = "Validation Errors";
							}
						} else {
							$data['color_code'] = "#c50000";
							$data['display_value'] = "block";
							$data['message'] = "Validation Errors";
							$data['flash_message'] = FALSE;
						}
					}
				}
			}
           
        } else {
            redirect(site_url('Admin/view-designation'));
        }
        $this->load->view('Admin/Designation/edit-designation', $data);
    }

    public function delete_designation() {
        $value = $this->input->post("id");
        if ($value != "") {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            if ($this->common_model->delete_details('DesignationID', $value, "tbldesignationmaster", $data_to_store)) {
                $this->session->set_flashdata("success_done", "Designation Details Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }

    public function create_sessiontimeout() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Create SessionTimeout";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('Minutes', 'SessionTimeout Name', 'required|is_unique[tblsessiontimeoutmaster.Minutes]');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'Minutes' => $this->input->post('Minutes'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblsessiontimeoutmaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "SessionTimeout Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/SessionTimeout/create-sessiontimeout', $data);
    }

    public function view_sessiontimeout() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View SessionTimeout";
        $data['title'] = "View SessionTimeout";
        $data['asset_url'] = site_url('assets/themes/');
        $data['sessiontimeout'] = $this->common_model->find_details("RecordStatus = 1", "tblsessiontimeoutmaster", "Minutes, SessionTimeoutID");
        $this->load->view('Admin/SessionTimeout/view-sessiontimeout', $data);
    }

    public function view_sessiontimeout_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "View SessionTimeout Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['sessiontimeout'] = $this->common_model->find_details(array("RecordStatus" => "1", "SessionTimeoutID" => $id), "tblsessiontimeoutmaster", "Minutes, SessionTimeoutID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['sessiontimeout']) > 0) {
            
        } else {
            redirect(site_url('Admin/view-sessiontimeout'));
        }
        $this->load->view('Admin/SessionTimeout/view-sessiontimeout-detail', $data);
    }

    public function edit_sessiontimeout($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Logout Time";
        $data['title'] = "Edit SessionTimeout";
        $data['asset_url'] = site_url('assets/themes/');
        $data['sessiontimeout'] = $this->common_model->find_details(array("RecordStatus" => "1", "SessionTimeoutID" => $id), "tblsessiontimeoutmaster", "Minutes, SessionTimeoutID");
        if (count($data['sessiontimeout']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("SessionTimeoutID", $id, "tblsessiontimeoutmaster", "Minutes");
                if ($this->input->post('Minutes') != $original_value) {
                    $is_unique = '|is_unique[tblsessiontimeoutmaster.Minutes]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('Minutes', 'SessionTimeout Name', 'required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'Minutes' => $this->input->post('Minutes'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("SessionTimeoutID", $id, $data_to_store, "tblsessiontimeoutmaster")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "SessionTimeout Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['sessiontimeout'] = $this->common_model->find_details(array("RecordStatus" => "1", "SessionTimeoutID" => $id), "tblsessiontimeoutmaster", "Minutes, SessionTimeoutID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-sessiontimeout'));
        }
        $this->load->view('Admin/SessionTimeout/edit-sessiontimeout', $data);
    }

    public function delete_sessiontimeout() {
        $value = $this->input->post("id");
        if ($value != "") {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            $this->common_model->delete_details('SessionTimeoutID', $value, "tblsessiontimeoutmaster", $data_to_store);
            echo "1";
        } else {
            echo "0";
        }
    }

    public function create_versionmodificationlimit() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Create VersionModificationLimit";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('NoOfDays', 'VersionModificationLimit Name', 'required|is_unique[tblversionmodificationlimit.NoOfDays]');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'NoOfDays' => $this->input->post('NoOfDays'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblversionmodificationlimit";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "VersionModificationLimit Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/VersionModificationLimit/create-versionmodificationlimit', $data);
    }

    public function view_versionmodificationlimit() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View VersionModificationLimit";
        $data['title'] = "View VersionModificationLimit";
        $data['asset_url'] = site_url('assets/themes/');
        $data['versionmodificationlimit'] = $this->common_model->find_details("RecordStatus = 1", "tblversionmodificationlimit", "NoOfDays, ID");
        $this->load->view('Admin/VersionModificationLimit/view-versionmodificationlimit', $data);
    }

    public function view_versionmodificationlimit_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "View VersionModificationLimit Detail";
        $data['asset_url'] = site_url('assets/themes/');
        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID, ModifiedBy, CreatedBy, CreatedOn, ModifiedOn");
        if (count($data['versionmodificationlimit']) > 0) {
            
        } else {
            redirect(site_url('Admin/view-versionmodificationlimit'));
        }
        $this->load->view('Admin/VersionModificationLimit/view-versionmodificationlimit-detail', $data);
    }

    public function edit_versionmodificationlimit($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['title'] = "Edit VersionModificationLimit";
        $data['asset_url'] = site_url('assets/themes/');
        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID");
        if (count($data['versionmodificationlimit']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('NoOfDays', 'VersionModificationLimit Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'NoOfDays' => $this->input->post('NoOfDays'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("ID", $id, $data_to_store, "tblversionmodificationlimit")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "VersionModificationLimit Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-versionmodificationlimit'));
        }
        $this->load->view('Admin/VersionModificationLimit/edit-versionmodificationlimit', $data);
    }

    public function delete_versionmodificationlimit() {
        $value = $this->input->post("id");
        if ($value != "") {
            $data_to_store = array(
                "RecordStatus" => 0
            );
            $this->common_model->delete_details('ID', $value, "tblversionmodificationlimit", $data_to_store);
            echo "1";
        } else {
            echo "0";
        }
    }

    public function security_settings() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Security Settings";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "View Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $data['security_settings'] = $this->common_model->find_details("RecordStatus = 1", "tblsecuritysettings", "LevelName, LevelPassword, SecurityID");
        $this->load->view('Admin/security-settings', $data);
    }

    public function edit_security_settings($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "View Security Settings";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $data['security_settings'] = $this->common_model->find_details(array("RecordStatus" => "1", "SecurityID" => $id), "tblsecuritysettings", "*");
        if (count($data['security_settings']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $this->form_validation->set_rules('current_password', 'Current Password', 'trim|required|min_length[8]');
                $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
                $this->form_validation->set_rules('re_password', 'Password Confirmation', 'trim|required|matches[password]');
                if ($this->form_validation->run() == FALSE) {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                } else {
                    $cur_pass = $this->input->post('current_password');
                    $check_cur_pass = $this->encryption->decrypt($this->common_model->find_single_value("SecurityID", $id, "tblsecuritysettings", "LevelPassword"));
                    if ($check_cur_pass == $cur_pass) {
                        $data_to_store = array(
                            'LevelPassword' => $this->encryption->encrypt($this->input->post('password')),
                            'ModifiedBy' => $this->session->userdata("id_session_list"),
                            'ModifiedOn' => date("Y-m-d H:i:s"),
                        );
                        if ($this->common_model->update_details("SecurityID", $id, $data_to_store, "tblsecuritysettings")) {
                            $data['flash_message'] = TRUE;
                            $data['color_code'] = "#57b91b";
                            $data['display_value'] = "block";
                            $data['message'] = "Password Changed.";
                        }
                    } else {
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Invalid Cuurent Password";
                        $data['flash_message'] = FALSE;
                    }
                }
            }
        } else {
            redirect(site_url('Admin/view-designation'));
        }
        $this->load->view('Admin/edit-security-settings', $data);
    }

    public function userloggedindetails() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "User Login History";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $data['userloggedindetails'] = array();
		
		//Filter data based on login user level
		$RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $StationID = $this->session->userdata("station_session_list");
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");
        $cond_filter = "tblusermaster.RecordStatus = 1";
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.LevelID IN (2,3,4)";
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.DivisionID = ".$DivisionID." AND tblusermaster.LevelID IN (3,4)";
            }

            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {
				$cond_filter = " tblusermaster.RecordStatus = 1 AND tblusermaster.RailwayID = ".$RailwayID." AND tblusermaster.DivisionID = ".$DivisionID." AND tblusermaster.StationID = ".$StationID." AND tblusermaster.LevelID IN (4)";
            }
        }
		$data['user'] = $this->common_model->find_user_master_details($cond_filter);
		
		$zoneID = "";
        $DivisionID = "";
        $StationID = "";
        $UserID = "";
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
				$zoneID = $this->input->post("RailwayID");
				$DivisionID = $this->input->post("DivisionID");
				$StationID = $this->input->post("StationID");
				$UserID = $this->input->post("UserID");
				
                $this->form_validation->set_rules('date', 'Date', 'trim|required');
                $this->form_validation->set_rules('UserID', 'UserID', 'trim|required');
                if ($this->form_validation->run() == FALSE) {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                } else {
                    $date = $this->input->post("date");
                    $first = explode(" - ", $date)[0];
                    $second = explode(" - ", $date)[1];
                    $first_date = date("Y-m-d", strtotime($first));
                    $second_date = date("Y-m-d", strtotime($second));
                    if ($this->input->post("UserID") != "All") {
                        $cond = array(
                            "tbluserloggedindetails.LoginDate >=" => $first_date, "tbluserloggedindetails.LoginDate <=" => $second_date,
                            "tbluserloggedindetails.UserID" => $this->input->post("UserID")
                        );
						$data['userloggedindetails'] = $this->common_model->find_userloggedindetails($cond);
                    }/*  else {


                        $cond = array(
                            "tbluserloggedindetails.LoginDate >=" => $first_date, "tbluserloggedindetails.LoginDate <=" => $second_date
                        );
                    } */


                    
                }
            }
		$data['zoneID'] = $zoneID;
        $data['divisionID'] = $DivisionID;
        $data['stationID'] = $StationID;
        $data['userID'] = $UserID;
       // }
        $this->load->view('Admin/userloggedindetails', $data);
    }

    public function version_req_fields() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "EI - Required Fields";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $data['userloggedindetails'] = array();
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID");
        $fields = $this->common_model->find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield");
        $data['fields'] = $fields;
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('VendorID', 'VendorID', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            } else {
                $vendorID = $this->input->post('VendorID');
                //Check Already Added In Vendor Field Map

                foreach ($fields as $field) {
                    $fieldID = $field['VersionFieldsMasterID'];
                    $is_visible = 0;
                    if ($this->input->post('field_visible_' . $fieldID) === "1") {
                        $is_visible = 1;
                    }
                    $is_mandatory = 0;
                    if ($this->input->post('field_mandatory_' . $fieldID) === "1") {
                        $is_mandatory = 1;
                    }
                    //var_dump($this->input->post("field_visible_".$fieldID));
                    $fmaps = $this->common_model->find_details("VendorID = '" . $vendorID . "' and field_id='" . $fieldID . "'", "tbl_versionfields_vendor_map", "id, VendorID,field_id,is_visible,is_mandatory", "", "", "1");
                    if ($fmaps) {
                        $fdata = array(
                            "is_visible" => $is_visible,
                            "is_mandatory" => $is_mandatory
                        );
                        $this->common_model->update_cond_details("id = '" . $fmaps[0]['id'] . "'", $fdata, "tbl_versionfields_vendor_map");
                    } else {
                        $fdata = array(
                            "VendorID" => $vendorID,
                            "field_id" => $field["VersionFieldsMasterID"],
                            "is_visible" => $is_visible,
                            "is_mandatory" => $is_mandatory
                        );
                        $this->common_model->store_details($fdata, "tbl_versionfields_vendor_map");
                    }
                }

                //Add New Fields and Check Visible And Mandatory
                $fieldnames = $this->input->post("FieldName");
                $visible_check = $this->input->post("FVisible");
                $mandatory_check = $this->input->post("FMandatory");
                for ($i = 0; $i < count($fieldnames); $i++) {
                    if ($fieldnames[$i] != "") {
                        $is_visible = 0;
                        $is_mandatory = 0;
                        if ($visible_check[$i] != null) {
                            $is_visible = 1;
                        }
                        if ($mandatory_check[$i] != null) {
                            $is_mandatory = 1;
                        }

                        $field_name = preg_replace("/[^A-Za-z0-9]/", "", $fieldnames[$i]);

                        $tdata = array(
                            "field_name" => strtolower($field_name),
                            "field_display_name" => $fieldnames[$i],
                            "is_autofield" => 1,
                            "RecordStatus" => 1
                        );

                        $nfield = $this->common_model->store_details($tdata, "tbl_versionfields_master");

                        $fdata = array(
                            "VendorID" => $vendorID,
                            "field_id" => $nfield,
                            "is_visible" => $is_visible,
                            "is_mandatory" => $is_mandatory
                        );
                        $this->common_model->store_details($fdata, "tbl_versionfields_vendor_map");
                    }
                }
                $fields = $this->common_model->find_details("RecordStatus = 1", "tbl_versionfields_master", "VersionFieldsMasterID, field_name, field_display_name, is_autofield");
                $data['fields'] = $fields;

                $this->session->set_flashdata('success_done', 'Succesfully updated');
                redirect("Admin/version-req-fields");
            }
        }
        $data['color_code'] = "green";
        $data['display_value'] = "block";
        $data['message'] = "field Value Added";
        $data['flash_message'] = TRUE;

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/Version/version-req-fields', $data);
    }

    public function version_desc_exec() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['desc_fields'] = array();
		
        $data['this_page_sub'] = "EI - Desc and Exec";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
		$data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('t_type', 'For Field', 'trim|required');
            $this->form_validation->set_rules('desc_value', 'Field Value', 'trim|required');
            $this->form_validation->set_rules('RailwayID', 'Zone', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            } else {
                $forField = $this->input->post("t_type");
                $descValue = $this->input->post("desc_value");
                $RailwayID = $this->input->post("RailwayID");
                $version_fields = $this->common_model->find_details("RailwayID = '" . $RailwayID . "' and for_field = '" . $forField . "' and field_value = '" . $descValue . "'", "tbl_version_fields");
                if (count($version_fields) <= 0) {
                    //Valid to Add
                    $data_to_store = array(
                        "RailwayID" => $RailwayID,
                        "for_field" => $forField,
                        "field_value" => $descValue
                    );
                    $this->common_model->store_details($data_to_store, "tbl_version_fields");
					$cond_desc = array(
								"RecordStatus" => "1",
								"for_field" => $forField,
								"RailwayID" => $RailwayID
							);
					$data['desc_fields'] = $this->common_model->find_details($cond_desc, "tbl_version_fields", "id, for_field, field_value");
					$data['fieldid'] = $forField;
                    $data['color_code'] = "green";
                    $data['display_value'] = "block";
                    $data['message'] = "Field Value Added";
                    $data['flash_message'] = TRUE;
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Field Value Already Exists";
                    $data['flash_message'] = TRUE;
                }
				$data['forField'] = $forField;
            }
        }

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/Version/version-desc-exec', $data);
    }

    public function EI_description_view() {
        $fieldid = $this->input->post("fieldid");
        $zoneid = $this->input->post("zoneid");

        if ($fieldid != "" && $zoneid != "") {

            $cond_stn = array(
                "RecordStatus" => "1",
                "for_field" => $fieldid,
                "RailwayID" => $zoneid
            );

            $data['fields'] = $this->common_model->find_details($cond_stn, "tbl_version_fields", "id, for_field, field_value");
            $data['fieldid'] = $fieldid;


            $this->load->view('Admin/Ajax/EI_description_view', $data);
        } else {
            echo "0";
        }
    }

    public function edit_version_desc($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "EI - Desc and Exec";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');

        $data['fields'] = $this->common_model->find_details(array("RecordStatus" => "1", "id" => $id), "tbl_version_fields", "id, RailwayID, for_field, field_value");
		$zoneid = $data['fields'][0]['RailwayID'];
		$data['zoneid'] = $this->common_model->find_details(array("RecordStatus" => "1", "RailwayID" => $zoneid), "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID")[0];
        if (count($data['fields']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("id", $id, "tbl_version_fields", "RailwayCode");

                $data_to_store = array(
                    'field_value' => $this->input->post('desc_value'),
                );
                if ($this->common_model->update_details("id", $id, $data_to_store, "tbl_version_fields")) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Records Updated";
                    $data['flash_message'] = TRUE;
                    $data['fields'] = $this->common_model->find_details(array("RecordStatus" => "1", "id" => $id), "tbl_version_fields", "id, for_field, field_value");
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            }
        } else {
            redirect(site_url('Admin/edit-version-desc'));
        }
        $this->load->view('Admin/Version/edit-version-desc', $data);
    }

    public function version_file_names() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "EI - S/W Files";
        $data['title'] = "Edit Security Settings";
        $data['asset_url'] = site_url('assets/themes/');
        $data['userloggedindetails'] = array();
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID");
        $data['vendor'] = $this->common_model->find_details("RecordStatus = 1", "tblvendormaster", "VendorName, VendorID");
        $data['file_types'] = $this->common_model->find_details("", "tbl_version_file_types", "id, file_type, type_value");
        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => "1"), "tblversionmodificationlimit", "NoOfDays, ID");
        if ($this->input->server('REQUEST_METHOD') === 'POST' && isset($_POST["file_id_sub"])) {
            $this->form_validation->set_rules('VendorID', 'VendorID', 'trim|required');
            if ($this->form_validation->run() == FALSE) {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            } else {
                $version_logic_details = $this->common_model->find_details("", "tblversionfilenames", "max(VersionFileNamesID) as VersionID");
                if (count($version_logic_details) > 0) {
                    $VersionLogicID = $version_logic_details[0]['VersionID'] + 1;
                } else {
                    $VersionLogicID = 1;
                }
                //Validate
                $valid = true;
                $msg = "";
                if ($this->input->post("FileNameOld")) {
                    $fnameold = $this->input->post("FileNameOld");
                    $fmincountold = $this->input->post("MinCountOld");
                    $fmaxcountold = $this->input->post("MaxCountOld");
                    for ($i = 0; $i < count($fnameold); $i++) {
                        if ($fnameold[$i] == "") {
                            $msg .= "Update: Starting Name must not be empty on Row " . ($i + 1) . "<br>";
                            $valid = false;
                        } else {
                            if ($fnameold[$i] != "*") {
                                if (!preg_match("/^[a-zA-Z0-9\d-_]+$/", $fnameold[$i])) {
                                    $msg .= "Update: Starting Name must contain valid Characters<br>";
                                    $valid = false;
                                }
                            }
                        }
                        if ($fmincountold[$i] == "" || $fmincountold[$i] == "0") {
                            $msg .= "Update: Required Min Count of files on Row " . ($i + 1) . "<br>";
                            $valid = false;
                        }
                        if ($fmaxcountold[$i] == "") {
                            $msg .= "Update: Max Count must not be blank on Row " . ($i + 1) . "<br>";
                            $valid = false;
                        }
                    }

                    if ($valid) {
                        for ($i = 0; $i < count($fnameold); $i++) {
                            $fnameold = $this->input->post("FileNameOld");
                            $fmincountold = $this->input->post("MinCountOld");
                            $seloldtype = $this->input->post('FileTypeOld');
                            $fmaxcountold = $this->input->post("MaxCountOld");
                            $data_to_store = array(
                                'FileName' => $fnameold[$i],
                                'FileType' => $seloldtype[$i],
                                "MinCount" => $fmincountold[$i],
                                "MaxCount" => $fmaxcountold[$i],
                                'ModifiedBy' => $this->session->userdata("id_session_list"),
                                'ModifiedOn' => date("Y-m-d H:i:s")
                            );
                            $table = "tblversionfilenames";
                            $vid = $this->input->post('VersionFileNamesID');
                            $this->common_model->update_details("VersionFileNamesID", $vid[$i], $data_to_store, "tblversionfilenames");
                        }
                    }
                }
                $skip = false;
                if ($this->input->post('FileName')) {
                    //$valid = true;
                    $FileName = $this->input->post('FileName');
                    $Ftype = $this->input->post('FileType');
                    $mincount = $this->input->post("MinCount");
                    $maxxCount = $this->input->post("MaxCount");

                    if (count($FileName) == 1) {
                        if ($FileName[0] == "") {
                            $skip = true;
                        }
                    }
                    if (!$skip) {
                        for ($i = 0; $i < count($FileName); $i++) {
                            if ($FileName[$i] == "") {
                                $msg .= "Starting Name must not be empty on Row " . ($i + 1) . "<br>";
                                $valid = false;
                            } else {
                                if ($FileName[$i] != "*") {
                                    if (!preg_match("/^[a-zA-Z0-9\d-_]+$/", $FileName[$i])) {
                                        $msg .= "Starting Name must contain valid Characters<br>";
                                        $valid = false;
                                    }
                                }
                            }

                            if ($mincount[$i] == "" || $mincount[$i] == "0") {
                                $msg .= "Required Min Count of files on Row " . ($i + 1) . "<br>";
                                $valid = false;
                            }
                            if ($maxxCount[$i] == "") {
                                $msg .= "Max Count must not be blank on Row " . ($i + 1) . "<br>";
                                $valid = false;
                            }
                        }
                    }
                    if ($valid && !$skip) {
                        for ($i = 0; $i < count($this->input->post('FileName')); $i++) {
                            $FileName = $this->input->post('FileName');
                            $Ftype = $this->input->post('FileType');
                            if ($Ftype[$i] != '') {
                                $mincount = $this->input->post("MinCount");
                                $maxxCount = $this->input->post("MaxCount");
                                $data_to_store = array(
                                    'VersionFileNamesID' => $VersionLogicID,
                                    'VendorID' => $this->input->post('VendorID'),
                                    'FileName' => $FileName[$i],
                                    'FolderName' => "",
                                    'FileType' => $Ftype[$i],
                                    "MinCount" => $mincount[$i],
                                    "MaxCount" => $maxxCount[$i],
                                    'CreatedBy' => $this->session->userdata("id_session_list"),
                                    'CreatedOn' => date("Y-m-d H:i:s"),
                                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                                    'ModifiedOn' => date("Y-m-d H:i:s"),
                                );
                                $table = "tblversionfilenames";
                                $this->common_model->store_details($data_to_store, "tblversionfilenames");
                            }
                        }
                    }
                }
                $data['color_code'] = "#3a5a9c";
                $data['display_value'] = "block";
                if ($valid) {
                    $data['message'] = "Version Files Details updated successfully";
                } else {
                    $data["message"] = $msg;
                }
                $data['flash_message'] = TRUE;
            }
        }
		
		//Second Submit
		if ($this->input->server('REQUEST_METHOD') === 'POST' && isset($_POST["Submit2"])) {
			$id = 1;
			$this->form_validation->set_rules('NoOfDays', 'VersionModificationLimit Name', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'NoOfDays' => $this->input->post('NoOfDays'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("ID", $id, $data_to_store, "tblversionmodificationlimit")) {
                        $data['flash_message'] = TRUE;
                        $data['color_codes'] = "#3a5a9c";
                        $data['display_values'] = "block";
                        $data['messages'] = "Version Modification Limit Updated successfully";
                        $data['versionmodificationlimit'] = $this->common_model->find_details(array("RecordStatus" => "1", "ID" => $id), "tblversionmodificationlimit", "NoOfDays, ID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_codes'] = "#c50000";
                        $data['display_values'] = "block";
                        $data['messages'] = "Validation Errors";
                    }
                } else {
                    $data['color_codes'] = "#c50000";
                    $data['display_values'] = "block";
                    $data['messages'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
		}

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $this->load->view('Admin/Version/version-file-names', $data);
    }

    public function level1_security_settings() {
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
            if ($this->form_validation->run() == FALSE) {
                echo "Password Must Contain 8 Char";
            } else {
                $cur_pass = $this->input->post('password');
                $check_cur_pass = $this->encryption->decrypt($this->common_model->find_single_value("SecurityID", 1, "tblsecuritysettings", "LevelPassword"));
                if ($check_cur_pass == $cur_pass) {
                    echo 1;
                } else {
                    echo "Invalid Password";
                }
            }
        } else {
            echo "Password Required";
        }
    }

    public function level2_security_settings() {
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
            if ($this->form_validation->run() == FALSE) {
                echo "Password Must Contain 8 Char";
            } else {
                $cur_pass = $this->input->post('password');
                $check_cur_pass = $this->encryption->decrypt($this->common_model->find_single_value("SecurityID", 2, "tblsecuritysettings", "LevelPassword"));
                if ($check_cur_pass == $cur_pass) {
                    echo 1;
                } else {
                    echo "Invalid Password";
                }
            }
        } else {
            echo "Password Required";
        }
    }

    public function level3_security_settings() {
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('password', 'Password', 'trim|required|min_length[8]');
            if ($this->form_validation->run() == FALSE) {
                echo "Password Must Contain 8 Char";
            } else {
                $cur_pass = $this->input->post('password');
                $check_cur_pass = $this->encryption->decrypt($this->common_model->find_single_value("SecurityID", 3, "tblsecuritysettings", "LevelPassword"));
                if ($check_cur_pass == $cur_pass) {
                    echo 1;
                } else {
                    echo "Invalid Password";
                }
            }
        } else {
            echo "Password Required";
        }
    }

    public function uploadAnyFile() {
        if (!empty($_FILES)) {
            $config['upload_path'] = './uploads/others/';
            $config['allowed_types'] = '*';
            $config['max_size'] = '500000';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload("file")) {
                echo $this->upload->display_errors();
            } else {
                $upload_data = $this->upload->data();
                $str = $upload_data['file_name'];
                echo ltrim($str, " ");
                /* $this->gallery_path = realpath(APPPATH . '../uploads/others/'); //fetching path
                  $config1 = array(
                  'source_image' => $upload_data['full_path'], //get original image
                  'new_image' => $this->gallery_path . '/thumbs', //save as new image //need to create thumbs first
                  'maintain_ratio' => true,
                  'width' => 650,
                  'height' => 450
                  );
                  $this->load->library('image_lib', $config1); //load library
                  $this->image_lib->resize(); //generating thumb */
            }
        }
    }

     public function uploadimage() {
        $serverIP = "";
         if($this->session->userdata("RailwayIDIP"))
        {
         $data = array( 
                "RailwayID" => $this->session->userdata("RailwayIDIP"),
                "DivisionID" => $this->session->userdata("DivisionIDIP")
            );
           $ServerIParray = $this->common_model->find_details($data, "tblserveripdivisionwise", "ServerIP");
            if(count($ServerIParray) > 0)
            {
                $serverIP = $ServerIParray[0]['ServerIP'];
            }
        }  
		
		
        if (!empty($_FILES)) {
			$config['upload_path'] = './uploads/files/';
			$config['allowed_types'] = 'zip';
            $config['max_size'] = '500000';
            $this->load->library('upload', $config);
            $this->upload->initialize($config);
            if (!$this->upload->do_upload("file")) {
                echo $this->upload->display_errors();
				
            } else {
                $upload_data = $this->upload->data();
                $str = $upload_data['file_name'];


               // $this->gallery_path = realpath(APPPATH . '../uploads/files/'); //fetching path
                
                $this->gallery_path = realpath($serverIP.'railways-v1/uploads/files/'); //fetching path
				
                $config1 = array(
                    'source_image' => $upload_data['full_path'], //get original image
                    'new_image' => $this->gallery_path . '/thumbs', //save as new image //need to create thumbs first
                    'maintain_ratio' => true,
                    'width' => 650,
                    'height' => 450
                );
                $this->load->library('image_lib', $config1); //load library
                $this->image_lib->resize(); //generating thumb
                echo ltrim($str, " ");
            }
        }
    }

    public function logout() {
        $this->session->unset_userdata('name_session_list');
        $this->session->unset_userdata('is_admin');
        $this->session->unset_userdata('id_session_list');
        $this->session->unset_userdata('last_activity');
        $this->session->unset_userdata('code_session_list');
        $this->session->unset_userdata('is_logged_in_session');
        redirect(site_url() . 'Admin/login');
    }

    public function create_help() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Help Settings";
        $data['this_page_middle'] = "Advanced Settings";
        $data['this_page_super_sub'] = "Add New help";
        $data['title'] = "Create Help";
        $data['asset_url'] = site_url('assets/themes/');
        if ($this->input->server('REQUEST_METHOD') === 'POST') {
            $this->form_validation->set_rules('HelpName', 'Help Name', 'required|is_unique[tblhelpmaster.HelpName]');
            $this->form_validation->set_rules('HelpDescription', 'Description', 'required');
            if ($this->form_validation->run()) {
                $data_to_store = array(
                    'HelpName' => $this->input->post('HelpName'),
                    'HelpDescription' => $this->input->post('HelpDescription'),
                    'CreatedBy' => $this->session->userdata("id_session_list"),
                    'ModifiedBy' => $this->session->userdata("id_session_list"),
                    'CreatedOn' => date("Y-m-d H:i:s"),
                    'ModifiedOn' => date("Y-m-d H:i:s"),
                );
                $table = "tblhelpmaster";
                if ($this->common_model->store_details($data_to_store, $table)) {
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "Help Added";
                    $data['flash_message'] = TRUE;
                    $data_session = array(
                        "HelpSession" => $this->common_model->find_details("RecordStatus = 1", "tblhelpmaster", "HelpName, HelpID")
                    );
                    $this->session->set_userdata($data_session);
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } else {
                $data['color_code'] = "#c50000";
                $data['display_value'] = "block";
                $data['message'] = "Validation Errors";
                $data['flash_message'] = FALSE;
            }
        }
        $this->load->view('Admin/Help/create-help', $data);
    }

    public function view_help() {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Help Settings";
        $data['this_page_middle'] = "Advanced Settings";
        $data['this_page_super_sub'] = "Add New help";
        $data['title'] = "View Help";
        $data['asset_url'] = site_url('assets/themes/');

        //create button rights
        $cond = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details = $this->common_model->find_details($cond, "tblusermaster", "LevelID, DesignationID");
        if (count($user_details) > 0) {
            $cond = array(
                "DesignationID" => $user_details[0]['DesignationID'],
                "LevelID" => $user_details[0]['LevelID'],
            );
            $user_role_details = $this->common_model->find_details($cond, "tbluserrolemaster", "Save,Edit,Remove,View,Approve_Reject");
            $data['create_button_rights'] = $user_role_details[0]['Save'];
            if($this->session->userdata("UserRole")=="Admin")
            {
                $data['edit_button_rights'] = 1;
                $data['create_button_rights'] = 1;
            }
        }

        $data['help'] = $this->common_model->find_details("RecordStatus = 1", "tblhelpmaster", "HelpName, HelpDescription, HelpID");
        $this->load->view('Admin/Help/view-help', $data);
    }

    public function view_help_detail($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Help";
        $data['this_page_sub'] = "View Help" . $id;
        $data['title'] = "View Help";
        $data['asset_url'] = site_url('assets/themes/');
        $data['help'] = $this->common_model->find_details("RecordStatus = 1 and HelpId = " . $id, "tblhelpmaster", "HelpName, HelpDescription, HelpID");
        $this->load->view('Admin/Help/view-help-detail', $data);
    }

    public function edit_help($id) {
        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Help Settings";
        $data['this_page_middle'] = "Advanced Settings";
        $data['this_page_super_sub'] = "Help Sub" . $id;
        $data['title'] = "Edit Help";
        $data['asset_url'] = site_url('assets/themes/');
        $data['help'] = $this->common_model->find_details(array("RecordStatus" => "1", "HelpID" => $id), "tblhelpmaster", "HelpName, HelpDescription, HelpID");
        if (count($data['help']) > 0) {
            if ($this->input->server('REQUEST_METHOD') === 'POST') {
                $original_value = $this->common_model->find_single_value("HelpID", $id, "tblhelpmaster", "HelpName");
                if ($this->input->post('HelpName') != $original_value) {
                    $is_unique = '|is_unique[tblhelpmaster.HelpName]';
                } else {
                    $is_unique = '';
                }
                $this->form_validation->set_rules('HelpName', 'Help Name', 'required' . $is_unique, array(
                    'required' => 'You have not provided %s.',
                    'is_unique' => 'This %s already exists.'
                ));
                $this->form_validation->set_rules('HelpDescription', 'Description', 'required');
                if ($this->form_validation->run()) {
                    $data_to_store = array(
                        'HelpName' => $this->input->post('HelpName'),
                        'HelpDescription' => $this->input->post('HelpDescription'),
                        'ModifiedBy' => $this->session->userdata("id_session_list"),
                        'ModifiedOn' => date("Y-m-d H:i:s"),
                    );
                    if ($this->common_model->update_details("HelpID", $id, $data_to_store, "tblhelpmaster")) {
                        $data['flash_message'] = TRUE;
                        $data['color_code'] = "#3a5a9c";
                        $data['display_value'] = "block";
                        $data['message'] = "Help Details Updated";
                        $data['flash_message'] = TRUE;
                        $data['help'] = $this->common_model->find_details(array("RecordStatus" => "1", "HelpID" => $id), "tblhelpmaster", "HelpName, HelpDescription, HelpID");
                    } else {
                        $data['flash_message'] = FALSE;
                        $data['color_code'] = "#c50000";
                        $data['display_value'] = "block";
                        $data['message'] = "Validation Errors";
                    }
                } else {
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                    $data['flash_message'] = FALSE;
                }
            }
        } else {
            redirect(site_url('Admin/view-help'));
        }
        $this->load->view('Admin/Help/edit-help', $data);
    }

    public function delete_help() {
        $value = $this->input->post("id");
        if ($value != "") {
            if ($this->common_model->delete_details('HelpID', $value, "tblhelpmaster")) {
                $this->session->set_flashdata("success_done", "Help Settings Deleted SuccessFully");
                echo "1";
            } else {
                echo "0";
            }
        } else {
            echo "0";
        }
    }
    
     public function edit_settings_ip($rid,$did) { 

        $data['empty'] = "";
        $data['color_code'] = "";
        $data['message'] = "";
        $data['display_value'] = "none";
        $data['this_page'] = "Master";
        $data['this_page_sub'] = "Server IP Details";
        $data['this_page_middle'] = "Advanced Settings";
        $data['title'] = "Edit Server IP Details";
        $data['asset_url'] = site_url('assets/themes/');
       $cond = array("RecordStatus" => "1", "DivisionID" => $did, "RailwayID" => $rid);
        $RailwayID = $this->session->userdata("railway_session_list");
        $DivisionID = $this->session->userdata("division_session_list");
        $division_det = $this->common_model->find_details($cond, "tbldivisionmaster", "DivisionName,DivisionCode");
        $railway_det = $this->common_model->find_details(array("RailwayID" => $rid), "tblrailwaymaster", "RailwayName,RailwayCode");
        $data['DivisionName'] = $division_det[0]['DivisionName'].' ('.$division_det[0]['DivisionCode'].')';
        $data['RailwayName'] = $railway_det[0]['RailwayName'].' ('.$railway_det[0]['RailwayCode'].')'; 
        $data['DivisionID'] = $did;
        $data['RailwayID'] = $rid;
        $cond_user_header = array(
            "UserID" => $this->session->userdata("id_session_list"),
        );
        $user_details_header = $this->common_model->find_details($cond_user_header, "tblusermaster", "LevelID, DesignationID");                
        if (count($user_details_header) > 0) {
            $data['levelid'] = $user_details_header[0]['LevelID'];
            if ($user_details_header[0]['LevelID'] == 2 && $this->session->userdata("UserRole")!="Admin") {
                $cond_zone = array(
                    "RecordStatus" => 1,
                    "RailwayID" => $RailwayID,
                );
                if($RailwayID != $rid)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 3 && $this->session->userdata("UserRole")!="Admin") {
                if($DivisionID != $did || $RailwayID != $rid)
                {
                    redirect(site_url('Admin/unauthorized'));
                }
            }
            if ($user_details_header[0]['LevelID'] == 4 && $this->session->userdata("UserRole")!="Admin") {                                
                    redirect(site_url('Admin/unauthorized'));
            }
        } 
        $cond_settings = array(
            "RailwayID" => $rid,
            "DivisionID" => $did,
        );
        $data['cond_div'] = array(
            "RecordStatus" => 1,
            "RailwayID" => $RailwayID,
        );
        $data['zone'] = $this->common_model->find_details("RecordStatus = 1", "tblrailwaymaster", "RailwayName, RailwayCode, RailwayID"); 
        $data['division_div']=  $this->common_model->find_details($data['cond_div'], "tbldivisionmaster", "DivisionName, DivisionCode, DivisionID, RailwayID");
        $data['ip_setting'] = $this->common_model->find_details($cond_settings, "tblserveripdivisionwise", "DivisionID, RailwayID, ServerIP"); 
        if ($this->input->server('REQUEST_METHOD') === 'POST') { 
            if($this->common_model->availableUrl($this->input->post("ServerIP"))!=1){ 
                $ConnectionStatus= 0;
            }else{
                $ConnectionStatus= 1; 
            }
            $data_to_store = array(
                'DivisionID' => $did,
                'RailwayID' => $rid,
                'ConnectionStatus' => $ConnectionStatus,
                 'ServerIP' => $this->input->post('ServerIP'),
                'ModifiedBy' => $this->session->userdata("id_session_list"),
                'ModifiedOn' => date("Y-m-d H:i:s"),
            );
            if (count($data['ip_setting']) > 0) { 
                $settingId = $data['ip_setting'][0]->id;
                $last = $settingId;
                $update_cond = array(
                    "RailwayID" => $rid,
                    "DivisionID" => $did
                );
                if ($this->common_model->update_cond_details($update_cond, $data_to_store, "tblserveripdivisionwise")) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "IP Setting Updated";
                    $data['flash_message'] = TRUE;
                    $data['ip_setting'] = $this->common_model->find_details($cond_settings, "tblserveripdivisionwise", "ID, DivisionID, RailwayID, ServerIP");
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            }
            else { 
                //insert   
                if ($this->common_model->store_details($data_to_store, 
                    "tblserveripdivisionwise")) {
                    $data['flash_message'] = TRUE;
                    $data['color_code'] = "#3a5a9c";
                    $data['display_value'] = "block";
                    $data['message'] = "IP Setting Updated";
                    $data['flash_message'] = TRUE;
                    $data['ip_setting'] = $this->common_model->find_details($cond_settings, "tblserveripdivisionwise", "ID, DivisionID, RailwayID, ServerIP");
                } else {
                    $data['flash_message'] = FALSE;
                    $data['color_code'] = "#c50000";
                    $data['display_value'] = "block";
                    $data['message'] = "Validation Errors";
                }
            } 
        } 
        $this->load->view('Admin/edit-setting-ip', $data);
    }

}
