/* globals hopscotch: false */

/* ============ */
/* EXAMPLE TOUR */
/* ============ */
var tour = {
  id: "hello-hopscotch",	
  showPrevButton: true,
  steps: [
    {
      title: "Create New",
      content: "Upload new EI - Logic files. (only authorized users can upload)",
      target: "tour1",
	  placement: "left",
      
     },
    {
      title: "Select Zone",
      content: "Select a Zone from here",
      target: "RailwayID",
      placement: "right",
      
      
    },
	{
      title: "Select Division (optional)",
      content: "Select Division from here. Do not select any zone if you want to view details from all divisions",
      target: "DivisionID",
      placement: "right",
      
      
    },
	{
      title: "Action",
      content: "Click on on Green button to view more details, Click on Blue button to Edit existing details, Click on Red button to Delete existing details.",
      target: "tour4",
      placement: "left",
      
      
    },
	{
      title: "Synchronization",
      content: "The Green tick icon indicates all the details are synchronized with Main server.",
      target: "tour5",
      placement: "left",
      
      
    },
	{
      title: "Manual Synchronization",
      content: "Unsynchronized data will be synchronized automatically on daily basis. Also, you can manually synchronize it by click this button.",
      target: "tour6",
      placement: "left",
      
      
    }
  ]
},

/* ========== */
/* TOUR SETUP */
/* ========== */
addClickListener = function(el, fn) {
  if (el.addEventListener) {
    el.addEventListener('click', fn, false);
  }
  else {
    el.attachEvent('onclick', fn);
  }
},

startBtnEl = document.getElementById("startTourBtn");

if (startBtnEl) {
  addClickListener(startBtnEl, function() {
    if (!hopscotch.isActive) {
      hopscotch.startTour(tour, 0);
    }
  });
}
else {
  // Assuming we're on page 2.
  if (hopscotch.getState() === "hello-hopscotch:1") {
    // tour id is hello-hopscotch and we're on the second step. sounds right, so start the tour!
    hopscotch.startTour(tour, 0);
  }
}
