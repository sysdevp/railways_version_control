/* globals hopscotch: false */

/* ============ */
/* EXAMPLE TOUR */
/* ============ */
var tour = {
  id: "hello-hopscotch",	
  showPrevButton: true,
  steps: [
    {
      title: "Dashboard",
      content: "View EI - Logic files of all stations",
      target: "index_tour1",
      placement: "bottom",
      
          },
    {
      title: "Pie chart",
      content: "OEM-wise current version count in all stations",
      target: "piechart",
      placement: "left",
      
      
    },
	{
      title: "More Details",
      content: "Click on the “Eye icon” to read more details",
      target: "index_tour3",
      placement: "left",
      
      
    }
  ]
},

/* ========== */
/* TOUR SETUP */
/* ========== */
addClickListener = function(el, fn) {
  if (el.addEventListener) {
    el.addEventListener('click', fn, false);
  }
  else {
    el.attachEvent('onclick', fn);
  }
},

startBtnEl = document.getElementById("startTourBtn");

if (startBtnEl) {
  addClickListener(startBtnEl, function() {
    if (!hopscotch.isActive) {
	  hopscotch.startTour(tour, 0);
    }
  });
}
else {
  // Assuming we're on page 2.
  if (hopscotch.getState() === "hello-hopscotch:1") {
    // tour id is hello-hopscotch and we're on the second step. sounds right, so start the tour!
   
   hopscotch.startTour(tour, 0);
  }
}
