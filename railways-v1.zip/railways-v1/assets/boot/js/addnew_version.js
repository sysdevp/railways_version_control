/* globals hopscotch: false */

/* ============ */
/* EXAMPLE TOUR */
/* ============ */
var tour = {
  id: "hello-hopscotch",	
  showPrevButton: true,
  steps: [
    {
      title: "Zone",
      content: "Only Railway board level user can change the Zone.",
      target: "tour1",
	  placement: "right",
      
     },
    {
      title: "Division",
      content: "Only Railway board and Zone level user can change the Division",
      target: "tour2",
      placement: "right",
      
      
    },
	{
      title: "Station",
      content: "Only Railway board, Zone and Division level user can change the station. If EI - Logic files are already uploaded, then the corresponding station will be displayed in red color.",
      target: "tour3",
      placement: "right",
      
      
    },
	{
      title: "Make of EI",
      content: "Select the OEM (MAke of EI)",
      target: "tour4",
      placement: "bottom",
      
      
    },
	{
      title: "View Conditions",
      content: "The uploaded software files should contains the files as defined here. If the starting name was mentioned as * then there is no restriction on file name.",
      target: "tour5",
      placement: "right",
      
      
    },
	{
      title: "Upload - Software file",
      content: "1. Click on “View Condition” and ensure the file contains the data as mentioned on “View Conditions” <br>2. Compress the Software file as ZIP format (Right click on the file -> Send to -> Compressed (Zipped) folder)",
      target: "tour8",
      placement: "bottom",
      
      
    },
	{
      title: "Certificate file",
      content: "If you do not have the Certificate file, then it can be uploaded later in the edit mode.",
      target: "tour9",
      placement: "bottom",
      
      
    },
	{
      title: "Upload",
      content: "Want to upload any other files? Upload here.",
      target: "tour10",
      placement: "bottom",
      
      
    },
	{
      title: "Additional Info",
      content: "DO you want to add any other additional information? You can add here",
      target: "tour11",
      placement: "bottom",
      
      
    },
	{
      title: "Add more",
      content: "CLick on the “+” icon to add more information",
      target: "tour12",
      placement: "left",
      
      
    },
	{
      title: "Remove",
      content: "CLick on the “-” icon to remove any information",
      target: "tour13",
      placement: "left",
      
      
    },
	{
      title: "Save Details",
      content: "Click here and provide the security password to save the details",
      target: "sub_btn",
      placement: "top",
      
      
    },
	{
      title: "Cancel",
      content: "CLick here to cancel cancel all the text you typed over here? ",
      target: "tour15",
      placement: "top",
      
      
    }
  ]
},

/* ========== */
/* TOUR SETUP */
/* ========== */
addClickListener = function(el, fn) {
  if (el.addEventListener) {
    el.addEventListener('click', fn, false);
  }
  else {
    el.attachEvent('onclick', fn);
  }
},

startBtnEl = document.getElementById("startTourBtn");

if (startBtnEl) {
  addClickListener(startBtnEl, function() {
    if (!hopscotch.isActive) {
      hopscotch.startTour(tour, 0);
    }
  });
}
else {
  // Assuming we're on page 2.
  if (hopscotch.getState() === "hello-hopscotch:1") {
    // tour id is hello-hopscotch and we're on the second step. sounds right, so start the tour!
    hopscotch.startTour(tour, 0);
  }
}
